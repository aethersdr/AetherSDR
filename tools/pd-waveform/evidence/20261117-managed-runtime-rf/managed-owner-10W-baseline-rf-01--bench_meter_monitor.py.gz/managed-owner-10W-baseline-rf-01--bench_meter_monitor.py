"""Host-side bench telemetry observer. No control/RF commands."""
from pathlib import Path
import json,os,select,subprocess,sys,time
class MeterMonitor:
 def __init__(self,directory):
  self.directory=Path(directory);self.latest=None;self.buffer=b'';self.count=0;self.closed=False
  self.log=(self.directory/'lp100a-readings.jsonl').open('w');self.error=(self.directory/'lp100a-stderr.log').open('w')
  self.proc=subprocess.Popen([sys.executable,str(Path(__file__).with_name('lp100a_reader.py')),'--seconds','120'],stdout=subprocess.PIPE,stderr=self.error,start_new_session=True)
  os.set_blocking(self.proc.stdout.fileno(),False)
 def poll(self):
  while select.select([self.proc.stdout],[],[],0)[0]:
   raw=os.read(self.proc.stdout.fileno(),65536)
   if not raw:break
   self.buffer+=raw
   if len(self.buffer)>262144:raise RuntimeError('external meter output exceeds bound')
   while b'\n' in self.buffer:
    line,self.buffer=self.buffer.split(b'\n',1);row=json.loads(line);stamp=row['host_monotonic_ns']
    if type(stamp)!=int or stamp>time.monotonic_ns() or self.latest and stamp<=self.latest['host_monotonic_ns']:raise RuntimeError('external meter clock invalid')
    self.latest=row;self.count+=1;self.log.write(json.dumps(row)+'\n');self.log.flush()
  if self.proc.poll() is not None:raise RuntimeError('external meter reader exited: %s'%self.proc.returncode)
 def require(self,power_limit=12,swr_limit=1.5):
  self.poll()
  if self.latest is None or (time.monotonic_ns()-self.latest['host_monotonic_ns'])/1e9>.5:raise RuntimeError('external meter data missing or older than500ms')
  r=self.latest
  if r['power_w']>power_limit:raise RuntimeError(('LP100A power stop',r['power_w']))
  if r['rf_present'] and r['power_w']>=.2 and r['swr']>=swr_limit:raise RuntimeError(('LP100A SWR stop',r['swr']))
  return dict(r)
 def ready(self):
  end=time.monotonic()+4
  while time.monotonic()<end:
   self.poll()
   if self.latest is not None and self.count>=3:return self.require()
   time.sleep(.02)
  raise RuntimeError('external meter startup timeout')
 def await_zero(self,seconds=6):
  end=time.monotonic()+seconds
  while time.monotonic()<end:
   row=self.require()
   if row['power_w']<.05:return row
   time.sleep(.04)
  raise RuntimeError('external meter did not return to idle after peak hold decay')
 def close(self):
  if self.closed:return
  self.closed=True
  self.proc.terminate()
  try:self.proc.wait(timeout=3)
  except subprocess.TimeoutExpired:self.proc.kill();self.proc.wait(timeout=2)
  self.proc.stdout.close();self.log.close();self.error.close()
if __name__=='__main__':
 import tempfile
 p=Path(sys.argv[1]);p.mkdir(exist_ok=True);m=MeterMonitor(p)
 try:
  r=m.ready();print(json.dumps({'ready':r,'count':m.count}));assert r['power_w']==0
 finally:m.close()
