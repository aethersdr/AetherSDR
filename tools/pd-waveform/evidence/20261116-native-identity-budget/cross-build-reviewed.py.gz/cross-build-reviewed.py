from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess
out=Path(__file__).resolve().parent;root=Path('/home/jeremy/AetherSDR/build/aetherpd-source/tools/flex-tailnet-shim');go=Path('/home/jeremy/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.1.linux-amd64/bin/go')
results=[]
def build(arch):
 target=out/("reviewed-"+arch);target.mkdir(exist_ok=False)
 env=os.environ.copy();env.update(CGO_ENABLED='0',GOOS='linux',GOARCH='arm' if arch=='armv7' else 'arm64',GOTOOLCHAIN='local',GOPROXY='off',GOCACHE=str(out.parent/'runtime-alignment-reset-retention/short'/arch/'go-cache'))
 if arch=='armv7':env['GOARM']='7'
 else:env.pop('GOARM',None)
 binary=target/'flex-tailnet-shim'
 cmd=[str(go),'build','-mod=vendor','-trimpath','-buildvcs=false','-ldflags=-s -w','-o',str(binary),'.']
 with (target/'build.log').open('w') as log:subprocess.run(cmd,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT,check=True)
 data=binary.read_bytes();assert data[:4]==b'\x7fELF'
 return {'arch':arch,'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest(),'ELF_class':data[4],'ELF_machine':int.from_bytes(data[18:20],'little'),'command':cmd,'executed_on_radio':False}
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
 for r in pool.map(build,['armv7','arm64']):results.append(r);print(json.dumps(r),flush=True)
(out/'cross-build-results-reviewed.json').write_text(json.dumps({'toolchain':subprocess.check_output([str(go),'version'],text=True).strip(),'toolchain_sha256':hashlib.sha256(go.read_bytes()).hexdigest(),'builds':results},indent=2)+'\n')
