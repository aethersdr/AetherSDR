from pathlib import Path
import json,os,shutil,subprocess
root=Path('/home/jeremy/AetherSDR/build/aetherpd-source/tools/flex-tailnet-shim');out=Path(__file__).resolve().parent;directory=out/'mutant-config-serialization';directory.mkdir(exist_ok=False)
for p in root.glob('*.go'):shutil.copy2(p,directory/p.name)
for name in ['go.mod','go.sum']:shutil.copy2(root/name,directory/name)
os.symlink(root/'vendor',directory/'vendor',target_is_directory=True)
p=directory/'node.go';s=p.read_text();before='\tif n.RunDir != "" {\n\t\tn.nativeConfigMu.Lock()\n\t\tdefer n.nativeConfigMu.Unlock()\n\t}\n';assert s.count(before)==1;s=s.replace(before,'');p.write_text(s)
env=os.environ.copy();env['GOCACHE']=str(out.parent/'go-cache')
with (out/'config-serialization-mutant.log').open('w') as log:r=subprocess.run(['go','test','-mod=vendor','-race','-timeout=20s','-run','^TestNativeProvisionConcurrentSavesStayAtomic$','-count=1','.'],cwd=directory,env=env,stdout=log,stderr=subprocess.STDOUT)
log=(out/'config-serialization-mutant.log').read_text();assert r.returncode==1 and '--- FAIL: TestNativeProvisionConcurrentSavesStayAtomic' in log and '[build failed]' not in log,log[-2000:]
(out/'config-serialization-mutation-result.json').write_text(json.dumps({'mutation':'remove_native_config_serialization','test':'TestNativeProvisionConcurrentSavesStayAtomic','exit':r.returncode,'rejected':True},indent=2)+'\n');print('configuration serialization mutant rejected')
