from pathlib import Path
import json,os,shutil,subprocess
root=Path('/home/jeremy/AetherSDR/build/aetherpd-source/tools/flex-tailnet-shim');out=Path(__file__).resolve().parent
cases=[('size-limit','native_state.go','if len(data) > nativeStateFileLimit {\n\t\treturn errNativeStateLimit\n\t}', 'if false {\n\t\treturn errNativeStateLimit\n\t}', '^TestNativeStateExactEncodedBoundaryAndAggregate$', 'aggregate size was not bounded'),('cache-before-write','native_state.go','if err = writeNativeStateFile(s.path, encoded); err != nil {','s.cache = next\n\tif err = writeNativeStateFile(s.path, encoded); err != nil {','^TestNativeStateFailedWriteDoesNotPoisonCacheOrRetry$','failed write replaced the in-memory identity'),('load-claim','node.go','n.nativeStateLoadFailed = err != nil','n.nativeStateLoadFailed = false','^TestNativeStateLoadFailureCannotBecomeFirstUse$','failed identity load exposed first-use enrollment')]
results=[]
for name,filename,before,after,pattern,reason in cases:
 directory=out/('mutant-'+name);directory.mkdir(exist_ok=False)
 for p in root.glob('*.go'):shutil.copy2(p,directory/p.name)
 for name2 in ['go.mod','go.sum']:shutil.copy2(root/name2,directory/name2)
 os.symlink(root/'vendor',directory/'vendor',target_is_directory=True)
 p=directory/filename;s=p.read_text();assert s.count(before)==1,(name,s.count(before));p.write_text(s.replace(before,after))
 env=os.environ.copy();env['GOCACHE']='/home/jeremy/AetherSDR/build/aetherpd-shim-integration/go-cache'
 cmd=['go','test','-mod=vendor','-timeout=20s','-run',pattern,'-count=1','.']
 with (out/(name+'-mutant.log')).open('w') as f:r=subprocess.run(cmd,cwd=directory,env=env,stdout=f,stderr=subprocess.STDOUT)
 log=(out/(name+'-mutant.log')).read_text();assert r.returncode==1 and reason in log and '[build failed]' not in log,(name,log[-2000:])
 results.append({'mutation':name,'test_pattern':pattern,'exit':r.returncode,'expected_failure':reason,'rejected':True})
 print(name,'rejected',flush=True)
(out/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
