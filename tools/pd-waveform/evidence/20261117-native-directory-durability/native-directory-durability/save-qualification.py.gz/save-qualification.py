from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import re
import subprocess
import tarfile

P = Path(__file__).resolve().parent
E = P.parent
W = E.parent / 'aetherpd-source'
S = W / 'tools/flex-tailnet-shim'
GO = '/home/jeremy/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.1.linux-amd64/bin/go'

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def read(path):
    return json.loads(path.read_text())

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

assert 'ok  ' in (P / 'full-pinned-race.log').read_text() and 'FAIL' not in (P / 'full-pinned-race.log').read_text()
assert 'native/unpack' in (P / 'pinned-subpackages-race.log').read_text()
assert '[SUCCESS] Generated static files' in (P / 'docs-build.log').read_text()
focused = (P / 'focused-final-pinned.log').read_text()
assert len(re.findall(r'^--- PASS:', focused, re.M)) == 7 and 'FAIL' not in focused
mutations = read(P / 'mutations.json') + read(P / 'additional-mutations.json')
assert len(mutations) == 11 and all(item['exit'] != 0 for item in mutations)
for item in mutations[:9]:
    item['Go_version'] = '1.27.4-X:nodwarf5'
binary_info = read(P / 'binary-build-info.json')
for arch, info in binary_info.items():
    binary = P / ('shim-pinned-' + arch)
    assert digest(binary) == info['sha256'] and ': go1.27.1\n' in info['build_info']

source_names = ['native_state.go', 'native_state_open_linux.go', 'native_state_open_other.go', 'node.go', 'native_state_commit_linux_test.go']
sources = {str((S / name).relative_to(W)): digest(S / name) for name in source_names}
original = P / 'original-source'
original.mkdir(exist_ok=False)
for name in source_names[:-1]:
    (original / name).write_bytes(subprocess.check_output(['git', 'show', 'bfc783751:tools/flex-tailnet-shim/' + name], cwd=W))
(P / 'reviewed.diff').write_bytes(subprocess.check_output(['git', 'diff', '--', 'tools/flex-tailnet-shim', 'docs/user/docs/tailscale-remote-access.md'], cwd=W))
now = datetime.now(timezone.utc).isoformat()
report = {
    'updated_utc': now,
    'status': 'native_identity_parent_directory_sync_and_uncertain_commit_component_qualified_not_installed',
    'production_ready': False, 'installed': False,
    'source_parent_commit': 'bfc7837519267aada255acb6ec3014b7fff11a3b',
    'source_sha256': sources,
    'problem': 'Native identity writes synced the temporary file and renamed it without syncing the containing directory. A returned success did not establish completion of that directory update.',
    'primary_reference': 'https://man7.org/linux/man-pages/man2/fsync.2.html',
    'implementation': [
        'Keep the existing64KiB limit and one fixed temporary sibling per identity file; no new persisted artifact.',
        'Open and pin the actual Linux directory, sync it before mutation, open the temporary relative to that descriptor, sync/close the complete file, rename relative to the same descriptor, then sync it again.',
        'Check that the named parent still selects the pinned directory; descriptor-relative cleanup cannot delete an unrelated replacement parent\'s temporary file.',
        'Errors after successful rename or changed final directory selection return a classified uncertain commit. They do not assert that the previous identity remains selected.',
        'Block live Tailscale state reads after an uncertain commit. Retain the last successful export snapshot. Force a full durable write before a retry can succeed, including equal-value and absent-deletion retries.',
        'For uncertain saved configuration, latch refusal of authenticated control, token-free claiming, boot enrollment and further writes. Cancel pending owned installation/session admission and the DSP/calibration lifetime; preserve the selected file for explicit reload recovery.',
        'An uncertain startup migration returns an error rather than clearing the refusal at load completion. Pre-rename failures retain the original selected identity and its authority.'
    ],
    'verification': {
        'pinned_Go': subprocess.check_output([GO, 'version'], text=True).strip(),
        'main_package_full_race_suite': (P / 'full-pinned-race.log').read_text().strip(),
        'other_module_packages_race_suite': (P / 'pinned-subpackages-race.log').read_text().strip(),
        'focused_test_functions': 7, 'focused_subcases': 12,
        'mutations_rejected': mutations,
        'cross_binaries': binary_info,
        'documentation_npm_ci_and_build': 'passed',
        'earlier_host_toolchain_result': 'Host Go1.27.4-X:nodwarf5 main race suite and ARM builds passed before the final first-use/rotation test expansion. They are preserved separately and are not the pinned compiler proof.'
    },
    'radio_access': False, 'RF_commands': [], 'reboot_commands': [], 'radio_credential_mutations': [],
    'unchanged_installed_runtime': {
        'source_commit': 'e50bfbd3a2b998eac6ae69ac5d790b58c7349c28',
        'release_blake2b_256': 'a8920b11a650ce36118589f818712636bae56f35b3b1570c8a8c8f6d404f0a3f'
    },
    'limitations': [
        'Source inspection establishes the original missing directory sync; no physical power-loss corruption was induced or reproduced. This is not the cause of the unrelated operator-confirmed reboot lockup.',
        'Fault tests inject file/directory sync and rename failures around actual temporary-file operations on the development host. They do not emulate every filesystem, flash-controller failure, abrupt power loss or interrupted installation boundary.',
        'Directory selection checks and descriptor-relative operations protect these file writes. Durability of newly created ancestor directories and the whole install/update transaction remains separate work.',
        'ARMv7 and ARM64 binaries compile with Go1.27.1; no complete authenticated runtime/distribution reproduction, radio installation, service restart, reboot or RF qualification is claimed for this source yet.',
        'Non-Linux helper fallback uses ordinary path-based file operations; its compilation and directory-sync behavior were not tested here, and it does not offer the Linux descriptor-relative guarantee. Native radio runtime qualification targets Linux; other platform tooling remains unqualified.',
        'No real tailnet account, saved radio identity or operator credential was changed. Managed-owner loss/rotation recovery and platform credential stores remain separate required gates.',
        'Actual FLEX6300 Linux2.6/Cortex-A8/one-core execution and directory-sync behavior remain required; cross-compilation does not qualify them.',
        'Full P1-P10 remains active, including unresolved software reboot hang and final keyed/stockAPD gates. The operator-deferred5W SWR/preamble investigation remains deferred.'
    ]
}
destination = W / 'tools/pd-waveform/evidence/20261117-native-directory-durability'
destination.mkdir(exist_ok=False)
paths = [path for path in P.iterdir() if path.is_file() and path.suffix in ['.py', '.log', '.json', '.diff']]
paths += list(original.glob('*.go'))
for item in mutations:
    folder = P / ('mutant-' + item['mutation'])
    paths.append(folder / 'result.log')
    filename = ('node.go' if any(word in item['mutation'] for word in ['authority', 'latch', 'startup', 'first_claim']) else
                'native_state_open_linux.go' if 'reopens_parent_path' in item['mutation'] else 'native_state.go')
    paths.append(folder / filename)
hashes = {}
for path in sorted(set(paths)):
    target = destination / (str(path.relative_to(E)) + '.gz')
    target.parent.mkdir(parents=True, exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(), mtime=0))
    assert gzip.decompress(target.read_bytes()) == path.read_bytes()
    hashes[str(target.relative_to(W))] = digest(target)
report['evidence_sha256'] = hashes
write(W / 'tools/pd-waveform/NATIVE-IDENTITY-DURABILITY-QUALIFICATION.json', report)
archive = E / 'native-directory-durability-components.tar.gz'
assert not archive.exists()
component_paths = [P / ('shim-pinned-' + arch) for arch in ['armv7', 'arm64']] + [P / 'binary-build-info.json'] + [S / name for name in source_names]
with tarfile.open(archive, 'w:gz') as tar:
    for path in component_paths:
        tar.add(path, arcname=(str(path.relative_to(E)) if path.is_relative_to(E) else 'source/' + str(path.relative_to(W))), recursive=False)
with tarfile.open(archive) as tar:
    assert len(tar.getmembers()) == len(component_paths)
    for path in component_paths:
        name = str(path.relative_to(E)) if path.is_relative_to(E) else 'source/' + str(path.relative_to(W))
        assert tar.extractfile(name).read() == path.read_bytes()
write(P / 'component-archive.json', {'archive': str(archive), 'bytes': archive.stat().st_size, 'sha256': digest(archive), 'members': len(component_paths)})
plan_path = E / 'production-completion-plan-20261113.json'
plan = read(plan_path)
plan['updated_utc'] = now
plan['native_identity_durability'] = {'report': 'tools/pd-waveform/NATIVE-IDENTITY-DURABILITY-QUALIFICATION.json',
    'status': report['status'], 'installed': False, 'pinned_main_and_other_packages_race_passed': True,
    'mutations_rejected': 11, 'ARMv7_ARM64_compile_passed': True, 'actual_power_loss_qualified': False}
plan['next_action'] = 'Reproduce complete ARMv7/ARM64 runtime and authenticated ARM64 ordinary-upgrade distribution from the new native identity directory durability source; measure exact disk admission, then qualify an ordinary receive-only update without rotating the saved owner. Preserve installed a892/e50 until that candidate is concretely verified. No software reboot retry until pending operator bench-presence/rear-power recovery coordination is answered. Keep full P1-P10, actual6300 adapter/kernel/storage, final faults/alignment/RF/stockAPD, joined-account/platform and independent release gates. Deferred5W SWR/preamble stays deferred.'
write(plan_path, plan)
target = destination / 'production-completion-plan.json.gz'
target.write_bytes(gzip.compress(plan_path.read_bytes(), mtime=0))
report['evidence_sha256'][str(target.relative_to(W))] = digest(target)
write(W / 'tools/pd-waveform/NATIVE-IDENTITY-DURABILITY-QUALIFICATION.json', report)
print(json.dumps({'evidence_files': len(report['evidence_sha256']), 'mutations_rejected': len(mutations), 'component_archive_bytes': archive.stat().st_size, 'installed': False}))
