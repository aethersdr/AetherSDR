from pathlib import Path
import json
import os
import shutil
import subprocess

P = Path(__file__).resolve().parent
W = P.parents[1] / 'aetherpd-source/tools/flex-tailnet-shim'
GO = '/home/jeremy/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.1.linux-amd64/bin/go'
env = dict(os.environ, GOTOOLCHAIN='local', GOCACHE=str(P.parent / 'go-cache'), GOPROXY='off')
cases = [
    ('first_claim_ignores_uncertain_commit', 'node.go',
     'return !n.nativeStateUnavailable && n.cfg.InstallationID == "" && (!n.provisioned() || n.cfg.PendingSignIn)',
     'return n.cfg.InstallationID == "" && (!n.provisioned() || n.cfg.PendingSignIn)',
     'TestNativeCommitUncertainFirstClaimDoesNotReopenEnrollment'),
    ('missing_pre_mutation_parent_sync', 'native_state.go',
     'if err = ops.sync(parent); err != nil {\n\t\treturn err\n\t}',
     'if false { return errNativeCommitUncertain }', 'TestNativeCommitWriteOrderAndFailureBoundary'),
]
report = []
for label, filename, before, after, test in cases:
    folder = P / ('mutant-' + label)
    folder.mkdir(exist_ok=False)
    for path in W.iterdir():
        if path.is_file() and (path.suffix == '.go' or path.name in ['go.mod', 'go.sum']):
            shutil.copyfile(path, folder / path.name)
    (folder / 'vendor').symlink_to(W / 'vendor', target_is_directory=True)
    text = (folder / filename).read_text()
    assert before in text
    (folder / filename).write_text(text.replace(before, after, 1))
    result = subprocess.run([GO, 'test', '-mod=vendor', '-count=1', '-run', '^' + test + '$', '.'],
                            cwd=folder, env=env, capture_output=True, text=True, timeout=90)
    output = result.stdout + result.stderr
    (folder / 'result.log').write_text(output)
    assert result.returncode != 0 and '--- FAIL:' in output and '[build failed]' not in output, (label, output)
    report.append({'mutation': label, 'rejected_by': test, 'exit': result.returncode, 'Go_version': '1.27.1'})
    print(json.dumps(report[-1]), flush=True)
(P / 'additional-mutations.json').write_text(json.dumps(report, indent=2) + '\n')
