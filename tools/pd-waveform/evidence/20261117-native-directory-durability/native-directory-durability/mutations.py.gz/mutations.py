from pathlib import Path
import json
import os
import shutil
import subprocess

P = Path(__file__).resolve().parent
W = P.parents[1] / 'aetherpd-source/tools/flex-tailnet-shim'
env = dict(os.environ, GOCACHE=str(P.parent / 'go-cache'), GOPROXY='off')
cases = [
    ('missing_parent_sync', 'native_state.go',
     'if err = ops.sync(parent); err != nil {\n\t\treturn fmt.Errorf("%w: %w", errNativeCommitUncertain, err)\n\t}',
     'if false { return errNativeCommitUncertain }', 'TestNativeCommitWriteOrderAndFailureBoundary'),
    ('unclassified_post_rename_failure', 'native_state.go',
     'return fmt.Errorf("%w: %w", errNativeCommitUncertain, err)', 'return err', 'TestNativeCommitUncertainConfigRevokesPDAndAdmission'),
    ('cached_retry_skips_repair', 'native_state.go',
     'if !s.commitUncertain && (data == nil && !present || data != nil && present && bytes.Equal(previous, data)) {',
     'if data == nil && !present || data != nil && present && bytes.Equal(previous, data) {', 'TestNativeCommitUncertainStateCannotSkipRepair'),
    ('uncertain_identity_remains_readable', 'native_state.go',
     'if s.commitUncertain {\n\t\treturn nil, errNativeCommitUncertain\n\t}',
     'if false { return nil, errNativeCommitUncertain }', 'TestNativeCommitUncertainStateCannotSkipRepair'),
    ('keep_authority_after_uncertain_commit', 'node.go',
     'if n.RunDir != "" && errors.Is(err, errNativeCommitUncertain) {',
     'if false && errors.Is(err, errNativeCommitUncertain) {', 'TestNativeCommitUncertainConfigRevokesPDAndAdmission'),
    ('allow_write_after_latch', 'node.go',
     'if n.RunDir != "" && unavailable {', 'if false && unavailable {', 'TestNativeCommitUncertainConfigRevokesPDAndAdmission'),
    ('startup_ignores_uncertain_migration', 'node.go',
     'if errors.Is(err, errNativeCommitUncertain) {\n\t\t\t\treturn err\n\t\t\t}',
     'if false && errors.Is(err, errNativeCommitUncertain) { return err }', 'TestNativeCommitLoadMigrationCannotClearUncertainLatch'),
    ('rename_reopens_parent_path', 'native_state_open_linux.go',
     'return unix.Renameat(int(parent.Fd()), from, int(parent.Fd()), to)',
     'return os.Rename(parent.Name()+"/"+from, parent.Name()+"/"+to)', 'TestNativeCommitPinsDirectoryThroughReplacementAndCleanup'),
    ('cleanup_reopens_parent_path', 'native_state_open_linux.go',
     'return unix.Unlinkat(int(parent.Fd()), name, 0)',
     'return os.Remove(parent.Name()+"/"+name)', 'TestNativeCommitPinsDirectoryThroughReplacementAndCleanup'),
]
reports = []
for label, filename, before, after, test in cases:
    folder = P / ('mutant-' + label)
    folder.mkdir(exist_ok=False)
    for source in W.iterdir():
        if source.is_file() and (source.suffix == '.go' or source.name in ['go.mod', 'go.sum']):
            shutil.copyfile(source, folder / source.name)
    (folder / 'vendor').symlink_to(W / 'vendor', target_is_directory=True)
    source = (folder / filename).read_text()
    assert before in source, label
    (folder / filename).write_text(source.replace(before, after, 1))
    result = subprocess.run(['go', 'test', '-mod=vendor', '-count=1', '-run', '^' + test + '$', '.'],
                            cwd=folder, env=env, capture_output=True, text=True, timeout=90)
    output = result.stdout + result.stderr
    (folder / 'result.log').write_text(output)
    assert result.returncode != 0 and '--- FAIL:' in output and '[build failed]' not in output, (label, result.returncode, output)
    reports.append({'mutation': label, 'rejected_by': test, 'exit': result.returncode})
    print(json.dumps(reports[-1]), flush=True)
(P / 'mutations.json').write_text(json.dumps(reports, indent=2) + '\n')
