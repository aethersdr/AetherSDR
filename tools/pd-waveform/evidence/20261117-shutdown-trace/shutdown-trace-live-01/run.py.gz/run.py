import ast,hashlib,json,os,secrets,select,socket,subprocess,sys,time
from pathlib import Path
P=Path(__file__).resolve().parent;E=P.parent;DEV=E/'shutdown-trace-development'
sys.path.insert(0,str(DEV));from trace_protocol import TraceReader,redact,MAX_TOTAL
sys.path.insert(0,str(E.parent/'aetherpd-source/tools'));from automation_probe import Bridge
assert not (P/'outcome.json').exists(),'Preserve every attempt'
report={'passed':False,'RF_commands':[],'reboot_commands':[],'installation_actions':[]};job=None;peer=None;listener=None;bridge=None;stream=None

def clean(value):
    if isinstance(value,str):return redact(value)
    if isinstance(value,list):return [clean(v) for v in value]
    if isinstance(value,dict):return {redact(k):clean(v) for k,v in value.items()}
    return value

def idle():
    radio=bridge.request({'cmd':'get','model':'radio'},5)['radio']
    assert radio['connected'] and not radio['transmitting'] and not radio['fullDuplex'] and radio['serial']=='2125-1213-8600-8895'
    return radio
try:
    bridge=Bridge('/tmp/aetherpd-prepared-cleanup');who=bridge.request({'cmd':'whoami'},5)
    assert who['pid']==4033867 and who['automationIdentity']=='aetherpd-shim-integration'
    report['desktop_sha256']=hashlib.sha256(Path('/proc',str(who['pid']),'exe').read_bytes()).hexdigest();assert report['desktop_sha256']=='431ef25f7cf3391671b8b0475ab489c75c8c415a0955dcf7ae7b426b316d5821'
    report['radio_before']=idle()
    result=subprocess.run([str(E/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=22);status=json.loads(result.stdout)
    assert status['http_status']==200 and status['body']=={'available':False,'state':'stopped'}
    route=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);route.connect(('192.168.50.100',4992));host=route.getsockname()[0];route.close()
    listener=socket.socket();listener.bind((host,0));listener.listen(1);listener.setblocking(False)
    config={'host':host,'port':listener.getsockname()[1],'nonce':secrets.token_hex(24),'boot_id':'65be86a7-fd98-4f16-ae62-505781cadb85','seconds':12}
    source=(DEV/'trace_protocol.py').read_text()+'\n'+(DEV/'collector_body.py').read_text().replace('CONFIG=None','CONFIG='+repr(config),1);ast.parse(source);(P/'trace-job.py').write_text(source)
    reader=TraceReader(config['nonce'],config['boot_id']);log=(P/'orchestration.log').open('w')
    job=subprocess.Popen([sys.executable,str(P/'run-job.py'),'trace'],stdout=log,stderr=subprocess.STDOUT)
    end=time.monotonic()+140;last_check=0
    while peer is None:
        assert job.poll() is None and time.monotonic()<end,'Observer did not connect; no duplicate job'
        if select.select([listener],[],[],.2)[0]:
            peer,address=listener.accept();assert address[0]=='192.168.50.100';peer.setblocking(False)
        if time.monotonic()-last_check>1:idle();last_check=time.monotonic()
    listener.close();listener=None
    fd=os.open(P/'trace.jsonl',os.O_WRONLY|os.O_CREAT|os.O_EXCL|os.O_NOFOLLOW,0o600);stream=os.fdopen(fd,'w')
    counts={};hello=None;terminal=None;end=time.monotonic()+25
    while True:
        assert time.monotonic()<end,'Collector observation deadline; retain the running job'
        if select.select([peer],[],[],.2)[0]:
            raw=peer.recv(16384)
            if not raw:break
            for event in reader.feed(raw):
                event=clean(event);event['host_received_ns']=time.monotonic_ns();stream.write(json.dumps(event,separators=(',',':'))+'\n');stream.flush();os.fsync(stream.fileno())
                counts[event['kind']]=counts.get(event['kind'],0)+1
                if event['kind']=='hello':hello=event['body']
                if event['kind']=='end':terminal=event['body']
        if time.monotonic()-last_check>.5:idle();last_check=time.monotonic()
    reader.finish();stream.close();stream=None
    assert hello and terminal and terminal['complete'] and terminal['reason']=='deadline' and terminal['journal_events']>0 and terminal['dropped_events']==0 and terminal['oversize_lines']==0
    end=time.monotonic()+45
    while job.poll() is None:idle();assert time.monotonic()<end,'Native orchestrator still live; do not restart';time.sleep(.25)
    assert job.returncode==0;outer=json.loads((P/'trace-result.json').read_text());native=json.loads(outer['logs'])
    assert outer['wait']['StatusCode']==0 and outer['job_container_deleted'] and outer['temporary_host_directory_deleted'] and native['collector_complete']
    assert native['total_export_bytes']==reader.total and reader.total<=MAX_TOTAL
    report.update(native=native,hello=hello,terminal=terminal,event_counts=counts,host_trace_bytes=(P/'trace.jsonl').stat().st_size,host_trace_sha256=hashlib.sha256((P/'trace.jsonl').read_bytes()).hexdigest(),source_sha256=hashlib.sha256(source.encode()).hexdigest(),radio_after=idle(),passed=True)
except Exception as error:report['error_type']=type(error).__name__;report['error']=redact(str(error))
finally:
    if stream:stream.close()
    if peer:peer.close()
    if listener:listener.close()
    if job and job.poll() is None:
        try:job.wait(timeout=55)
        except subprocess.TimeoutExpired:report['job_still_live']=True;report['passed']=False
    if bridge:bridge.close()
    (P/'outcome.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['passed','error_type','error','event_counts','host_trace_bytes','job_still_live'] if k in report}),flush=True)
    if not report['passed']:raise SystemExit(1)
