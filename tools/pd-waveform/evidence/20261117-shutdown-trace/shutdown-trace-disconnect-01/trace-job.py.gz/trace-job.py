"""Bounded transport for an opt-in, read-only bench shutdown observer."""
import json,re,time
MAX_FRAME=32768
MAX_TOTAL=2*1024*1024
MAX_QUEUE=128*1024
KINDS={'hello','journal','heartbeat','snapshot','end','error'}

def redact(text):
    text=re.sub(r'(?i)https?://[^\s\"<>]+','[redacted-url]',text)
    text=re.sub(r'(?i)\bbearer[ \t]+[^\s\",;}]+','Bearer [redacted]',text)
    key=r'\b(?:[a-z0-9]+_)*(?:token|authkey|auth_key|access_key|password|secret|authorization)\b'
    text=re.sub('(?i)('+key+r'[\"\x27]?\s*[=:]\s*)(?:"(?:\\.|[^"\\])*"|\x27[^\x27]*\x27|[^\s,;}]+)',r'\1[redacted]',text)
    return text

class TraceQueue:
    def __init__(self,nonce,boot):
        self.nonce=nonce;self.boot=boot;self.data=bytearray();self.sequence=0;self.total=0;self.dropped=0;self.max_queued=0
    def emit(self,kind,body,terminal=False):
        if kind not in KINDS or not isinstance(body,dict):raise ValueError('invalid event')
        frame={'version':1,'kind':kind,'sequence':self.sequence,'nonce':self.nonce,'boot_id':self.boot,'mono_ns':time.monotonic_ns(),'body':body}
        raw=(json.dumps(frame,separators=(',',':'),ensure_ascii=True)+'\n').encode()
        allowance=MAX_TOTAL if terminal else MAX_TOTAL-4096
        if len(raw)>MAX_FRAME or len(self.data)+len(raw)>MAX_QUEUE or self.total+len(raw)>allowance:
            self.dropped+=1;return False
        self.data.extend(raw);self.total+=len(raw);self.sequence+=1;self.max_queued=max(self.max_queued,len(self.data));return True
    def flush(self,sock):
        if not self.data:return
        try:count=sock.send(self.data)
        except (BlockingIOError,InterruptedError):return
        if count<=0:raise ConnectionError('observer stream closed')
        del self.data[:count]

class TraceReader:
    def __init__(self,nonce,boot):
        self.nonce=nonce;self.boot=boot;self.buffer=bytearray();self.total=0;self.sequence=0;self.ended=False
    def feed(self,data):
        self.total+=len(data)
        if self.total>MAX_TOTAL:raise ValueError('trace byte budget exceeded')
        self.buffer.extend(data);events=[]
        while b'\n' in self.buffer:
            raw,_,remaining=self.buffer.partition(b'\n');self.buffer=bytearray(remaining)
            if len(raw)+1>MAX_FRAME:raise ValueError('trace frame too large')
            try:frame=json.loads(raw)
            except (ValueError,RecursionError):raise ValueError('invalid trace JSON') from None
            if not isinstance(frame,dict) or set(frame)!={'version','kind','sequence','nonce','boot_id','mono_ns','body'}:raise ValueError('invalid trace schema')
            if frame['version']!=1 or type(frame['version']) is not int or type(frame['kind']) is not str or frame['kind'] not in KINDS or frame['nonce']!=self.nonce or frame['boot_id']!=self.boot:raise ValueError('trace identity mismatch')
            if type(frame['sequence']) is not int or frame['sequence']!=self.sequence or type(frame['mono_ns']) is not int or frame['mono_ns']<0 or not isinstance(frame['body'],dict):raise ValueError('invalid trace sequence or body')
            if self.ended or (self.sequence==0 and frame['kind']!='hello'):raise ValueError('invalid trace lifecycle')
            self.sequence+=1;self.ended=frame['kind']=='end'
            frame.pop('nonce');events.append(frame)
        if len(self.buffer)>=MAX_FRAME:raise ValueError('unterminated trace frame too large')
        return events
    def finish(self):
        if self.buffer or not self.ended:raise ValueError('incomplete trace')

import hashlib,os,select,socket,subprocess,signal
from pathlib import Path
CONFIG={'host': '192.168.50.221', 'port': 55797, 'nonce': '6c0bbcef88c45b97361455b80e706b160dd1a282a875f11a', 'boot_id': '65be86a7-fd98-4f16-ae62-505781cadb85', 'seconds': 12}

def unit_snapshot(names):
    args=['/usr/bin/nsenter','--target','1','--cgroup','/usr/bin/systemctl','show','--property=Id,ActiveState,SubState,MainPID,After,Before,Requires,Wants,Conflicts,SendSIGKILL,KillMode,TimeoutStopUSec,DefaultDependencies,ControlGroup',*names]
    result=subprocess.run(args,capture_output=True,text=True,timeout=4)
    return {'exit':result.returncode,'properties':redact(result.stdout[:18000]),'stderr':redact(result.stderr[:1000]),'truncated':len(result.stdout)>18000}

def firmware_identity():
    inodes=set()
    for file in ['/proc/net/tcp','/proc/net/tcp6']:
        for line in Path(file).read_text().splitlines()[1:]:
            fields=line.split()
            if len(fields)>9 and fields[1].endswith(':1380') and fields[3]=='0A':inodes.add(fields[9])
    rows=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():continue
        try:
            found=any(os.readlink(fd) in {'socket:['+inode+']' for inode in inodes} for fd in (p/'fd').iterdir())
            if not found:continue
            cgroups=(p/'cgroup').read_text().splitlines()
            units=[line.rsplit('/',1)[-1] for line in cgroups if line.endswith('.service')]
            rows.append({'pid':int(p.name),'exe':os.readlink(p/'exe'),'comm':(p/'comm').read_text().strip(),'cgroup':cgroups,'units':units})
        except OSError:continue
    return rows

def cleanup_child(child):
    if child is None:return None
    if child.poll() is None:
        try:os.killpg(child.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            child.wait(timeout=2)
    child.stdout.close();return child.returncode

def run_observer():
    report={'RF_commands':[],'changes':[],'collector_complete':False};peer=None;child=None;queue=None;reason='error'
    try:
        assert type(CONFIG['seconds']) is int and 3<=CONFIG['seconds']<=120
        boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert boot==CONFIG['boot_id']
        assert Path('/var/lib/smartsdr/aetherpd/upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('e0b73370e023a026fdd3ad7f1eb7ab3785b1d5324ea3f6c809024d5124e861e0')
        assert hashlib.sha256(Path('/run/aetherpd/bin/pd-radio-launch').read_bytes()).hexdigest()=='262a370c286bb07d1751b01211b0ca76ec75ebd29d2e1230111128ccd554b773'
        firmware=firmware_identity();assert firmware
        units=sorted({u for row in firmware for u in row['units'] if re.fullmatch(r'[A-Za-z0-9_.@\\-]{1,160}\.service',u)})
        instances=set()
        for proc in Path('/proc').iterdir():
            if not proc.name.isdecimal():continue
            try:
                for line in (proc/'cgroup').read_text().splitlines():
                    name=line.rsplit('/',1)[-1]
                    if re.fullmatch(r'aetherpd-start@[0-9]+-[0-9]+-78666\.service',name):instances.add(name)
            except OSError:pass
        assert len(instances)<=2
        names=['aetherpd-boot.service','aetherpd-shim.service','aetherpd-start.socket',*sorted(instances),*units]
        snapshot=unit_snapshot(names);assert snapshot['exit']==0 and not snapshot['truncated']
        peer=socket.create_connection((CONFIG['host'],CONFIG['port']),3);peer.setblocking(False)
        queue=TraceQueue(CONFIG['nonce'],boot)
        assert queue.emit('hello',{'firmware':firmware,'units':snapshot,'source':'read-only journal follow; no reboot or RF controls'})
        args=['/usr/bin/nsenter','--target','1','--cgroup','/usr/bin/journalctl','--boot='+boot.replace('-',''),'--follow','--lines=40','--no-pager','--output=json']
        child=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
        os.set_blocking(child.stdout.fileno(),False)
        report['journal_pid']=child.pid;start=time.monotonic();deadline=start+CONFIG['seconds'];beat=start;buffer=bytearray();discard=False;read_bytes=0;read_lines=0;accepted=0;oversize=0
        reason='deadline'
        while time.monotonic()<deadline:
            queue.flush(peer)
            readable,_,_=select.select([child.stdout,peer],[],[],.1)
            if peer in readable:
                data=peer.recv(1)
                reason='peer_closed' if not data else 'unexpected_input';break
            if child.stdout in readable:
                chunk=os.read(child.stdout.fileno(),16384)
                if not chunk:reason='journal_exit';break
                read_bytes+=len(chunk)
                if read_bytes>4*1024*1024:reason='source_budget';break
                for byte in chunk:
                    if byte==10:
                        read_lines+=1
                        if not discard:
                            try:entry=json.loads(buffer)
                            except (ValueError,RecursionError):entry=None
                            if isinstance(entry,dict):
                                unit=entry.get('_SYSTEMD_UNIT','');identifier=entry.get('SYSLOG_IDENTIFIER','')
                                selected=entry.get('_PID')=='1' or identifier=='kernel' or (isinstance(unit,str) and (unit.startswith('aetherpd-') or unit in units))
                                if selected:
                                    fields={k:redact(str(entry[k]))[:8192 if k=='MESSAGE' else 256] for k in ['_BOOT_ID','_SYSTEMD_UNIT','SYSLOG_IDENTIFIER','_COMM','_PID','PRIORITY','MESSAGE','__MONOTONIC_TIMESTAMP','__REALTIME_TIMESTAMP'] if k in entry and isinstance(entry[k],str)}
                                    if queue.emit('journal',{'fields':fields}):accepted+=1
                        buffer.clear();discard=False
                    elif not discard:
                        if len(buffer)<65536:buffer.append(byte)
                        else:buffer.clear();discard=True;oversize+=1
            now=time.monotonic()
            if now-beat>=1:
                queue.emit('heartbeat',{'elapsed_ns':int((now-start)*1e9),'read_lines':read_lines,'journal_events':accepted,'dropped_events':queue.dropped,'oversize_lines':oversize,'queued_bytes':len(queue.data)})
                beat=now
            if queue.total>=MAX_TOTAL-12000:reason='export_budget';break
        complete=reason=='deadline' and not queue.dropped and not oversize
        report.update(reason=reason,read_bytes=read_bytes,read_lines=read_lines,journal_events=accepted,oversize_lines=oversize,dropped_events=queue.dropped,elapsed_s=time.monotonic()-start)
        report['journal_exit']=cleanup_child(child);child=None
        assert queue.emit('end',{'complete':complete,'reason':reason,'read_lines':read_lines,'journal_events':accepted,'dropped_events':queue.dropped,'oversize_lines':oversize},terminal=True)
        end=time.monotonic()+2
        while queue.data and time.monotonic()<end:
            queue.flush(peer)
            if queue.data:select.select([],[peer],[],.05)
        report['collector_complete']=complete and not queue.data;report['total_export_bytes']=queue.total;report['max_queued_bytes']=queue.max_queued
    except Exception as error:report['error_type']=type(error).__name__;report['reason']=reason
    finally:
        if child is not None:report['journal_exit']=cleanup_child(child)
        if peer is not None:peer.close()
        print(json.dumps(report),flush=True)

import contextlib,io
buffered=io.StringIO()
with contextlib.redirect_stdout(buffered):run_observer()
result=json.loads(buffered.getvalue())
result['journal_pid_gone']=not Path('/proc',str(result['journal_pid'])).exists()
result['previous_journal_pid_gone']=not Path('/proc/2234').exists()
print(json.dumps(result),flush=True)
