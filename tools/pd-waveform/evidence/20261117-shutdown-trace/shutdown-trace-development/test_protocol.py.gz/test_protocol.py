import json,socket,time
from trace_protocol import *
nonce='a'*48;boot='65be86a7-fd98-4f16-ae62-505781cadb85'
for text in ['https://login.example/path?key=sentinel','Authorization: Bearer sentinel','token=sentinel','"auth_key":"sentinel"',"password='sentinel with space'",'SHIM_PROVISION_TOKEN=sentinel','access_token:sentinel']:
    result=redact(text);assert 'sentinel' not in result,(text,result)
assert redact('ordinary message: source=123 state=READY')=='ordinary message: source=123 state=READY'
queue=TraceQueue(nonce,boot);assert queue.emit('hello',{'probe':True});assert queue.emit('journal',{'message':redact('token=sentinel')});assert queue.emit('end',{'complete':True},terminal=True)
reader=TraceReader(nonce,boot);rows=[]
for byte in bytes(queue.data):rows+=reader.feed(bytes([byte]))
reader.finish();assert len(rows)==3 and all('nonce' not in row for row in rows)
raw=bytes(queue.data)
def refused(data,token=nonce):
    try:r=TraceReader(token,boot);r.feed(data);r.finish()
    except ValueError:return True
    return False
assert refused(raw,'b'*48) and refused(raw[:-2]) and refused(b'x'*MAX_FRAME)
frames=raw.splitlines();frame=json.loads(frames[0]);frame['sequence']=True;assert refused(json.dumps(frame).encode()+b'\n')
frame=json.loads(frames[0]);frame['extra']='x';assert refused(json.dumps(frame).encode()+b'\n')
assert refused(frames[0]+b'\n'+frames[0]+b'\n') and refused(raw+frames[-1]+b'\n')
a,b=socket.socketpair();a.setblocking(False);b.setblocking(False);a.setsockopt(socket.SOL_SOCKET,socket.SO_SNDBUF,4096)
q=TraceQueue(nonce,boot);assert q.emit('hello',{})
start=time.monotonic()
for _ in range(10000):q.emit('journal',{'message':'x'*8000});q.flush(a)
assert time.monotonic()-start<3 and len(q.data)<=MAX_QUEUE and q.total<=MAX_TOTAL and q.dropped>0
received=bytearray()
while q.data:
    q.flush(a)
    try:received.extend(b.recv(65536))
    except BlockingIOError:pass
while True:
    try:received.extend(b.recv(65536))
    except BlockingIOError:break
assert q.emit('end',{'drops':q.dropped},terminal=True)
while q.data:q.flush(a)
while True:
    try:received.extend(b.recv(65536))
    except BlockingIOError:break
r=TraceReader(nonce,boot);r.feed(received);r.finish();a.close();b.close()
print(json.dumps({'passed':True,'redaction_formats':7,'fragmentation_sequence_identity_lifecycle_refusals':True,'slow_consumer_drops':q.dropped,'max_queue':q.max_queued,'total_bytes':q.total,'transport':'own private Unix socket pair; no firmware peer, radio or RF'}))
