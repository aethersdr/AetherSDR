"""Bounded transport for an opt-in, read-only bench shutdown observer."""
import json,re,time
MAX_FRAME=32768
MAX_TOTAL=2*1024*1024
MAX_QUEUE=128*1024
KINDS={'hello','journal','heartbeat','snapshot','end','error'}

def redact(text):
    text=re.sub(r'(?i)https?://[^\s\"<>]+','[redacted-url]',text)
    text=re.sub(r'(?i)\bbearer[ \t]+[^\s\",;}]+','Bearer [redacted]',text)
    key=r'\b(?:[a-z0-9]+_)*(?:token|authkey|auth_key|access_key|password|secret|authorization)\b'
    text=re.sub('(?i)('+key+r'[\"\x27]?\s*[=:]\s*)(?:"(?:\\.|[^"\\])*"|\x27[^\x27]*\x27|[^\s,;}]+)',r'\1[redacted]',text)
    return text

class TraceQueue:
    def __init__(self,nonce,boot):
        self.nonce=nonce;self.boot=boot;self.data=bytearray();self.sequence=0;self.total=0;self.dropped=0;self.max_queued=0
    def emit(self,kind,body,terminal=False):
        if kind not in KINDS or not isinstance(body,dict):raise ValueError('invalid event')
        frame={'version':1,'kind':kind,'sequence':self.sequence,'nonce':self.nonce,'boot_id':self.boot,'mono_ns':time.monotonic_ns(),'body':body}
        raw=(json.dumps(frame,separators=(',',':'),ensure_ascii=True)+'\n').encode()
        allowance=MAX_TOTAL if terminal else MAX_TOTAL-4096
        if len(raw)>MAX_FRAME or len(self.data)+len(raw)>MAX_QUEUE or self.total+len(raw)>allowance:
            self.dropped+=1;return False
        self.data.extend(raw);self.total+=len(raw);self.sequence+=1;self.max_queued=max(self.max_queued,len(self.data));return True
    def flush(self,sock):
        if not self.data:return
        try:count=sock.send(self.data)
        except (BlockingIOError,InterruptedError):return
        if count<=0:raise ConnectionError('observer stream closed')
        del self.data[:count]

class TraceReader:
    def __init__(self,nonce,boot):
        self.nonce=nonce;self.boot=boot;self.buffer=bytearray();self.total=0;self.sequence=0;self.ended=False
    def feed(self,data):
        self.total+=len(data)
        if self.total>MAX_TOTAL:raise ValueError('trace byte budget exceeded')
        self.buffer.extend(data);events=[]
        while b'\n' in self.buffer:
            raw,_,remaining=self.buffer.partition(b'\n');self.buffer=bytearray(remaining)
            if len(raw)+1>MAX_FRAME:raise ValueError('trace frame too large')
            try:frame=json.loads(raw)
            except (ValueError,RecursionError):raise ValueError('invalid trace JSON') from None
            if not isinstance(frame,dict) or set(frame)!={'version','kind','sequence','nonce','boot_id','mono_ns','body'}:raise ValueError('invalid trace schema')
            if frame['version']!=1 or type(frame['version']) is not int or type(frame['kind']) is not str or frame['kind'] not in KINDS or frame['nonce']!=self.nonce or frame['boot_id']!=self.boot:raise ValueError('trace identity mismatch')
            if type(frame['sequence']) is not int or frame['sequence']!=self.sequence or type(frame['mono_ns']) is not int or frame['mono_ns']<0 or not isinstance(frame['body'],dict):raise ValueError('invalid trace sequence or body')
            if self.ended or (self.sequence==0 and frame['kind']!='hello'):raise ValueError('invalid trace lifecycle')
            self.sequence+=1;self.ended=frame['kind']=='end'
            frame.pop('nonce');events.append(frame)
        if len(self.buffer)>=MAX_FRAME:raise ValueError('unterminated trace frame too large')
        return events
    def finish(self):
        if self.buffer or not self.ended:raise ValueError('incomplete trace')
