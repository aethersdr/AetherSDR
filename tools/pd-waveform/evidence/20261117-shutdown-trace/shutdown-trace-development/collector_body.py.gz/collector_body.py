import hashlib,os,select,socket,subprocess,signal
from pathlib import Path
CONFIG=None

def unit_snapshot(names):
    args=['/usr/bin/nsenter','--target','1','--cgroup','/usr/bin/systemctl','show','--property=Id,ActiveState,SubState,MainPID,After,Before,Requires,Wants,Conflicts,SendSIGKILL,KillMode,TimeoutStopUSec,DefaultDependencies,ControlGroup',*names]
    result=subprocess.run(args,capture_output=True,text=True,timeout=4)
    return {'exit':result.returncode,'properties':redact(result.stdout[:18000]),'stderr':redact(result.stderr[:1000]),'truncated':len(result.stdout)>18000}

def firmware_identity():
    inodes=set()
    for file in ['/proc/net/tcp','/proc/net/tcp6']:
        for line in Path(file).read_text().splitlines()[1:]:
            fields=line.split()
            if len(fields)>9 and fields[1].endswith(':1380') and fields[3]=='0A':inodes.add(fields[9])
    rows=[]
    for p in Path('/proc').iterdir():
        if not p.name.isdecimal():continue
        try:
            found=any(os.readlink(fd) in {'socket:['+inode+']' for inode in inodes} for fd in (p/'fd').iterdir())
            if not found:continue
            cgroups=(p/'cgroup').read_text().splitlines()
            units=[line.rsplit('/',1)[-1] for line in cgroups if line.endswith('.service')]
            rows.append({'pid':int(p.name),'exe':os.readlink(p/'exe'),'comm':(p/'comm').read_text().strip(),'cgroup':cgroups,'units':units})
        except OSError:continue
    return rows

def cleanup_child(child):
    if child is None:return None
    if child.poll() is None:
        try:os.killpg(child.pid,signal.SIGTERM)
        except ProcessLookupError:pass
        try:child.wait(timeout=2)
        except subprocess.TimeoutExpired:
            try:os.killpg(child.pid,signal.SIGKILL)
            except ProcessLookupError:pass
            child.wait(timeout=2)
    child.stdout.close();return child.returncode

def run_observer():
    report={'RF_commands':[],'changes':[],'collector_complete':False};peer=None;child=None;queue=None;reason='error'
    try:
        assert type(CONFIG['seconds']) is int and 3<=CONFIG['seconds']<=120
        boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert boot==CONFIG['boot_id']
        assert Path('/var/lib/smartsdr/aetherpd/upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('e0b73370e023a026fdd3ad7f1eb7ab3785b1d5324ea3f6c809024d5124e861e0')
        assert hashlib.sha256(Path('/run/aetherpd/bin/pd-radio-launch').read_bytes()).hexdigest()=='262a370c286bb07d1751b01211b0ca76ec75ebd29d2e1230111128ccd554b773'
        firmware=firmware_identity();assert firmware
        units=sorted({u for row in firmware for u in row['units'] if re.fullmatch(r'[A-Za-z0-9_.@\\-]{1,160}\.service',u)})
        instances=set()
        for proc in Path('/proc').iterdir():
            if not proc.name.isdecimal():continue
            try:
                for line in (proc/'cgroup').read_text().splitlines():
                    name=line.rsplit('/',1)[-1]
                    if re.fullmatch(r'aetherpd-start@[0-9]+-[0-9]+-78666\.service',name):instances.add(name)
            except OSError:pass
        assert len(instances)<=2
        names=['aetherpd-boot.service','aetherpd-shim.service','aetherpd-start.socket',*sorted(instances),*units]
        snapshot=unit_snapshot(names);assert snapshot['exit']==0 and not snapshot['truncated']
        peer=socket.create_connection((CONFIG['host'],CONFIG['port']),3);peer.setblocking(False)
        queue=TraceQueue(CONFIG['nonce'],boot)
        assert queue.emit('hello',{'firmware':firmware,'units':snapshot,'source':'read-only journal follow; no reboot or RF controls'})
        args=['/usr/bin/nsenter','--target','1','--cgroup','/usr/bin/journalctl','--boot='+boot.replace('-',''),'--follow','--lines=40','--no-pager','--output=json']
        child=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True)
        os.set_blocking(child.stdout.fileno(),False)
        report['journal_pid']=child.pid;start=time.monotonic();deadline=start+CONFIG['seconds'];beat=start;buffer=bytearray();discard=False;read_bytes=0;read_lines=0;accepted=0;oversize=0
        reason='deadline'
        while time.monotonic()<deadline:
            queue.flush(peer)
            readable,_,_=select.select([child.stdout,peer],[],[],.1)
            if peer in readable:
                data=peer.recv(1)
                reason='peer_closed' if not data else 'unexpected_input';break
            if child.stdout in readable:
                chunk=os.read(child.stdout.fileno(),16384)
                if not chunk:reason='journal_exit';break
                read_bytes+=len(chunk)
                if read_bytes>4*1024*1024:reason='source_budget';break
                for byte in chunk:
                    if byte==10:
                        read_lines+=1
                        if not discard:
                            try:entry=json.loads(buffer)
                            except (ValueError,RecursionError):entry=None
                            if isinstance(entry,dict):
                                unit=entry.get('_SYSTEMD_UNIT','');identifier=entry.get('SYSLOG_IDENTIFIER','')
                                selected=entry.get('_PID')=='1' or identifier=='kernel' or (isinstance(unit,str) and (unit.startswith('aetherpd-') or unit in units))
                                if selected:
                                    fields={k:redact(str(entry[k]))[:8192 if k=='MESSAGE' else 256] for k in ['_BOOT_ID','_SYSTEMD_UNIT','SYSLOG_IDENTIFIER','_COMM','_PID','PRIORITY','MESSAGE','__MONOTONIC_TIMESTAMP','__REALTIME_TIMESTAMP'] if k in entry and isinstance(entry[k],str)}
                                    if queue.emit('journal',{'fields':fields}):accepted+=1
                        buffer.clear();discard=False
                    elif not discard:
                        if len(buffer)<65536:buffer.append(byte)
                        else:buffer.clear();discard=True;oversize+=1
            now=time.monotonic()
            if now-beat>=1:
                queue.emit('heartbeat',{'elapsed_ns':int((now-start)*1e9),'read_lines':read_lines,'journal_events':accepted,'dropped_events':queue.dropped,'oversize_lines':oversize,'queued_bytes':len(queue.data)})
                beat=now
            if queue.total>=MAX_TOTAL-12000:reason='export_budget';break
        complete=reason=='deadline' and not queue.dropped and not oversize
        report.update(reason=reason,read_bytes=read_bytes,read_lines=read_lines,journal_events=accepted,oversize_lines=oversize,dropped_events=queue.dropped,elapsed_s=time.monotonic()-start)
        report['journal_exit']=cleanup_child(child);child=None
        assert queue.emit('end',{'complete':complete,'reason':reason,'read_lines':read_lines,'journal_events':accepted,'dropped_events':queue.dropped,'oversize_lines':oversize},terminal=True)
        end=time.monotonic()+2
        while queue.data and time.monotonic()<end:
            queue.flush(peer)
            if queue.data:select.select([],[peer],[],.05)
        report['collector_complete']=complete and not queue.data;report['total_export_bytes']=queue.total;report['max_queued_bytes']=queue.max_queued
    except Exception as error:report['error_type']=type(error).__name__;report['reason']=reason
    finally:
        if child is not None:report['journal_exit']=cleanup_child(child)
        if peer is not None:peer.close()
        print(json.dumps(report),flush=True)

run_observer()
