from pathlib import Path
import hashlib,json,socket,subprocess,sys,time
P=Path(__file__).resolve().parent;E=P.parent;W=E.parent/'aetherpd-source';sys.path.insert(0,str(W/'tools'));from automation_probe import Bridge
sys.path.insert(0,str(W/'tools/pd-waveform/session'));import kernel_probe_tool as tool
assert not (P/'live-outcome.json').exists();bridge=Bridge('/tmp/aetherpd-boot-tmpfs');attempted=False
report={'passed':False,'RF_commands':[],'reboot_commands':[],'root_used_for_probe_delivery':False};events=[]
def idle():
 r=bridge.request({'cmd':'get','model':'radio'},6)['radio'];assert r['connected'] and not r['transmitting'] and not r['fullDuplex'] and r['serial']=='2125-1213-8600-8895';return r
try:
 who=bridge.request({'cmd':'whoami'},5);assert who['pid']==139216 and who['automationIdentity']=='aetherpd-shim-integration'
 report['radio_before']=idle();report['desktop_sha256']=hashlib.sha256(Path('/proc/139216/exe').read_bytes()).hexdigest();assert report['desktop_sha256']=='481311206d2862bc3e9f8d6a24d09d40556521d60a32da2d12b7dddfbd3b8e03'
 try:
  with socket.create_connection(('192.168.50.100',tool.PORT),1):pass
 except ConnectionRefusedError:report['probe_port_before']='refused'
 else:raise RuntimeError('Existing probe listener; refuse replacing another live instance')
 package=P/'first-source-path/package/AetherPDKernelProbe.ssdr_waveform';digest=hashlib.sha256(package.read_bytes()).hexdigest();tool.package(package,digest)
 report['package_sha256']=digest;report['package_bytes']=package.stat().st_size;attempted=True
 args=[sys.executable,str(W/'tools/pd-waveform/session/kernel_probe_tool.py'),'--host','192.168.50.100','install',str(package),'--sha256',digest]
 result=subprocess.run(args,capture_output=True,text=True,timeout=35);(P/'live-upload.log').write_text(result.stdout+result.stderr);assert result.returncode==0,result.stderr
 start=time.monotonic();deadline=start+90;probe=None
 while time.monotonic()<deadline:
  idle()
  try:probe=tool.status('192.168.50.100');break
  except (ConnectionRefusedError,socket.timeout,TimeoutError,OSError) as error:events.append({'elapsed_s':time.monotonic()-start,'exception':type(error).__name__});time.sleep(.5)
 assert probe is not None,'No probe report; no reboot retry'
 assert probe['uid']==probe['euid']==78666 and probe['gid']==probe['egid']==20
 assert probe['cap_effective']==probe['cap_permitted']==probe['cap_inheritable']=='0000000000000000'
 rows=probe['filesystems'];assert len(rows)==6 and {x['path'] for x in rows}=={'/run','/run/aetherpd','/tmp','/dev/shm','/user','/var/tmp'}
 for x in rows:
  assert type(x['type_errno']) is int and type(x['space_errno']) is int
  if x['type_errno']:assert x['type'] is None and x['tmpfs'] is None
  else:assert type(x['tmpfs']) is bool and x['type'].startswith('0x')
  if x['space_errno']:assert x['available_bytes'] is None and x['available_inodes'] is None and x['block_bytes'] is None
  else:assert type(x['available_bytes']) is int and x['available_bytes']>=0
 assert all(x['tmpfs'] is True for x in rows if x['path'] in ['/run','/run/aetherpd','/tmp','/dev/shm'])
 assert probe['packet_ring_runtime_tested'] is False and probe['setup_privileges_provisioned'] is False and probe['rf_commands']==[]
 report.update(probe=probe,ready_s=time.monotonic()-start,passed=True)
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
 if attempted:
  try:
   args=[sys.executable,str(W/'tools/pd-waveform/session/kernel_probe_tool.py'),'--host','192.168.50.100','uninstall'];result=subprocess.run(args,capture_output=True,text=True,timeout=20);(P/'live-uninstall.log').write_text(result.stdout+result.stderr);assert result.returncode==0,result.stderr
   report['uninstall_acknowledged']=True;deadline=time.monotonic()+25
   while True:
    idle()
    try:
     with socket.create_connection(('192.168.50.100',tool.PORT),.5):pass
    except ConnectionRefusedError:report['probe_port_closed']=True;break
    assert time.monotonic()<deadline,'Probe listener remains after uninstall';time.sleep(.25)
  except Exception as error:report['cleanup_error']=type(error).__name__+': '+str(error);report['passed']=False
 try:report['radio_after']=idle()
 except Exception as error:report['radio_check_error']=str(error);report['passed']=False
 bridge.close();report['wait_events']=events;(P/'live-outcome.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['passed','error','cleanup_error','ready_s','probe_port_closed'] if k in report}),flush=True)
 if not report['passed']:raise SystemExit(1)
