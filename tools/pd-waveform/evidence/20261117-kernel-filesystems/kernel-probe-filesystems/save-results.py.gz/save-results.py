from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import tarfile

P = Path(__file__).resolve().parent
E = P.parent
W = E.parent / 'aetherpd-source'
SOURCE = 'e50bfbd3a2b998eac6ae69ac5d790b58c7349c28'
RELEASE = 'a8920b11a650ce36118589f818712636bae56f35b3b1570c8a8c8f6d404f0a3f'

def read(path):
    return json.loads(path.read_text())

def write(path, value):
    path.write_text(json.dumps(value, indent=2) + '\n')

def digest(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def preserve(label, paths):
    destination = W / 'tools/pd-waveform/evidence' / label
    destination.mkdir(exist_ok=False)
    hashes = {}
    for path in sorted(set(paths)):
        target = destination / (str(path.relative_to(E)) + '.gz')
        target.parent.mkdir(parents=True, exist_ok=True)
        data = path.read_bytes()
        target.write_bytes(gzip.compress(data, mtime=0))
        assert gzip.decompress(target.read_bytes()) == data
        hashes[str(target.relative_to(W))] = digest(target)
    return hashes

installed = E / 'boot-tmpfs-installed'
lifecycle = E / 'boot-tmpfs-lifecycle-01'
installation = read(installed / 'install-result.json')
session = read(lifecycle / 'api-outcome.json')
fault_outer = read(lifecycle / 'api-result.json')
fault = json.loads(fault_outer['logs'])
audit_outer = read(lifecycle / 'audit-result.json')
audit = json.loads(audit_outer['logs'])
probe = read(P / 'live-outcome.json')
reproduction = read(P / 'reproduction.json')
mutants = read(P / 'mutations.json')
assert installation['committed'] and not installation['diagnostics_used_for_delivery']
assert installation['candidate_source'] == SOURCE and installation['rf_commands'] == []
assert session['passed'] and session['RF_commands'] == []
assert fault['stopped_verified'] and fault['primary_restart_verified'] and fault['journal']['dropped'] == 0
assert audit['passed'] and not audit['arp'] and audit['arp_journal_bytes'] == 0
assert all(not value for value in audit['temporary_installation_paths'].values())
assert all(fault_outer[k] and audit_outer[k] for k in ['job_container_deleted', 'temporary_host_directory_deleted'])
assert session['installation_after']['body']['selected_release_blake2b_256'] == RELEASE
assert probe['passed'] and probe['probe_port_closed'] and probe['uninstall_acknowledged']
assert all(value['rejected'] for value in mutants)
assert reproduction['first-source-path']['sha256'] == reproduction['second-longer-source-path']['sha256'] == probe['package_sha256']
now = datetime.now(timezone.utc).isoformat()

report = {
    'updated_utc': now,
    'status': 'ordinary_desktop_update_and_receive_only_whole_service_lifecycle_passed_software_reboot_unqualified',
    'production_ready': False,
    'runtime_source_commit': SOURCE,
    'release_blake2b_256': RELEASE,
    'previous_release_blake2b_256': 'b30bb5074b4c962183662c82026655ad0d94646de333c0ec8119507b5bea5115',
    'package_report': 'tools/pd-waveform/BOOT-TMPFS-RUNTIME-QUALIFICATION.json',
    'desktop_source_commit': '9f75395a4c7a6d48c7705c73dae7f53ff9097337',
    'desktop_sha256': session['desktop_sha256'],
    'ordinary_update': {
        'committed': True, 'elapsed_s': installation['elapsed_s'],
        'operator_plan_reviewed': True, 'diagnostics_used_for_delivery': False,
        'predecessor_credential_used_for_delivery': installation['predecessor_credential_used_for_delivery'],
        'terminal': installation['latest']['pdInstallState']['value'],
        'installation_id': audit['installation_id'],
        'owner_config_sha256': audit['owner_config_sha256'],
        'owner_verifier_fingerprint': session['owner_after']['owner_verifier_fingerprint'],
        'local_only_identity': session['owner_after']['state'] == 'local'
    },
    'receive_only_lifecycle': {
        'FDX': False, 'boot_id': fault['boot_id'],
        'unkeyed_PD_mode_used': True,
        'original_graph_processes_including_zombies': len(fault['before']),
        'all_original_processes_gone_ms': fault['retired_ms'],
        'primary_service_ready_ms': fault['primary_ready_ms'],
        'firmware_PID_before': fault['firmware_before']['MainPID'],
        'firmware_PID_after': fault['firmware_after']['MainPID'],
        'firmware_stop_or_restart_requested': False,
        'explicit_Start_required_for_new_IQ_session': True,
        'ordinary_Start_before_s': session['first_start']['ready_s'],
        'ordinary_Start_after_s': session['restart']['ready_s'],
        'capture_before': session['capture_before'],
        'capture_after_restart': session['capture_after_restart'],
        'final_status': session['final_stop'],
        'journal_dropped': fault['journal']['dropped'],
        'kernel_start_socket_listener_gone_while_stopped': not fault['kernel_start_socket_while_stopped'],
        'owner_config_unchanged': fault['owner_config_before'] == fault['owner_config_after']
    },
    'final_independent_native_audit': audit,
    'RF_commands': [], 'reboot_commands': [], 'credential_mutations': [],
    'limitations': [
        'Receive-only FLEX-8600 service-stop/start proof on the exact installed candidate. Not keyed teardown, firmware stop or whole-system shutdown.',
        'Earlier software reboot caused the operator-confirmed green-LED whole-radio hang requiring rear DC removal. Cause unresolved; that failed test remains failed. No reboot retry here. Bench recovery coordination remains pending.',
        'Local-only saved identity was preserved; this does not qualify joined Tailscale account state, persistent log growth or other desktop credential stores.',
        'Privileged laboratory observer stopped/restarted only the fixed installed service group and audited metadata. Broad diagnostics were not the update delivery mechanism. Its temporary job and scratch were removed.',
        'Actual FLEX-6300 installation adapter, filesystem layout, Linux2.6/Cortex-A8/one-core behavior, storage high-water and RF remain unqualified.',
        'Full original P1-P10 production gates remain. The operator-deferred 5W SWR and preamble investigation stays deferred. No RF result is inferred from unchanged DSP bytes.'
    ]
}
paths = []
for folder in [installed, lifecycle]:
    paths.extend(path for path in folder.iterdir() if path.is_file() and path.suffix in ['.py', '.json', '.log', '.f32le'] and path.name != 'desktop.log')
report['evidence_sha256'] = preserve('20261117-boot-tmpfs-installed', paths)
write(W / 'tools/pd-waveform/BOOT-TMPFS-INSTALLED-QUALIFICATION.json', report)

probe_report = {
    'updated_utc': now,
    'status': 'read_only_filesystem_metadata_probe_reproduced_and_ordinary_waveform_launch_qualified_on_8600',
    'production_ready': False, 'probe_package_version': '0.1.3', 'JSON_schema_version': 1,
    'source_base_commit': '9f75395a4c7a6d48c7705c73dae7f53ff9097337',
    'source_sha256': {str(path.relative_to(W)): digest(path) for path in (W / 'tools/pd-waveform/session').glob('*') if path.is_file() and path.name in ['kernel_probe.c', 'pd_pi_probe.h', 'kernel_probe_package.py', 'kernel_probe_tool.py', 'kernel_probe_test.c', 'test_kernel_probe_tool.py']},
    'package_sha256': probe['package_sha256'], 'package_bytes': probe['package_bytes'],
    'reproduction': reproduction,
    'socket_free_CTest_passed': True, 'socket_free_Python_tests_passed': 6,
    'ASan_UBSan_LSan_passed': True, 'mutations': mutants,
    'ordinary_live_launch': probe,
    'response_limit_bytes': 4096, 'immutable_startup_snapshot': True,
    'RF_commands': [], 'reboot_commands': [], 'privileged_setup_commands': [],
    'limitations': [
        'The report describes six fixed paths as the actual waveform user. Failed queries produce null plus errno; successful zero availability remains numeric zero. No file contents or write test.',
        'FLEX-8600 /run and /run/aetherpd were tmpfs. The supplied6300 probe did not establish /run; actual6300 metadata remains required.',
        'Reproducibility uses two distinct source, output and compiler-cache paths on the same host and pinned Zig toolchain; not an independent builder.',
        'Uninstall acknowledged and TCP48998 closed. Those observations do not establish deletion of every cached firmware upload or extracted file.',
        'No setup authority, packet-ring runtime, sustained real-time priority donation, reboot, RF, persistent storage high-water or AetherPD runtime qualification follows from this read-only probe.',
        'The report is unauthenticated metadata served on the LAN until the diagnostic is removed; it has no request/control verbs.'
    ]
}
paths = [path for path in P.iterdir() if path.is_file() and path.suffix in ['.py', '.json', '.log']]
package = P / 'first-source-path/package/AetherPDKernelProbe.ssdr_waveform'
paths.append(package)
for label in ['first-source-path', 'second-longer-source-path']:
    paths.extend(path for path in (P / label / 'package').iterdir() if path.is_file() and path.suffix == '.json')
probe_report['evidence_sha256'] = preserve('20261117-kernel-filesystems', paths)
write(W / 'tools/pd-waveform/KERNEL-FILESYSTEM-PROBE-QUALIFICATION.json', probe_report)

plan_path = E / 'production-completion-plan-20261113.json'
plan = read(plan_path)
plan['updated_utc'] = now
plan['current_candidate'].update(source_commit=SOURCE, selected_release_blake2b_256=RELEASE,
    installed_receive_only_whole_graph_and_fresh_IQ_qualified=True, RF_qualified_on_this_package=False,
    software_reboot_qualified=False, production_ready=False)
plan['boot_tmpfs_guard'].update(installed=True, installed_report='tools/pd-waveform/BOOT-TMPFS-INSTALLED-QUALIFICATION.json')
plan['boot_tmpfs_guard']['complete_runtime_build']['installed'] = True
plan['boot_tmpfs_guard']['desktop_preparation'].update(status='launched_updated_and_receive_only_lifecycle_passed', installed=True)
plan['kernel_filesystem_probe'] = {'report': 'tools/pd-waveform/KERNEL-FILESYSTEM-PROBE-QUALIFICATION.json', 'package_version': '0.1.3',
    'package_sha256': probe['package_sha256'], 'ordinary_8600_launch_passed': True, 'actual_6300_run_required': True}
plan['next_action'] = 'Preserve installed a892/e50 and receive-only lifecycle evidence. Continue independent P1-P10 production work. Do not repeat software reboot until pending operator bench-presence/rear-power recovery coordination is answered. Actual6300 kernel/filesystem/network and delivery adapter, final keyed fault graph, natural alignment/cold-start, joined-account/platform/store, storage/power-loss, repeated RF and stockAPD, independent review/release remain required. Operator-deferred5W SWR/preamble work stays parked.'
write(plan_path, plan)
target = W / 'tools/pd-waveform/evidence/20261117-boot-tmpfs-installed/production-completion-plan.json.gz'
target.write_bytes(gzip.compress(plan_path.read_bytes(), mtime=0))
report['evidence_sha256'][str(target.relative_to(W))] = digest(target)
write(W / 'tools/pd-waveform/BOOT-TMPFS-INSTALLED-QUALIFICATION.json', report)

kit = E / 'kernel-filesystem-probe-0.1.3-handoff.tar.gz'
assert not kit.exists()
files = [(package, package.name)]
for name in ['kernel_probe_tool.py', 'kernel_probe_package.py', 'README.md']:
    files.append((W / 'tools/pd-waveform/session' / name, name))
files.append((W / 'tools/pd-waveform/KERNEL-FILESYSTEM-PROBE-QUALIFICATION.json', 'qualification.json'))
with tarfile.open(kit, 'w:gz') as tar:
    for source, destination in files:
        tar.add(source, arcname=destination, recursive=False)
with tarfile.open(kit) as tar:
    for source, destination in files:
        assert tar.extractfile(destination).read() == source.read_bytes()
write(P / 'handoff-kit.json', {'archive': str(kit), 'bytes': kit.stat().st_size, 'sha256': digest(kit), 'members': len(files), 'contains_private_secrets': False})
print(json.dumps({'installed_evidence_files': len(report['evidence_sha256']), 'probe_evidence_files': len(probe_report['evidence_sha256']), 'handoff_kit': str(kit)}))
