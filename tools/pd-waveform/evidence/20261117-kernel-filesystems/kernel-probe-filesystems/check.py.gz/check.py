from pathlib import Path
import importlib.util,json,os,resource,subprocess
P=Path(__file__).resolve().parent;W=P.parents[1]/'aetherpd-source';S=W/'tools/pd-waveform/session';report=[]
def no_core():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
args=['cc','-std=gnu11','-O1','-g','-fsanitize=address,undefined','-fno-omit-frame-pointer','-pthread',str(S/'kernel_probe_test.c'),'-o',str(P/'sanitized')]
r=subprocess.run(args,capture_output=True,text=True);(P/'sanitizer-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
r=subprocess.run([str(P/'sanitized')],capture_output=True,text=True,timeout=10,preexec_fn=no_core,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1'));(P/'sanitizer.log').write_text(r.stdout+r.stderr);assert r.returncode==0,(r.returncode,r.stderr)
text=(S/'kernel_probe.c').read_text();cases={'null_type':('if(kind_error){strcpy(type,"null");}','if(0){strcpy(type,"null");}'),'overflow':('if(!space_error && (!space->f_frsize || (uint64_t)space->f_bavail>UINT64_MAX/(uint64_t)space->f_frsize)){space_error=EOVERFLOW;}','if(0){space_error=EOVERFLOW;}')}
for name,(old,new) in cases.items():
 assert old in text;out=P/('mutant-'+name);out.mkdir(exist_ok=False);(out/'kernel_probe.c').write_text(text.replace(old,new,1));(out/'test.c').write_bytes((S/'kernel_probe_test.c').read_bytes())
 r=subprocess.run(['cc','-std=gnu11','-O0','-g','-pthread','-I'+str(S),str(out/'test.c'),'-o',str(out/'test')],capture_output=True,text=True);assert r.returncode==0,r.stderr
 r=subprocess.run([str(out/'test')],capture_output=True,text=True,preexec_fn=no_core,timeout=10);(out/'result.log').write_text(r.stdout+r.stderr);assert r.returncode==-6,(name,r.returncode,r.stdout,r.stderr);report.append({'mutant':name,'rejected':True,'exit':r.returncode})
source=(S/'kernel_probe_tool.py').read_text();old='if len(data) > MAX_REPORT_BYTES:';assert old in source;modpath=P/'unbounded-tool.py';modpath.write_text(source.replace(old,'if False:',1));spec=importlib.util.spec_from_file_location('probe_unbounded',modpath);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
import sys
sys.path.insert(0,str(S));import test_kernel_probe_tool
original=test_kernel_probe_tool.tool;test_kernel_probe_tool.tool=module
import unittest,io
stream=io.StringIO();result=unittest.TextTestRunner(stream=stream).run(test_kernel_probe_tool.ProbeToolTest('test_report_exact_byte_bound'));(P/'tool-bound-mutant.log').write_text(stream.getvalue());assert not result.wasSuccessful() and len(result.failures)==1
report.append({'mutant':'missing_tool_byte_cap','rejected':True})
(P/'mutations.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'ASan_UBSan_LSan_passed':True,'mutations':report}))
