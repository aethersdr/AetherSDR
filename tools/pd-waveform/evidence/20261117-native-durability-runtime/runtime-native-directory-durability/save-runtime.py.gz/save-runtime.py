from pathlib import Path
from datetime import datetime, timezone
import gzip, hashlib, json, tarfile

P=Path(__file__).resolve().parent;E=P.parent;W=E.parent/'aetherpd-source';U=E/'upgrade-native-directory-durability-02';F=E/'upgrade-native-directory-durability'
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
r=read(P/'report.json');u=read(U/'report.json');b=read(P/'budget-report.json');comparison=read(P/'payload-comparison.json')
assert r['source_commit']==u['source_commit']=='aa5a33fc5de78ad5a9d6e5d48ba2e9c697e03bf0'
assert all(x['identical_release'] and x['identical_manifest'] for x in r['architectures'].values()) and u['complete_eight_file_distribution_identical']
assert all(x['changed_expanded_payload_members']==['flex-tailnet-shim'] and x['changed_release_members']==['payload.bundle'] and x['boot_helper_identical'] for x in comparison.values())
files=[]
for arch in ['armv7','arm64']:
 for name in ['candidate.release','public-key','release-digest','manifest.json']:files.append(P/'short'/arch/name)
for name in u['first']['selection']['files']:files.append(U/'short/package'/name)
for name in ['manifest.json','selection.json']:files.append(U/'short'/name)
for name in ['report.json','source-sha256.json','payload-comparison.json','budget-report.json']:files.append(P/name)
for name in ['report.json','build.py']:files.append(U/name)
archive=E/'native-directory-durability-authenticated-artifacts.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for path in files:tar.add(path,arcname=str(path.relative_to(E)),recursive=False)
with tarfile.open(archive) as tar:
 for path in files:assert tar.extractfile(str(path.relative_to(E))).read()==path.read_bytes()
meta={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(files),'source_commit':r['source_commit'],'private_seed_included':False,'installed':False}
write(E/'native-directory-durability-artifact-archive.json',meta)
now=datetime.now(timezone.utc).isoformat()
report={'updated_utc':now,'status':'signed_ARMv7_ARM64_runtime_and_ARM64_upgrade_reproduced_and_disk_admission_component_qualified_not_installed','production_ready':False,'installed':False,
 'source_commit':r['source_commit'],'component_report':'tools/pd-waveform/NATIVE-IDENTITY-DURABILITY-QUALIFICATION.json',
 'two_distinct_source_output_compiler_cache_paths':True,'toolchains':{'Go':r['go'],'zig':r['zig'],'same_host_and_toolchains':True},'architectures':comparison,
 'native_runtime_and_worker_signatures_verified':True,'full_upgrade_distribution_eight_files_identical':True,
 'previous_release_blake2b_256':'a8920b11a650ce36118589f818712636bae56f35b3b1570c8a8c8f6d404f0a3f',
 'native_disk_admission':{'real_authenticated_predecessor_candidate_pair':True,'exact_byte_one_byte_short_exact_inode_one_inode_short_checks_passed':True,
 'ARMv7_max_modeled_peak_bytes':max(x['successor_peak_including_native_reserve_bytes'] for x in b['measurements'] if x['arch']=='armv7'),
 'ARMv7_min_model_headroom_decimal_41_MB':min(x['remaining_from_41_decimal_MB'] for x in b['measurements'] if x['arch']=='armv7')},
 'preserved_failed_distribution_attempt':{'directory':F.name,'failure':'Development version0.0.0-dir-sync.<commit> rejected by existing version grammar before distribution completion; corrected to0.0.0-dirsync.<commit> in a new directory. No upload.'},
 'artifact_archive':meta,'RF_commands':[],'reboot_commands':[],
 'limitations':['Offline complete package reproduction and native synthetic capacity proof only; installed radio remainsa892/e50. Ordinary desktop update/startup/cleanup remain separate gates.',
 'Same-host/pinned-toolchain reproduction is not independent-builder or shipping catalogue qualification. Publisher9a is the existing development key; no new deployed-key rotation is claimed.',
 'Only the Go shim expanded record changed; DSP, all fixed helpers includingpd-boot, service definitions and correction defaults are byte-identical to the installed predecessor.',
 'Disk admission uses real signed inputs but modeled state/metadata allowances and synthetic capacities. It does not measure actual6300 firmware upload copies, storage high-water or first-install adapter overhead.',
 'Actual6300 directory-sync/kernel/network/one-core qualification, delivery adapter, physical power-loss, joined-account/platform and fullP1-P10 remain open.',
 'Unresolved software reboot hang is not repaired or qualified by this package. Bench recovery coordination remains pending; no reboot/RF retry. Deferred5W SWR/preamble work remains deferred.']}
destination=W/'tools/pd-waveform/evidence/20261117-native-durability-runtime';destination.mkdir(exist_ok=False);hashes={};paths=[]
for directory in [P,U,F]:paths.extend(x for x in directory.iterdir() if x.is_file() and x.suffix in ['.json','.py','.c','.log'])
for label in ['short','second-distinct-long-source-path']:
 for arch in ['armv7','arm64']:paths.append(P/label/arch/'manifest.json')
 for name in ['manifest.json','selection.json']:paths.append(U/label/name)
paths += [F/'short/selection.json',E/'native-directory-durability-artifact-archive.json']
for path in sorted(set(paths)):
 target=destination/(str(path.relative_to(E))+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(path.read_bytes(),mtime=0));assert gzip.decompress(target.read_bytes())==path.read_bytes();hashes[str(target.relative_to(W))]=sha(target)
report['evidence_sha256']=hashes
plan_path=E/'production-completion-plan-20261113.json';plan=read(plan_path);plan['updated_utc']=now;entry=plan['native_identity_durability'];entry['runtime_report']='tools/pd-waveform/NATIVE-IDENTITY-DURABILITY-RUNTIME-QUALIFICATION.json';entry['runtime_build'].update(status='complete_exit0_byte_identical_two_paths',installed=False);entry['upgrade_distribution'].update(status='initial_version_label_rejected_retry_complete_exit0_byte_identical',retry_status='complete_exit0',retry_exec_session_id=33495);entry['native_signed_pair_disk_admission_passed']=True
plan['next_action']='Build the matched ordinary desktop using upgrade-native-directory-durability-02/short/selection.json, review exacta892 predecessor andc3d252 successor, then run the authorized ordinary receive-only update and localIQ/cleanup qualification while preserving the existing owner. No software reboot retry without pending operator bench recovery coordination. Preserve fullP1-P10 and all actual6300, keyed/alignment/RF/stockAPD, credential/platform/power-loss and release gates; deferred5W SWR/preamble stays deferred.';write(plan_path,plan)
target=destination/'production-completion-plan.json.gz';target.write_bytes(gzip.compress(plan_path.read_bytes(),mtime=0));hashes[str(target.relative_to(W))]=sha(target)
write(W/'tools/pd-waveform/NATIVE-IDENTITY-DURABILITY-RUNTIME-QUALIFICATION.json',report)
print(json.dumps({'evidence_files':len(hashes),'artifact_bytes':meta['bytes'],'artifact_sha256':meta['sha256'],'ARMv7_peak':report['native_disk_admission']['ARMv7_max_modeled_peak_bytes'],'installed':False}))
