import json,pathlib,sys,time
sys.path.insert(0,'/home/jeremy/AetherSDR/build/aetherpd-source/tools');from automation_probe import Bridge
out=pathlib.Path(__file__).resolve().parent;b=Bridge('/tmp/aetherpd-managed-owner')
def request(q):
 r=b.request(q,8);assert r.get('ok'),r;return r
def panel():
 result={}
 def walk(x):
  if isinstance(x,dict):
   n=x.get('objectName','')
   if n.startswith('pdInstall'):result[n]={k:x[k] for k in ['value','enabled'] if k in x}
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 tree=request({'cmd':'dumpTree','target':'AetherPDDialog'})
 for root in tree.get('roots',[]):
  if root.get('objectName')=='AetherPDDialog' and root.get('visible'):walk(root)
 return result
who=request({'cmd':'whoami'});assert who['pid']==json.loads((out/'instance.json').read_text())['pid']
r=request({'cmd':'get','model':'radio'})['radio']
if not r['connected']:
 request({'cmd':'connect','action':'local','value':'serial 2125-1213-8600-8895'})
 end=time.monotonic()+25
 while not r['connected']:
  assert time.monotonic()<end,'connection observation timeout';time.sleep(.2);r=request({'cmd':'get','model':'radio'})['radio']
request({'cmd':'invoke','target':'Waveforms...','action':'trigger'});time.sleep(.3)
request({'cmd':'invoke','target':'openAetherPD','action':'click'});time.sleep(.3)
assert r['connected'] and not r['transmitting'] and not r['fullDuplex'] and r['serial']=='2125-1213-8600-8895'
request({'cmd':'invoke','target':'pdInstallPrepare','action':'click'});end=time.monotonic()+30
while True:
 p=panel()
 if p['pdInstallApprove']['enabled']:break
 assert time.monotonic()<end,p;time.sleep(.2)
manifest=json.loads((out.parent/'upgrade-managed-owner-policy/short/manifest.json').read_text());text=p['pdInstallPlan']['value']
assert '938fc001e83ac5bfd1a998264c77b4aeff18d1409360c9212771cbbc2c70af93' in text and manifest['release']['blake2b_256'] in text and manifest['selection']['candidate_key'] in text
assert 'Clear obsolete failed AetherPD session records only after verifying they are empty.' in text
(out/'prepared.json').write_text(json.dumps({'whoami':who,'radio':r,'panel':p,'approved':False,'package_source':'7080de965a595ac44982b8f8cfdbc5142ea07dee'},indent=2)+'\n');print(json.dumps(p,indent=2));b.close()
