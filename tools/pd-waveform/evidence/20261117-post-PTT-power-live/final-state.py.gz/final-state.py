import hashlib,json,pathlib,subprocess,sys
P=pathlib.Path(__file__).resolve().parent;B=P.parent
sys.path.insert(0,str(B.parent/'aetherpd-source/tools'));from automation_probe import Bridge
instance=json.loads((P/'instance.json').read_text());bridge=Bridge(instance['socket']);report={'RF_commands':[]}
try:
 report['whoami']=bridge.request({'cmd':'whoami'},5);assert report['whoami']['pid']==instance['pid']
 with pathlib.Path('/proc',str(instance['pid']),'exe').open('rb') as f:report['desktop_sha256']=hashlib.file_digest(f,'sha256').hexdigest()
 assert report['desktop_sha256']==instance['binary_sha256']
 for m in ['radio','transmit','slices','pans']:report[m]=bridge.request({'cmd':'get','model':m},5)
 for path in ['status','aetherpd/installation','aetherpd/status']:
  result=subprocess.run([str(B/'first-iq-live/vault-v3'),path],capture_output=True,text=True,timeout=22);report[path]=json.loads(result.stdout)
 r=report['radio']['radio'];tx=report['transmit']['transmit'];assert r['connected'] and not r['transmitting'] and not r['fullDuplex'] and not tx['tuning'] and not tx['mox'] and not tx['apdEnabled']
 assert tx['rfPower']==1 and tx['maxPowerLevel']==10 and report['aetherpd/status']['body']['state']=='stopped'
 owner=report['status']['body'];assert owner['state']=='local' and owner['provisioned'] and not owner['claimable'] and owner['managed_owner_version']==1 and not owner['tailnet_ip']
 assert report['aetherpd/installation']['body']['selected_release_blake2b_256']=='43d1c23b5ba4c7567d234650aa77e95dc4a096732087654de0b1228ca730d043'
 report['login']=json.loads(subprocess.run([str(B/'managed-remote-access-ui/credential-probe'),'login'],capture_output=True,text=True,timeout=35,check=True).stdout)
 assert report['login']['state']=='local' and not report['login']['auth_url_present'] and report['login']['owner_verifier_fingerprint']=='9d5efda3384e7d4100d905c7dcecbc5fa975f494db0ffd7f4d13d6095c5f925c'
 args=['ssh','-o','BatchMode=yes','-o','ConnectTimeout=6','-o','IdentitiesOnly=yes','-i','/home/jeremy/agent-worktrees/c3957d44/flexipv6-build/keys/probe','-o','UserKnownHostsFile=/tmp/aetherpd-shim-integration-kh-probe','-o','StrictHostKeyChecking=accept-new','-p','22222','root@192.168.50.100','cat /proc/sys/kernel/random/boot_id']
 report['radio_boot_id']=subprocess.run(args,capture_output=True,text=True,timeout=12,check=True).stdout.strip();assert report['radio_boot_id']=='1225abd2-52c4-4716-af98-e789ebb0bff5';report['passed']=True
finally:bridge.close()
(P/'final-state.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':True,'desktop_sha256':report['desktop_sha256'],'owner_unchanged':True,'radio_idle_FDX_off':True,'service_stopped':True,'RF_commands':[]}))
