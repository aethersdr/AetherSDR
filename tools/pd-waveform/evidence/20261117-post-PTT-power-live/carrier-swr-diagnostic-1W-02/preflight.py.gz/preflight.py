import base64,hashlib,json,pathlib,subprocess,sys,time
from bench_audio_route_native import Route
from bench_meter_monitor import MeterMonitor
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent.parent/'aetherpd-source/tools'));from automation_probe import Bridge
b=Bridge('/tmp/aetherpd-post-ptt-power');r={'passed':False,'RF_commands':[]};route=None;meter=None;guard=None

def api(action,identifier=None):
 command=[str(P/'bench-api'),action]+([identifier] if identifier else []);run=subprocess.run(command,capture_output=True,text=True,timeout=16);d=json.loads(run.stdout);assert run.returncode==0 and d['complete'],d;return d['body'] if action!='capture' else d
try:
 assert b.request({'cmd':'whoami'},5)['pid']==3832966
 radio=b.request({'cmd':'get','model':'radio'},5)['radio'];tx=b.request({'cmd':'get','model':'transmit'},5)['transmit'];assert radio['connected'] and not radio['transmitting'] and not radio['fullDuplex'] and tx['rfPower']==1 and tx['maxPowerLevel']==10 and not tx['apdEnabled'] and tx['micSelection']=='PC' and not tx['dax'] and not tx['speechProc'] and not tx['voxEnable']
 native=api('status');assert native['registered'] and not native['keyed'] and not native['correction_enabled'];r['native_before']=native
 meter=MeterMonitor(P);r['LP_idle_before']=meter.ready();assert r['LP_idle_before']['power_w']==0
 route=Route(P/'preflight-route-cleanup.json');r['route']=route.start();route.verify()
 capture=api('capture');raw=base64.b64decode(capture.pop('iq_f32le'),validate=True);assert len(raw)==131072 and hashlib.sha256(raw).hexdigest()==capture['iq_sha256'];r['capture']=capture;(P/'USB-idle-receive.f32le').write_bytes(raw)
 guard=api('guard-begin');r['guard_begin']=guard;assert guard['state']=='observing' and guard['remaining_ms']>7000
 r['guard_stop']=api('guard-stop',guard['test_id']);deadline=time.monotonic()+10
 while True:
  status=api('guard-status',guard['test_id'])
  if status['state']=='ended':break
  assert time.monotonic()<deadline;time.sleep(.1)
 r['guard_ended']=status;r['radio_after']=b.request({'cmd':'get','model':'radio'},5)['radio'];assert not r['radio_after']['transmitting'];r['passed']=True
finally:
 if guard:
  try:api('guard-stop',guard['test_id'])
  except Exception:pass
 if route:r['route_cleanup']=route.close();assert not r['route_cleanup'].get('errors'),r['route_cleanup']
 if meter:meter.close()
 b.close();(P/'preflight-result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({'passed':r['passed'],'guard_receive_only_launch_stop':True,'USB_local_IQ_received':True,'temporary_audio_route_removed':True,'RF_commands':[]}))
