from pathlib import Path
import gzip, hashlib, json
from datetime import datetime, timezone

OUT = Path(__file__).resolve().parent
BASE = OUT.parent
WORK = BASE.parent / 'aetherpd-source'
REBOOT = BASE / 'credential-persistence-reboot'
UPGRADE = BASE / 'upgrade-credential-persistence'
EVIDENCE = WORK / 'tools/pd-waveform/evidence/20261117-credential-persistence-installed'
REPORT = WORK / 'tools/pd-waveform/CREDENTIAL-PERSISTENCE-INSTALLED-QUALIFICATION.json'

def load(path):
    return json.loads(path.read_text())

def audit(path):
    outer = load(path)
    assert outer['wait']['StatusCode'] == 0
    assert outer['job_container_deleted'] and outer['temporary_host_directory_deleted']
    inner = json.loads(outer['logs'])
    assert inner['passed']
    return inner

def capture(path):
    value = load(path / 'usb-receive-iq-check.json')
    assert value['passed'] and value['stopped']['body']['state'] == 'stopped'
    raw = (path / 'usb-receive-iq.f32le').read_bytes()
    assert len(raw) == value['iq_bytes'] == 131072
    assert hashlib.sha256(raw).hexdigest() == value['iq_sha256']
    return {key: value[key] for key in ('iq_bytes', 'iq_sha256', 'rms', 'nonzero_values')} | {
        'transport': value['capture']['feedback_binding']['transport'],
        'channel': value['capture']['feedback_binding']['channel'],
        'GUI_handle': value['capture']['feedback_binding']['gui_handle'],
        'sample_rate_hz': value['capture']['sample_rate_hz'],
        'FDX': value['after']['fullDuplex'],
        'keyed': value['final_status']['body']['keyed'],
        'Stop_state': value['stopped']['body']['state']}

before = audit(OUT / 'final-audit-result.json')
after = audit(REBOOT / 'post-reboot-audit-result.json')
reboot = load(REBOOT / 'reboot-check.json')
assert reboot['passed'] and reboot['reboot_commands_sent'] == 1
assert before['identity_sha256'] == after['identity_sha256']
assert before['runtime_hashes'] == after['runtime_hashes']
assert before['boot_id'] != after['boot_id'] == reboot['boot_id_after']
install = load(OUT / 'install-result.json')
assert install['committed']
upgrade = load(UPGRADE / 'report.json')
assert upgrade['complete_eight_file_distribution_identical']
backup = Path('/home/jeremy/AetherSDR/aetherpd-checkpoints/20261117-runtime-9b402c2d4/credential-persistence-authenticated-artifacts.tar.gz')
report = {
    'updated_utc': datetime.now(timezone.utc).isoformat(),
    'status': 'ordinary_desktop_upgrade_receive_only_DAX_IQ_cleanup_and_software_reboot_qualified_on_8600',
    'runtime_source_commit': '7b7f6a15126f6fecbef55aeed3a746b1aa7b2ecd',
    'release_blake2b_256': '938fc001e83ac5bfd1a998264c77b4aeff18d1409360c9212771cbbc2c70af93',
    'predecessor_release_blake2b_256': 'c732d9afcb0da6b7d1317c7e523c5cbd78800ff8e9a4993097ecd41318bf2614',
    'development_publisher_key': '9a4286d5d3e006c5237a2fa3cf282ec3b9710a4e1b92b18d80f0122177e5a7ce',
    'production_ready': False,
    'component_reports': [
        'tools/pd-waveform/NATIVE-IDENTITY-BUDGET-QUALIFICATION.json',
        'tools/pd-waveform/CREDENTIAL-PERSISTENCE-ORDERING-QUALIFICATION.json',
        'tools/pd-waveform/CREDENTIAL-PERSISTENCE-RUNTIME-QUALIFICATION.json'],
    'desktop': load(OUT / 'instance.json'),
    'ordinary_desktop_upgrade': {
        'confirmed_committed': True, 'elapsed_s': install['elapsed_s'],
        'approved_plan': load(OUT / 'audit-pins.json')['approved_plan'],
        'temporary_carrier': load(OUT / 'audit-pins.json')['carrier'],
        'temporary_components_removed': True,
        'root_diagnostics_used_for_delivery': False,
        'predecessor_credential_used_for_delivery': True,
        'identity_hash_preserved': True,
        'eight_file_distribution_reproduced': True,
        'separate_build_paths_and_caches_same_host': True},
    'before_reboot_receive_IQ': capture(OUT),
    'software_reboot': reboot,
    'after_reboot_receive_IQ': capture(REBOOT),
    'audits': {'before_reboot': before, 'after_reboot': after},
    'authenticated_artifact_backup': {
        'path': str(backup), 'bytes': backup.stat().st_size,
        'sha256': hashlib.sha256(backup.read_bytes()).hexdigest(),
        'allowlisted_files': 38, 'private_signing_seed_in_files': False},
    'RF_commands': [], 'radio_credential_mutations': [],
    'limitations': [
        'One ordinary upgrade, one software reboot and two finite receive-only captures on FLEX8600 firmware4.3.16.42034. No physical power cut or actual FLEX6300 execution.',
        'Identity preservation covers the existing local-only configuration and its exact hash; no tsnet identity exists on this installation. Actual tailnet enrollment, pending-sign-in recovery, token rotation/signout and upstream StateStore write-failure behavior remain unqualified.',
        'Native identity limits and credential race guards are included in the installed shim. Their adversarial cases remain offline component evidence; ordinary receive-only operation does not exercise credential revocation or disk-full cases.',
        'Managed InstallationID continuity, pending ownership and lost provision-response recovery remain open. No live credential mutation was attempted.',
        'Fixed helpers and DSP are unchanged. This result does not substitute for the remaining final-process-graph fault matrix, interrupted updates, whole-volume state/log budgeting or directory durability under abrupt power loss.',
        'Development publisher and compile-time desktop selection only: no shipping catalogue, publisher-key distribution, independent builder or final release review is claimed.',
        'Existing broadly privileged diagnostics bridge was used only for independent read-only audits. Normal desktop installation and IQ Start/Stop do not use it. The broad bridge is excluded from shipped delivery.',
        'No RF, correction, final matched5W/10W, speech, natural128sample cause, native SWR disagreement, full integrated analyzer or stockAPD comparison is qualified by this report. Earlier results and failures retain their original source/release pins.',
        'Reboot and readiness timings are host observations including polling; these are not FPGA-to-process latency measurements.',
        'All P1-P10 requirements remain in the complete external plan; production readiness remains false.']}
paths = {UPGRADE: ['build.py', 'report.json', 'short.log', 'second-distinct-long-source-path.log'],
         OUT: ['build-desktop.py', 'desktop-provenance.json', 'desktop-build-0.log', 'desktop-build-1.log',
               'relaunch.py', 'instance.json', 'prepare.py', 'prepared.json', 'install.py', 'install-result.json',
               'receive-iq-check.py', 'usb-receive-iq-check.json', 'usb-receive-iq.f32le', 'audit-pins.json',
               'run-job.py', 'final-audit-job.py', 'final-audit-result.json', 'save-evidence.py'],
         REBOOT: ['reboot-check.py', 'reboot-intent.json', 'reboot-check.json', 'open-fresh-panel.py',
                  'connected.json', 'instance.json', 'receive-iq-check.py', 'usb-receive-iq-check.json',
                  'usb-receive-iq.f32le', 'run-job.py', 'post-reboot-audit-job.py', 'post-reboot-audit-result.json']}
for label in ('short', 'second-distinct-long-source-path'):
    paths[UPGRADE] += [label + '/selection.json', label + '/manifest.json']
EVIDENCE.mkdir(parents=True, exist_ok=False)
hashes = {}
for directory, names in paths.items():
    for name in names:
        source = directory / name
        assert source.is_file(), source
        destination = EVIDENCE / (directory.name + '--' + name.replace('/', '--') + '.gz')
        destination.write_bytes(gzip.compress(source.read_bytes(), mtime=0))
        hashes[str(destination.relative_to(WORK))] = hashlib.sha256(destination.read_bytes()).hexdigest()
report['evidence_sha256'] = hashes
REPORT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report': str(REPORT), 'evidence_files': len(hashes), 'production_ready': False}))
