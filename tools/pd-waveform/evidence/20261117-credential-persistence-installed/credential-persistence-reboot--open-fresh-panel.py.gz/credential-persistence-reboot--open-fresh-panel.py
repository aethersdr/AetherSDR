import json,pathlib,sys,time
sys.path.insert(0,'/home/jeremy/AetherSDR/build/aetherpd-source/tools')
from automation_probe import Bridge
p=pathlib.Path(__file__).resolve().parent
assert json.loads((p/'reboot-check.json').read_text())['passed']
b=Bridge('/tmp/aetherpd-credential-persistence')
def req(q):
 r=b.request(q,8);assert r.get('ok'),r;return r
assert req({'cmd':'whoami'})['pid']==3443744
radio=req({'cmd':'get','model':'radio'})['radio']
if not radio['connected']:req({'cmd':'connect','action':'local','value':'serial 2125-1213-8600-8895'})
end=time.monotonic()+35
while True:
 radio=req({'cmd':'get','model':'radio'})['radio']
 assert not radio['transmitting'] and not radio['fullDuplex']
 if radio['connected']:
  pans=req({'cmd':'get','model':'pans'})['pans'];slices=req({'cmd':'get','model':'slices'})['slices']
  if len(pans)==1 and pans[0]['ownedByUs'] and len(slices)==1:
   assert pans[0]['rxAntenna']=='RX_A' and pans[0]['rfGain']==0 and abs(pans[0]['centerMhz']-7.15)<1e-6 and slices[0]['mode']=='USB'
   break
 assert time.monotonic()<end,'Receiver readiness deadline';time.sleep(.2)
req({'cmd':'invoke','target':'pdDone','action':'click'});time.sleep(.2)
req({'cmd':'invoke','target':'Waveforms...','action':'trigger'})
req({'cmd':'invoke','target':'openAetherPD','action':'click'})
(p/'connected.json').write_text(json.dumps({'radio':radio,'pans':pans,'slices':slices,'RF_commands':[]},indent=2)+'\n')
print(json.dumps({'connected':True,'pan':pans[0]['panId'],'new_gui_handle':pans[0]['clientHandle']}));b.close()
