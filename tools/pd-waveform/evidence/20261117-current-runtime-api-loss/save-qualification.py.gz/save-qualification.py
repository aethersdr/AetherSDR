from pathlib import Path
import datetime,gzip,hashlib,json
p=Path(__file__).resolve().parent;e=p.parent;w=e.parent/'aetherpd-source';d=w/'tools/pd-waveform/evidence/20261117-current-runtime-api-loss';d.mkdir(exist_ok=False)
a=json.loads((p/'api-outcome.json').read_text());r=json.loads((p/'recovery-outcome.json').read_text());f=a['fault_probe'];outer=json.loads((p/'audit-result.json').read_text());audit=json.loads(outer['logs'])
assert not a['passed'] and r['passed'] and f['probe_complete'] and audit['passed']
for name in ['api-result.json','audit-result.json']:
 out=json.loads((p/name).read_text());assert out['wait']['StatusCode']==0 and out['job_container_deleted'] and out['temporary_host_directory_deleted']
assert f['workers_gone_ms']<2000 and not f['arp_after'] and f['journal_after']['size']==0
assert len(f['original_worker_pid_checks_including_zombies'])==9
assert r['capture_after_restart']['bytes']==131072 and r['final_stop']['body']=={'available':False,'state':'stopped'}
evidence={}
for file in sorted(p.iterdir()):
 if not file.is_file() or file.suffix not in ['.py','.json','.log','.f32le']:continue
 target=d/(file.name+'.gz');target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));evidence[str(target.relative_to(w))]=hashlib.sha256(target.read_bytes()).hexdigest()
report={
 'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'current_installed_8600_receive_only_owned_unkey_API_loss_cleanup_explicit_restart_and_IQ_qualified',
 'production_ready':False,
 'runtime_source_commit':'7080de965a595ac44982b8f8cfdbc5142ea07dee',
 'release_blake2b_256':'43d1c23b5ba4c7567d234650aa77e95dc4a096732087654de0b1228ca730d043',
 'desktop':json.loads((p/'instance.json').read_text()),
 'radio':{'model':'FLEX-8600','firmware':r['radio_after']['version'],'boot_id':f['boot_id'],'FDX':False,'RF_commands':[]},
 'fault':{'command':f['commands'],'target':f['target'],'target_socket':f['target_api_socket'],'admission':'SHA256/UID/capability/NNP/session-cgroup/current-GUI and exact socket pinning plus fresh complete idle interlock before disconnect.','ack_ms':f['ack_ms'],'guard_exit_ms':f['guard_exit_ms'],'all_original_worker_pids_including_zombies_gone_ms':f['workers_gone_ms'],'original_worker_count':9,'ARP_removed':not f['arp_after'],'ARP_journal_bytes':f['journal_after']['size'],'accept_local':f['accept_local'],'post_fault_status':a['status_after_fault']},
 'ordinary_recovery':{'explicit_GUI_Start':True,'ready_s':r['restart']['ready_s'],'capture_before':a['capture_before'],'capture_after_restart':r['capture_after_restart'],'final_stop':r['final_stop'],'privileged_repair':False,'credential_mutations':[],'owner_verifier_fingerprint':r['owner_after']['owner_verifier_fingerprint']},
 'final_independent_audit':audit,
 'preserved_failures':[
  {'attempt':'preparation-01','Start_actions':0,'fault_actions':0,'error':'AetherPD panel was closed; pdStart widget absent. No RF or session fault. Ordinary panel opening fixed the harness preparation.'},
  {'attempt':'api','error':a['error'],'cleanup_error':a.get('cleanup_error'),'meaning':'Native fault and cleanup passed. The orchestration incorrectly required clean stopped before restart. cleanup_unconfirmed is an expected retained terminal warning after an abnormal guardian exit; existing code explicitly permits operator Start from that state. No production fix or relaxed cleanup claim was needed.'}
 ],
 'limitations':[
  'Receive-only regression on this exact installed release; no keyed unkey timing or sustained correction qualification.',
  'Disconnects only the owned unkey API role. It does not qualify every API, credential loss, simultaneous failures or all partial-start stages.',
  'Three capability-free control processes remain after normal Stop; no claim that all installed service processes exit.',
  'Temporary lab host-root observer supplies only fault injection and independent audit; normal startup/recovery and IQ use the installed service. It is not part of the shipping product.',
  'No package installation, reboot, physical power-loss or actual FLEX6300 qualification in this test.',
  'Operator-deferred5W SWR investigation remains unresolved. No related RF test or safety policy change.',
  'All other unqualified P1–P10 production and independent release gates remain open.'
 ],
 'evidence_sha256':evidence,
}
(w/'tools/pd-waveform/CURRENT-RUNTIME-API-LOSS-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
planpath=e/'production-completion-plan-20261113.json';plan=json.loads(planpath.read_text());plan['current_runtime_API_loss']={'report':'tools/pd-waveform/CURRENT-RUNTIME-API-LOSS-QUALIFICATION.json','receive_only_fault_cleanup_and_explicit_restart_passed':True,'all_original_workers_gone_ms':f['workers_gone_ms'],'restart_ready_s':r['restart']['ready_s'],'full_IQ_bytes':131072,'final_state':'stopped','production_ready':False}
plan['current_candidate']['runtime_state']='stopped';plan['current_candidate']['RF_idle']=True
plan['last_goal_turn_classification']='progress: offline waveform regression/dispatch evidence preserved and operator-deferred5W experiment parked; current installed owned-unkey API loss retired9originalworkers in500.617ms; ordinary explicit Start recovered fullIQ in1.945s; independent cleanup/payload/identity audit passed; original harness failures retained.'
plan['next_action']='Continue genuinely unqualified installed partial capture/DSP startup and final failure/restart cases, using prior evidence to avoid repeating completed source-stage, unkey-API-loss and ordinary reboot/IQ tests. Keep operator-deferred5W SWR work parked. Retain full P1–P10 scope, final RF/stockAPD, actual6300, platform/disk/credential and release gates.'
planpath.write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'evidence_files':len(evidence),'report':'CURRENT-RUNTIME-API-LOSS-QUALIFICATION.json','production_ready':False}))
