import shlex, subprocess
from pathlib import Path
root=Path(__file__).resolve().parent
project=root.parent/'first-install-desktop-monitor/project'
for target, sources in {
 'aetherpd_package_download_test':['AetherPDPackage.cpp','AetherPDPackageDownload.cpp','aetherpd_package_download_test.cpp'],
 'aetherpd_installation_coordinator_test':['AetherPDPackage.cpp','AetherPDPackageDownload.cpp','AetherPDInstallationModel.cpp','AetherPDInstallationCoordinator.cpp','aetherpd_installation_coordinator_test.cpp']}.items():
 lines=subprocess.check_output(['ninja','-C',str(project),'-t','commands',target],text=True).splitlines()
 objects={}
 for name in sources:
    args=shlex.split(next(line for line in lines if line.endswith('/'+name)))
    if args[0]=='ccache':args=args[1:]
    old=args[args.index('-o')+1];new=str(root/(target+'-'+name+'.asan.o'));objects[old]=new
    clean=[];i=0
    while i<len(args):
        if args[i] in ['-MF','-MT']:i+=2;continue
        if args[i]=='-MD':i+=1;continue
        clean.append(new if args[i]==old else args[i]);i+=1
    clean += ['-fsanitize=address,undefined','-fno-omit-frame-pointer']
    subprocess.run(clean,cwd=project,check=True)
 link=shlex.split(lines[-1]);assert link[:2]==[':', '&&'] and link[-2:]==['&&', ':']
 link=[objects.get(arg,arg) for arg in link[2:-2] if not arg.startswith('-Wl,--dependency-file=')]
 link[link.index('-o')+1]=str(root/(target+'-asan'))
 where=link.index('libaethercore.a');link[where:where]=[path for path in objects.values() if path not in link]
 link += ['-fsanitize=address,undefined']
 subprocess.run(link,cwd=project,check=True)
