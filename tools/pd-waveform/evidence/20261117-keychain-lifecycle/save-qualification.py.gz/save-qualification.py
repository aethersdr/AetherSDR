from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import platform
import subprocess
import tarfile

P = Path(__file__).resolve().parent
E = P.parent
W = E.parent / 'aetherpd-source'
source = subprocess.check_output(['git', 'rev-parse', 'HEAD'], cwd=W, text=True).strip()
assert source == '239931ebfc212396cb7a28460274dd320b93ec43'
result = json.loads((P/'result.json').read_text())
absence = json.loads((P/'backend-absence.json').read_text())
assert result['success'] and absence['success']
def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()
assert sha(P/'keychain-lifecycle-v1') == result['binary_sha256']
assert sha(P/'build/keychain-lifecycle') == absence['binary_sha256']
evidence = W/'tools/pd-waveform/evidence/20261117-keychain-lifecycle'
evidence.mkdir(exist_ok=False)
files = ['CMakeLists.txt', 'probe-v1.cpp', 'probe.cpp', 'run.py', 'result.json', 'backend-absence.json', 'environment.json', 'save-qualification.py']
hashes = {}
for name in files:
    target = evidence/(name+'.gz')
    target.write_bytes(gzip.compress((P/name).read_bytes(), mtime=0))
    hashes[str(target.relative_to(W))] = sha(target)
archive = E/'keychain-slot-lifecycle-components.tar.gz'
assert not archive.exists()
with tarfile.open(archive, 'w:gz') as tar:
    for name in files + ['keychain-lifecycle-v1', 'build/keychain-lifecycle']:
        tar.add(P/name, arcname='qualification/'+name, recursive=False)
    for name in ['src/core/TailnetShimTokenStore.cpp', 'src/core/TailnetShimTokenStore.h', 'src/core/SettingsCredentialPolicy.h', 'LICENSE']:
        tar.add(W/name, arcname='source/'+name, recursive=False)
members = {}
with tarfile.open(archive) as tar:
    for member in tar:
        assert member.isfile()
        content = tar.extractfile(member).read()
        original = P/member.name.removeprefix('qualification/') if member.name.startswith('qualification/') else W/member.name.removeprefix('source/')
        assert hashlib.sha256(content).hexdigest() == sha(original)
        members[member.name] = hashlib.sha256(content).hexdigest()
report = {
    'updated_utc': datetime.now(timezone.utc).isoformat(), 'source_commit': source,
    'production_ready': False, 'component_qualified': True,
    'scope': 'Current production TailnetShimTokenStore.cpp compiled unchanged with HAVE_KEYCHAIN; standalone native Linux processes and real Secret Service. No simulated backend, radio connection, credential rotation or application UI.',
    'environment': json.loads((P/'environment.json').read_text()),
    'fixture_policy': 'Five unique disposable entries; fixture strings have no radio authority. No real radio credential was read, overwritten or deleted.',
    'slots': ['active owner', 'WSPR on the same fixture radio', 'first-install attempt A', 'first-install attempt B', 'another fixture radio active owner'],
    'results': {
        'operations': len(result['operations']), 'cleanup_operations': len(result['cleanup']),
        'all_passed': result['success'], 'entry_not_found_backend_reads': len(absence['checks']),
        'backend_absence_passed': absence['success'],
        'first_attempt_removal_preserved_other_four_slots': True,
        'caller_destroyed_before_event_loop_write_persisted': True,
        'destroyed_caller_received_no_callback': True,
        'SIGKILL_after_write_persistence_ack_survived_in_fresh_reader': True,
        'repeat_deletion_of_missing_entry_succeeded': True,
        'initial_absence_before_fixture_writes': True,
        'process_count': len(result['operations']) + len(result['cleanup']) + len(absence['checks'])
    },
    'shipping_source_changes': [], 'radio_changes': [], 'RF_commands': [], 'reboot_commands': [],
    'limits': [
        'One host/session/backend. Does not qualify Windows Credential Manager, macOS Keychain, every Linux keyring, or actual radio-side identity persistence.',
        'No simultaneous writers, inter-process stale-cache reconciliation, owner recovery/rotation, keyring lock/outage or real Tailscale enrollment was exercised.',
        'SIGKILL follows a successful library persistence acknowledgment. No pre-ack crash, keyring daemon crash, filesystem/power-loss durability guarantee or machine reboot is claimed.',
        'Slot lifecycle uses the real credential store; it is not proof of the complete installer or UI workflow.',
        'No new default CTest is registered: this probe deliberately accesses the real operator-session keychain and belongs to manual platform qualification.',
        'Full P1-P10 objective, original radio reboot hang, actual6300, natural alignment, final RF and stockAPD comparison and independent release gates remain incomplete.'
    ],
    'artifact_archive': {'path': str(archive), 'bytes': archive.stat().st_size, 'sha256': sha(archive), 'members': len(members), 'all_members_verified': True, 'scope': 'Diagnostic probe/source/receipts only; not a signed AetherPD distribution or byte-reproducibility claim.'},
    'evidence_sha256': hashes
}
(W/'tools/pd-waveform/KEYCHAIN-LIFECYCLE-QUALIFICATION.json').write_text(json.dumps(report, indent=2)+'\n')
plan_path = E/'production-completion-plan-20261113.json'
plan = json.loads(plan_path.read_text())
plan['updated_utc'] = report['updated_utc']
plan['last_goal_turn_classification'] = 'progress: real Linux keychain slot, context-destruction, acknowledged-writer-SIGKILL and backend-absence qualification; Windows pre-compile download failure preserved and existing macOS job verified live.'
plan['desktop_keychain_lifecycle'] = {'report':'tools/pd-waveform/KEYCHAIN-LIFECYCLE-QUALIFICATION.json','Linux_real_backend_component_qualified':True,'Windows_keychain_qualified':False,'macOS_keychain_qualified':False,'concurrent_writers_qualified':False,'production_ready':False}
plan_path.write_text(json.dumps(plan, indent=2)+'\n')
print(json.dumps({'report': 'KEYCHAIN-LIFECYCLE-QUALIFICATION.json', 'processes': report['results']['process_count'], 'artifact':report['artifact_archive']}))
