import datetime
import hashlib
import json
import os
from pathlib import Path
import selectors
import signal
import subprocess
import sys
import uuid

directory = Path(__file__).resolve().parent
binary = directory / 'build/keychain-lifecycle'
receipt = directory / 'result.json'
assert not receipt.exists(), 'Retain the existing attempt; do not overwrite or silently retry.'
namespace = 'aetherpd-keychain-lifecycle-' + str(uuid.uuid4())
slots = {'active': (namespace, 'active'), 'wspr': (namespace, 'wspr'),
         'attemptA': (namespace + '/attempt-A', 'first'),
         'attemptB': (namespace + '/attempt-B', 'first'),
         'otherRadio': (namespace + '-other', 'active')}
data = {'created_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'namespace': namespace, 'source_commit': subprocess.check_output(
            ['git', 'rev-parse', 'HEAD'], cwd='/home/jeremy/AetherSDR/build/aetherpd-source', text=True).strip(),
        'binary_sha256': hashlib.sha256(binary.read_bytes()).hexdigest(),
        'credentials': 'Disposable fixture values only; none has radio authority.',
        'operations': [], 'cleanup': [], 'radio_mutations': [], 'success': False}

def save():
    temporary = receipt.with_suffix('.tmp')
    temporary.write_text(json.dumps(data, indent=2) + '\n')
    temporary.replace(receipt)

def operation(mode, slot, expected='', value='', cleanup=False):
    identifier, entry = slots[slot]
    record = {'mode': mode, 'slot': slot, 'started_utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
    data['cleanup' if cleanup else 'operations'].append(record)
    save()
    command = [str(binary), mode, identifier, entry, expected, value]
    if mode == 'write-hold':
        process = subprocess.Popen(command, text=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        try:
            with selectors.DefaultSelector() as selector:
                selector.register(process.stdout, selectors.EVENT_READ)
                assert selector.select(timeout=12), 'No persistence acknowledgment received.'
                acknowledgement = process.stdout.readline().strip()
            assert acknowledgement == 'persistence_acknowledged', acknowledgement
            os.kill(process.pid, signal.SIGKILL)
            stdout, stderr = process.communicate(timeout=5)
            record.update(exit=process.returncode, acknowledgment=acknowledgement,
                          output=stdout.strip(), error=stderr.strip(), killed_after_persistence_ack=True)
            assert process.returncode == -signal.SIGKILL
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate(timeout=5)
            save()
    else:
        result = subprocess.run(command, text=True, capture_output=True, timeout=15)
        record.update(exit=result.returncode, output=result.stdout.strip(), error=result.stderr.strip())
        save()
        assert result.returncode == 0, record

save()
failure = None
try:
    for slot in slots:
        operation('read', slot)
    for slot in slots:
        operation('write', slot, value='fixture-' + slot + '-one')
    for slot in slots:
        operation('read', slot, expected='fixture-' + slot + '-one')
    operation('delete', 'attemptA')
    operation('read', 'attemptA')
    for slot in ['active', 'wspr', 'attemptB', 'otherRadio']:
        operation('read', slot, expected='fixture-' + slot + '-one')
    operation('write-close', 'active', value='fixture-active-context-closed')
    operation('read', 'active', expected='fixture-active-context-closed')
    operation('write-hold', 'attemptB', value='fixture-attemptB-writer-killed')
    operation('read', 'attemptB', expected='fixture-attemptB-writer-killed')
    operation('read', 'active', expected='fixture-active-context-closed')
    operation('read', 'wspr', expected='fixture-wspr-one')
    data['checks_passed'] = True
except Exception as error:
    failure = repr(error)
    data['failure'] = failure
finally:
    for slot in slots:
        for mode in ['delete', 'read', 'delete', 'read']:
            try:
                operation(mode, slot, cleanup=True)
            except Exception as error:
                data.setdefault('cleanup_errors', []).append({'slot': slot, 'mode': mode, 'error': repr(error)})
    data['success'] = data.get('checks_passed', False) and not data.get('cleanup_errors')
    save()
print(json.dumps({'success': data['success'], 'operations': len(data['operations']),
                  'cleanup': len(data['cleanup']), 'failure': failure,
                  'cleanup_errors': data.get('cleanup_errors', [])}))
sys.exit(0 if data['success'] else 1)
