from pathlib import Path
import concurrent.futures,hashlib,json,sys
O=Path(__file__).resolve().parent;W=O.parents[1]/'aetherpd-source';sys.path.insert(0,str(W/'tools/pd-waveform/boot'));import build
key=bytes.fromhex('9a4286d5d3e006c5237a2fa3cf282ec3b9710a4e1b92b18d80f0122177e5a7ce')
def one(arch):
 r={}
 for entry in ['pd_boot.c','pd_update.c']:
  f=build.build(O/('cross-'+arch),arch,entry,key);r[entry]={'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()}
 return arch,r
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:r=dict(pool.map(one,['arm64','armv7']))
(O/'cross-build.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r),flush=True)
