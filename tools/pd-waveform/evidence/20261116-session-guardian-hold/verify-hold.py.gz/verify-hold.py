from pathlib import Path
import importlib.util,json,subprocess,sys
O=Path(__file__).resolve().parent
W=O.parents[1]/'aetherpd-source'
S=W/'tools/pd-waveform/boot'
sys.path.insert(0,str(S))
import build
report={}
real_run=subprocess.run

def build_service(name,source=None,sanitize=False):
 out=O/name
 def wrapped(args,*a,**kw):
  if source is not None and str(S/'pd_service.c') in args:
   args=[str(source) if str(x)==str(S/'pd_service.c') else x for x in args]
  return real_run(args,*a,**kw)
 build.subprocess.run=wrapped
 try:return build.build(out,'host','service_check.c',sanitize=sanitize)
 finally:build.subprocess.run=real_run

def run(name,args,expected=0):
 p=real_run(args,capture_output=True,text=True)
 (O/(name+'.log')).write_text(p.stdout+p.stderr)
 report[name]={'exit':p.returncode,'expected':expected,'tail':(p.stdout+p.stderr)[-1800:]}
 print(name,p.returncode,flush=True)
 assert (p.returncode==0)==(expected==0),report[name]

checker=build_service('host')
run('service-tests-current',[sys.executable,str(S/'test_service.py'),'--checker',str(checker)])
original=(S/'pd_service.c').read_text()
for name,old,new,method in [
 ('mutant-applied-policy','state.guardian_hold==(layout>>1)','1','test_applied_session_hold_is_required_for_startup'),
 ('mutant-legacy-stop','if(!sessions->states[i].quiet || sessions->states[i].populated){return 0;}','if(0){return 0;}','test_legacy_stop_policy_is_quiesce_only'),
 ('mutant-legacy-kernel','return service_processes_quiet(1);','return 1;','test_legacy_hidden_kernel_session_refuses_before_stop')]:
 assert old in original
 path=O/(name+'.c');path.write_text(original.replace(old,new))
 exe=build_service(name,path)
 run(name,[sys.executable,str(S/'test_service.py'),'--checker',str(exe),'ServiceTest.'+method],1)
report_path=O/'hold-verification.json'
report_path.write_text(json.dumps(report,indent=2)+'\n')
exe=build_service('sanitized-service',sanitize=True)
run('service-sanitized',[sys.executable,str(S/'test_service.py'),'--checker',str(exe)])
report_path.write_text(json.dumps(report,indent=2)+'\n')
