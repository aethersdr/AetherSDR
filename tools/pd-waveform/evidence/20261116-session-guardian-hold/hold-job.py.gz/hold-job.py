import hashlib,json,os,pathlib,signal,subprocess,time
P=pathlib.Path;root=P('/run/aetherpd-hold-policy-probe');unit='aetherpd-hold-policy-probe.service';report={'passed':False,'RF_commands':[],'fixture_only':True,'shipping_units_changed':False};started=False;target=None;parentfd=None
subject=r'''import json,os,signal,socket,subprocess,time
from pathlib import Path
root=Path('/run/aetherpd-hold-policy-probe');assert os.getuid()==os.geteuid()==65534
api=socket.create_connection(('127.0.0.1',4992),2);r,w=os.pipe();release=False;terminations=0
def handle(number,frame):
 global release,terminations
 if number==signal.SIGUSR1:release=True
 if number==signal.SIGTERM:terminations+=1
signal.signal(signal.SIGTERM,handle);signal.signal(signal.SIGUSR1,handle)
args=['/run/aetherpd/bin/pd-lease-guard',str(api.fileno()),str(r),'7','USB','0x00000002','0x40000000']
child=subprocess.Popen(args,pass_fds=(api.fileno(),r),stdout=subprocess.PIPE,stderr=subprocess.DEVNULL);os.close(r);api.close()
record={'parent':os.getpid(),'guardian':child.pid,'registered_DSP':False,'target_slice':7,'args':args};(root/'out/ready.json').write_text(json.dumps(record));deadline=time.monotonic()+15
while not release and time.monotonic()<deadline:
 assert child.poll() is None;time.sleep(.05)
os.close(w)
try:
 data,_=child.communicate(timeout=5);record.update(exit=child.returncode,events=data.decode(),parent_SIGTERM_count=terminations,voluntary_release=True)
except subprocess.TimeoutExpired:
 # The fixture API never registered a waveform and slice7 cannot exist on
 # this four-slice radio. No production API lease is held by this process.
 child.kill();data,_=child.communicate();record.update(exit=child.returncode,events=data.decode(),voluntary_release=False)
(root/'out/result.json').write_text(json.dumps(record))
'''
def run(args,timeout=8):
 p=subprocess.run(args,capture_output=True,text=True,timeout=timeout);assert p.returncode==0,(args,p.returncode,p.stderr);return p.stdout
def alive(row):
 try:
  fields=(P('/proc')/str(row['pid'])/'stat').read_text().rsplit(')',1)[1].split();return int(fields[19])==row['start_ticks'] and fields[0]!='Z'
 except (FileNotFoundError,ProcessLookupError):return False
def fields(pid):
 p=P('/proc')/str(pid);f={l.split(':',1)[0]:l.split(':',1)[1].strip() for l in (p/'status').read_text().splitlines() if ':' in l}
 return {'pid':pid,'start_ticks':int((p/'stat').read_text().rsplit(')',1)[1].split()[19]),'uid':f['Uid'],'caps':{k:f[k] for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']},'NNP':f['NoNewPrivs'],'cgroup':(p/'cgroup').read_text(),'sha256':hashlib.sha256((p/'exe').read_bytes()).hexdigest()}
try:
 assert any(l.split(':')[0]=='nobody' and l.split(':')[2:4]==['65534','65534'] for l in P('/etc/passwd').read_text().splitlines());report['fixture_identity']='nobody UID65534, not the installed waveform user';
 assert not root.exists();expected='297183f7504ffd6c9c6d9f4713976a2bcbfc1df5d9caa788c402fd8568c0954e';assert hashlib.sha256(P('/run/aetherpd/bin/pd-lease-guard').read_bytes()).hexdigest()==expected
 existing=subprocess.run(['/usr/bin/systemctl','show',unit,'-p','LoadState'],capture_output=True,text=True,timeout=5);assert existing.stdout.strip()=='LoadState=not-found'
 root.mkdir(mode=0o755);root.chmod(0o755);(root/'out').mkdir(mode=0o700);os.chown(root/'out',65534,65534);(root/'subject.py').write_text(subject);(root/'subject.py').chmod(0o444)
 cmd=['/usr/bin/systemd-run','--unit='+unit,'--property=User=nobody','--property=Group=65534','--property=NoNewPrivileges=yes','--property=CapabilityBoundingSet=','--property=KillMode=control-group','--property=TimeoutStopSec=1s','--property=SendSIGKILL=no','--property=Restart=no','--','/usr/bin/python3',str(root/'subject.py')]
 report['previous_attempt_journal']=run(['/usr/bin/journalctl','-u',unit,'-n','12','--no-pager','-o','cat']);report['start_command']=cmd;run(cmd);started=True;deadline=time.monotonic()+5
 while not (root/'out/ready.json').exists():assert time.monotonic()<deadline;time.sleep(.05)
 ready=json.loads((root/'out/ready.json').read_text());target=fields(ready['guardian']);report['guardian']=target
 assert target['uid'].split()==['65534']*4 and target['NNP']=='1' and not any(int(v,16) for v in target['caps'].values()) and unit in target['cgroup'] and target['sha256']==expected
 props=run(['/usr/bin/systemctl','show',unit,'-p','SendSIGKILL','-p','KillMode','-p','TimeoutStopUSec','-p','User','-p','Group','-p','NoNewPrivileges','-p','MainPID']);report['applied_before_stop']=props
 assert 'SendSIGKILL=no\n' in props and 'KillMode=control-group\n' in props and 'TimeoutStopUSec=1s\n' in props and 'MainPID='+str(ready['parent'])+'\n' in props
 parent=fields(ready['parent']);assert parent['uid'].split()==['65534']*4 and unit in parent['cgroup'];parentfd=os.pidfd_open(ready['parent']);assert alive(parent);report['parent']=parent
 stamp=time.monotonic_ns();run(['/usr/bin/systemctl','stop','--no-block',unit]);time.sleep(2.5);assert alive(target),'Guardian killed despite applied hold';report['guardian_alive_after_stop_ms']=(time.monotonic_ns()-stamp)/1e6
 report['applied_after_timeout']=run(['/usr/bin/systemctl','show',unit,'-p','SendSIGKILL','-p','KillMode','-p','ActiveState','-p','Result'])
 signal.pidfd_send_signal(parentfd,signal.SIGUSR1);report['lifetime_release_signal']={'pid':parent['pid'],'start_ticks':parent['start_ticks'],'signal':'SIGUSR1'};deadline=time.monotonic()+7
 while not (root/'out/result.json').exists():assert time.monotonic()<deadline;time.sleep(.05)
 result=json.loads((root/'out/result.json').read_text());report['subject']=result;assert result['voluntary_release'] and result['exit']==0 and 'already_safe' in result['events'];assert not alive(target)
 report['journal']=run(['/usr/bin/journalctl','-u',unit,'-n','40','--no-pager','-o','cat']);assert 'with signal SIGKILL' not in report['journal'];report['passed']=True
except Exception as e:report['error']=type(e).__name__+': '+str(e)
finally:
 if started:
  if parentfd is not None:
   try:signal.pidfd_send_signal(parentfd,signal.SIGUSR1)
   except ProcessLookupError:pass
  end=time.monotonic()+8
  while target and alive(target) and time.monotonic()<end:time.sleep(.1)
  if target and alive(target):
   report['fixture_forced_cleanup']=True;report['passed']=False;subprocess.run(['/usr/bin/systemctl','kill','--kill-who=all','--signal=SIGKILL',unit],capture_output=True,timeout=5)
  subprocess.run(['/usr/bin/systemctl','reset-failed',unit],capture_output=True,timeout=5)
  report['final_unit_state']=subprocess.run(['/usr/bin/systemctl','show',unit,'-p','LoadState','-p','MainPID','-p','ControlGroup'],capture_output=True,text=True,timeout=5).stdout
  report['fixture_processes_gone']=not target or not alive(target);report['passed']=report['passed'] and report['fixture_processes_gone']
 if parentfd is not None:os.close(parentfd)
 if root.exists():
  import shutil;shutil.rmtree(root);report['temporary_fixture_directory_removed']=not root.exists()
 print(json.dumps(report),flush=True)
