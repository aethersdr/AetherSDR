from pathlib import Path
import json,os,subprocess
O=Path(__file__).resolve().parent;W=O.parents[1]/'aetherpd-source';G=W/'tools/flex-tailnet-shim';S=W/'tools/pd-waveform/session'
report={}
def run(name,args,success=True,env=None):
 p=subprocess.run(args,cwd=G,capture_output=True,text=True,env=env)
 (O/(name+'.log')).write_text(p.stdout+p.stderr)
 report[name]={'exit':p.returncode,'expected_success':success,'tail':(p.stdout+p.stderr)[-1800:]}
 print(name,p.returncode,flush=True)
 assert (p.returncode==0)==success,report[name]
base=['cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-I',str(S),'-I',str(S.parent/'boot')]
run('start-session-build-current',base+[str(S/'start_session_test.c'),'-o',str(O/'start-session-current')])
run('start-session-current',[str(O/'start-session-current')])
source=(S/'pd_start_session.c').read_text();old='if(!pd_service_session_policy()){return 6;}'
assert old in source
(O/'mutant-start-session.c').write_text(source.replace(old,'if(0){return 6;}'))
test=(S/'start_session_test.c').read_text().replace('#include "pd_start_session.c"','#include "'+str(O/'mutant-start-session.c')+'"')
(O/'mutant-start-session-test.c').write_text(test)
run('mutant-start-session-build',base+[str(O/'mutant-start-session-test.c'),'-o',str(O/'mutant-start-session')])
run('mutant-start-session',[str(O/'mutant-start-session')],False)
env=dict(os.environ,GOTOOLCHAIN='local',GOPROXY='off',GOCACHE=str(O.parent/'go-cache'))
go='/home/jeremy/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.1.linux-amd64/bin/go'
source=(G/'aetherpd_install_request.go').read_text()
for name,old,new in [('mutant-install-confirmation','!n.pdSessionCleanupConfirmed || ',''),('mutant-install-channel-close','n.pdSession.Close()','// lifetime channel intentionally retained')]:
 assert old in source
 path=O/(name+'.go');path.write_text(source.replace(old,new))
 overlay=O/(name+'-overlay.json');overlay.write_text(json.dumps({'Replace':{str(G/'aetherpd_install_request.go'):str(path)}}))
 run(name,[go,'test','-mod=vendor','-overlay',str(overlay),'-count=1','-run','TestPDInstallRequestRequiresObservedCleanup','.'],False,env)
(O/'handoff-mutations.json').write_text(json.dumps(report,indent=2)+'\n')
