from pathlib import Path
import subprocess,sys,json
O=Path(__file__).resolve().parent;S=O.parents[1]/'aetherpd-source/tools/pd-waveform/boot';sys.path.insert(0,str(S));import build
original=(S/'pd_service.c').read_text();assert 'current==1' in original
mutant=O/'mutant-own-session.c';mutant.write_text(original.replace('current==1','current!=999999'))
real=subprocess.run
def wrapped(args,*a,**kw):
 return real([str(mutant) if str(x)==str(S/'pd_service.c') else x for x in args],*a,**kw)
build.subprocess.run=wrapped
try:exe=build.build(O/'mutant-own-session','host','service_check.c')
finally:build.subprocess.run=real
p=real([sys.executable,str(S/'test_service.py'),'--checker',str(exe),'ServiceTest.test_startup_requires_own_live_applied_session_policy'],capture_output=True,text=True)
(O/'mutant-own-session.log').write_text(p.stdout+p.stderr)
assert p.returncode!=0
(O/'own-session-mutation.json').write_text(json.dumps({'exit':p.returncode,'expected_success':False,'assertion_detected':True},indent=2)+'\n')
