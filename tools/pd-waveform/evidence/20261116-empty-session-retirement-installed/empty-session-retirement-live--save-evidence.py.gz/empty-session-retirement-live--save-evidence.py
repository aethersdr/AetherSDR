"""Preserve qualified collector inputs and results without private profiles/keys."""
import datetime
import gzip
import hashlib
import json
from pathlib import Path

BASE = Path(__file__).resolve().parent.parent
WORK = BASE.parent / 'aetherpd-source'
DEST = WORK / 'tools/pd-waveform/evidence/20261116-empty-session-retirement-installed'
REPORT = WORK / 'tools/pd-waveform/EMPTY-FAILED-SESSION-COLLECTION-INSTALLED-QUALIFICATION.json'
SOURCE = 'a6a4904f70c7fb4ed1eef35aa3c48a09c8f11580'


def read(name):
    return json.loads((BASE / name).read_text())


def audited(name):
    outer = read(name)
    assert outer['wait']['StatusCode'] == 0
    assert outer['job_container_deleted'] and outer['temporary_host_directory_deleted']
    inner = json.loads(outer['logs'])
    assert inner.get('passed', True)
    return inner


def collection_events(text):
    return [json.loads(line[line.index('{'):]) for line in text.splitlines()
            if 'empty_failed_sessions_retired' in line]


assert not REPORT.exists() and not DEST.exists()
runtime = read('runtime-empty-session-retirement/report.json')
upgrade = read('upgrade-empty-session-retirement/report.json')
budget = read('runtime-empty-session-retirement/budget-report.json')
instance = read('empty-session-retirement-live/instance.json')
install = read('empty-session-retirement-live/install-result.json')
before = audited('empty-session-retirement-live/before-result.json')
updated = audited('empty-session-retirement-live/after-update-result.json')
reconnect = read('empty-session-retirement-reconnect/outcome.json')
recovered = audited('empty-session-retirement-recovery/final-audit-result.json')
reboot = read('empty-session-retirement-reboot/reboot-check.json')
final = audited('empty-session-retirement-reboot/post-reboot-audit-result.json')
iq = [read(name + '/usb-receive-iq-check.json') for name in [
    'empty-session-retirement-live', 'empty-session-retirement-recovery',
    'empty-session-retirement-reboot']]
assert runtime['source_commit'] == upgrade['source_commit'] == SOURCE
assert all(v['identical_manifest'] and v['identical_release'] for v in runtime['architectures'].values())
assert upgrade['complete_eight_file_distribution_identical']
assert install['committed'] and not install['diagnostics_used_for_delivery']
old_failures = [row for row in before['sessions'] if row['ActiveState'] == 'failed']
assert len(old_failures) == 6
assert all(row['MainPID'] == row['ControlPID'] == '0' and not row['ControlGroup']
           and not row['kernel_members'] for row in old_failures)
update_events = collection_events(updated['upgrade_journal'])
assert update_events[-1] == {'event': 'empty_failed_sessions_retired', 'count': 6, 'rf_commands': []}
assert reconnect['passed'] and reconnect['probe']['passed']
assert reconnect['disconnected_window_survivor_count'] == 1
assert not reconnect['probe']['service_manager_forced_SIGKILL']
assert reconnect['probe']['applied_final']['ActiveState'] == 'failed'
session_events = collection_events('\n'.join(recovered['latest_session_journals'].values()))
assert session_events[-1] == {'event': 'empty_failed_sessions_retired', 'count': 1, 'rf_commands': []}
assert reboot['passed'] and reboot['reboot_commands_sent'] == 1
assert reboot['boot_id_before'] != reboot['boot_id_after'] == final['boot_id']
assert reboot['before'] == reboot['after']
assert all(x['passed'] and x['iq_bytes'] == 131072 and x['stopped']['body']['state'] == 'stopped'
           and not x['rf_commands'] for x in iq)
assert not final['arp'] and not final['all_failed_sessions']
assert final['identity_sha256'] == recovered['identity_sha256'] == updated['identity_sha256']
assert not any(final['temporary_paths'].values())

files = []
def include(folder, names):
    files.extend((BASE / folder / name) for name in names)

include('runtime-empty-session-retirement', ['report.json', 'run.py', 'budget-report.json',
    'build-budget.py', 'budget_probe.c', 'measure-budget.py', 'build-budget.py.log',
    'measure-budget.py.log', 'build-console.log'])
include('upgrade-empty-session-retirement', ['report.json', 'build.py', 'build-console.log',
    'short/selection.json', 'short/manifest.json'])
include('empty-session-retirement-live', ['relaunch.py', 'prepare.py', 'install.py',
    'instance.json', 'desktop-provenance.json', 'prepared.json', 'install-result.json',
    'before-job.py', 'before-result.json', 'after-update-job.py', 'after-update-result.json',
    'receive-iq-check.py', 'usb-receive-iq-check.json', 'usb-receive-iq.f32le',
    'artifact-receipt.json', 'save-evidence.py'])
include('empty-session-retirement-reconnect', ['run.py', 'run-job.py', 'observer-functions.py',
    'observer-tail.py', 'observe-job.py', 'observe-result.json', 'events.json', 'outcome.json'])
include('empty-session-retirement-recovery', ['receive-iq-check.py', 'usb-receive-iq-check.json',
    'usb-receive-iq.f32le', 'final-audit-job.py', 'final-audit-result.json'])
include('empty-session-retirement-reboot', ['reboot-check.py', 'reboot-check.json',
    'reboot-intent.json', 'open-fresh-panel.py', 'connected.json', 'receive-iq-check.py',
    'usb-receive-iq-check.json', 'usb-receive-iq.f32le', 'post-reboot-audit-job.py',
    'post-reboot-audit-result.json'])
DEST.mkdir()
evidence = {}
for path in files:
    relative = str(path.relative_to(BASE)).replace('/', '--') + '.gz'
    target = DEST / relative
    target.write_bytes(gzip.compress(path.read_bytes(), compresslevel=9, mtime=0))
    evidence[str(target.relative_to(WORK))] = hashlib.sha256(target.read_bytes()).hexdigest()

rows = [row for row in budget['measurements'] if row['arch'] == 'armv7']
peak = max(row['successor_peak_including_native_reserve_bytes'] for row in rows)
probe = reconnect['probe']
report = {
    'updated_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
    'status': 'installed_empty_failure_collection_upgrade_new_session_and_software_reboot_qualified_on_8600',
    'production_ready': False,
    'runtime_source_commit': SOURCE,
    'release_blake2b_256': runtime['architectures']['arm64']['first']['release']['blake2b_256'],
    'desktop': instance,
    'component_report': 'tools/pd-waveform/EMPTY-FAILED-SESSION-COLLECTION-QUALIFICATION.json',
    'reproducibility': {
        'architectures': ['armv7', 'arm64'], 'separate_source_output_and_compiler_caches': True,
        'same_host_toolchains': True, 'runtime_releases_identical': True,
        'eight_file_upgrade_distribution_identical': True,
        'release_bytes': {arch: value['first']['release']['bytes']
                          for arch, value in runtime['architectures'].items()},
    },
    'disk_budget': {'scope': budget['measurement'], 'armv7_max_modeled_upgrade_peak_bytes': peak,
        'headroom_from_41_decimal_MB': 41000000 - peak,
        'boundaries': 'Exact byte/inode admitted; one byte/inode short refused for both architectures and block/volume layouts.',
        'state_and_metadata_allowances_are_enforced': False, 'actual_6300_measured': False},
    'ordinary_desktop_upgrade': {
        'committed': True, 'elapsed_s': install['elapsed_s'],
        'displayed_plan_includes_empty_record_collection': True,
        'diagnostics_used_for_delivery': False,
        'predecessor_credential_used_for_delivery': True,
        'temporary_installer_cleanup_confirmed': True,
        'verified_empty_failure_names_before': [row['Id'] for row in old_failures],
        'collector_journal_events': update_events,
        'initial_worker_attempt': 'Journal records exit4 followed by the configured restart and successful completion; the precise first-attempt branch was not isolated.'},
    'receive_only_disconnect_and_reconnect': {
        'passed': True, 'original_workers': len(probe['original_workers']),
        'survivors_at_30s_disconnected': reconnect['disconnected_window_survivor_count'],
        'first_original_workers_gone_after_disconnect_ack_ms': probe['first_workers_gone_after_ack_ms'],
        'manager_forced_SIGKILL': False, 'empty_failed_record_created': probe['applied_final']['Id'],
        'stale_panel_Start_refused_disconnected_and_reconnected': True,
        'fresh_ordinary_session_collector_events': session_events,
        'populated_guardian_survives_while_another_record_is_collected':
            'Component tested; the live test observes guardian hold/retirement before the fresh collector, not simultaneous collection during that hold.'},
    'receive_IQ': {'complete_131072_byte_captures': 3, 'channel': 4,
        'transport': 'local_dax_iq', 'sample_rate_hz': 48000, 'FDX': False,
        'phases': ['after_upgrade', 'after_disconnect_reconnect', 'after_software_reboot'],
        'fresh_GUI_binding_and_finite_nonzero_samples_checked': True, 'all_Stop_states': 'stopped'},
    'software_reboot': {'commands_sent': 1, 'boot_id_before': reboot['boot_id_before'],
        'boot_id_after': reboot['boot_id_after'], 'exact_commit_ready_s': reboot['ready_s'],
        'exact_installation_receipt_preserved': True,
        'ordinary_authenticated_primary_available_before_post_reboot_diagnostic_job': True,
        'physical_power_loss_tested': False},
    'final_audit': {'boot_id': final['boot_id'], 'processes': final['processes'],
        'runtime_hashes': final['runtime_hashes'], 'boot_sha256': final['permanent_boot_sha256'],
        'identity_sha256': final['identity_sha256'], 'identity_mode': 'local_only; no tsnet state present',
        'upgrade_generation_hex': final['upgrade_generation_hex'],
        'temporary_installer_paths_absent': True, 'fixed_ARP_absent': True,
        'accept_local': final['accept_local'], 'failed_session_records': 0,
        'baseline_only': True, 'all_baseline_UIDs': 78666, 'all_capability_sets': 0,
        'NoNewPrivs': 1, 'diagnostic_jobs_removed_their_temporary_containers_and_scratch': True},
    'RF_commands': [],
    'limitations': [
        'No RF correction, sustained duty, stock APD comparison or native keyed deadline test was run in this qualification.',
        'Same DSP binary as preceding work; earlier finite RF improvement is preserved, not requalified by receive-only tests.',
        'One protected disconnect and one software reboot; physical power loss and all interrupted installation boundaries remain separate gates.',
        'Actual FLEX6300/Linux2.6/CortexA8/single-core/legacy service-manager operation is unqualified; ARMv7 reproducibility is not hardware proof.',
        'Capacity is modeled from authentic files and explicit allowances, not measured 6300 state usage or enforced state/log limits.',
        'Development publisher and local-only identity; shipping catalogue, cross-platform credentials and credential rotation/signout remain open.',
        'The existing diagnostics bridge was used only for independent read-only audits/observation, not update delivery or manual record reset; it is not a shipping dependency.',
        'Full P1-P10 remains active. LP100A integration remains deferred.'
    ],
    'evidence_sha256': evidence,
}
REPORT.write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps({'report': str(REPORT), 'evidence_files': len(evidence),
    'release': report['release_blake2b_256'], 'boot_id': final['boot_id'], 'production_ready': False}))
