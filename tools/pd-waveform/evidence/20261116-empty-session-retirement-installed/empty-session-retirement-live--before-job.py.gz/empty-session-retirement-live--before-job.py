import json,pathlib,subprocess
p=subprocess.run(['/usr/bin/systemctl','show','aetherpd-start@*.service','-p','Id','-p','ActiveState','-p','SubState','-p','MainPID','-p','ControlPID','-p','ControlGroup','-p','SendSIGKILL'],capture_output=True,text=True,timeout=8,check=True)
rows=[dict(line.split('=',1) for line in block.splitlines()) for block in p.stdout.strip().split('\n\n') if block]
for row in rows:
 row['kernel_members']=[]
 for proc in pathlib.Path('/proc').iterdir():
  if not proc.name.isdecimal():continue
  try:
   if any('/'+row['Id'] in line for line in (proc/'cgroup').read_text().splitlines()):row['kernel_members'].append(int(proc.name))
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
print(json.dumps({'RF_commands':[],'mutations':[],'sessions':rows}),flush=True)
