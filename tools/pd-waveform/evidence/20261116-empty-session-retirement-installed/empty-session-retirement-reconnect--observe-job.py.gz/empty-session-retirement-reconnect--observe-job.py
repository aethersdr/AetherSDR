import hashlib,json,os,re,select,socket,subprocess,time
from pathlib import Path
CONFIG={'host': '192.168.50.221', 'port': 44557, 'nonce': '85e218156d3a50eaae051540bba01e99f10f587bbe4490ad', 'gui_handle': '0x4ef92338', 'pan': '0x40000000', 'desktop_pid': 2699295, 'generation': 'bd80453923ae0a6ad8de70e015d5120481d94c0d57f888ce93c962edbb82147e'}
report={'probe_complete':False,'passed':False,'signals':[],'RF_commands':[],'API_observations':[],'changes':[]};started=time.monotonic();observer=None;notice=None;handles=[];api_buffer=b''
def graph():
 rows=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   exe=os.readlink(p/'exe')
   if '/aetherpd/' not in exe:continue
   f={l.split(':',1)[0]:l.split(':',1)[1].strip() for l in (p/'status').read_text().splitlines() if ':' in l}
   rows.append({'pid':int(p.name),'ppid':int(f['PPid']),'exe':exe,'uid':f['Uid'],'state':f['State'],'cgroup':(p/'cgroup').read_text().splitlines(),'start_ticks':int((p/'stat').read_text().rsplit(')',1)[1].split()[19]),'caps':{k:f[k] for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']},'nnp':f['NoNewPrivs']})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return rows
def arp():return [l for l in Path('/proc/net/arp').read_text().splitlines()[1:] if l.split()[0]=='172.30.2.1']
def journal():
 p=Path('/run/.aetherpd-fixed-arp.8600');return {'exists':p.exists(),'size':p.stat().st_size if p.exists() else None,'sha256':hashlib.sha256(p.read_bytes()).hexdigest() if p.exists() else None}

def original_alive(row):
 try:return int((Path('/proc')/str(row['pid'])/'stat').read_text().rsplit(')',1)[1].split()[19])==row['start_ticks']
 except (FileNotFoundError,ProcessLookupError):return False

def receive_api(timeout=0):
 global api_buffer
 if not select.select([observer],[],[],timeout)[0]:return
 data=observer.recv(16384);assert data,'Passive API observer disconnected'
 api_buffer+=data;assert len(api_buffer)<262144
 while b'\n' in api_buffer:
  line,api_buffer=api_buffer.split(b'\n',1);text=line.decode('ascii').strip()
  if (text.startswith('S') and ('|slice ' in text or '|interlock ' in text)) or text.startswith(('R3|','R4|','R5|')):
   assert len(report['API_observations'])<4096,'Observation limit reached'
   report['API_observations'].append({'monotonic_ns':time.monotonic_ns(),'line':text})
   if '|interlock ' in text and '|interlock band ' not in text:
    report['latest_interlock']=dict(x.split('=',1) for x in text.split('|',1)[1].split()[1:] if '=' in x)

def idle():
 f=report.get('latest_interlock',{})
 return all(f.get(k)==v for k,v in {'state':'READY','source':'','tx_client_handle':'0x00000000','tx_allowed':'1','reason':''}.items())

def applied():
 p=subprocess.run(['/usr/bin/systemctl','show',unit,'-p','Id','-p','MainPID','-p','ActiveState','-p','SubState','-p','KillMode','-p','SendSIGKILL','-p','TimeoutStopUSec','-p','Result'],capture_output=True,text=True,timeout=8,check=True)
 values=dict(x.split('=',1) for x in p.stdout.splitlines())
 assert values['Id']==unit and values['SendSIGKILL']=='no' and values['KillMode']=='control-group',values
 return values

def sample():
 rows=graph();active=[r for r in rows if r['cgroup']==target['cgroup'] and Path(r['exe']).name in workers]
 survivors=[r for r in originals if original_alive(r)]
 state=[(r['pid'],r['state']) for r in active]
 if not report['changes'] or state!=report['changes'][-1]['signature']:
  report['changes'].append({'after_ack_ms':(time.monotonic_ns()-ack_stamp)/1e6,'signature':state,'active':active,'original_survivors':survivors})
 if not active and not survivors and 'first_workers_gone_after_ack_ms' not in report:
  report['first_workers_gone_after_ack_ms']=(time.monotonic_ns()-ack_stamp)/1e6
 receive_api(.025)
 return active,survivors

def read_notice(deadline):
 data=b''
 while b'\n' not in data:
  assert time.monotonic()<deadline,'Controller acknowledgement deadline'
  if select.select([notice],[],[],.05)[0]:
   part=notice.recv(4096);assert part,'Controller disconnected'
   data+=part;assert len(data)<8192
  if 'ack_stamp' in globals():sample()
 result=json.loads(data);assert result['nonce']==CONFIG['nonce'];return result

try:
 assert hashlib.sha256(Path('/var/lib/smartsdr/aetherpd/state/provision.json').read_bytes()).hexdigest()=='f511e5f09f41a99b0f5cd29e4e321eb6f93ec02162df41175ae6866173233cb5'
 assert Path('/var/lib/smartsdr/aetherpd/upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex(CONFIG['generation'])
 report['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
 assert report['boot_id']=='839d29c7-c56e-4c61-a87e-05fdf1c6b6b6'
 report['before']=graph();dsps=[r for r in report['before'] if r['exe']=='/run/aetherpd/bin/aether-pd'];assert len(dsps)==1
 target=dsps[0];p=Path('/proc')/str(target['pid'])
 assert target['uid'].split()==['78666']*4 and target['nnp']=='1' and not any(int(v,16) for v in target['caps'].values())
 assert hashlib.sha256((p/'exe').read_bytes()).hexdigest()=='bed41f7b3f3308acdacf783e327a16d713a0b7466ac100c812b8b909d0716be8'
 env=dict(x.split(b'=',1) for x in (p/'environ').read_bytes().split(b'\0') if b'=' in x)
 assert int(env.get(b'AETHER_PD_GUI_HANDLE',b'0'),16)==int(CONFIG['gui_handle'],16) and env.get(b'AETHER_PD_DAXIQ')==b'4' and int(env.get(b'AETHER_PD_FEEDBACK_PAN',b'0'),16)==int(CONFIG['pan'],16)
 matches=re.findall(r'aetherpd-start@[0-9]+-[0-9]+-78666\.service',str(target['cgroup']));assert len(matches)==1;unit=matches[0]
 report['applied_before']=applied()
 workers={'aether-pd','pd-iq-source','pd-capture-bootstrap','pd-fixed-arp','pd-unkey-guard','pd-lease-guard'}
 originals=[r for r in report['before'] if r['cgroup']==target['cgroup'] and Path(r['exe']).name in workers];assert len(originals)==9
 for row in originals:
  handles.append(os.pidfd_open(row['pid']));assert original_alive(row)
 report['original_workers']=originals;report['ARP_before']=arp();assert len(report['ARP_before'])==1
 observer=socket.create_connection(('127.0.0.1',4992),2)
 observer.sendall(b'C1|sub slice all\nC2|sub tx all\nC3|slice list\n');observer.setblocking(False)
 end=time.monotonic()+4
 while not idle():
  receive_api(.1);assert time.monotonic()<end,'Fresh idle interlock absent; no disconnect requested'
 notice=socket.create_connection((CONFIG['host'],CONFIG['port']),3);notice.setblocking(False)
 notice.sendall((json.dumps({'nonce':CONFIG['nonce'],'ready':True})+'\n').encode())
 ack=read_notice(time.monotonic()+12);assert ack['disconnected_observed'] and ack['pid']==CONFIG['desktop_pid']
 report['disconnect_ack']={k:v for k,v in ack.items() if k!='nonce'};ack_stamp=time.monotonic_ns();report['disconnect_ack_ns']=ack_stamp
 observer.sendall(b'C4|slice list\n');deadline=time.monotonic()+30
 while time.monotonic()<deadline:sample()
 report['applied_after_disconnected_window']=applied();report['disconnected_window_survivors']=[r for r in originals if original_alive(r)]
 notice.sendall((json.dumps({'nonce':CONFIG['nonce'],'phase':'disconnected_window_complete','survivor_count':len(report['disconnected_window_survivors'])})+'\n').encode())
 ack=read_notice(time.monotonic()+35);assert ack['reconnected_observed'] and ack['pid']==CONFIG['desktop_pid'];report['reconnect_ack']={k:v for k,v in ack.items() if k!='nonce'}
 observer.sendall(b'C5|slice list\n');deadline=time.monotonic()+15
 while time.monotonic()<deadline:sample()
 active,survivors=sample();report['after']=graph();report['remaining_original_workers']=survivors
 report['ARP_after']=arp();report['journal_after']=journal();report['applied_final']=applied()
 report['session_journal']=subprocess.run(['/usr/bin/journalctl','-u',unit,'-n','100','--no-pager','-o','short-monotonic'],capture_output=True,text=True,timeout=8,check=True).stdout
 report['service_manager_forced_SIGKILL']=any(x in report['session_journal'] for x in ['with signal SIGKILL','with signal 9'])
 report['retirement_complete']=not active and not survivors
 report['accept_local']=Path('/proc/sys/net/ipv4/conf/eth0.10/accept_local').read_text().strip()
 report['probe_complete']=True;report['passed']=report['retirement_complete'] and not report['service_manager_forced_SIGKILL'] and not report['ARP_after'] and report['journal_after']['size']==0 and idle() and report['accept_local']=='0'
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
 for fd in handles:os.close(fd)
 if observer:observer.close()
 if notice:notice.close()
 report['total_s']=round(time.monotonic()-started,3);print(json.dumps(report),flush=True)
