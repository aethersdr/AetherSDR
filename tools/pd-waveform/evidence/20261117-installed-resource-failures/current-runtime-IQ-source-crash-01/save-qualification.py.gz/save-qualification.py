from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess
P=Path(__file__).resolve().parent;E=P.parent;W=E.parent/'aetherpd-source'
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();assert base.startswith('d55d782fb')
NAMES=['current-runtime-both-arp-owners-01','current-runtime-IQ-source-crash-01'];cases={};jobs=[]
for name in NAMES:
 d=E/name;live=read(d/'api-outcome.json');outer=read(d/'api-result.json');fault=json.loads(outer['logs']);ao=read(d/'audit-result.json');audit=json.loads(ao['logs'])
 assert live['passed'] and fault['probe_complete'] and audit['passed'] and len(fault['resources'])==10
 assert live['Start_actions']==2 and live['Stop_actions']==1 and live['final_stop']['body']['state']=='stopped'
 assert live['status_after_fault']=={'body':{'available':False,'state':'cleanup_unconfirmed'},'http_status':200}
 for capture in ('capture_before','capture_after_restart'):assert live[capture]['bytes']==131072 and live[capture]['metadata']['feedback_binding']['transport']=='local_dax_iq'
 assert fault['owner_config_before']==fault['owner_config_after']==audit['owner_config_sha256']=='7d4785dbb7087355992d037ded02bd381d2ca828d6383ac97d03681103cc6d89'
 assert fault['firmware_before']['MainPID']==fault['firmware_after']['MainPID']=='1143'
 assert not fault['commands'] and not fault.get('thaw_errors') and not audit['arp'] and audit['arp_journal_bytes']==0
 assert len(audit['processes'])==3 and all(not any(int(v,16) for v in r['caps'].values()) for r in audit['processes'])
 assert not any(audit['temporary_installation_paths'].values())
 for kind,obj in [('fault',outer),('audit',ao)]:
  assert obj['wait']['StatusCode']==0 and obj['job_container_deleted'] and obj['temporary_host_directory_deleted'];jobs.append({'case':name,'kind':kind,'job_removed':True,'host_scratch_removed':True})
 cases[name]={'passed':True,'fault':fault,'ordinary_GUI_recovery':{'start_actions':live['Start_actions'],'stop_actions':live['Stop_actions'],'ready_before_s':live['first_start']['ready_s'],'ready_successor_s':live['restart']['ready_s'],'captures':{k:live[k] for k in ('capture_before','capture_after_restart')},'terminal_after_fault':live['status_after_fault'],'terminal_after_Stop':live['final_stop'],'installation_before':live['installation_before'],'installation_after':live['installation_after'],'owner_after':live['owner_after'],'diagnostics_job_removed_before_explicit_successor_Start':True},'independent_final_audit':audit}
both=cases[NAMES[0]]['fault'];iq=cases[NAMES[1]]['fault'];assert both['thaw_guard_reaped'] and both['ARP_journal_after_fault']['bytes']==64 and both['ARP_before']==both['ARP_after_fault']
assert not iq['ARP_after_fault'] and iq['ARP_journal_after_fault']==0
refused=read(E/'current-runtime-primary-crash-01/api-result.json');rf=json.loads(refused['logs']);assert not rf['probe_complete'] and 'injection' not in rf and not rf['commands'] and refused['job_container_deleted'] and refused['temporary_host_directory_deleted']
assert not read(E/'current-runtime-primary-crash-01/api-outcome.json')['passed'];jobs.append({'case':'current-runtime-primary-crash-01','kind':'refused preflight; no fault injected','job_removed':True,'host_scratch_removed':True})
ret=read(E/NAMES[0]/'retired-identities-result.json');retbody=json.loads(ret['logs']);assert retbody['passed'] and retbody['checked']==24 and ret['job_container_deleted'] and ret['temporary_host_directory_deleted'];jobs.append({'case':NAMES[0],'kind':'24 old identity accounting','job_removed':True,'host_scratch_removed':True})
assert len(cases[NAMES[1]]['independent_final_audit']['prior_owned_pids'])==36 and not any(cases[NAMES[1]]['independent_final_audit']['prior_owned_pids'].values())
final=read(P/'final-observation.json');assert final['AetherPD']['body']['state']=='stopped' and not final['radio']['radio']['transmitting'] and not final['radio']['radio']['fullDuplex']
report={'updated_utc':datetime.now(timezone.utc).isoformat(),'production_ready':False,'source_commit':base,'runtime_source_commit':'92488a6a1f55723f44c7be0efa720b651282131a','installed_release_blake2b_256':'0d88765b3eaad89fde171f98955ac8dcef959543a93db9967b25d920912c43e7','desktop':read(P/'instance.json'),'cases':cases,
 'refused_probe':{'case':'current-runtime-primary-crash-01','passed':False,'fault_injected':False,'cause':'Harness assumed absolute cgroup namespace path; observed kernel path contained /../../../ prefix. Target signal guard refused before injection. Preserved unchanged; no same-owner kill retry.', 'ordinary_Stop_completed':read(E/'current-runtime-primary-crash-01/api-outcome.json')['Stop_actions']==1},
 'measurement_scope':{'both_ARP_resource_retirement_from_freeze_start_ms':both['resources_retired_ms'],'both_ARP_freeze_confirmation_ms':both['both_owners_stopped_ms'],'IQ_source_resource_retirement_from_signal_start_ms':iq['resources_retired_ms'],'resource_observation_poll_s':0.05,'resource_count_each_case':10,'test_frequency_MHz':7.150,'RF_transmitted':False,'FDX':False,'IQ_samples_per_capture':16384,'capture_count_successful_cases':4,'capture_bytes_each':131072},
 'temporary_laboratory_jobs':jobs,'all_36_prior_session_process_identities_gone_including_zombies':True,'owner_configuration_preserved':True,'firmware_PID_preserved':True,'fixed_ARP_and_journal_clear_after_recovery':True,'final_observation':final,'new_package_installed':False,'RF_commands':[],'reboot_commands':[],'service_restart_commands':[],'laboratory_direct_ARP_mutations':[],
 'limits':['One unkeyed FLEX8600 case per fault, not worst-case timing, keyed unkey qualification or actualFLEX6300 evidence.',
 'The two ARP cleanup owners were first confirmed stopped, then killed through pinned process handles so neither could clean up between deaths. A separate three-second thaw child and finally cleanup prevented the intentional freeze from becoming the steady state; that child was reaped.',
 'After each fault the ordinary private control owner/launcher and primary remain intentionally available. Only the ten resource processes retire automatically. These results do not change the earlier failed full-control-channel-retirement assertion into a pass.',
 'cleanup_unconfirmed remains truthful after unexpected child exit, even when native observation confirms resource retirement. Normal explicit Start, not a status callback or automatic restart, creates the successor.',
 'The observer injected fixed-target signals and read metadata through the existing broad laboratory bootstrap. It did not repair ARP, restart services, install persistent privileges or drive RF. This laboratory transport is not a shipping dependency.',
 'Selected runtime member hashes and current process UID/capability sets were independently inspected. No private owner token or signing seed is in this report or evidence.',
 'No whole-radio shutdown/reboot, successful credential revocation, remaining keyed/final-graph fault matrix, natural128 alignment/cold-start diagnosis, repeated RF/stockAPD, actual6300 provisioning or independent release completion. Reboot hang and deferredSWR scope remain unchanged.']}
destination=W/'tools/pd-waveform/evidence/20261117-installed-resource-failures';destination.mkdir(exist_ok=False);hashes={}
for name in ['current-runtime-primary-crash-01',*NAMES]:
 for path in sorted((E/name).iterdir()):
  if not path.is_file() or path.suffix not in ('.py','.json','.log','.f32le'):continue
  target=destination/(str(path.relative_to(E))+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('wb') as f:
   with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(path.read_bytes())
  assert gzip.decompress(target.read_bytes())==path.read_bytes();hashes[str(target.relative_to(W))]=sha(target)
report['evidence_sha256']=hashes
(W/'tools/pd-waveform/INSTALLED-RESOURCE-FAILURES-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
planpath=E/'production-completion-plan-20261113.json';plan=read(planpath);plan['updated_utc']=report['updated_utc'];plan['last_goal_turn_classification']='progress';plan['installed_resource_failures']=report
plan['installed_process_failures'].update(current_receive_only_report='tools/pd-waveform/INSTALLED-RESOURCE-FAILURES-QUALIFICATION.json',automatic_IQ_source_resource_cleanup_current_qualified=True,installed_both_ARP_owner_recovery_current_qualified=True,automatic_IQ_source_full_cleanup=False)
plan['installed_process_failures']['next_action']='Preserve current0d doubleARP-owner/IQsource resource-retirement and explicit successor evidence, with three intentional control processes distinct from resources. Do not repeat equivalent owner-kill baseline tests. Remaining final keyed/combined failures, successful owner revocation, interrupted updates/power loss, actual6300 and full P1-P10 release gates remain.'
plan['arp_restart_recovery'].update(installed_successor_recovery_qualified=True,installed_release=report['installed_release_blake2b_256'],installed_report='tools/pd-waveform/INSTALLED-RESOURCE-FAILURES-QUALIFICATION.json',rf_tested=False)
plan['current_candidate'].update(installed_receive_only_double_ARP_owner_recovery_qualified=True,installed_receive_only_IQ_source_resource_cleanup_qualified=True,boot_id=both['boot_id'],production_ready=False)
plan['next_action']='Proceed with remaining originalP1-P10 requirements; current0d receive-only doubleARP-owner and IQsource recovery now have exact native audits and normal GUI freshIQ proofs. Do not repeat already-covered owner-kill baselines or call full control-channel retirement automatic. Actual6000 privilege-entry source/teammate probes, coordinated reboot trace, deferredSWR steering and final keyed/RF/stockAPD remain external live gates. Continue unresolved credential/recovery/platform and release work that does not depend on those answers.'
planpath.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'evidence_files':len(hashes),'successful_cases':2,'old_session_identities_gone':36,'temporary_jobs_removed':len(jobs),'runtime_unchanged':True}))
