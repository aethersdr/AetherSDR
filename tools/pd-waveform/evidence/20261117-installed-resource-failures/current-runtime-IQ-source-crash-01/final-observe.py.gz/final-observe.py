from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,sys
P=Path(__file__).resolve().parent;E=P.parent;sys.path.insert(0,str(E.parent/'aetherpd-source/tools'));from automation_probe import Bridge
b=Bridge('/tmp/aetherpd-native-durability')
try:
 who=b.request({'cmd':'whoami'},5);r=b.request({'cmd':'get','model':'radio'},5);t=b.request({'cmd':'get','model':'transmit'},5)
 assert who['pid']==618033 and r['radio']['connected'] and not r['radio']['transmitting'] and not r['radio']['fullDuplex'] and not t['transmit']['mox'] and not t['transmit']['tuning'] and not t['transmit']['apdEnabled']
 s=json.loads(subprocess.run([str(E/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=20,check=True).stdout);assert s['http_status']==200 and s['body']['state']=='stopped'
 (P/'final-observation.json').write_text(json.dumps({'observed_utc':datetime.now(timezone.utc).isoformat(),'whoami':who,'radio':r,'transmit':t,'AetherPD':s,'RF_commands':[],'reboot_commands':[]},indent=2)+'\n')
 print('Fresh bridge and authenticated status: unkeyed, FDX off, AetherPD stopped.')
finally:b.close()
