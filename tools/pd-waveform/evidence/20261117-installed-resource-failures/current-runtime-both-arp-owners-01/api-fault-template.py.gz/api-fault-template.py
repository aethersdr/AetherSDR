import hashlib,json,os,re,select,signal,socket,subprocess,time
from pathlib import Path
CONFIG=None
report={'case':'installed_both_ARP_owners_SIGKILL_unkeyed_PD_journal_successor','probe_complete':False,'RF_commands':[],'reboot_commands':[],'commands':[],'observations':[]};observer=None
NS=['/usr/bin/nsenter','--target','1','--cgroup','/usr/bin/systemctl']
EXPECTED={'flex-tailnet-shim': 'b590d6afa83bbb3cd531e9de5be6d657a137bca3d2c36779db822ab8f0d2517a', 'aether-pd': 'b3fc2de87fb51a20721d53a3e0758c4206b29f4ccd6ad1b96e273400471cdf8d', 'pd-primary-launch': 'decf786355f10450819a2ee8645089873084f6745424dc495111c65df59c7ce5', 'pd-start-session': '568641ceb68da3176abfb42b996d521db4f5604d8a026c7add754168f752a47b', 'pd-radio-launch': '262a370c286bb07d1751b01211b0ca76ec75ebd29d2e1230111128ccd554b773', 'pd-fixed-arp': '2e6001780d2c8d42f2d422237cea7a4dcbc24d1ace9ee4aff7ee422a09072f49', 'pd-iq-source': '37fa974279793ccb0b4ee5891bc361a536d1cc917a12521ffe8d09781cc35ac0', 'pd-capture-bootstrap': 'b3132499052fdb709c64fa0267171072299aae21fe0a970c0debc4648e40eccc', 'pd-unkey-guard': '1663086c576cd08332a97c7c20771b3ee7653824c73c93e100c1583e4c88888f', 'pd-lease-guard': '297183f7504ffd6c9c6d9f4713976a2bcbfc1df5d9caa788c402fd8568c0954e', 'pd-boot': '0e9dc30619820bd06304b92c144f63858336dea21aeab00be92932d81ce6691f'}
def graph():
 rows=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   exe=os.readlink(p/'exe')
   if '/aetherpd/' not in exe:continue
   f=dict(line.split(':',1) for line in (p/'status').read_text().splitlines() if ':' in line)
   rows.append({'pid':int(p.name),'exe':exe,'state':f['State'].strip(),'uid':f['Uid'].split(),'nnp':f['NoNewPrivs'].strip(),'caps':{k:f[k].strip() for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']},'cgroup':(p/'cgroup').read_text().splitlines(),'start_ticks':int((p/'stat').read_text().rsplit(')',1)[1].split()[19]),'sha256':hashlib.sha256((p/'exe').read_bytes()).hexdigest()})
  except (OSError,KeyError):pass
 return rows

def alive(row):
 try:return int((Path('/proc')/str(row['pid'])/'stat').read_text().rsplit(')',1)[1].split()[19])==row['start_ticks']
 except OSError:return False

def state(unit):
 p=subprocess.run(NS+['show','--property=Id,MainPID,ActiveState,SubState,ControlGroup,KillMode,SendSIGKILL,TimeoutStopUSec,DropInPaths,FragmentPath,After,Before,ExecStart,DefaultDependencies',unit],capture_output=True,text=True,timeout=3);assert p.returncode==0
 return dict(line.split('=',1) for line in p.stdout.splitlines() if '=' in line)

def connect_idle():
 global observer
 if observer:observer.close()
 observer=socket.create_connection(('127.0.0.1',4992),2);observer.setblocking(False);observer.sendall(b'C1|sub tx all\nC2|sub slice all\n');buf=b'';end=time.monotonic()+4;idle=None;target=None
 while time.monotonic()<end:
  if not select.select([observer],[],[],.1)[0]:continue
  data=observer.recv(16384);assert data;buf+=data;assert len(buf)<262144
  while b'\n' in buf:
   line,buf=buf.split(b'\n',1);s=line.decode('ascii').strip()
   if not s.startswith('S') or '|' not in s:continue
   body=s.split('|',1)[1];f=dict(x.split('=',1) for x in body.split() if '=' in x)
   if body.startswith('interlock ') and not body.startswith('interlock band ') and all(k in f for k in ['state','source','tx_client_handle','tx_allowed','reason']):
    assert f['state']=='READY' and not f['source'] and f['tx_client_handle']=='0x00000000' and f['tx_allowed']=='1' and not f['reason'];idle=f
   if body.startswith('slice 0 ') and all(k in f for k in ['mode','client_handle','pan']):target=f
  if idle is not None and target is not None:return {'interlock':idle,'slice':target}
 raise RuntimeError('Fresh idle and slice snapshot absent')

UNIT_HASHES={'aetherpd-boot.service': '08f24faab3500778cfbf343cf62d00970789a44f63c5915cddd311fc6283a504', 'aetherpd-start.socket': '1d77b02319b737ba07d8fd27cca0ae01479bfde05aca1b5a8270ba4d7b981d21', 'aetherpd-start@.service': 'd999a37b368ca764a3a3818a674fc29288cfdda1b9280aa0315b3247da4975d1', 'aetherpd-shim.service': 'ec48d75a6346751d1440cc166889a75484e3a399935ebdd0877553331355081b'}

def redact(text):
    text=re.sub(r'(?i)https?://[^\s\"<>]+','[redacted-url]',text)
    text=re.sub(r'(?i)\bbearer[ \t]+[^\s\",;}]+','Bearer [redacted]',text)
    key=r'\b(?:[a-z0-9]+_)*(?:token|authkey|auth_key|access_key|password|secret|authorization)\b'
    text=re.sub('(?i)('+key+r'[\"\x27]?\s*[=:]\s*)(?:"(?:\\.|[^"\\])*"|\x27[^\x27]*\x27|[^\s,;}]+)',r'\1[redacted]',text)
    return text


journal_child=None;journal_buffer=bytearray();journal_discard=False;journal_bytes=0;journal_records=[];journal_oversize=0;journal_dropped=0
stop_requested=False;stopped_verified=False;start_requested=False;start_verified=False;pinned=[];thaw_guard=None

def drain_journal():
 global journal_bytes,journal_discard,journal_oversize,journal_dropped
 if journal_child is None:return
 for _ in range(4):
  try:data=os.read(journal_child.stdout.fileno(),16384)
  except BlockingIOError:return
  if not data:return
  journal_bytes+=len(data)
  for byte in data:
   if byte==10:
    if not journal_discard:
     try:item=json.loads(journal_buffer)
     except (ValueError,RecursionError):item=None
     if isinstance(item,dict):
      fields={k:redact(item[k])[:8192 if k=='MESSAGE' else 256] for k in ['_BOOT_ID','_SYSTEMD_UNIT','SYSLOG_IDENTIFIER','_PID','PRIORITY','MESSAGE','__MONOTONIC_TIMESTAMP','__REALTIME_TIMESTAMP'] if isinstance(item.get(k),str)}
      if len(journal_records)<1024 and journal_bytes<=1024*1024:journal_records.append(fields)
      else:journal_dropped+=1
    journal_buffer.clear();journal_discard=False
   elif not journal_discard:
    if len(journal_buffer)<65536:journal_buffer.append(byte)
    else:journal_buffer.clear();journal_discard=True;journal_oversize+=1

def unit_members(names):
 result=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   lines=(p/'cgroup').read_text().splitlines()
   if any(any('/'+n in c and (c.endswith('/'+n) or '/'+n+'/' in c) for n in names) for c in lines):
    result.append({'pid':int(p.name),'cgroup':lines,'state':(p/'stat').read_text().rsplit(')',1)[1].split()[0]})
  except FileNotFoundError:pass
  except ProcessLookupError:pass
 return result


try:
 report['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert report['boot_id']=='65be86a7-fd98-4f16-ae62-505781cadb85'
 assert hasattr(os,'pidfd_open') and hasattr(signal,'pidfd_send_signal'),'No safe process handle support; no injection'
 assert Path('/var/lib/smartsdr/aetherpd/upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('9b5205957c872ee6e9419f75674120cb4dfe86b439030aa2ffc047aa96a0ee2a')
 report['owner_config_before']=hashlib.sha256(Path('/var/lib/smartsdr/aetherpd/state/provision.json').read_bytes()).hexdigest();assert report['owner_config_before']=='7d4785dbb7087355992d037ded02bd381d2ca828d6383ac97d03681103cc6d89'
 report['unit_hashes']={n:hashlib.sha256((Path('/etc/systemd/system')/n).read_bytes()).hexdigest() for n in UNIT_HASHES};assert report['unit_hashes']==UNIT_HASHES
 report['firmware_before']=state('smartsdr.service');assert report['firmware_before']['ActiveState']=='active'
 report['before']=graph();dsps=[r for r in report['before'] if Path(r['exe']).name=='aether-pd'];assert len(dsps)==1;dsp=dsps[0]
 cohort=[r for r in report['before'] if r['cgroup']==dsp['cgroup']];assert len(cohort)==12
 primary=[r for r in report['before'] if r not in cohort];assert len(primary)==1
 for row in report['before']:
  role=Path(row['exe']).name;assert row['sha256']==EXPECTED[role]
  if role in ['pd-fixed-arp','pd-capture-bootstrap']:
   assert row['uid']==['65534']*4
   assert {k:int(v,16) for k,v in row['caps'].items()}=={'CapInh':0,'CapPrm':4096 if role=='pd-fixed-arp' else 0,'CapEff':4096 if role=='pd-fixed-arp' else 0,'CapBnd':0,'CapAmb':0}
  else:assert row['uid']==['78666']*4 and row['nnp']=='1' and not any(int(v,16) for v in row['caps'].values())
 instance=dsp['cgroup'][0].rsplit('/',1)[1];assert re.fullmatch(r'aetherpd-start@[0-9]+-[0-9]+-78666\.service',instance)
 names=['aetherpd-shim.service','aetherpd-start.socket',instance,'aetherpd-boot.service'];report['units']=names
 report['units_before']={n:state(n) for n in names}
 for n,s in report['units_before'].items():
  assert s['Id']==n and s['ActiveState']=='active' and s['DropInPaths']==''
  assert s['FragmentPath']=='/etc/systemd/system/'+('aetherpd-start@.service' if n==instance else n)
 assert report['units_before'][instance]['SendSIGKILL']=='no' and report['units_before'][instance]['KillMode']=='control-group'
 report['radio_before']=connect_idle();sl=report['radio_before']['slice'];assert sl['mode']=='PD' and int(sl['client_handle'],16)==CONFIG['gui_handle'] and int(sl['pan'],16)==CONFIG['feedback_pan']
 args=['/usr/bin/nsenter','--target','1','--cgroup','/usr/bin/journalctl','--boot='+report['boot_id'].replace('-',''),'--lines=80','--follow','--no-pager','--output=json',*['--unit='+n for n in names],'--unit=smartsdr.service']
 journal_child=subprocess.Popen(args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT,start_new_session=True);os.set_blocking(journal_child.stdout.fileno(),False);report['journal_pid']=journal_child.pid
 keepers=[r for r in cohort if Path(r['exe']).name=='pd-fixed-arp'];assert len(keepers)==2
 def ppid(row):return int((Path('/proc')/str(row['pid'])/'stat').read_text().rsplit(')',1)[1].split()[1])
 keeper_ids={r['pid'] for r in keepers};watchers=[r for r in keepers if ppid(r) in keeper_ids];assert len(watchers)==1
 keeper=next(r for r in keepers if r['pid']!=watchers[0]['pid']);watcher=watchers[0]
 launch_pid=int(report['units_before'][instance]['MainPID']);launch=next(r for r in cohort if r['pid']==launch_pid);assert Path(launch['exe']).name=='pd-boot'
 controls=[r for r in cohort if Path(r['exe']).name=='flex-tailnet-shim' and ppid(r)==launch_pid];assert len(controls)==1
 control_ids={launch_pid,controls[0]['pid']};resources=[r for r in cohort if r['pid'] not in control_ids];assert len(resources)==10
 report['resources']=resources;report['control_pids']=sorted(control_ids)
 def arp():return [l for l in Path('/proc/net/arp').read_text().splitlines()[1:] if l.split()[0]=='172.30.2.1']
 journal_path=Path('/run/.aetherpd-fixed-arp.8600');record=journal_path.read_bytes()
 report['ARP_before']=arp();report['ARP_journal_before']={'bytes':len(record),'sha256':hashlib.sha256(record).hexdigest()};assert len(report['ARP_before'])==1 and record.startswith(b'PDARP001')
 assert report['ARP_before'][0].split()[5]=='eth0.10' and int(report['ARP_before'][0].split()[2],16)==6
 assert report['ARP_before'][0].split()[3].lower()==Path('/sys/class/net/eth0.10/address').read_text().strip().lower()
 for row in (keeper,watcher):
  fd=os.pidfd_open(row['pid'],0);pinned.append((row,fd));assert alive(row) and hashlib.sha256((Path('/proc')/str(row['pid'])/'exe').read_bytes()).hexdigest()==EXPECTED['pd-fixed-arp']
 thaw_guard=os.fork()
 if thaw_guard==0:
  time.sleep(3)
  for row,fd in pinned:
   try:signal.pidfd_send_signal(fd,signal.SIGCONT,None,0)
   except OSError:pass
  os._exit(0)
 report['thaw_guard_pid']=thaw_guard
 stamp=time.monotonic_ns()
 for row,fd in pinned:signal.pidfd_send_signal(fd,signal.SIGSTOP,None,0)
 deadline=time.monotonic()+2
 while True:
  assert all(alive(row) for row,fd in pinned)
  if all((Path('/proc')/str(row['pid'])/'stat').read_text().rsplit(')',1)[1].split()[0] in ('T','t') for row,fd in pinned):break
  assert time.monotonic()<deadline,'Failed to freeze both cleanup owners; unfreeze in finally'
  time.sleep(.005)
 report['both_owners_stopped_ms']=(time.monotonic_ns()-stamp)/1e6
 for row,fd in pinned:signal.pidfd_send_signal(fd,signal.SIGKILL,None,0)
 report['injection']={'kind':'SIGSTOP both confirmed, then SIGKILL both','pids':[r['pid'] for r,fd in pinned],'pidfd':True,'stamp_ns':stamp}
 deadline=time.monotonic()+20
 while True:
  drain_journal();survivors=[r for r in resources if alive(r)]
  report['observations'].append({'elapsed_ms':(time.monotonic_ns()-stamp)/1e6,'original_resource_survivor_pids':[r['pid'] for r in survivors]})
  if not survivors:break
  assert time.monotonic()<deadline,'Resource retirement incomplete; no signal escalation or firmware action';time.sleep(.05)
 report['resources_retired_ms']=(time.monotonic_ns()-stamp)/1e6
 report['after']=graph();assert all(r['pid'] in control_ids or r['pid']==primary[0]['pid'] for r in report['after'])
 assert all(alive(r) for r in [primary[0],launch,controls[0]])
 report['radio_after_fault']=connect_idle();assert report['radio_after_fault']['slice']['mode']=='USB'
 report['firmware_after']=state('smartsdr.service');assert report['firmware_after']['MainPID']==report['firmware_before']['MainPID'] and report['firmware_after']['ActiveState']=='active'
 report['ARP_after_fault']=arp();assert report['ARP_after_fault']==report['ARP_before']
 after_record=journal_path.read_bytes();assert after_record==record;report['ARP_journal_after_fault']={'bytes':len(after_record),'sha256':hashlib.sha256(after_record).hexdigest()}
 report['successor_required']='Both capability owners are gone. The exact boot/profile-bound ARP ownership record remains for an explicit normal Start to reclaim; this job does not modify ARP or restart any service.'
 report['owner_config_after']=hashlib.sha256(Path('/var/lib/smartsdr/aetherpd/state/provision.json').read_bytes()).hexdigest();assert report['owner_config_after']==report['owner_config_before']
 assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()==report['boot_id']
 report['accept_local']=Path('/proc/sys/net/ipv4/conf/eth0.10/accept_local').read_text().strip();assert report['accept_local']=='0'
 time.sleep(.15);drain_journal();assert not journal_oversize and not journal_dropped,'Journal exceeded bounded record allowance'
 report['probe_complete']=True
except Exception as error:report['error']=type(error).__name__+': '+redact(str(error))
finally:
 if thaw_guard:
  got,status=os.waitpid(thaw_guard,os.WNOHANG)
  if got==0:
   os.kill(thaw_guard,signal.SIGTERM);os.waitpid(thaw_guard,0)
  report['thaw_guard_reaped']=True
 for row,fd in pinned:
  try:signal.pidfd_send_signal(fd,signal.SIGCONT,None,0)
  except ProcessLookupError:pass
  except Exception as error:report.setdefault('thaw_errors',[]).append(type(error).__name__)
  finally:os.close(fd)
 if observer:observer.close()
 if journal_child is not None:
  drain_journal()
  if journal_child.poll() is None:
   try:os.killpg(journal_child.pid,signal.SIGTERM)
   except ProcessLookupError:pass
   try:journal_child.wait(timeout=2)
   except subprocess.TimeoutExpired:
    os.killpg(journal_child.pid,signal.SIGKILL);journal_child.wait(timeout=2)
  journal_child.stdout.close();report['journal_exit']=journal_child.returncode;report['journal_pid_gone']=not Path('/proc',str(journal_child.pid)).exists()
 report['journal']={'records':journal_records,'raw_bytes':journal_bytes,'oversize':journal_oversize,'dropped':journal_dropped,'unterminated_bytes':len(journal_buffer)}
 report['stopped_verified']=stopped_verified;report['primary_restart_verified']=start_verified
 print(json.dumps(report),flush=True)
