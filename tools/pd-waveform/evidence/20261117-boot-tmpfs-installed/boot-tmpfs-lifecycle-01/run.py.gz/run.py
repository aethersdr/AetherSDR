import ast,base64,hashlib,json,math,pathlib,struct,subprocess,sys,time
P=pathlib.Path(__file__).resolve().parent;E=P.parent
sys.path.insert(0,str(E.parent/'aetherpd-source/tools'));from automation_probe import Bridge
assert not (P/'api-outcome.json').exists(),'Preserve every attempt'
instance=json.loads((P/'instance.json').read_text());bridge=Bridge(instance['socket'])
report={'passed':False,'RF_commands':[],'credential_mutations':[],'Start_actions':0,'Stop_actions':0};events=[];job=None;started=False

def event(name,**values):
 events.append({'event':name,'monotonic_ns':time.monotonic_ns(),**values});(P/'api-events.json').write_text(json.dumps(events,indent=2)+'\n')
def req(q):
 r=bridge.request(q,8);event('bridge',request=q,response=r);assert r.get('ok'),r;return r

def read(path):
 r=subprocess.run([str(E/'first-iq-live/vault-v3'),path],capture_output=True,text=True,timeout=22)
 result=json.loads(r.stdout);event('authenticated_read',path=path,response=result);return result

def idle():
 r=req({'cmd':'get','model':'radio'})['radio'];assert r['connected'] and not r['transmitting'] and not r['fullDuplex'] and r['serial']=='2125-1213-8600-8895'
 tx=req({'cmd':'get','model':'transmit'})['transmit'];assert not tx['mox'] and not tx['tuning'] and not tx['apdEnabled']
 return r

def start():
 global started
 idle();req({'cmd':'invoke','target':'pdStart','action':'click'});started=True;report['Start_actions']+=1;begin=time.monotonic();end=begin+35
 while True:
  s=read('aetherpd/status')
  if s['http_status']==200 and s['body'].get('registered'):break
  assert time.monotonic()<end,s;time.sleep(.25)
 assert not s['body']['keyed'] and not s['body']['correcting']
 return {'ready_s':time.monotonic()-begin,'status':s}

def stop():
 global started
 req({'cmd':'invoke','target':'pdStop','action':'click'});report['Stop_actions']+=1;end=time.monotonic()+20
 while True:
  s=read('aetherpd/status')
  if s['http_status']==200 and s['body'].get('state')=='stopped':break
  assert time.monotonic()<end,s;time.sleep(.25)
 started=False;return s

def capture(label,identity):
 c=read('aetherpd/capture');assert c['http_status']==200,c
 meta=c['body'];binding=meta['feedback_binding']
 assert binding['valid'] and not binding['failed'] and binding['transport']=='local_dax_iq'
 assert binding['channel']==4 and binding['gui_handle']==identity['gui_handle'] and binding['pan']==identity['feedback_pan']
 assert meta['sample_rate_hz']==48000 and meta['sample_count']==16384 and not meta['keyed'] and not meta['correcting']
 raw=bytearray()
 for n in range(32):
  r=read('aetherpd/capture/'+meta['capture_id']+'/'+str(n));assert r['http_status']==200,r
  assert r['body']['offset']==n*512
  data=base64.b64decode(r['body']['iq_f32le'],validate=True);assert len(data)==4096;raw.extend(data)
 values=struct.unpack('<'+str(len(raw)//4)+'f',raw)
 assert len(raw)==131072 and all(math.isfinite(x) for x in values) and any(x!=0 for x in values)
 (P/(label+'.f32le')).write_bytes(raw)
 return {'metadata':meta,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
try:
 who=req({'cmd':'whoami'});assert who['pid']==instance['pid'] and who['automationIdentity']=='aetherpd-shim-integration'
 report['desktop_sha256']=hashlib.sha256(pathlib.Path('/proc',str(who['pid']),'exe').read_bytes()).hexdigest();assert report['desktop_sha256']==instance['binary_sha256']
 report['radio_before']=idle();installation=read('aetherpd/installation');assert installation['http_status']==200 and installation['body']['selected_release_blake2b_256']=='a8920b11a650ce36118589f818712636bae56f35b3b1570c8a8c8f6d404f0a3f'
 report['installation_before']=installation
 pans=req({'cmd':'get','model':'pans'})['pans'];assert len(pans)==1 and pans[0]['ownedByUs'] and pans[0]['rxAntenna']=='RX_A' and pans[0]['rfGain']==0
 identity={'gui_handle':int(pans[0]['clientHandle'],16),'feedback_pan':int(pans[0]['panId'],16)};report['identity']=identity
 before=read('aetherpd/status');assert before['http_status'] in [200,503] and before['body'].get('state') in ['stopped','unavailable'] and not before['body'].get('registered',False)
 req({'cmd':'invoke','target':'pdIqSelection','action':'setCurrentIndex','value':1})
 report['first_start']=start();report['capture_before']=capture('api-before-IQ',identity)
 report['unkeyed_PD_request']=req({'cmd':'slice','action':'mode','value':'PD'})
 end=time.monotonic()+5
 while True:
  idle();slices=req({'cmd':'get','model':'slices'})['slices']
  if len(slices)==1 and slices[0]['mode']=='PD':break
  assert time.monotonic()<end,'Unkeyed PD transition unconfirmed';time.sleep(.1)
 report['slice_mode_before_probe']=slices
 source=(P/'api-fault-template.py').read_text().replace('CONFIG=None','CONFIG='+repr(identity),1);ast.parse(source);(P/'api-job.py').write_text(source)
 with (P/'api-job-console.log').open('w') as out:
  job=subprocess.Popen([sys.executable,str(P/'run-job.py'),'api'],stdout=out,stderr=subprocess.STDOUT)
  end=time.monotonic()+150
  while job.poll() is None:
   idle();assert time.monotonic()<end,'Job still live; never duplicate';time.sleep(.5)
 assert job.returncode==0,'Diagnostics orchestration failed'
 outer=json.loads((P/'api-result.json').read_text());probe=json.loads(outer['logs']);report['fault_probe']=probe
 assert outer['wait']['StatusCode']==0 and outer['job_container_deleted'] and outer['temporary_host_directory_deleted'] and probe['probe_complete'],probe
 report['status_after_fault']=read('aetherpd/status');assert not report['status_after_fault']['body'].get('registered',False)
 report['post_fault_policy']='Closed channel remains unavailable; explicit Start revalidates a fresh constructor.'
 started=False
 report['restart']=start();report['capture_after_restart']=capture('api-restarted-IQ',identity)
 report['final_stop']=stop();report['radio_after']=idle();report['installation_after']=read('aetherpd/installation');assert report['installation_after']['body']==installation['body']
 report['owner_after']=json.loads(subprocess.run([str(E/'managed-remote-access-ui/credential-probe'),'login'],capture_output=True,text=True,timeout=35,check=True).stdout)
 assert report['owner_after']['state']=='local' and not report['owner_after']['auth_url_present'] and report['owner_after']['owner_verifier_fingerprint']=='9d5efda3384e7d4100d905c7dcecbc5fa975f494db0ffd7f4d13d6095c5f925c'
 report['passed']=True
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
 if job and job.poll() is None:
  try:job.wait(timeout=55)
  except subprocess.TimeoutExpired:report['job_still_live']=True;report['passed']=False
 if started and not report.get('job_still_live'):
  try:report['fallback_stop']=stop()
  except Exception as error:report['cleanup_error']=str(error);report['passed']=False
 bridge.close();(P/'api-outcome.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['passed','error','cleanup_error','Start_actions','Stop_actions','job_still_live'] if k in report}),flush=True)
 if not report['passed']:raise SystemExit(1)
