from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,tarfile
E=Path(__file__).resolve().parent.parent;W=E.parent/'aetherpd-source'
previous=Path((E/'latest-checkpoint-path.txt').read_text().strip());old=json.loads((previous/'checkpoint.json').read_text())
assert old['source_commit'].startswith('361acc6a0')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
dest=previous.parent/('20261117-first-install-catalogue-'+commit[:9]);dest.mkdir(exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
for p in previous.glob('*.tar.gz'):os.link(p,dest/p.name)
changes=subprocess.check_output(['git','diff','--name-only','--diff-filter=ACMRT',old['source_commit'],commit],cwd=W,text=True).splitlines();assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=D',old['source_commit'],commit],cwd=W)
overlay=dest/'source-first-install-catalogue-overlay.tar.gz'
with tarfile.open(overlay,'w:gz') as t:
 for n in changes:t.add(W/n,arcname=n,recursive=False)
archives=old['source_reconstruction']+[overlay.name];expected={}
for name in archives:
 with tarfile.open(dest/name) as t:
  for m in t:
   if m.isfile():expected[m.name]=hashlib.sha256(t.extractfile(m).read()).hexdigest()
   elif m.issym():expected[m.name]=hashlib.sha256(m.linkname.encode()).hexdigest()
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0')[:-1]
for n in tracked:
 p=W/n;assert expected.get(n)==(hashlib.sha256(os.readlink(p).encode()).hexdigest() if p.is_symlink() else sha(p)),n
for p in [E/'production-completion-plan-20261113.json',W/'tools/pd-waveform/FIRST-INSTALL-CATALOGUE-QUALIFICATION.json',W/'tools/pd-waveform/FIRST-INSTALL-HTTPS-QUALIFICATION.json',W/'tools/pd-waveform/FINAL-RUNTIME-RF-QUALIFICATION.json',E/'first-install-catalogue/catalogue-first-preview.png']:
 shutil.copyfile(p,dest/p.name)
meta={'created_utc':datetime.now(timezone.utc).isoformat(),'source_commit':commit,'source_reconstruction':archives,'source_deletions':[],'overlay_in_order_in_empty_directory':True,'all_tracked_source_paths_verified':len(tracked),'latest_overlay_members':len(changes),'installed_release':old['installed_release'],'runtime_source_commit':old['runtime_source_commit'],'first_install_catalogue':'Exact model/firmware/digest selection and normal first/saved UI download paths component-verified. Retained publisher recovery and uncertain-journal refusal; 4CTest suites,7mutantsdetected,address/undefined/leak instrumentedtests passed,full desktop/static/docs builds passed. Shipping catalogue empty. Upgrade catalogue/inventory and live hosted delivery remain open.','RF':'No RF this turn; prior finite10Wpair and SWR-aborted repeat preserved separately. No repeatability qualification.','software_reboot_qualified':False,'radio_changes_this_turn':[],'pending_operator_steering':old['pending_operator_steering'],'production_ready':False,'goal_status':'active','previous_checkpoint':str(previous),'all_exec_jobs_this_turn':'All current build/test/sanitizer/mutation/docs/UI jobs terminal; checkpoint performs no radio or build operation.'}
(dest/'checkpoint.json').write_text(json.dumps(meta,indent=2)+'\n')
hashes={p.name:sha(p) for p in dest.iterdir() if p.is_file()};(dest/'SHA256SUMS').write_text(''.join(h+'  '+n+'\n' for n,h in sorted(hashes.items())));assert all(sha(dest/n)==h for n,h in hashes.items())
(E/'latest-checkpoint-path.txt').write_text(str(dest)+'\n');print(json.dumps({'checkpoint':str(dest),'verified_files':len(hashes),'tracked_source_paths':len(tracked)}))
