import hashlib,json,os,pathlib,subprocess
P=pathlib.Path;store=P('/var/lib/smartsdr/aetherpd');report={'rf_commands':[],'processes':[]}
try:
 plan=(store/'migration-approved').read_bytes();report['migration_plan_blake2b_256']=hashlib.blake2b(plan,digest_size=32).hexdigest()
 report['transaction_sha256']=hashlib.sha256((store/'transaction').read_bytes()).hexdigest()
 cfg=json.loads((store/'state/provision.json').read_text());assert cfg['local_only'] and len(cfg['installation_id'])==64 and cfg['installation_id'].startswith('b6050e0036d2cfe9')
 assert not (store/'state/tsnet').exists()
 report['installation_id']=cfg['installation_id']
 report['identity_sha256']=hashlib.sha256((store/'state/provision.json').read_bytes()).hexdigest()
 report['temporary_paths']={p:P(p).exists() for p in ['/var/lib/smartsdr/aetherpd-installation','/run/aetherpd-install','/run/aetherpd-delivery','/etc/systemd/system/aetherpd-install.service','/etc/systemd/system/aetherpd-recover.service','/var/lib/smartsdr/aetherpd-upgrade','/etc/systemd/system/aetherpd-upgrade.service','/etc/systemd/system/aetherpd-upgrade-recover.service']}
 assert not any(report['temporary_paths'].values())
 for p in P('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   exe=os.readlink(p/'exe')
   if exe.startswith(('/run/aetherpd/', '/var/lib/smartsdr/aetherpd/')) or 'pd-first-request' in exe:
    status={l.split(':',1)[0]:l.split(':',1)[1].strip() for l in (p/'status').read_text().splitlines() if ':' in l}
    row={'pid':int(p.name),'exe':exe,'uid':status['Uid'],'caps':{k:status[k] for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']},'nnp':status['NoNewPrivs'],'sha256':hashlib.sha256((p/'exe').read_bytes()).hexdigest()};report['processes'].append(row)
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 assert len(report['processes']) in (1,3)
 assert all(x['uid'].split()==['78666']*4 and all(int(v,16)==0 for v in x['caps'].values()) and x['nnp']=='1' for x in report['processes'])
 assert not any(P(x['exe']).name in ['aether-pd','pd-iq-source','pd-capture-bootstrap'] for x in report['processes'])
 primary=next(x for x in report['processes'] if x['exe']=='/run/aetherpd/bin/flex-tailnet-shim');assert primary['exe']=='/run/aetherpd/bin/flex-tailnet-shim' and primary['uid'].split()==['78666']*4 and all(int(x,16)==0 for x in primary['caps'].values()) and primary['nnp']=='1'
 assert primary['sha256']=='cc3af96b554afe25fb733bf70cdbdeb6f710c3b2273792f2166737b7200c709a'
 report['private_sockets']=[l for l in P('/proc/net/unix').read_text().splitlines() if any(x in l for x in ['aetherpd-config-','aetherpd-bootstrap-','aetherpd-relay-'])];assert not report['private_sockets']
 ns=['/usr/bin/nsenter','--target','1','--cgroup']
 p=subprocess.run(ns+['/usr/bin/podman','ps','-a','--format','{{.Names}}'],capture_output=True,text=True,timeout=10);assert p.returncode==0
 report['containers']=p.stdout.splitlines();assert not any(x.startswith(('aetherpd-first-','aetherpd-install-','aetherpd-carrier-')) for x in report['containers'])
 report['arp']=[l for l in P('/proc/net/arp').read_text().splitlines()[1:] if l.split()[0]=='172.30.2.1'];assert not report['arp']
 report['accept_local']=P('/proc/sys/net/ipv4/conf/eth0.10/accept_local').read_text().strip();assert report['accept_local']=='0'
 report['legacy_container_absent']='aetherpd-before-first-24cfa90ab5052bf8' not in report['containers'];assert report['legacy_container_absent']
 report['cached_first_artifacts']=[]
 for root in ['/user/waveforms','/var/lib/smartsdr']:
  for item in P(root).rglob('*b6050e0036d2cfe9*'):
   report['cached_first_artifacts'].append(str(item))
 assert not report['cached_first_artifacts']
 expected={'flex-tailnet-shim': 'cc3af96b554afe25fb733bf70cdbdeb6f710c3b2273792f2166737b7200c709a', 'aether-pd': 'bed41f7b3f3308acdacf783e327a16d713a0b7466ac100c812b8b909d0716be8', 'pd-primary-launch': 'decf786355f10450819a2ee8645089873084f6745424dc495111c65df59c7ce5', 'pd-start-session': '1957d5682d9fbde0fe49590b7028b4e200a55363b3e9abeaac3982ac495ed64d', 'pd-radio-launch': '09c9103a47581d829c61ff33fa180556ccda2e3a4071ed1951fb643e0c838877', 'pd-fixed-arp': '2e6001780d2c8d42f2d422237cea7a4dcbc24d1ace9ee4aff7ee422a09072f49', 'pd-iq-source': '37fa974279793ccb0b4ee5891bc361a536d1cc917a12521ffe8d09781cc35ac0', 'pd-capture-bootstrap': 'b3132499052fdb709c64fa0267171072299aae21fe0a970c0debc4648e40eccc', 'pd-unkey-guard': 'd945aeaf3926c51e63a2054d64f4bd799334d453cc575e060ec37464cadf7662', 'pd-lease-guard': '297183f7504ffd6c9c6d9f4713976a2bcbfc1df5d9caa788c402fd8568c0954e'}
 report['runtime_hashes']={n:hashlib.sha256((P('/run/aetherpd/bin')/n).read_bytes()).hexdigest() for n in expected if n!='LICENSES'}
 assert all(report['runtime_hashes'][n]==h for n,h in expected.items() if n!='LICENSES')
 assert (store/'upgrade-generation').is_file()
 report['upgrade_generation_present']=True;report['upgrade_generation_hex']=(store/'upgrade-generation').read_bytes().hex();assert (store/'upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('d8dd7cf7b04b797e515b04d354865f872b3f0b329d7888ec7dd2ef5902942e3d')
 assert report['identity_sha256']=='f511e5f09f41a99b0f5cd29e4e321eb6f93ec02162df41175ae6866173233cb5'
 backup=P('/var/lib/smartsdr/aetherpd-guardian-backup-54e21aa67/store/state/provision.json')
 report['prior_backup_identity_sha256']=hashlib.sha256(backup.read_bytes()).hexdigest()
 assert report['prior_backup_identity_sha256']=='7e315aee252647fbbaf713d7633ec4b72fbd9c73406bedc54b107bedc5476931'
 report['owned_upgrade_carrier_artifacts']=[]
 for root in ['/user/waveforms','/var/lib/smartsdr']:
  report['owned_upgrade_carrier_artifacts'] += [str(item) for item in P(root).rglob('*4e71893fd3ccd68d5dca3361bf54d5cb*')]
 assert not report['owned_upgrade_carrier_artifacts']
 report['systemd_version']=subprocess.run(['/usr/bin/systemctl','--version'],capture_output=True,text=True,timeout=5,check=True).stdout
 report['failed_old_session_unit']=subprocess.run(['/usr/bin/systemctl','show','aetherpd-start@8-2580-78666.service','-p','Result','-p','ActiveState','-p','MainPID','-p','KillMode','-p','SendSIGKILL','-p','TimeoutStopUSec'],capture_output=True,text=True,timeout=5,check=True).stdout
 template=P('/etc/systemd/system/aetherpd-start@.service').read_text();assert 'SendSIGKILL=no\n' in template and 'KillMode=control-group\n' in template
 report['applied_sessions']=subprocess.run(['/usr/bin/systemctl','show','aetherpd-start@*.service','-p','Id','-p','MainPID','-p','ActiveState','-p','KillMode','-p','SendSIGKILL'],capture_output=True,text=True,timeout=8,check=True).stdout
 for block in report['applied_sessions'].strip().split('\n\n'):
  if not block:continue
  values=dict(line.split('=',1) for line in block.splitlines());assert values['SendSIGKILL']=='no' and values['KillMode']=='control-group'
 report['permanent_boot_sha256']=hashlib.sha256((store/'pd-boot').read_bytes()).hexdigest();assert report['permanent_boot_sha256']=='f47eec37ccc223e9f4d4b0a79568079486032b9d2eeeb2c07afa075376b6bba5'
 report['latest_session_journals']={}
 blocks=report['applied_sessions'].strip().split('\n\n')
 for block in blocks:
  if not block:continue
  values=dict(line.split('=',1) for line in block.splitlines())
  if values.get('ActiveState')!='active':continue
  name=values['Id'];assert __import__('re').fullmatch(r'aetherpd-start@[0-9]+-[0-9]+-78666\.service',name)
  report['latest_session_journals'][name]=subprocess.run(['/usr/bin/journalctl','-u',name,'-n','100','--no-pager','-o','short-monotonic'],capture_output=True,text=True,timeout=8,check=True).stdout
 report['boot_id']=P('/proc/sys/kernel/random/boot_id').read_text().strip();report['passed']=True
finally:
 print(json.dumps(report),flush=True)
