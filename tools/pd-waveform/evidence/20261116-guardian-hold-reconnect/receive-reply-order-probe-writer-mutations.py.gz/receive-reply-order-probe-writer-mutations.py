from pathlib import Path
import json,os,subprocess
O=Path(__file__).resolve().parent;W=O.parents[1]/'aetherpd-source';G=W/'tools/flex-tailnet-shim';source=(G/'aetherpd_receive_restore.go').read_text();report={}
env=dict(os.environ,GOTOOLCHAIN='local',GOPROXY='off',GOCACHE=str(O.parent/'go-cache'));go='/home/jeremy/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.1.linux-amd64/bin/go'
for name,old,new in [('reject-unrelated','if seq != writer.sequence {\n\t\t\tcontinue\n\t\t}','if seq != writer.sequence { return "", errors.New("unexpected receive command reply") }'),('accept-own-error','if code != 0 {','if code == 9999 {')]:
 assert old in source
 f=O/(name+'.go');f.write_text(source.replace(old,new));overlay=O/(name+'-overlay.json');overlay.write_text(json.dumps({'Replace':{str(G/'aetherpd_receive_restore.go'):str(f)}}))
 p=subprocess.run([go,'test','-mod=vendor','-overlay',str(overlay),'-count=1','-run','TestPDReceiveWriter','.'],cwd=G,env=env,capture_output=True,text=True)
 (O/(name+'.log')).write_text(p.stdout+p.stderr);report[name]={'exit':p.returncode,'expected_success':False,'tail':(p.stdout+p.stderr)[-1800:]};print(name,p.returncode,flush=True);assert p.returncode!=0
(O/'writer-mutations.json').write_text(json.dumps(report,indent=2)+'\n')
