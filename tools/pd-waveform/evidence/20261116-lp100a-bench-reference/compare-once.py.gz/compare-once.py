"""One short5W GUI transmission; record LP100A and raw Flex meters together."""
import importlib.util,json,pathlib,sys,time
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent
sys.path.insert(0,str(BASE.parent/'aetherpd-source/tools'))
from automation_probe import Bridge
from bench_meter_monitor import MeterMonitor
spec=importlib.util.spec_from_file_location('raw_meters',ROOT/'meter-watch.py');meters=importlib.util.module_from_spec(spec);spec.loader.exec_module(meters)
spec=importlib.util.spec_from_file_location('bench_common',BASE/'stock-candidate/bench-common.py');common=importlib.util.module_from_spec(spec);spec.loader.exec_module(common)
assert not (ROOT/'comparison-result.json').exists() and not (ROOT/'comparison-events.json').exists(),'One attempt only; preserve failures'
b=Bridge('/tmp/aetherpd-empty-session-retirement');lp=None;flex=None;observer=None;events=[];key_requested=False
report={'RF_key_actions':0,'planned_key_seconds':3,'nominal_W':5,'configured_max_W':10,'LP_power_stop_W':6,'LP_SWR_stop':1.5,'product_integration_deferred':True,'automatic_retries':False,'safe_cleanup_confirmed':False}
def record(kind,**kw):
 events.append({'event':kind,'host_monotonic_ns':time.monotonic_ns(),**kw});(ROOT/'comparison-events.json').write_text(json.dumps(events,indent=2)+'\n')
def req(q):
 r=b.request(q,5);record('bridge',request=q,result=r);assert r.get('ok'),r;return r
def invoke(name,action='click',value=None):
 q={'cmd':'invoke','target':name,'action':action}
 if value is not None:q['value']=value
 return req(q)
def panel():
 tree=req({'cmd':'dumpTree','target':'AetherPDMeasurementDialog'});result={}
 def visit(x):
  if not isinstance(x,dict):return
  name=x.get('objectName','')
  if name.startswith('pdMeasure'):result[name]={k:x[k] for k in ['value','enabled'] if k in x}
  for item in x.get('children',[]):visit(item)
 for root in tree.get('roots',[]):
  if root.get('objectName')=='AetherPDMeasurementDialog' and root.get('visible'):visit(root)
 assert result,'No current measurement panel';return result
def status():
 import subprocess
 p=subprocess.run([str(BASE/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=20);return json.loads(p.stdout)
def wait_control(name,seconds=8):
 end=time.monotonic()+seconds
 while True:
  p=panel()
  if p.get(name,{}).get('enabled'):return p
  assert time.monotonic()<end,(name,p);time.sleep(.1)
try:
 who=req({'cmd':'whoami'});assert who['pid']==2699295 and who['txAllowed'] and who['automationIdentity']=='aetherpd-shim-integration'
 radio=req({'cmd':'get','model':'radio'})['radio'];tx=req({'cmd':'get','model':'transmit'})['transmit'];slices=req({'cmd':'get','model':'slices'})['slices'];pans=req({'cmd':'get','model':'pans'})['pans']
 assert radio['connected'] and not radio['transmitting'] and not radio['fullDuplex'] and radio['serial']=='2125-1213-8600-8895'
 assert tx['rfPower']==5 and tx['maxPowerLevel']<=10 and not tx['apdEnabled']
 assert len(slices)==1 and slices[0]['mode']=='PD' and slices[0]['txAntenna']=='ANT1' and slices[0]['rxAntenna']=='RX_A' and slices[0]['frequency']==7.15
 assert len(pans)==1 and pans[0]['ownedByUs'] and pans[0]['rfGain']==0 and pans[0]['centerMhz']==7.15;gui=int(pans[0]['clientHandle'],16);report['GUI_handle']=gui
 current=status();assert current['http_status']==200 and current['body']['registered'] and not current['body']['keyed'];binding=current['body']['feedback_binding'];assert binding['valid'] and binding['transport']=='local_dax_iq' and binding['channel']==4 and binding['gui_handle']==gui
 lp=MeterMonitor(ROOT);report['LP_idle_before']=lp.ready();assert report['LP_idle_before']['power_w']==0
 flex=meters.MeterWatch();end=time.monotonic()+5
 while not flex.ready():assert time.monotonic()<end,'Flex meter stream missing';time.sleep(.02)
 metadata=req({'cmd':'get','model':'meters'})['meters']['all'];pins={(x['index'],x['name'],x['unit']) for x in metadata};assert {(4,'+13.8A','Volts'),(8,'FWDPWR','dBm'),(9,'REFPWR','dBm'),(10,'SWR','SWR'),(11,'PATEMP','degC')}<=pins
 observer=common.Observer();snap=observer.snapshot();assert snap['interlock']['state']=='READY' and snap['apd']['enable']=='0'
 invoke('pdMeasureDummyLoad','setChecked','true');invoke('pdMeasurePowerLimit','setValue',10)
 wait_control('pdMeasureArm');invoke('pdMeasureArm');end=time.monotonic()+8
 while True:
  s=status()
  if s.get('body',{}).get('calibration_state')=='armed' and s['body'].get('source_purpose')=='measurement':break
  assert time.monotonic()<end,s;time.sleep(.1)
 wait_control('pdMeasurePrepare');invoke('pdMeasurePrepare');controls=wait_control('pdMeasureTransmit');assert float(controls['pdMeasureTimeout']['value'])==10
 assert lp.require()['power_w']==0;flex.check(time.monotonic_ns());snap=observer.snapshot();assert snap['interlock']['state']=='READY'
 record('operator_key_intent',nominal_W=5,frequency_MHz=7.15,planned_key_seconds=3,native_cleanup_budget_seconds=9,desktop_timeout_seconds=10,LP_power_stop_W=6,LP_SWR_stop=1.5,existing_radio_guards_active=True)
 report['RF_key_actions']=1;key_requested=True;requested_ns=time.monotonic_ns();invoke('pdMeasureTransmit');deadline=time.monotonic()+5;first_tx=None;last_tx=None
 while time.monotonic()<deadline:
  snap=observer.snapshot();now=time.monotonic_ns();inter=snap['interlock'];lp_row=lp.require();flex.pump();radio=req({'cmd':'get','model':'radio'})['radio']
  assert not radio['fullDuplex']
  if inter.get('state')=='TRANSMITTING':
   assert int(inter.get('tx_client_handle','0'),16)==gui
   if first_tx is None:first_tx=now;deadline=min(deadline,time.monotonic()+3)
   last_tx=now
   if now-first_tx>500_000_000 and lp_row['power_w']>=.2:assert lp_row['coherent'],'LP peak/impedance/SWR record is incoherent'
  record('sample',interlock=inter,LP=lp_row,Flex=flex.snapshot(),GUI_transmitting=radio['transmitting'])
  flex.check(first_tx if first_tx is not None else requested_ns)
  if first_tx is not None and inter.get('state')=='READY' and not radio['transmitting']:break
  time.sleep(.025)
 report['observed_transmitting']=first_tx is not None;report['first_TX_host_ns']=first_tx;report['last_TX_host_ns']=last_tx
 if first_tx is None:raise RuntimeError('No transmission observed; no retry')
except Exception as error:
 report['stop_reason']=type(error).__name__+': '+str(error);record('stop_reason',reason=report['stop_reason'])
finally:
 try:
  if key_requested:
   p=panel()
   if p.get('pdMeasureStop',{}).get('enabled'):invoke('pdMeasureStop')
   radio=req({'cmd':'get','model':'radio'})['radio']
   if radio['transmitting']:
    snap=observer.snapshot();assert int(snap['interlock'].get('tx_client_handle','0'),16)==gui,'Foreign TX owner'
    req({'cmd':'key','action':'ptt','value':'off'})
   end=time.monotonic()+12
   while True:
    radio=req({'cmd':'get','model':'radio'})['radio'];snap=observer.snapshot()
    if not radio['transmitting'] and snap['interlock'].get('state')=='READY':break
    assert time.monotonic()<end,'RF-off observation deadline';time.sleep(.05)
   report['radio_after']=radio;record('RF_off_confirmed',snapshot=snap)
   if lp:report['LP_idle_after']=lp.await_zero()
  invoke('pdStop');end=time.monotonic()+20
  while True:
   stopped=status()
   if stopped.get('body',{}).get('state')=='stopped':break
   assert time.monotonic()<end,stopped;time.sleep(.2)
  report['stopped']=stopped;report['safe_cleanup_confirmed']=True
 except Exception as error:report['cleanup_error']=type(error).__name__+': '+str(error)
 if flex:
  (ROOT/'flex-raw-meters.json').write_text(json.dumps({'rows':flex.rows,'port':flex.port,'replies':flex.replies},indent=2)+'\n');flex.close()
 if observer:
  (ROOT/'interlock-observations.json').write_text(json.dumps(observer.rows,indent=2)+'\n');observer.close()
 if lp:lp.close()
 b.close();(ROOT/'comparison-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
 if not report['safe_cleanup_confirmed']:raise SystemExit(1)
