from pathlib import Path
import gzip,hashlib,json,tarfile
from datetime import datetime,timezone
P=Path(__file__).resolve().parent;E=P.parent;W=E.parent/'aetherpd-source';U=E/'upgrade-boot-tmpfs'
def read(p):return json.loads(p.read_text())
r=read(P/'report.json');d=read(U/'report.json');b=read(P/'budget-report.json');comparison=read(P/'payload-comparison.json');assert all(v['identical_release'] and v['identical_manifest'] for v in r['architectures'].values()) and d['complete_eight_file_distribution_identical']
files=[]
for arch in ['armv7','arm64']:
 for name in ['candidate.release','public-key','release-digest','manifest.json']:files.append(P/'short'/arch/name)
for name in d['first']['selection']['files']:files.append(U/'short/package'/name)
for name in ['manifest.json','selection.json']:files.append(U/'short'/name)
for name in ['report.json','source-sha256.json','payload-comparison.json','budget-report.json']:files.append(P/name)
for name in ['report.json','build.py']:files.append(U/name)
archive=E/'boot-tmpfs-authenticated-artifacts.tar.gz';assert not archive.exists()
with tarfile.open(archive,'w:gz') as tar:
 for p in files:tar.add(p,arcname=str(p.relative_to(E)),recursive=False)
with tarfile.open(archive) as tar:
 for p in files:assert tar.extractfile(str(p.relative_to(E))).read()==p.read_bytes()
meta={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'members':len(files),'source_commit':r['source_commit'],'private_seed_included':False,'installed':False,'production_ready':False};(E/'boot-tmpfs-artifact-archive.json').write_text(json.dumps(meta,indent=2)+'\n')
now=datetime.now(timezone.utc).isoformat();dest=W/'tools/pd-waveform/evidence/20261117-boot-tmpfs-runtime';dest.mkdir(exist_ok=False);hashes={}
paths=[]
for directory in [P,U]:
 for p in directory.iterdir():
  if p.is_file() and p.suffix in ['.json','.py','.c','.log']:paths.append(p)
for label in ['short','second-distinct-long-source-path']:
 for arch in ['armv7','arm64']:paths.append(P/label/arch/'manifest.json')
 for name in ['manifest.json','selection.json']:paths.append(U/label/name)
paths.append(E/'boot-tmpfs-artifact-archive.json')
for p in sorted(paths):
 target=dest/(str(p.relative_to(E))+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(p.read_bytes(),mtime=0));assert gzip.decompress(target.read_bytes())==p.read_bytes();hashes[str(target.relative_to(W))]=hashlib.sha256(target.read_bytes()).hexdigest()
report={'updated_utc':now,'status':'complete_signed_ARMv7_ARM64_runtime_and_ARM64_upgrade_reproduced_and_native_disk_admission_qualified_not_installed','production_ready':False,'installed':False,'source_commit':r['source_commit'],'component_report':'tools/pd-waveform/BOOT-TMPFS-QUALIFICATION.json','two_distinct_source_output_compiler_cache_paths':True,'toolchains':{'Go':r['go'],'zig':r['zig'],'same_host_and_toolchains':True},'architectures':comparison,'native_signatures_verified':True,'full_distribution_eight_files_identical':True,'expanded_payload_all_eleven_records_identical_to_b30':True,'previous_release_blake2b_256':'b30bb5074b4c962183662c82026655ad0d94646de333c0ec8119507b5bea5115','private_seed_persisted':False,'native_disk_admission':{'real_signed_predecessor_candidate_pair':True,'exact_byte_one_byte_short_exact_inode_one_inode_short_checks_passed':True,'ARMv7_max_modeled_peak_bytes':max(x['successor_peak_including_native_reserve_bytes'] for x in b['measurements'] if x['arch']=='armv7'),'ARMv7_min_model_headroom_decimal_41_MB':min(x['remaining_from_41_decimal_MB'] for x in b['measurements'] if x['arch']=='armv7')},'artifact_archive':meta,'RF_commands':[],'reboot_commands':[],'limitations':['Complete offline package and native synthetic capacity qualification only. This candidate is not installed; current8600 remainsb30/e636. Ordinary desktop preparation/update/startup and reboot are separate gates.','Reproducibility uses distinct source/output/cache paths on the same host and pinned toolchains; no independent release-builder proof.','Real predecessor/candidate inputs feed production space admission, but capacities and state/metadata allowances remain synthetic. This is not actual6300 whole-volume/high-water or first-install adapter qualification.','ARMv7 compilation does not supply its missing first-install delivery adapter or actualLinux2.6/CortexA8/one-core execution.','All11 expanded payload records matchb30; source binding/signatures changed and the fixed boot helper contains the new tmpfs guard. DSP, shim, other fixed helpers, service definitions and correction defaults are unchanged.','Previous software reboot hang remainsunqualified. Bench-presence coordination question is pending; no reboot/RF retry or unkey guarantee follows from this package build. FullP1–P10 and deferred5WSWR/preamble scope remain intact.'],'evidence_sha256':hashes}
(W/'tools/pd-waveform/BOOT-TMPFS-RUNTIME-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
p=E/'production-completion-plan-20261113.json';plan=read(p);plan['updated_utc']=now;plan['boot_tmpfs_guard']['runtime_report']='tools/pd-waveform/BOOT-TMPFS-RUNTIME-QUALIFICATION.json';plan['boot_tmpfs_guard']['complete_runtime_build'].update(status='complete_exit0_byte_identical_two_paths',installed=False);plan['boot_tmpfs_guard']['distribution_reproduced']=True;plan['boot_tmpfs_guard']['native_signed_pair_disk_admission_passed']=True;plan['next_action']='Build the matched ordinary desktop with upgrade-boot-tmpfs/short/selection.json, review exactb30 predecessor/new signed runtime, approve the authorized ordinary update and qualify receive-only startup/full localIQ/full-service restart and cleanup. No software reboot retry until operator bench-presence coordination is answered. Keep the whole originalP1–P10 scope, actual6300 adapter/layout/kernel, full storage/account/platform/keyed/RF/stockAPD/release gates and deferred5WSWR/preamble intact.';p.write_text(json.dumps(plan,indent=2)+'\n');target=dest/'production-completion-plan.json.gz';target.write_bytes(gzip.compress(p.read_bytes(),mtime=0));report['evidence_sha256'][str(target.relative_to(W))]=hashlib.sha256(target.read_bytes()).hexdigest();(W/'tools/pd-waveform/BOOT-TMPFS-RUNTIME-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'evidence_members':len(report['evidence_sha256']),'archive_bytes':meta['bytes'],'archive_sha256':meta['sha256'],'installed':False,'ARMv7_peak':report['native_disk_admission']['ARMv7_max_modeled_peak_bytes']}))
