"""Only owned stopped fixtures; prove cancel differs from controller EOF."""
import json,os,pathlib,signal,subprocess,time
ROOT=pathlib.Path(__file__).resolve().parent
results=[]
for mode in ['deadline','explicit_cancel','controller_EOF']:
 child=subprocess.Popen(['sleep','30']);fd=os.pidfd_open(child.pid);read_fd,write_fd=os.pipe();watch=None
 try:
  signal.pidfd_send_signal(fd,signal.SIGSTOP);end=time.monotonic()+1
  while (pathlib.Path('/proc')/str(child.pid)/'stat').read_text().rsplit(')',1)[1].split()[0] not in ['T','t']:
   assert time.monotonic()<end
  target=ROOT/('watchdog-fixture-'+mode+'.json');assert not target.exists()
  watch=subprocess.Popen(['python3',str(ROOT/'resume-watchdog.py'),str(fd),str(read_fd),str(time.monotonic()+.1),str(target)],pass_fds=(fd,read_fd))
  os.close(read_fd);read_fd=-1
  if mode=='explicit_cancel':os.write(write_fd,b'x')
  if mode=='controller_EOF':os.close(write_fd);write_fd=-1
  watch.wait(timeout=2);assert watch.returncode==0
  result=json.loads(target.read_text());expected={'deadline':'resumed_at_deadline','explicit_cancel':'canceled','controller_EOF':'resumed_after_controller_EOF'}[mode]
  assert result['action']==expected,result
  state=(pathlib.Path('/proc')/str(child.pid)/'stat').read_text().rsplit(')',1)[1].split()[0]
  assert (state in ['T','t'])==(mode=='explicit_cancel')
  results.append({'mode':mode,'passed':True,'action':result['action']})
 finally:
  if read_fd>=0:os.close(read_fd)
  if write_fd>=0:os.close(write_fd)
  if watch and watch.poll() is None:watch.wait(timeout=2)
  signal.pidfd_send_signal(fd,signal.SIGCONT);child.terminate();child.wait(timeout=2);os.close(fd)
(ROOT/'watchdog-check.json').write_text(json.dumps({'passed':True,'only_owned_fixture_children_signaled':True,'cases':results,'RF_commands':[]},indent=2)+'\n')
print(json.dumps(results))
