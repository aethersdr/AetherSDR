"""Read retained wire/process evidence; distinguish RF unkey from reservation."""
import hashlib,json,pathlib,re
P=pathlib.Path(__file__).resolve().parent
def fields(text):
 if not text.startswith('interlock ') or text.startswith('interlock band '):return {}
 result={}
 for item in text.split()[1:]:
  if '=' not in item:continue
  key,value=item.split('=',1)
  if key in result:return {}
  result[key]=value
 return result
def rf_ready(value,owner):
 required={'state','source','reason','tx_allowed','tx_client_handle'}
 if not required<=value.keys():return False
 if not re.fullmatch(r'0x[0-9a-fA-F]{8}',value['tx_client_handle']):return False
 return value['state']=='READY' and value['source']==value['reason']=='' and value['tx_allowed']=='1' and int(value['tx_client_handle'],16) in [0,owner]

original=json.loads((P/'outcome.json').read_text());assert original['passed'] is False
events=json.loads((P/'keyed-events.json').read_text());outer=json.loads((P/'keyed-result.json').read_text());root=json.loads(outer['logs'])
assert outer['wait']['StatusCode']==0 and outer['job_container_deleted'] and outer['temporary_host_directory_deleted']
owner=int(root['key']['fields']['tx_client_handle'],16)
assert root['key']['fields']['state']=='TRANSMITTING' and root['key']['fields']['source']=='SW'
ready=next(e for e in root['events'] if e['monotonic_ns']>root['key']['monotonic_ns'] and rf_ready(e['fields'],owner))
released=next(e for e in root['events'] if e['monotonic_ns']>ready['monotonic_ns'] and rf_ready(e['fields'],owner) and int(e['fields']['tx_client_handle'],16)==0)
elapsed=(ready['monotonic_ns']-root['key']['monotonic_ns'])/1e6;assert 8500<=elapsed<=9500
assert root['same_DSP_alive'] and root['bounded_guard_original_PID_gone'] and not root['signals'] and not root['rf_commands']
assert root['independent_guards']['measurement_9000ms']['guard_argv'][-1]=='9000'
host_rows=next(e['rows'] for e in reversed(events) if e['event']=='observer_rows')
key_host=next(e for e in host_rows if (f:=fields(e['body'])).get('state')=='TRANSMITTING' and int(f['tx_client_handle'],16)==owner)
ready_host=next(e for e in host_rows if e['monotonic_ns']>key_host['monotonic_ns'] and rf_ready(fields(e['body']),owner))
pause=next(e for e in events if e['event']=='desktop_stopped')
resume=next(e for e in events if e['event'] in ['desktop_resumed','emergency_desktop_resume'])
assert pause['monotonic_ns']<ready_host['monotonic_ns']<resume['monotonic_ns']
before=[e for e in events if e['event']=='desktop_still_stopped' and e['monotonic_ns']<=ready_host['monotonic_ns']][-1]
after=next(e for e in events if e['event']=='desktop_still_stopped' and e['monotonic_ns']>=ready_host['monotonic_ns'])
assert before['state'] in ['T','t'] and after['state'] in ['T','t']
assert after['monotonic_ns']-before['monotonic_ns']<150_000_000
assert all(e['state'] in ['T','t'] for e in events if e['event']=='desktop_still_stopped' and e['monotonic_ns']<=ready_host['monotonic_ns'])
assert json.loads((P/'watchdog.json').read_text())['action']=='canceled'
for e in events:
 if e['event']!='bridge' or e['monotonic_ns']>=ready_host['monotonic_ns']:continue
 q=e['request'];assert not(q.get('cmd')=='key' and q.get('value')=='off')
 assert not(q.get('cmd')=='invoke' and q.get('target') in ['pdMeasureStop','pdStop'])
assert sum(e['event']=='bridge' and e['request'].get('target')=='pdMeasureTransmit' for e in events)==1
good=dict(ready['fields']);assert int(good['tx_client_handle'],16)==owner and rf_ready(good,owner)
bad=[]
for key,value in [('state','TRANSMITTING'),('state','PTT_REQUESTED'),('state','UNKEY_REQUESTED'),('source','SW'),('reason','FAULT'),('tx_allowed','0'),('tx_client_handle','0x00000001'),('tx_client_handle','bad')]:
 f=dict(good);f[key]=value;assert not rf_ready(f,owner);bad.append([key,value])
for key in ['state','source','reason','tx_allowed','tx_client_handle']:
 f=dict(good);del f[key];assert not rf_ready(f,owner)
sdk=pathlib.Path('/home/jeremy/AetherSDR/reference/FlexLib/FlexLib/Radio.cs');source=sdk.read_text();method=source.split('private bool IsInterlockMox(InterlockState state)',1)[1].split('private bool ShouldUpdateMoxOrTuneState',1)[0]
assert all('case InterlockState.'+name+':' in method for name in ['Transmitting','PTTRequested','UnkeyRequested']) and 'case InterlockState.Ready:' not in method and 'bool ret_val = false;' in method
lp=[json.loads(line) for line in (P/'lp100a-readings.jsonl').read_text().splitlines()]
result={'RF_unkey_reanalysis_passed':True,'original_automation_verdict_unchanged':False,'original_passed':original['passed'],
 'original_failure':'Harness required tx_client_handle0 after READY; that tests complete reservation release, a stronger condition than RF unkey.',
 'root_observed_key_to_RF_READY_ms':elapsed,'root_observed_key_to_owner_zero_READY_ms':(released['monotonic_ns']-root['key']['monotonic_ns'])/1e6,
 'host_observed_key_to_RF_READY_ms':(ready_host['monotonic_ns']-key_host['monotonic_ns'])/1e6,
 'RF_READY_before_desktop_resume_ms':(resume['monotonic_ns']-ready_host['monotonic_ns'])/1e6,
 'paused_process_samples_bracketing_READY':{'before':before,'after':after},'RF_READY_fields':ready['fields'],
 'same_DSP_alive':True,'DSP_PID':root['before'][next(i for i,x in enumerate(root['before']) if x['exe']=='/run/aetherpd/bin/aether-pd')]['pid'],
 'bounded_guard_PID':root['independent_guards']['measurement_9000ms']['pid'],'native_guard_program_duration_ms':9000,
 'no_host_unkey_or_Stop_before_RF_READY':True,'no_DSP_signals':True,'LP_peak_held_W':max(x['power_w'] for x in lp),
 'LP_max_reported_SWR_when_power_above_point2W':max(x['swr'] for x in lp if x['power_w']>.2),
 'FlexLib_Radio_cs_sha256':hashlib.sha256(sdk.read_bytes()).hexdigest(),'authority':'Published FlexLib4.3.16 Radio.IsInterlockMox: only Transmitting/PTTRequested/UnkeyRequested setMOX; READY remains false regardless retained client handle.',
 'predicate_refusals':bad,'missing_required_fields_refused':True,'production_guards_changed':False,
 'limitations':['Reanalysis of retained live evidence; original failed receipts remain untouched. Corrected harness live rerun not claimed.',
 'API-reported RF unkey is distinct from retirement of the operation and release of the client reservation. Strict production cleanup/ownership gates are unchanged.',
 'The fixed source completed at8seconds before API unkey. Do not call the9second API transition a calibrated physical RF cessation measurement.',
 'Native helper stdout events are discarded by its supervisor; attribution uses fixed verified executable/9000ms argument, timing, paused host, no alternate host unkey and preserved DSP identity.',
 'No FPGA/LP sample clock synchronization or new spectral improvement/stock comparison is claimed.']}
result['original_automation_verdict_unchanged']=json.loads((P/'outcome.json').read_text())['passed'] is False
(P/'RF-unkey-reanalysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({k:result[k] for k in ['RF_unkey_reanalysis_passed','root_observed_key_to_RF_READY_ms','RF_READY_before_desktop_resume_ms','LP_peak_held_W','LP_max_reported_SWR_when_power_above_point2W']}))
