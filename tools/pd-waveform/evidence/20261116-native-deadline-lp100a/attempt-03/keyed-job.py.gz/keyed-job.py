import hashlib,json,os,re,select,signal,socket,subprocess,time
from pathlib import Path
CONFIG={'host': '192.168.50.221', 'port': 43093, 'nonce': '5d81beb0a82a763d0b1baec5285b243e173cf74ba6f70bd5', 'gui_handle': 288543591}
report={'passed':False,'signals':[],'rf_commands':[],'events':[]};handles=[];observer=None
EXPECTED={'aether-pd':'bed41f7b3f3308acdacf783e327a16d713a0b7466ac100c812b8b909d0716be8','pd-unkey-guard':'d945aeaf3926c51e63a2054d64f4bd799334d453cc575e060ec37464cadf7662'}
def graph():
 rows=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   exe=os.readlink(p/'exe')
   if '/aetherpd/' not in exe:continue
   f=dict(l.split(':',1) for l in (p/'status').read_text().splitlines() if ':' in l)
   rows.append({'pid':int(p.name),'ppid':int(f['PPid']),'exe':exe,'uid':f['Uid'].split(),'state':f['State'].strip(),'cgroup':(p/'cgroup').read_text().splitlines(),'start_ticks':int((p/'stat').read_text().rsplit(')',1)[1].split()[19]),'caps':{k:f[k].strip() for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']},'nnp':f['NoNewPrivs'].strip(),'guard_argv':(p/'cmdline').read_bytes().rstrip(b'\0').decode('ascii').split('\0') if Path(exe).name=='pd-unkey-guard' else []})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return rows
def validate(row):
 assert row['uid']==['78666']*4 and row['nnp']=='1' and not any(int(v,16) for v in row['caps'].values()),row
 assert hashlib.sha256((Path('/proc')/str(row['pid'])/'exe').read_bytes()).hexdigest()==EXPECTED[Path(row['exe']).name]
def read_interlocks(seconds):
 global buf
 end=time.monotonic()+seconds;events=[]
 while time.monotonic()<end:
  if not select.select([observer],[],[],min(.01,max(0,end-time.monotonic())))[0]:continue
  data=observer.recv(16384);assert data,'Observer disconnected';buf+=data;assert len(buf)<131072
  while b'\n' in buf:
   line,buf=buf.split(b'\n',1)
   if line.startswith(b'S') and b'|interlock ' in line and b'|interlock band ' not in line:
    f=dict(v.split('=',1) for v in line.decode('ascii').strip().split('|',1)[1].split()[1:] if '=' in v)
    if 'state' in f:
     row={'monotonic_ns':time.monotonic_ns(),'fields':f};report['events'].append(row);events.append(row)
 return events
try:
 assert hashlib.sha256(Path('/var/lib/smartsdr/aetherpd/state/provision.json').read_bytes()).hexdigest()=='f511e5f09f41a99b0f5cd29e4e321eb6f93ec02162df41175ae6866173233cb5'
 assert Path('/var/lib/smartsdr/aetherpd/upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('bd80453923ae0a6ad8de70e015d5120481d94c0d57f888ce93c962edbb82147e')
 assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='da955e3f-c404-4337-97fd-1d42ddb693e8'
 report['before']=graph();dsp=[p for p in report['before'] if p['exe']=='/run/aetherpd/bin/aether-pd'];assert len(dsp)==1;target=dsp[0];validate(target);group=target['cgroup'];assert len(group)==1 and '/aetherpd-start@' in group[0]
 fd=os.pidfd_open(target['pid']);handles.append(fd);assert int((Path('/proc')/str(target['pid'])/'stat').read_text().rsplit(')',1)[1].split()[19])==target['start_ticks']
 observer=socket.create_connection(('127.0.0.1',4992),2);observer.setblocking(False);observer.sendall(b'C1|sub tx all\n');buf=b'';first=read_interlocks(1)
 assert first and first[-1]['fields']['state']=='READY' and int(first[-1]['fields']['tx_client_handle'],16)==0
 with socket.create_connection((CONFIG['host'],CONFIG['port']),3) as notify:notify.sendall((json.dumps({'nonce':CONFIG['nonce'],'ready':True,'target':target})+'\n').encode())
 end=time.monotonic()+35;key=None
 while time.monotonic()<end and key is None:
  for e in read_interlocks(.03):
   if e['fields']['state']=='TRANSMITTING':
    assert int(e['fields']['tx_client_handle'],16)==CONFIG['gui_handle'] and e['fields'].get('source')=='SW',e
    key=e;break
 assert key is not None,'No operator transmission; no signal sent';report['key']=key
 # Validate the fixed guards after200ms ownedTX, before pausing the desktop. A prior stop prevents injection.
 while time.monotonic_ns()-key['monotonic_ns']<200_000_000:
  for e in read_interlocks(.02):assert e['fields']['state']=='TRANSMITTING','RF ended before injection; no retry'
 report['at_fault']=graph();cohort=[p for p in report['at_fault'] if p['cgroup']==group]
 guards=[p for p in cohort if p['exe']=='/run/aetherpd/bin/pd-unkey-guard'];assert len(guards)==2,('Expected lifetime and bounded guards; no signal sent',guards)
 for g in guards:
  validate(g);args=g['guard_argv'];assert args[1:3]==['3','4'] and int(args[3],16)>0 and int(args[3],16)!=CONFIG['gui_handle'] and int(args[4],16)==CONFIG['gui_handle']
 lifetime=[g for g in guards if len(g['guard_argv'])==5];bounded=[g for g in guards if len(g['guard_argv'])==6 and g['guard_argv'][5]=='9000'];assert len(lifetime)==1 and len(bounded)==1,('Guard role mismatch; no signal sent',guards);report['independent_guards']={'lifetime':lifetime[0],'measurement_9000ms':bounded[0]}
 assert any(p['pid']==target['pid'] and p['start_ticks']==target['start_ticks'] for p in cohort)
 with socket.create_connection((CONFIG['host'],CONFIG['port']),3) as confirm:
  confirm.settimeout(2);confirm.sendall((json.dumps({'nonce':CONFIG['nonce'],'phase':'guards_validated','key':key})+'\n').encode());raw=b''
  while b'\n' not in raw:
   part=confirm.recv(4096);assert part;raw+=part;assert len(raw)<8192
  ack=json.loads(raw);assert ack['nonce']==CONFIG['nonce'] and ack['desktop_stopped'] and ack['pid']==2699295 and ack['start_ticks']==8156132
  report['desktop_stop_ack']={k:v for k,v in ack.items() if k!='nonce'}
 stamp=time.monotonic_ns();report['desktop_pause_ack_ns']=stamp
 end=key['monotonic_ns']/1e9+10;idle=None
 while time.monotonic()<end and idle is None:
  for e in read_interlocks(.02):
   if e['fields']['state']=='READY' and int(e['fields']['tx_client_handle'],16)==0:idle=e;break
 assert idle is not None,'No READY while desktop paused'
 report['unkey']=idle;report['key_to_idle_ms']=(idle['monotonic_ns']-key['monotonic_ns'])/1e6;report['pause_ack_to_idle_ms']=(idle['monotonic_ns']-stamp)/1e6
 assert 8500<=report['key_to_idle_ms']<=9500,'Run ended before deadline window or beyond existing bound'
 time.sleep(.1);report['after']=graph();same=[p for p in report['after'] if p['pid']==target['pid'] and p['start_ticks']==target['start_ticks']];assert len(same)==1;validate(same[0]);assert not same[0]['state'].startswith(('T','t','Z'))
 report['same_DSP_alive']=True;bounded_before=bounded[0]
 p=Path('/proc')/str(bounded_before['pid'])
 try:assert int((p/'stat').read_text().rsplit(')',1)[1].split()[19])!=bounded_before['start_ticks'],'Bounded guardian not reaped'
 except (FileNotFoundError,ProcessLookupError):pass
 report['bounded_guard_original_PID_gone']=True
 report['arp']=[l for l in Path('/proc/net/arp').read_text().splitlines()[1:] if l.split()[0]=='172.30.2.1'];assert len(report['arp'])==1;report['arp_journal_bytes']=Path('/run/.aetherpd-fixed-arp.8600').stat().st_size;assert report['arp_journal_bytes']==64
 unit_names=re.findall(r'aetherpd-start@[0-9]+-[0-9]+-78666\.service',str(group));assert len(unit_names)==1
 report['session_journal']=subprocess.run(['/usr/bin/journalctl','-u',unit_names[0],'-n','120','--no-pager','-o','short-monotonic'],capture_output=True,text=True,timeout=8,check=True).stdout
 report['accept_local']=Path('/proc/sys/net/ipv4/conf/eth0.10/accept_local').read_text().strip();assert report['accept_local']=='0';report['passed']=True
except Exception as e:report['error']=type(e).__name__+': '+str(e)
finally:
 for fd in handles:os.close(fd)
 if observer:observer.close()
 print(json.dumps(report),flush=True)
