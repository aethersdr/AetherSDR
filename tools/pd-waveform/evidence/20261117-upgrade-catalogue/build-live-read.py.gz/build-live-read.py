import shlex,subprocess
from pathlib import Path
E=Path(__file__).resolve().parent;B=E.parent/'first-install-desktop-monitor/project'
lines=subprocess.check_output(['ninja','-C',str(B),'-t','commands','aetherpd_installation_read_test'],text=True).splitlines()
args=shlex.split(next(x for x in lines if x.endswith('/aetherpd_installation_read_test.cpp')))
if args[0]=='ccache':args=args[1:]
old=args[args.index('-o')+1];new=str(E/'live-read.o');source=args[-1];clean=[];i=0
while i<len(args):
 if args[i] in ['-MF','-MT']:i+=2;continue
 if args[i]=='-MD':i+=1;continue
 clean.append(new if args[i]==old else str(E/'live-read.cpp') if args[i]==source else args[i]);i+=1
subprocess.run(clean,cwd=B,check=True)
link=shlex.split(lines[-1]);assert link[:2]==[':', '&&'] and link[-2:]==['&&', ':']
link=[new if x==old else x for x in link[2:-2] if not x.startswith('-Wl,--dependency-file=')]
link[link.index('-o')+1]=str(E/'live-read');subprocess.run(link,cwd=B,check=True)
