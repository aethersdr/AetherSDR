#include "core/AetherPDInstallationRead.h"
#include "core/TailnetShimTokenStore.h"
#include <QCoreApplication>
#include <QJsonDocument>
#include <QJsonObject>
#include <QTextStream>
#include <QTimer>
using namespace AetherSDR;
int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    AetherPDInstallationRead read;
    bool done = false;
    auto finish = [&](bool passed, const QJsonObject& fields) {
        if (done) { return; } done = true;
        QJsonObject report = fields; report.insert("passed", passed);
        report.insert("scope", "One owner-authenticated fixed LAN GET; no mutation, retry, install, RF or reboot");
        QTextStream(stdout) << QJsonDocument(report).toJson(QJsonDocument::Compact) << Qt::endl;
        app.exit(passed ? 0 : 1);
    };
    QObject::connect(&read, &AetherPDInstallationRead::finished, &app, [&] {
        const auto observed = read.observation();
        if (!observed) { finish(false, {{"failure", int(read.failure())}}); return; }
        const bool matches = observed->serial == "2125-1213-8600-8895" && observed->firmware == "4.3.16.42034" && observed->profile == 1
            && observed->selectedDigest == "c3d2522512f66f32025747661335e82eb8a3f572fe9888acf7af8380f9a43404"
            && observed->selectedKey == "9a4286d5d3e006c5237a2fa3cf282ec3b9710a4e1b92b18d80f0122177e5a7ce";
        finish(matches, {{"serial", observed->serial}, {"firmware", observed->firmware}, {"profile", int(observed->profile)},
            {"committed", observed->committed}, {"selected_release_blake2b_256", observed->selectedDigest},
            {"selected_release_key", observed->selectedKey}, {"plan_digest", observed->planDigest}});
    });
    QTimer::singleShot(20000, &app, [&] { finish(false, {{"failure", "bounded observation expired"}}); });
    QTimer::singleShot(0, &app, [&] {
        TailnetShimTokenStore::load("2125-1213-8600-8895", &app, [&](const QString& token) {
            if (done) { return; }
            if (token.isEmpty()) { finish(false, {{"failure", "owner credential unavailable"}}); return; }
            if (!read.begin(QHostAddress("192.168.50.100"), token)) { finish(false, {{"failure", "read refused"}}); }
        });
    });
    return app.exec();
}
