from pathlib import Path
import json, shlex, subprocess
E=Path(__file__).resolve().parent
B=E.parent/'first-install-desktop-monitor/project'
W=E.parent.parent/'aetherpd-source'
mutations=[('inventory-bound', 'src/core/AetherPDInstallationRead.cpp', 'kReplyBytes = 2048', 'kReplyBytes = 4096', 'aetherpd_installation_read_test', 'failuresPublishNoObservation'), ('inventory-deadline', 'src/core/AetherPDInstallationRead.cpp', 'kDeadlineMs = 10000', 'kDeadlineMs = 20000', 'aetherpd_installation_read_test', 'fragmentedReplyDoesNotExtendDeadline'), ('inventory-redirect', 'src/core/AetherPDInstallationRead.cpp', 'QNetworkRequest::ManualRedirectPolicy', 'QNetworkRequest::NoLessSafeRedirectPolicy', 'aetherpd_installation_read_test', 'oneReadHasFixedPathAndNoMutationOrRedirect'), ('predecessor-key', 'src/core/AetherPDReleaseCatalogue.cpp', '&& QString::fromLatin1(entry.release.trust.previousKey.toHex()) == installed.selectedKey', '', 'aetherpd_package_download_test', 'upgradeCatalogueBindsPredecessorKeyProfileModelAndFirmware'), ('approved-recheck', 'src/models/AetherPDInstallationModel.cpp', 'beginInstallationRead(token, true); return;', 'startCoordinator(token); return;', 'aetherpd_installation_coordinator_test', 'catalogueUpgradeChecksBeforeDownloadAndAgainAfterExactApproval'), ('owner-fingerprint', 'src/models/AetherPDInstallationModel.cpp', 'if (tailnetshim::credentialFingerprint(token) != m_inventoryOwnerFingerprint)', 'if (false)', 'aetherpd_installation_coordinator_test', 'catalogueUpgradeChecksBeforeDownloadAndAgainAfterExactApproval'), ('package-identity', 'src/models/AetherPDInstallationModel.cpp', 'if (!m_selectedUpgrade) { return true; }', 'return true;', 'aetherpd_installation_coordinator_test', 'catalogueUpgradeRefusesUnknownInventoryAndMetadataBeforeInstallation'), ('inventory-radio', 'src/models/AetherPDInstallationModel.cpp', 'if (observed->serial != m_serial || observed->firmware != m_firmware) { unavailable(Failure::SessionChanged); return; }', '/* removed radio binding */', 'aetherpd_installation_coordinator_test', 'catalogueUpgradeRefusesUnknownInventoryAndMetadataBeforeInstallation'), ('credential-generation', 'src/models/AetherPDInstallationModel.cpp', 'if (generation != m_generation || m_state != State::LoadingInventoryCredential) { return; }', 'if (m_state != State::LoadingInventoryCredential) { return; }', 'aetherpd_installation_coordinator_test', 'lateInventoryCredentialCannotEnterReplacementPreparation')]
results=[]
for name,source,old,new,target,test in mutations:
 root=E/name;root.mkdir(exist_ok=True)
 path=W/source;text=path.read_text();assert old in text
 patched=root/path.name;patched.write_text(text.replace(old,new))
 lines=subprocess.check_output(['ninja','-C',str(B),'-t','commands',target],text=True).splitlines()
 args=shlex.split(next(line for line in lines if line.endswith('/'+path.name)))
 if args[0]=='ccache':args=args[1:]
 obj=str(root/'mutation.o'); original=args[args.index('-o')+1]
 clean=[];i=0
 while i<len(args):
  if args[i] in ['-MF','-MT']:i+=2;continue
  if args[i]=='-MD':i+=1;continue
  clean.append(obj if args[i]==original else str(patched) if args[i]==str(path) else args[i]);i+=1
 clean+=['-I'+str(path.parent)]
 with (root/'build.log').open('w') as log:subprocess.run(clean,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
 link=shlex.split(lines[-1]);assert link[:2]==[':', '&&'] and link[-2:]==['&&', ':']
 link=[arg for arg in link[2:-2] if not arg.startswith('-Wl,--dependency-file=')]
 binary=root/'test';link[link.index('-o')+1]=str(binary);link.insert(link.index('libaethercore.a'),obj)
 with (root/'link.log').open('w') as log:subprocess.run(link,cwd=B,stdout=log,stderr=subprocess.STDOUT,check=True)
 with (root/'test.log').open('w') as log:r=subprocess.run([str(binary),test],cwd=B,stdout=log,stderr=subprocess.STDOUT,timeout=30)
 report={'name':name,'source':source,'test':test,'exit':r.returncode,'detected':r.returncode>0 and 'FAIL!' in (root/'test.log').read_text()}
 results.append(report);print(json.dumps(report),flush=True)
 assert report['detected'],report
(E/'mutations.json').write_text(json.dumps(results,indent=2)+'\n')
