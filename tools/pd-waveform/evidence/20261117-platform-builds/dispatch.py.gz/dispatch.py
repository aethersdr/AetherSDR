from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,time
P=Path(__file__).resolve().parent;W=P.parents[1]/'aetherpd-source';SHA='239931ebfc212396cb7a28460274dd320b93ec43';BRANCH='feat/aetherpd-shim-integration';REPO='aethersdr/AetherSDR'
assert subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()==SHA and not subprocess.check_output(['git','status','--porcelain'],cwd=W)
plan=P/'dispatch-receipt.json';assert not plan.exists(),'Inspect existing receipts and runs; never redispatch solely on an observation timeout'
def gh(args):return subprocess.run(['gh',*args],capture_output=True,text=True,timeout=35,check=True)
def api(path,params=()):return json.loads(gh(['api','--method','GET',path,*[v for k,x in params for v in ('-f',k+'='+x)]]).stdout)
report={'created_utc':datetime.now(timezone.utc).isoformat(),'commit':SHA,'branch':BRANCH,'mode':'existing unsigned branch-build workflows; no signing, release/Store publication, issues or workflow edits','workflow_sha256':{n:hashlib.sha256((W/'.github/workflows'/n).read_bytes()).hexdigest() for n in ('windows-installer.yml','macos-dmg.yml')},'dispatches':[],'RF_commands':[],'radio_mutations':[]}
write=lambda:plan.write_text(json.dumps(report,indent=2)+'\n');write()
for name,inputs in [('windows-installer.yml',{'publish_store_flight':'false','dev_overrides':'false'}),('macos-dmg.yml',{})]:
 current=api('repos/'+REPO+'/git/ref/heads/'+BRANCH);assert current['object']['sha']==SHA
 params=[('branch',BRANCH),('event','workflow_dispatch'),('head_sha',SHA),('per_page','20')]
 existing=api('repos/'+REPO+'/actions/workflows/'+name+'/runs',params)['workflow_runs']
 exact=[x for x in existing if x['head_sha']==SHA and x['head_branch']==BRANCH]
 row={'workflow':name,'inputs':inputs,'mutation_attempted':False,'reused_existing':bool(exact)};report['dispatches'].append(row);write()
 if not exact:
  row['mutation_attempted']=True;row['requested_utc']=datetime.now(timezone.utc).isoformat();write()
  args=['workflow','run',name,'--repo',REPO,'--ref',BRANCH]
  for k,v in inputs.items():args+=['-f',k+'='+v]
  result=gh(args);row['dispatch_exit']=result.returncode;row['dispatch_stdout']=result.stdout;write()
  end=time.monotonic()+40
  while True:
   exact=[x for x in api('repos/'+REPO+'/actions/workflows/'+name+'/runs',params)['workflow_runs'] if x['head_sha']==SHA and x['head_branch']==BRANCH]
   if exact:break
   if time.monotonic()>=end:row['observation']='not yet visible; receipt retained, do not duplicate';write();raise SystemExit(3)
   time.sleep(1)
 assert len(exact)==1,[(x['id'],x['status']) for x in exact]
 x=exact[0];row['run']={k:x[k] for k in ('id','head_sha','head_branch','status','conclusion','html_url','event','created_at')};write();print(json.dumps(row['run']),flush=True)
