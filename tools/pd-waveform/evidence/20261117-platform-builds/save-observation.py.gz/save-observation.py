from datetime import datetime, timezone
from pathlib import Path
import gzip
import hashlib
import json
import re

P=Path(__file__).resolve().parent
E=P.parent
W=E.parent/'aetherpd-source'
dispatch=json.loads((P/'dispatch-receipt.json').read_text())
raw=json.loads((P/'observed-jobs-and-windows-log.json').read_text())
log=raw['windowsLog']['structuredContent']['content']
assert isinstance(log,str)
lines=log.splitlines()
index=next(i for i,line in enumerate(lines) if 'Downloading ONNX Runtime 1.27.0' in line)
excerpt='\n'.join(lines[index:index+12])+'\n'
(P/'windows-download-failure.log').write_text(excerpt)
windows=raw['windows']['structuredContent']
(P/'windows-jobs.json').write_text(json.dumps(windows,indent=2)+'\n')
mac=json.loads((P/'macos-jobs-2258.json').read_text())
assert all(j['status']=='in_progress' for j in mac['jobs'])
evidence=W/'tools/pd-waveform/evidence/20261117-platform-builds'
evidence.mkdir(exist_ok=False)
names=['dispatch.py','dispatch-receipt.json','dispatch-console.log','run-status-observation.json',
       'run-44192966528.json','run-44192984291.json','windows-jobs.json',
       'windows-download-failure.log','macos-jobs-2258.json','ort-direct-download.json',
       'ort127.json','ort-latest.json','save-observation.py']
hashes={}
for name in names:
    target=evidence/(name+'.gz')
    target.write_bytes(gzip.compress((P/name).read_bytes(),mtime=0))
    hashes[str(target.relative_to(W))]=hashlib.sha256(target.read_bytes()).hexdigest()
now=datetime.now(timezone.utc).isoformat()
report={
    'updated_utc':now, 'source_commit':dispatch['commit'], 'production_ready':False,
    'platform_builds_qualified':False,
    'scope':'Existing feature-branch unsigned application packaging workflows; no signing, release/Store publication, workflow edits, issues or retry. Not the required PR check suite or feature tests.',
    'dispatch':dispatch,
    'windows':{
        'run_id':44192966528,'job_id':134426909409,'status':'completed','conclusion':'failure',
        'failure_step':'Setup ONNX Runtime (Silero VAD + speaker labeling + signal classifier)',
        'cause_observed':'Invoke-WebRequest returned Not Found downloading the pinned official ONNX Runtime1.27.0 Windows x64 archive; configure, compile and packaging were skipped.',
        'failure_excerpt':excerpt, 'direct_download':json.loads((P/'ort-direct-download.json').read_text()),
        'artifacts':[], 'signing_Store_release_jobs':'not executed; package, release and both Store jobs reported skipped',
        'source_fix_claimed':False,'retry_dispatched':False,
        'upstream_listing':{'url':'https://github.com/microsoft/onnxruntime/releases/expanded_assets/v1.27.0',
            'lists_expected_asset':True,'expected_sha256':'c5c81710938e68079ff1a192b04897faabe4b43830d48f39f27ecd4e16138bfc',
            'limit':'Web-tool listing and direct endpoint/API responses disagree. A listed checksum is not verification of downloaded bytes. No conclusion that the project pin/version is invalid and no unreviewed dependency substitution.'}
    },
    'macos':{'run_id':44192984291,'status':'in_progress','conclusion':None,
        'jobs':[{'id':j['id'],'name':j['name'],'status':j['status'],'conclusion':j['conclusion'],'active_steps':[s['name'] for s in j.get('steps',[]) if s['status']=='in_progress']} for j in mac['jobs']],
        'next_action':'Poll this exact run/job handle; do not redispatch on observation timeout. Record final build conclusions and verify publishing/signing guards before claiming artifacts.'},
    'limits':[
        'No Windows application source compiled in this run; no Windows build success is claimed.',
        'Both macOS architecture jobs were authoritatively live when observed. They have not yet produced a successful build result.',
        'An unsigned app build does not qualify platform keychains, complete UI/installer lifecycle, signed distribution, all feature tests or required merge checks.',
        'Manual full-suite and sanitizer workflows were not dispatched because their failure paths automatically write GitHub issues, contrary to local-only tracking.',
        'No radio operation, RF, reboot or installer mutation occurred in this qualification.'
    ],
    'radio_mutations':[],'RF_commands':[],'reboot_commands':[], 'evidence_sha256':hashes
}
(W/'tools/pd-waveform/PLATFORM-BUILD-OBSERVATION.json').write_text(json.dumps(report,indent=2)+'\n')
plan_path=E/'production-completion-plan-20261113.json'
plan=json.loads(plan_path.read_text())
plan['updated_utc']=now
plan['platform_builds']={'report':'tools/pd-waveform/PLATFORM-BUILD-OBSERVATION.json','source_commit':dispatch['commit'],
    'windows':{'run_id':44192966528,'state':'failed_before_compile_ONNX_HTTP404','qualified':False},
    'macos':{'run_id':44192984291,'state':'both_architecture_jobs_verified_live','qualified':False},
    'no_issue_writing_workflow_dispatched':True,'production_ready':False}
plan_path.write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'report':'PLATFORM-BUILD-OBSERVATION.json','evidence_files':len(hashes),'Windows':'pre-compile dependency download failure','macOS':'verified live, not qualified'}))
