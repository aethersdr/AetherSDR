import ast,json,pathlib,re,secrets,select,socket,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent
sys.path.insert(0,str(BASE.parent/'aetherpd-source/tools'));from automation_probe import Bridge
assert not (ROOT/'outcome.json').exists(),'Preserve each attempt'
instance=json.loads((BASE/'receive-reply-routing-live/instance.json').read_text())
b=Bridge(instance['socket']);events=[];report={'passed':False,'RF_commands':[],'credential_mutations':[],'Start_actions':0}
job=None;started=False;disconnected=False;conn=None
listener=socket.socket();listener.bind(('0.0.0.0',0));listener.listen(1);listener.settimeout(.5)
def record(kind,**kw):
 events.append({'event':kind,'monotonic_ns':time.monotonic_ns(),**kw});(ROOT/'events.json').write_text(json.dumps(events,indent=2)+'\n')
def req(q):
 r=b.request(q,8);record('bridge',request=q,result=r);assert r.get('ok'),r;return r
def status():
 p=subprocess.run([str(BASE/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=22)
 r=json.loads(p.stdout);record('service_status',result=r);return r
def panel():
 tree=b.request({'cmd':'dumpTree','target':'AetherPDDialog'},5);assert tree.get('ok'),tree
 result={}
 def visit(x):
  if isinstance(x,dict):
   name=x.get('objectName','')
   if name.startswith('pd'):result[name]={k:x[k] for k in ['value','enabled','toolTip','accessibleDescription'] if k in x}
   for value in x.get('children',[]):visit(value)
  elif isinstance(x,list):
   for value in x:visit(value)
 for root in tree.get('roots',[]):
  if root.get('objectName')=='AetherPDDialog' and root.get('visible'):visit(root)
 assert result,'No visible AetherPD panel';record('panel_controls',controls=result);return result
def stale_panel():
 controls=panel()
 for name in ['pdStart','pdStop','pdCalibrationArm','pdMeasurementArm']:
  if name in controls:assert controls[name].get('enabled') is False,(name,controls[name])
 result=b.request({'cmd':'invoke','target':'pdStart','action':'click'},5);record('stale_Start_refusal',result=result);assert not result.get('ok'),result
 return {'controls':controls,'stale_Start_refusal':result}
def connect_again():
 global disconnected
 req({'cmd':'connect','action':'local','value':'serial 2125-1213-8600-8895'});deadline=time.monotonic()+30
 while True:
  radio=req({'cmd':'get','model':'radio'})['radio']
  if radio['connected']:
   assert not radio['transmitting'] and not radio['fullDuplex'] and radio['serial']=='2125-1213-8600-8895'
   pans=req({'cmd':'get','model':'pans'})['pans'];slices=req({'cmd':'get','model':'slices'})['slices']
   if len(pans)==1 and pans[0]['ownedByUs'] and len(slices)==1:
    assert pans[0]['rxAntenna']=='RX_A' and pans[0]['rfGain']==0 and slices[0]['mode']=='USB'
    disconnected=False;return radio,pans,slices
  assert time.monotonic()<deadline,'Receiver readiness deadline';time.sleep(.2)
def read_notice(deadline):
 data=b''
 while b'\n' not in data:
  assert time.monotonic()<deadline,'Observer message deadline'
  if select.select([conn],[],[],.15)[0]:
   part=conn.recv(4096);assert part,'Observer connection closed';data+=part;assert len(data)<8192
  radio=b.request({'cmd':'get','model':'radio'},5)['radio'];assert not radio['transmitting'] and not radio['fullDuplex']
 result=json.loads(data);assert result['nonce']==config['nonce'];return result
try:
 who=req({'cmd':'whoami'});assert who['pid']==instance['pid'] and who['automationIdentity']=='aetherpd-shim-integration';report['whoami']=who
 radio=req({'cmd':'get','model':'radio'})['radio'];assert radio['connected'] and not radio['transmitting'] and not radio['fullDuplex'];report['radio_before']=radio
 pans=req({'cmd':'get','model':'pans'})['pans'];slices=req({'cmd':'get','model':'slices'})['slices']
 assert len(pans)==1 and pans[0]['ownedByUs'] and pans[0]['rxAntenna']=='RX_A' and pans[0]['rfGain']==0 and abs(pans[0]['centerMhz']-7.15)<1e-6
 assert len(slices)==1 and slices[0]['mode']=='USB';report['pans_before']=pans;report['slices_before']=slices
 assert status()['body'].get('state')=='stopped';panel()
 req({'cmd':'invoke','target':'pdIqSelection','action':'setCurrentIndex','value':1});req({'cmd':'invoke','target':'pdStart','action':'click'});started=True;report['Start_actions']+=1
 deadline=time.monotonic()+35
 while True:
  current=status()
  if current['http_status']==200 and current['body'].get('registered'):break
  assert time.monotonic()<deadline,current;time.sleep(.5)
 binding=current['body']['feedback_binding'];assert binding['valid'] and binding['channel']==4 and binding['gui_handle']==int(pans[0]['clientHandle'],16) and binding['pan']==int(pans[0]['panId'],16)
 assert not current['body']['keyed'] and not current['body']['correcting'];report['registered_before']=current
 route=socket.socket(socket.AF_INET,socket.SOCK_DGRAM);route.connect(('192.168.50.100',4992))
 plan=json.loads((BASE/'receive-reply-routing-live/prepared.json').read_text())['panel']['pdInstallPlan']['value']
 config={'host':route.getsockname()[0],'port':listener.getsockname()[1],'nonce':secrets.token_hex(24),'gui_handle':pans[0]['clientHandle'],'pan':pans[0]['panId'],'desktop_pid':who['pid'],'generation':re.search(r'Attempt \(BLAKE2b-256\): ([0-9a-f]{64})',plan).group(1)};route.close()
 prefix="import hashlib,json,os,re,select,socket,subprocess,time\nfrom pathlib import Path\nCONFIG="+repr(config)+"\nreport={'probe_complete':False,'passed':False,'signals':[],'RF_commands':[],'API_observations':[],'changes':[]};started=time.monotonic();observer=None;notice=None;handles=[];api_buffer=b''\n"
 source=prefix+(ROOT/'observer-functions.py').read_text()+'\n'+(ROOT/'observer-tail.py').read_text();ast.parse(source);(ROOT/'observe-job.py').write_text(source)
 with (ROOT/'orchestration.log').open('w') as log:job=subprocess.Popen([sys.executable,str(ROOT/'run-job.py'),'observe'],stdout=log,stderr=subprocess.STDOUT)
 deadline=time.monotonic()+120
 while conn is None:
  try:conn,_=listener.accept()
  except socket.timeout:assert job.poll() is None and time.monotonic()<deadline,'Observer unavailable; no disconnect requested'
 conn.setblocking(False);notice=read_notice(time.monotonic()+10);assert notice['ready'];record('observer_ready')
 req({'cmd':'disconnect'});disconnected=True;deadline=time.monotonic()+8
 while req({'cmd':'get','model':'radio'})['radio']['connected']:
  assert time.monotonic()<deadline;time.sleep(.05)
 conn.sendall((json.dumps({'nonce':config['nonce'],'disconnected_observed':True,'pid':who['pid']})+'\n').encode());report['stale_while_disconnected']=stale_panel()
 # General GUI state reads do not renew the private channel. No PD HTTP reads
 # are made until both disconnected and reconnected observation windows finish.
 notice=read_notice(time.monotonic()+40);assert notice['phase']=='disconnected_window_complete';report['disconnected_window_survivor_count']=notice['survivor_count']
 radio,new,slices=connect_again();report['radio_after_reconnect']=radio;report['pans_after_reconnect']=new;report['slices_after_reconnect']=slices
 assert new[0]['clientHandle']!=pans[0]['clientHandle'];report['stale_after_reconnect']=stale_panel()
 conn.sendall((json.dumps({'nonce':config['nonce'],'reconnected_observed':True,'pid':who['pid'],'new_gui_handle':new[0]['clientHandle']})+'\n').encode())
 deadline=time.monotonic()+45
 while job.poll() is None:
  radio=b.request({'cmd':'get','model':'radio'},5)['radio'];assert radio['connected'] and not radio['transmitting'] and not radio['fullDuplex'];assert time.monotonic()<deadline;time.sleep(.3)
 assert job.returncode==0
 outer=json.loads((ROOT/'observe-result.json').read_text());probe=json.loads(outer['logs']);report['probe']=probe
 assert outer['wait']['StatusCode']==0 and outer['job_container_deleted'] and outer['temporary_host_directory_deleted'] and probe['probe_complete'],probe
 report['status_after_probe']=status();started=False
 req({'cmd':'invoke','target':'pdDone','action':'click'});time.sleep(.2);req({'cmd':'invoke','target':'Waveforms...','action':'trigger'});req({'cmd':'invoke','target':'openAetherPD','action':'click'});report['fresh_panel_opened']=True
 report['passed']=probe['passed']
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
 if conn:conn.close()
 if disconnected:
  try:report['fallback_receiver']=connect_again()
  except Exception as error:report['fallback_reconnect_error']=str(error)
 if job and job.poll() is None:
  try:job.wait(timeout=55)
  except subprocess.TimeoutExpired:report['observer_still_running']=True
 if started and not disconnected and not report.get('observer_still_running'):
  try:
   req({'cmd':'invoke','target':'pdDone','action':'click'});time.sleep(.2);req({'cmd':'invoke','target':'Waveforms...','action':'trigger'});req({'cmd':'invoke','target':'openAetherPD','action':'click'});report['fallback_Stop']=req({'cmd':'invoke','target':'pdStop','action':'click'})
  except Exception as error:report['fallback_Stop_error']=str(error)
 listener.close();b.close();(ROOT/'outcome.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['passed','error','Start_actions','disconnected_window_survivor_count','fallback_reconnect_error','fallback_Stop_error','observer_still_running'] if k in report}),flush=True)
 if not report['passed']:raise SystemExit(1)
