#include <math.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>
enum { RATE=24000, TAPS=127, kSamples=4*RATE };
typedef struct {
    double hr[TAPS], hi[TAPS];   // complex taps
    double z[TAPS];              // real input history
    int pos;
} cbp_t;

// Complex band-pass for USB: a low-pass of half-width (hi-lo)/2 shifted to
// the band's centre. Fed a real signal, it outputs the analytic signal of
// the band lo..hi, which is upper-sideband I/Q.
static void cbp_init(cbp_t* f, double lo, double hi)
{
    memset(f, 0, sizeof *f);
    double fc = (hi - lo) / 2 / RATE, f0 = (hi + lo) / 2 / RATE, sum = 0;
    double lp[TAPS];
    for (int n = 0; n < TAPS; n++) {
        int m = n - (TAPS - 1) / 2;
        double s = m == 0 ? 2 * fc : sin(2 * M_PI * fc * m) / (M_PI * m);
        double w = 0.42 - 0.5 * cos(2 * M_PI * n / (TAPS - 1)) + 0.08 * cos(4 * M_PI * n / (TAPS - 1));
        lp[n] = s * w;
        sum += lp[n];
    }
    for (int n = 0; n < TAPS; n++) {
        int m = n - (TAPS - 1) / 2;
        f->hr[n] = lp[n] / sum * cos(2 * M_PI * f0 * m);
        f->hi[n] = lp[n] / sum * sin(2 * M_PI * f0 * m);
    }
}

static void cbp_step(cbp_t* f, double x, double* i, double* q)
{
    f->z[f->pos] = x;
    double si = 0, sq = 0;
    int k = f->pos;
    for (int n = 0; n < TAPS; n++) {
        si += f->hr[n] * f->z[k];
        sq += f->hi[n] * f->z[k];
        k = k == 0 ? TAPS - 1 : k - 1;
    }
    f->pos = (f->pos + 1) % TAPS;
    // The real input's positive-frequency half carries half its amplitude.
    *i = 2 * si;
    *q = 2 * sq;
}


static double uniform(uint32_t* seed)
{
    *seed=*seed*1664525u+1013904223u;
    return ((*seed>>8)/16777216.0)-0.5;
}
int main(void)
{
    const char* names[]={"native-real-input.f64le","proper-complex-input.f64le"};
    for(int mode=0;mode<2;++mode){
        cbp_t real_filter,imag_filter;
        cbp_init(&real_filter,-4500,7500);
        cbp_init(&imag_filter,-4500,7500);
        uint32_t seed=12345;
        FILE* file=fopen(names[mode],"wb");
        if(!file){return 2;}
        for(int n=0;n<kSamples;++n){
            const double scale=0.57*0.7*(mode?1.0/sqrt(2.0):1.0);
            double ri,rq,ii=0,iq=0;
            cbp_step(&real_filter,scale*uniform(&seed),&ri,&rq);
            if(mode){cbp_step(&imag_filter,scale*uniform(&seed),&ii,&iq);}
            const double value[]={ri,rq};
            if(!isfinite(value[0])||!isfinite(value[1])||hypot(value[0],value[1])>0.7){fclose(file);return 3;}
            if(fwrite(value,sizeof(double),2,file)!=2){fclose(file);return 4;}
        }
        if(fclose(file)){return 5;}
    }
    return 0;
}
