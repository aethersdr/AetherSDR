from pathlib import Path
import subprocess,json,hashlib
p=Path(__file__).resolve().parent;source=(p/'prototype.c').read_text();validation=(p/'validate.py').read_text().replace("p.parent.parent/'aetherpd-source'","Path('/home/jeremy/AetherSDR/build/aetherpd-source')").replace('assert error<1e-12','assert error<1e-12,(name,error)');results=[]
for name,old,new in [('missing-imaginary','const double value[]={ri-iq,rq+ii};','const double value[]={ri,rq};'),('missing-normalization','(mode?1.0/sqrt(2.0):1.0)','1.0')]:
 assert source.count(old)==1;d=p.parent/('proper-complex-mutant-'+name);d.mkdir(exist_ok=False);(d/'prototype.c').write_text(source.replace(old,new));(d/'validate.py').write_text(validation)
 with (d/'build-run.log').open('w') as f:
  subprocess.run(['cc','-O2','-std=gnu11','-Wall','-Wextra','-Werror','prototype.c','-lm','-o','prototype'],cwd=d,stdout=f,stderr=subprocess.STDOUT,check=True);subprocess.run(['./prototype'],cwd=d,stdout=f,stderr=subprocess.STDOUT,check=True)
 with (d/'validation.log').open('w') as f:r=subprocess.run(['python3',str(d/'validate.py')],stdout=f,stderr=subprocess.STDOUT)
 log=(d/'validation.log').read_text();assert r.returncode==1 and "('proper-complex-input'," in log,(name,r.returncode,log)
 results.append({'mutant':name,'validation_exit':r.returncode,'expected_failure':log.splitlines()[-1],'source_sha256':hashlib.sha256((d/'prototype.c').read_bytes()).hexdigest()})
assert (p/'prototype.c').read_text()==source
with (p/'validation-final.log').open('w') as f:subprocess.run(['python3',str(p/'validate.py')],stdout=f,stderr=subprocess.STDOUT,check=True)
(p/'mutations.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps({'mutations':results,'original_C_source_unchanged_and_final_validation_passed':True}))
