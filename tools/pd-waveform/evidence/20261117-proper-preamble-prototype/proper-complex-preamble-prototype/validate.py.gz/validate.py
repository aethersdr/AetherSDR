from pathlib import Path
import ctypes as C,json,hashlib,subprocess,sys
import numpy as np
p=Path(__file__).resolve().parent;w=p.parent.parent/'aetherpd-source';src=w/'tools/pd-waveform';assert sys.byteorder=='little'
cmd=['cc','-shared','-fPIC','-O2','-std=gnu11','-Wall','-Wextra','-Werror',str(src/'pd_align.c'),str(src/'pd_eq.c'),'-lm','-o',str(p/'libprototype-validation.so')]
with (p/'validation-build.log').open('w') as f:subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True)
lib=C.CDLL(str(p/'libprototype-validation.so'));D=C.POINTER(C.c_double)
for name,args,ret in [('pd_align_create',[C.c_int,C.c_int],C.c_void_p),('pd_align_destroy',[C.c_void_p],None),('pd_align_estimate_delay',[C.c_void_p,D,D,C.c_int],C.c_double),('pd_align_phase_corr',[C.c_void_p],C.c_double),('pd_eq_create',[C.c_int],C.c_void_p),('pd_eq_destroy',[C.c_void_p],None),('pd_eq_train',[C.c_void_p,D,D,C.c_int],None),('pd_eq_solve',[C.c_void_p],C.c_int),('pd_eq_residual',[C.c_void_p],C.c_double),('pd_eq_apply',[C.c_void_p,D,D,C.c_int,D,D],C.c_int)]:
 f=getattr(lib,name);f.argtypes=args;f.restype=ret
ptr=lambda a:a.ctypes.data_as(D)
rate=24000;n=4*rate;nt=127;m=np.arange(nt)-(nt-1)/2;fc=.25;f0=1500/rate;lp=2*fc*np.sinc(2*fc*m)*(.42-.5*np.cos(2*np.pi*np.arange(nt)/(nt-1))+.08*np.cos(4*np.pi*np.arange(nt)/(nt-1)));h=lp/lp.sum()*np.exp(2j*np.pi*f0*m)
def white(count):
 seed=12345;u=np.empty(count)
 for k in range(count):seed=(seed*1664525+1013904223)&0xffffffff;u[k]=((seed>>8)/16777216.)-.5
 return u
u=white(n);uv=white(2*n).reshape(-1,2);replays=[2*np.convolve(.57*.7*u,h)[:n],2*np.convolve(.57*.7*(uv[:,0]+1j*uv[:,1])/np.sqrt(2),h)[:n]];results=[]
for mode,name in enumerate(['native-real-input','proper-complex-input']):
 f=p/(name+'.f64le');assert f.stat().st_size==n*16;z=np.fromfile(f,dtype='<c16');assert np.isfinite(z).all();error=float(abs(z-replays[mode]).max());assert error<1e-12
 core=z[nt:];power=float(np.mean(abs(core)**2));circularity=float(abs(np.mean((core-core.mean())**2))/np.mean(abs(core-core.mean())**2));assert abs(z).max()<.7
 fft=np.fft.fft(z);freq=np.fft.fftfreq(n,1/rate);P=abs(fft)**2;outside=float(P[(freq< -4500)|(freq>7500)].sum()/P.sum());assert outside<.03
 bands=[float(P[(freq>=a)&(freq<=b)].sum()) for a,b in [(-4000,-2000),(-1000,1000),(2000,4000),(5000,7000)]]
 # Known fractional delay, phase and small frequency offset on a flat linear path.
 count=48000;delay=1677.47;length=131072;binfreq=np.fft.fftfreq(length);delayed=np.fft.ifft(np.fft.fft(z[:count],length)*np.exp(-2j*np.pi*binfreq*delay))[:count];rx=np.ascontiguousarray(.82*delayed*np.exp(1j*(.3+2*np.pi*(-.03)*np.arange(count)/rate)),dtype=np.complex128);tx=np.ascontiguousarray(z[:count]);align=lib.pd_align_create(4096,2*count);assert align
 try:
  estimate=lib.pd_align_estimate_delay(align,ptr(tx),ptr(rx),count);phase=lib.pd_align_phase_corr(align);assert abs(estimate-delay)<.05 and phase>.99,(name,estimate,phase)
 finally:lib.pd_align_destroy(align)
 # Train the actual equalizer on one half; test a known nonflat linear path on held-out samples.
 channel=np.zeros(6,dtype=np.complex128);channel[0]=.82;channel[2]=.07+.04j;channel[5]=-.03j;filtered=np.ascontiguousarray(np.convolve(z,channel)[:n]);eq=lib.pd_eq_create(31);assert eq
 try:
  txall=np.ascontiguousarray(z);lib.pd_eq_train(eq,ptr(txall),ptr(filtered),count);assert lib.pd_eq_solve(eq)==1;training_residual=lib.pd_eq_residual(eq)
  test=np.ascontiguousarray(z[count:]);test_rx=np.ascontiguousarray(filtered[count:]);out=np.empty(n-count,dtype=np.complex128);feedback=np.empty_like(out);valid=lib.pd_eq_apply(eq,ptr(test),ptr(test_rx),len(test),ptr(out),ptr(feedback));assert valid>count-64
  prediction=out[:valid];target=feedback[:valid];gain=np.vdot(prediction,target)/np.vdot(prediction,prediction);residual=float(np.mean(abs(target-gain*prediction)**2)/np.mean(abs(target)**2));assert residual<1e-4,(name,residual)
 finally:lib.pd_eq_destroy(eq)
 results.append({'source':name,'sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'C_vs_NumPy_max_abs_error':error,'RMS':power**.5,'peak':float(abs(z).max()),'circularity':circularity,'outside_nominal_band_power_fraction':outside,'subband_powers':bands,'estimated_known_delay':estimate,'known_delay_error_samples':estimate-delay,'alignment_phase_correlation':phase,'EQ_training_residual':training_residual,'EQ_heldout_shape_residual':residual,'EQ_heldout_samples':valid})
assert results[0]['circularity']>.7 and results[1]['circularity']<.02
RMSdelta=20*np.log10(results[1]['RMS']/results[0]['RMS']);assert abs(RMSdelta)<.05
banddelta=[float(10*np.log10(a/b)) for a,b in zip(results[1]['subband_powers'],results[0]['subband_powers'])];assert max(abs(x) for x in banddelta)<.5
report={'passed':True,'sources':results,'proper_minus_native_RMS_dB':float(RMSdelta),'proper_minus_native_subband_power_dB':banddelta,'validation_compile_command':cmd,'compiler':subprocess.check_output(['cc','--version'],text=True).splitlines()[0],'actual_native_component_sha256':{name:hashlib.sha256((src/name).read_bytes()).hexdigest() for name in ['pd_align.c','pd_eq.c']},'scope':'Host-only C generator using unchanged native cbp functions, independently checked against NumPy; actual native alignment and EQ components tested with known synthetic channels.','limits':['No radio deployment or RF test of the proper-complex source.','No SWR-causality conclusion; no production/default/guard changes.','No actual6300 CPU/deadline or full WDSP/waveform-dispatch integration qualification.']}
(p/'validation.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report,indent=2))
