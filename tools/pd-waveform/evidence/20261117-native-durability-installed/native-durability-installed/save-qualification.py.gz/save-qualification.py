from pathlib import Path
from datetime import datetime, timezone
import gzip,hashlib,json

P=Path(__file__).resolve().parent;E=P.parent;W=E.parent/'aetherpd-source';L=E/'native-durability-lifecycle-01'
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
installation=read(P/'install-result.json');session=read(L/'api-outcome.json');outer=read(L/'api-result.json');fault=json.loads(outer['logs']);audit_outer=read(L/'audit-result.json');audit=json.loads(audit_outer['logs'])
assert installation['committed'] and 'Temporary installer cleanup confirmed.' in installation['latest']['pdInstallState']['value']
assert not installation['diagnostics_used_for_delivery'] and installation['candidate_source']=='aa5a33fc5de78ad5a9d6e5d48ba2e9c697e03bf0'
assert session['passed'] and fault['stopped_verified'] and fault['primary_restart_verified'] and fault['journal']['dropped']==0 and audit['passed']
assert all(outer[k] and audit_outer[k] for k in ['job_container_deleted','temporary_host_directory_deleted'])
assert session['existing_effective_routes_save']['passed'] and session['final_stop']['body']['state']=='stopped'
assert session['installation_after']['body']['selected_release_blake2b_256']=='c3d2522512f66f32025747661335e82eb8a3f572fe9888acf7af8380f9a43404'
assert all(session[k]['bytes']==131072 for k in ['capture_before','capture_after_restart','capture_after_configuration_save'])
now=datetime.now(timezone.utc).isoformat()
report={'updated_utc':now,'status':'ordinary_desktop_update_receive_only_whole_service_restart_fresh_IQ_and_native_config_save_qualified_software_reboot_unqualified',
 'production_ready':False,'runtime_source_commit':'aa5a33fc5de78ad5a9d6e5d48ba2e9c697e03bf0',
 'release_blake2b_256':'c3d2522512f66f32025747661335e82eb8a3f572fe9888acf7af8380f9a43404',
 'previous_release_blake2b_256':'a8920b11a650ce36118589f818712636bae56f35b3b1570c8a8c8f6d404f0a3f',
 'runtime_report':'tools/pd-waveform/NATIVE-IDENTITY-DURABILITY-RUNTIME-QUALIFICATION.json',
 'desktop_source_commit':'5d8d6070f28d478a65c853f3ca5d2a9224016342','desktop_sha256':session['desktop_sha256'],
 'ordinary_update':{'committed':True,'elapsed_s':installation['elapsed_s'],'exact_operator_plan_reviewed':True,
 'diagnostics_used_for_delivery':False,'predecessor_credential_used_for_delivery':True,'terminal':installation['latest']['pdInstallState']['value'],
 'installation_id':audit['installation_id'],'owner_verifier_fingerprint':audit['owner_verifier_fingerprint']},
 'receive_only_lifecycle':{'FDX':False,'boot_id':fault['boot_id'],'unkeyed_PD_mode_used':True,'original_graph_processes_including_zombies':len(fault['before']),
 'all_original_processes_gone_ms':fault['retired_ms'],'primary_service_ready_ms':fault['primary_ready_ms'],'firmware_PID_before':fault['firmware_before']['MainPID'],
 'firmware_PID_after':fault['firmware_after']['MainPID'],'firmware_stop_or_restart_requested':False,'explicit_Start_required_for_new_IQ_session':True,
 'ordinary_Start_before_s':session['first_start']['ready_s'],'ordinary_Start_after_s':session['restart']['ready_s'],
 'capture_before':session['capture_before'],'capture_after_restart':session['capture_after_restart'],'capture_after_configuration_save':session['capture_after_configuration_save'],
 'final_status':session['final_stop'],'journal_dropped':fault['journal']['dropped'],'owner_configuration_unchanged_through_service_fault':fault['owner_config_before']==fault['owner_config_after']},
 'ordinary_native_configuration_write':{'client_receipt':session['existing_effective_routes_save'],'positive_write_path':'Authenticated PUT /v1/routes on the installed primary, with the currently observed effective routes and no discovered-sharing replacement.',
 'after_write_complete_finite_local_IQ':True,'final_owner_verifier_preserved':True,'configuration_sha256_before_write':fault['owner_config_after'],
 'configuration_sha256_after_write':audit['owner_config_sha256'],'note':'The public save serializes the configuration and an explicit empty routes array. File bytes changed; effective routes/sharing and the owner verifier were independently preserved. Client elapsed_s includes keychain and GET/PUT/GET; it is not fsync duration or FPGA/IQ latency.'},
 'final_independent_native_audit':audit,'RF_commands':[],'reboot_commands':[],'credential_mutations':[],
 'limitations':['Receive-only FLEX-8600 proof. No keyed teardown, new-package RF/stockAPD comparison, firmware stop or whole-system shutdown.',
 'Operator-confirmed prior green-LED reboot lockup requiring rear DC removal remains failed and unexplained. No reboot retry; bench recovery coordination remains pending.',
 'The ordinary successful native configuration save exercises this candidate on the radio filesystem. No storage error or physical power loss was induced; directory/ancestor/controller and complete transaction durability remain unqualified.',
 'Privileged laboratory observer stopped/restarted the fixed installed service group and read metadata. It did not deliver the update. Its temporary job and scratch were removed; the existing diagnostics transport is not part of the shipped product.',
 'Only a local managed identity was exercised; joined-account log growth, owner-loss/rotation and cross-platform credential store qualification remain open.',
 'Actual FLEX6300 adapter, /run layout, Linux2.6/Cortex-A8/one-core execution, storage high-water and RF remain unqualified.',
 'Full original P1-P10 remains active. The operator-deferred5W SWR/preamble investigation remains deferred.']}
destination=W/'tools/pd-waveform/evidence/20261117-native-durability-installed';destination.mkdir(exist_ok=False);hashes={}
paths=[]
for directory in [P,L]:paths.extend(path for path in directory.iterdir() if path.is_file() and path.suffix in ['.py','.json','.log','.cpp','.f32le'] and path.name!='desktop.log')
for path in sorted(paths):
 target=destination/(str(path.relative_to(E))+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(path.read_bytes(),mtime=0));assert gzip.decompress(target.read_bytes())==path.read_bytes();hashes[str(target.relative_to(W))]=sha(target)
report['evidence_sha256']=hashes
plan_path=E/'production-completion-plan-20261113.json';plan=read(plan_path);plan['updated_utc']=now
plan['current_candidate'].update(source_commit=report['runtime_source_commit'],selected_release_blake2b_256=report['release_blake2b_256'],installed_receive_only_whole_graph_and_fresh_IQ_qualified=True,ordinary_native_identity_directory_write_qualified=True,RF_qualified_on_this_package=False,software_reboot_qualified=False,production_ready=False)
entry=plan['native_identity_durability'];entry.update(installed=True,installed_report='tools/pd-waveform/NATIVE-IDENTITY-DURABILITY-INSTALLED-QUALIFICATION.json',ordinary_update_passed=True,receive_only_IQ_and_service_restart_passed=True,ordinary_same_effective_routes_write_passed=True,actual_power_loss_qualified=False)
entry['runtime_build']['installed']=True;entry['upgrade_distribution']['installed']=True
entry['desktop']={'source_commit':report['desktop_source_commit'],'instance':read(P/'instance.json')}
entry['current_owner_configuration_sha256']=audit['owner_config_sha256'];entry['old_configuration_sha256_before_reflexive_save']=fault['owner_config_after']
plan['next_action']='Preserve installedc3d252/aa5 and ordinary native configuration-write/receive-only restart evidence. Continue remaining originalP1-P10 production work without retrying software reboot until pending operator bench-presence/rear-power recovery coordination is answered. Actual6300 adapter/kernel/layout/storage, interrupted-transaction/power-loss boundaries and ancestor durability, final keyed faults/alignment/RF/stockAPD, joined-account/owner recovery/platform stores and independent release gates remain. Deferred5W SWR/preamble remains deferred.';write(plan_path,plan)
target=destination/'production-completion-plan.json.gz';target.write_bytes(gzip.compress(plan_path.read_bytes(),mtime=0));hashes[str(target.relative_to(W))]=sha(target)
write(W/'tools/pd-waveform/NATIVE-IDENTITY-DURABILITY-INSTALLED-QUALIFICATION.json',report)
print(json.dumps({'evidence_files':len(hashes),'installed':True,'retired_ms':fault['retired_ms'],'fresh_IQ_captures':3,'configuration_file_bytes':audit['owner_config_file_bytes'],'software_reboot_qualified':False}))
