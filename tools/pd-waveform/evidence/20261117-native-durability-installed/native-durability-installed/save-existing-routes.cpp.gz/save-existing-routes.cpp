#include "core/TailnetShimTokenStore.h"
#include <QCoreApplication>
#include <QCryptographicHash>
#include <QEventLoop>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkProxy>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QRegularExpression>
#include <QTimer>
#include <cstdio>
#include <optional>

using namespace AetherSDR;
int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("AetherSDR"));
    if (argc != 1) { return 2; }
    QTimer::singleShot(30000, &app, [&] { app.exit(3); });
    TailnetShimTokenStore::load(QStringLiteral("2125-1213-8600-8895"), &app, [&](const QString& token) {
        if (!QRegularExpression(QStringLiteral("\\A[0-9a-f]{64}\\z")).match(token).hasMatch()) { app.exit(4); return; }
        QNetworkAccessManager network;
        network.setProxy(QNetworkProxy::NoProxy);
        const auto exchange = [&](bool save, const QJsonObject& body = {}) -> std::optional<QJsonObject> {
            QNetworkRequest request(QUrl(save ? QStringLiteral("http://192.168.50.100:48992/v1/routes")
                                              : QStringLiteral("http://192.168.50.100:48992/v1/status")));
            request.setAttribute(QNetworkRequest::RedirectPolicyAttribute, QNetworkRequest::ManualRedirectPolicy);
            request.setRawHeader("Authorization", "Bearer " + token.toLatin1());
            request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
            request.setTransferTimeout(10000);
            QNetworkReply* reply = save ? network.put(request, QJsonDocument(body).toJson(QJsonDocument::Compact)) : network.get(request);
            QEventLoop loop;
            QObject::connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
            loop.exec();
            const int code = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
            const QByteArray bytes = reply->read(65537);
            const QJsonDocument document = QJsonDocument::fromJson(bytes);
            reply->deleteLater();
            if (code != 200 || bytes.size() > 65536 || !document.isObject()) { return std::nullopt; }
            return document.object();
        };
        const auto before = exchange(false);
        const QString identity = QStringLiteral("b6050e0036d2cfe91bce6f36c8c88faaea90e86722dd13c710a57015adb53654");
        if (!before || before->value(QStringLiteral("installation_id")).toString() != identity
            || before->value(QStringLiteral("managed_owner_version")).toInt() != 1
            || before->value(QStringLiteral("state")).toString() != QStringLiteral("local")
            || before->value(QStringLiteral("claimable")).toBool(true)
            || !before->value(QStringLiteral("tailnet_ip")).toString().isEmpty()
            || !before->value(QStringLiteral("routes")).isArray()) { app.exit(5); return; }
        // Preserve effective routes and leave the discovered-device setting absent
        // so its existing explicit value or default remains owned by the radio.
        const QJsonObject body{{QStringLiteral("routes"), before->value(QStringLiteral("routes"))}};
        const auto saved = exchange(true, body);
        const auto after = saved ? exchange(false) : std::nullopt;
        if (!saved || !after || after->value(QStringLiteral("installation_id")).toString() != identity
            || after->value(QStringLiteral("managed_owner_version")).toInt() != 1
            || after->value(QStringLiteral("state")).toString() != QStringLiteral("local")
            || after->value(QStringLiteral("claimable")).toBool(true)
            || after->value(QStringLiteral("routes")) != before->value(QStringLiteral("routes"))
            || after->value(QStringLiteral("share_discovered")) != before->value(QStringLiteral("share_discovered"))
            || !after->value(QStringLiteral("tailnet_ip")).toString().isEmpty()) { app.exit(6); return; }
        const QByteArray verifier = QCryptographicHash::hash(token.toLatin1(), QCryptographicHash::Sha256).toHex();
        const QJsonObject result{{QStringLiteral("passed"), true}, {QStringLiteral("http_status"), 200},
            {QStringLiteral("PUT_routes_requests"), 1}, {QStringLiteral("effective_routes_and_sharing_unchanged"), true},
            {QStringLiteral("installation_id"), identity}, {QStringLiteral("state"), QStringLiteral("local")},
            {QStringLiteral("owner_verifier_fingerprint"), QString::fromLatin1(QCryptographicHash::hash(verifier, QCryptographicHash::Sha256).toHex())}};
        const QByteArray output = QJsonDocument(result).toJson(QJsonDocument::Compact);
        std::fwrite(output.constData(), 1, output.size(), stdout);
        std::puts(""); app.exit(0);
    });
    return app.exec();
}
