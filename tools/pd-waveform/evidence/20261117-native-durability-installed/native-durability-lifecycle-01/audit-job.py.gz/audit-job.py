EXPECTED={'pd-primary-launch': 'decf786355f10450819a2ee8645089873084f6745424dc495111c65df59c7ce5', 'pd-start-session': '568641ceb68da3176abfb42b996d521db4f5604d8a026c7add754168f752a47b', 'pd-radio-launch': '262a370c286bb07d1751b01211b0ca76ec75ebd29d2e1230111128ccd554b773', 'pd-fixed-arp': '2e6001780d2c8d42f2d422237cea7a4dcbc24d1ace9ee4aff7ee422a09072f49', 'pd-iq-source': '37fa974279793ccb0b4ee5891bc361a536d1cc917a12521ffe8d09781cc35ac0', 'pd-capture-bootstrap': 'b3132499052fdb709c64fa0267171072299aae21fe0a970c0debc4648e40eccc', 'pd-unkey-guard': '1663086c576cd08332a97c7c20771b3ee7653824c73c93e100c1583e4c88888f', 'pd-lease-guard': '297183f7504ffd6c9c6d9f4713976a2bcbfc1df5d9caa788c402fd8568c0954e', 'flex-tailnet-shim': '70783de051fd785a00c12646dd0e862824156b8cb6d57fb73f105298d67e6995', 'aether-pd': 'b3fc2de87fb51a20721d53a3e0758c4206b29f4ccd6ad1b96e273400471cdf8d'}
import hashlib,json,os
from pathlib import Path
report={'passed':False,'RF_commands':[],'processes':[]}
try:
 store=Path('/var/lib/smartsdr/aetherpd')
 report['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
 assert report['boot_id']=='65be86a7-fd98-4f16-ae62-505781cadb85'
 report['owner_config_sha256']=hashlib.sha256((store/'state/provision.json').read_bytes()).hexdigest()
 cfg=json.loads((store/'state/provision.json').read_text())
 assert cfg['local_only'] and cfg['installation_id']=='b6050e0036d2cfe91bce6f36c8c88faaea90e86722dd13c710a57015adb53654'
 report['installation_id']=cfg['installation_id']
 report['owner_verifier_fingerprint']=hashlib.sha256(cfg['token_sha256'].encode('ascii')).hexdigest();assert report['owner_verifier_fingerprint']=='9d5efda3384e7d4100d905c7dcecbc5fa975f494db0ffd7f4d13d6095c5f925c'
 assert cfg.get('routes') in [None,[]] and not cfg.get('pending_sign_in',False)
 report['configuration_temp_absent']=not (store/'state/provision.json.tmp').exists();assert report['configuration_temp_absent']
 report['owner_config_file_bytes']=(store/'state/provision.json').stat().st_size;assert report['owner_config_file_bytes']<=65536
 report['owner_config_allocated_bytes']=(store/'state/provision.json').stat().st_blocks*512
 assert (store/'upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('1dd0ccdc3ed7264e79931d61fed15494957fbe4e062a51212e42cd5d16609cd2')
 report['runtime_sha256']={n:hashlib.sha256((Path('/run/aetherpd/bin')/n).read_bytes()).hexdigest() for n in EXPECTED}
 assert report['runtime_sha256']==EXPECTED
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   exe=os.readlink(p/'exe')
   if not exe.startswith(('/run/aetherpd/','/var/lib/smartsdr/aetherpd/')):continue
   f={line.split(':',1)[0]:line.split(':',1)[1].strip() for line in (p/'status').read_text().splitlines() if ':' in line}
   row={'pid':int(p.name),'exe':exe,'state':f['State'],'uid':f['Uid'],'nnp':f['NoNewPrivs'],'caps':{k:f[k] for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']},'sha256':hashlib.sha256((p/'exe').read_bytes()).hexdigest()}
   report['processes'].append(row)
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 assert len(report['processes'])==3
 assert all(r['uid'].split()==['78666']*4 and r['nnp']=='1' and not any(int(v,16) for v in r['caps'].values()) for r in report['processes'])
 assert all(Path(r['exe']).name in ['flex-tailnet-shim','pd-primary-launch','pd-boot'] for r in report['processes'])
 assert all(r['sha256']==('0e9dc30619820bd06304b92c144f63858336dea21aeab00be92932d81ce6691f' if Path(r['exe']).name=='pd-boot' else EXPECTED[Path(r['exe']).name]) for r in report['processes'])
 report['arp']=[line for line in Path('/proc/net/arp').read_text().splitlines()[1:] if line.split()[0]=='172.30.2.1'];assert not report['arp']
 report['arp_journal_bytes']=Path('/run/.aetherpd-fixed-arp.8600').stat().st_size;assert report['arp_journal_bytes']==0
 report['accept_local']=Path('/proc/sys/net/ipv4/conf/eth0.10/accept_local').read_text().strip();assert report['accept_local']=='0'
 report['private_sockets']=[line for line in Path('/proc/net/unix').read_text().splitlines() if any(x in line for x in ['aetherpd-config-','aetherpd-bootstrap-','aetherpd-relay-'])];assert not report['private_sockets']
 paths=['/var/lib/smartsdr/aetherpd-installation','/run/aetherpd-install','/run/aetherpd-delivery','/etc/systemd/system/aetherpd-install.service','/etc/systemd/system/aetherpd-recover.service','/var/lib/smartsdr/aetherpd-upgrade','/etc/systemd/system/aetherpd-upgrade.service','/etc/systemd/system/aetherpd-upgrade-recover.service']
 report['temporary_installation_paths']={p:Path(p).exists() for p in paths};assert not any(report['temporary_installation_paths'].values())
 report['passed']=True
except Exception as e:report['error']=type(e).__name__+': '+str(e)
finally:
 print(json.dumps(report),flush=True)
