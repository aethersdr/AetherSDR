from pathlib import Path
import hashlib,json,subprocess,sys,time
from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey
P=Path(__file__).resolve().parent
W=P.parents[1]/'aetherpd-source'; boot=W/'tools/pd-waveform/boot'
sys.path.insert(0,str(boot));import build
start=time.monotonic();results=[]
cases=[('transaction','transaction_check.c','test_transaction.py'),('upgrade','upgrade_transaction_check.c','test_upgrade_transaction.py'),('state','state_check.c','test_state_transfer.py')]
key=Ed25519PrivateKey.from_private_bytes(hashlib.sha256(b'AetherPD whole-worker fixture, never a shipping trust anchor').digest()).public_key().public_bytes_raw()
for label,entry,test in cases+[('worker','pd_install_worker.c','test_worker.py')]:
 with (P/(label+'-build.log')).open('w') as log:
  import contextlib
  with contextlib.redirect_stdout(log),contextlib.redirect_stderr(log):
   checker=build.build(P/label,'host',entry,key if label=='worker' else None,False,label=='worker')
   if label=='worker':
    subprocess.run(['cc','-O2','-static',str(boot/'worker_namespace.c'),'-o',str(P/'worker/worker-namespace')],stdout=log,stderr=log,check=True)
 with (P/(label+'-tests.log')).open('w') as log:
  result=subprocess.run([sys.executable,str(boot/test),'--checker',str(checker),'-v'],stdout=log,stderr=subprocess.STDOUT,timeout=180)
 results.append({'suite':label,'exit':result.returncode,'binary_sha256':hashlib.sha256(checker.read_bytes()).hexdigest()})
 (P/'installer-tests.json').write_text(json.dumps({'results':results,'elapsed_s':time.monotonic()-start},indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
