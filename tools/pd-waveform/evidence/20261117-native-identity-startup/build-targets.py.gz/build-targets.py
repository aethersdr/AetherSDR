from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
import hashlib,json,os,shutil,subprocess,time
P=Path(__file__).resolve().parent; W=P.parents[1]/'aetherpd-source'; src=W/'tools/flex-tailnet-shim'
GO='/home/jeremy/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.1.linux-amd64/bin/go'
copy=P/'second-source-path/flex-tailnet-shim';copy.mkdir(parents=True,exist_ok=False)
for f in src.iterdir():
 if f.is_file() and (f.suffix=='.go' or f.name in ('go.mod','go.sum')):shutil.copyfile(f,copy/f.name)
(copy/'vendor').symlink_to(src/'vendor',target_is_directory=True)
start=time.monotonic()
def build(arch):
 results=[]
 for label,folder in [('first',src),('second',copy)]:
  out=P/(label+'-'+arch);out.mkdir(exist_ok=False)
  env=dict(os.environ,GOTOOLCHAIN='local',GOPROXY='off',CGO_ENABLED='0',GOOS='linux',GOARCH='arm' if arch=='armv7' else 'arm64',GOCACHE=str(P.parent/'runtime-native-directory-durability/short'/arch/'go-cache'))
  if arch=='armv7':env['GOARM']='7'
  else:env.pop('GOARM',None)
  with (P/(label+'-'+arch+'.log')).open('w') as log:
   subprocess.run([GO,'build','-mod=vendor','-trimpath','-buildvcs=false','-ldflags=-s -w','-o',str(out/'flex-tailnet-shim'),'.'],cwd=folder,env=env,stdout=log,stderr=subprocess.STDOUT,timeout=240,check=True)
  data=(out/'flex-tailnet-shim').read_bytes();results.append({'path':str(out/'flex-tailnet-shim'),'sha256':hashlib.sha256(data).hexdigest(),'bytes':len(data)})
 assert results[0]['sha256']==results[1]['sha256']
 return arch,{'runs':results,'byte_identical':True,'scope':'shim executable only; no signed full release or actual target execution'}
with ThreadPoolExecutor(max_workers=2) as pool:results=dict(pool.map(build,['armv7','arm64']))
(P/'target-builds.json').write_text(json.dumps({'toolchain':'Go 1.27.1','architectures':results,'elapsed_s':time.monotonic()-start},indent=2)+'\n')
print(json.dumps(results),flush=True)
