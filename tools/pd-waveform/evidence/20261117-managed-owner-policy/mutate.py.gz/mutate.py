from pathlib import Path
import json, os, shutil, subprocess
ROOT = Path('/home/jeremy/AetherSDR/build/aetherpd-source/tools/flex-tailnet-shim')
OUT = Path(__file__).resolve().parent
GO = '/home/jeremy/go/pkg/mod/golang.org/toolchain@v0.0.1-go1.27.1.linux-amd64/bin/go'
cases = [
 ('installation-id', 'node.go', 'provisionCredentials', 'return presented, hash, installationID', 'return presented, hash, ""', '^TestManagedEnrollment', 'managed installation lost its owner boundary'),
 ('pending-owner', 'node.go', 'claimableLocked', 'n.cfg.InstallationID == "" && ', '', '^TestManagedEnrollment', 'managed installation lost its owner boundary'),
 ('owner-token', 'node.go', 'provisionCredentials', 'return presented, hash, installationID', 'token, hash = newToken(); return token, hash, installationID', '^TestManagedEnrollment', 'managed owner credential changed'),
 ('disconnect-owner', 'node.go', 'forgetConfig', 'if cfg.InstallationID != "" {', 'if false && cfg.InstallationID != "" {', '^TestManagedDisconnectKeepsLocalControl', 'managed installation lost its owner boundary'),
 ('failed-local-save', 'node.go', 'forgetConfig', 'if err := n.saveConfigLocked(cfg); err != nil {', 'if err := n.saveConfigLocked(cfg); false && err != nil {', '^TestManagedDisconnectWriteFailure', 'failed local-control save reported a successful disconnect'),
 ('nonlocal-validation', 'node.go', 'load', 'if n.cfg.LocalOnly || n.cfg.InstallationID != "" {', 'if n.cfg.LocalOnly {', '^TestManagedTailnetIdentityValidation', 'invalid managed tailnet identity became usable or claimable'),
 ('rejoin-session', 'login.go', 'replaceNode', 'if n.pdProcess != nil {', 'if false && n.pdProcess != nil {', '^TestPDManagedRejoin', 'authority change retained a pending calibration arm'),
 ('disconnect-session', 'node.go', 'forgetConfig', 'if n.pdProcess != nil {', 'if false && n.pdProcess != nil {', '^TestPDManagedDisconnectRetires', 'authority change retained a pending calibration arm')]
results=[]
for name,file,method,before,after,pattern,expected in cases:
 d=OUT/('mutant-'+name);d.mkdir(exist_ok=False)
 for f in [*ROOT.glob('*.go'),ROOT/'go.mod',ROOT/'go.sum']:shutil.copyfile(f,d/f.name)
 os.symlink(ROOT/'vendor',d/'vendor',target_is_directory=True)
 f=d/file;s=f.read_text();a=s.index('func (n *Node) '+method+'(');b=s.find('\nfunc ',a+1);b=len(s) if b<0 else b;body=s[a:b];assert body.count(before)==1,(name,body.count(before));f.write_text(s[:a]+body.replace(before,after)+s[b:])
 env=dict(os.environ,GOTOOLCHAIN='local',GOPROXY='off',GOCACHE=str(OUT.parent/'go-cache'))
 command=[GO,'test','-mod=vendor','-race','-timeout=15s','-run',pattern,'-count=1','.']
 with (OUT/(name+'-mutant.log')).open('w') as log:r=subprocess.run(command,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
 log=(OUT/(name+'-mutant.log')).read_text();assert r.returncode==1 and expected in log and '[build failed]' not in log,(name,log[-2500:])
 results.append({'mutation':name,'test':pattern,'exit':r.returncode,'expected_failure':expected,'rejected':True});print(name+' rejected',flush=True)
(OUT/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
