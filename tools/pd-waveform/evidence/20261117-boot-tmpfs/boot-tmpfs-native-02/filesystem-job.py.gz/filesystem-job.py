EXPECTED={'armv7': 'da4f1db848c93ccaae8aaff08c49e8f9bf41325e8e108f8cfecb6d46ce3b9d93', 'arm64': '46bb71059dbda64f282b3570439d158375790b619a90f2f6785cdaa2afc9c3be'}
import ctypes,hashlib,json,os,shutil,stat,subprocess,uuid
from pathlib import Path
report={'case':'real_tmpfs_vs_persistent_boot_directory','passed':False,'RF_commands':[],'service_changes':[],'cases':[],'fixtures_removed':False};roots=[]
class FS(ctypes.Structure):
 _fields_=[('type',ctypes.c_long),('rest',ctypes.c_byte*248)]
libc=ctypes.CDLL(None,use_errno=True);libc.statfs.argtypes=[ctypes.c_char_p,ctypes.POINTER(FS)];libc.statfs.restype=ctypes.c_int

def filesystem(p):
 s=FS();assert libc.statfs(os.fsencode(p),ctypes.byref(s))==0;return s.type
try:
 assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='65be86a7-fd98-4f16-ae62-505781cadb85'
 assert Path('/var/lib/smartsdr/aetherpd/upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('4e003424d8ea5c2d4046019b9e756bac530622812296c07bad36f6339e2d66e5')
 setpriv=Path('/usr/bin/setpriv');assert setpriv.is_file()
 work=Path(WORKDIR);assert work.is_dir()
 assert filesystem(work)!=0x01021994 and filesystem(Path('/dev/shm'))==0x01021994
 for arch,digest in EXPECTED.items():
  binary=work/('native-check-'+arch);assert hashlib.sha256(binary.read_bytes()).hexdigest()==digest;binary.chmod(0o755)
  for kind,parent,expected in [('persistent',work,1),('RAM',Path('/dev/shm'),0)]:
   root=parent/('aetherpd-fs-fixture-'+uuid.uuid4().hex);root.mkdir(mode=0o755);roots.append(root);(root/'run').mkdir(mode=0o755)
   assert root.stat().st_uid==0 and (root/'run').stat().st_uid==0
   args=[str(setpriv),'--bounding-set=-all','--inh-caps=-all','--ambient-caps=-all','--no-new-privs','--',str(binary),str(root)]
   result=subprocess.run(args,capture_output=True,text=True,timeout=5);created=(root/'run/aetherpd').exists()
   row={'arch':arch,'fixture_kind':kind,'filesystem_type':hex(filesystem(root/'run')),'exit':result.returncode,'runtime_created':created,'stderr':result.stderr[:1000],'child_requires_empty_effective_permitted_inheritable_caps':True};report['cases'].append(row)
   assert result.returncode==expected,row
   assert created==(kind=='RAM'),row
   if created:
    s=(root/'run/aetherpd').lstat();assert stat.S_ISDIR(s.st_mode) and s.st_uid==0 and stat.S_IMODE(s.st_mode)==0o755
 report['passed']=True
except Exception as e:report['error']=type(e).__name__+': '+str(e)
finally:
 for root in roots:
  try:shutil.rmtree(root)
  except Exception as e:report['cleanup_error']=type(e).__name__;report['passed']=False
 report['fixtures_removed']=all(not p.exists() for p in roots)
 print(json.dumps(report),flush=True)
