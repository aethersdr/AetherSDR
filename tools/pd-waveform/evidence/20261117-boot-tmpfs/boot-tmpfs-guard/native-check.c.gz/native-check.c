/* Test-only entry; used in the job's private filesystem fixtures. */
#define PD_BOOT_MAIN unused_boot_entry
#include "pd_boot.c"
#undef PD_BOOT_MAIN
int main(int argc,char** argv){
 if(argc!=2 || getuid()!=0 || geteuid()!=0){return 2;}
 struct __user_cap_header_struct h={_LINUX_CAPABILITY_VERSION_3,0};struct __user_cap_data_struct caps[2]={{0}};
 if(syscall(SYS_capget,&h,caps) || caps[0].effective || caps[0].permitted || caps[0].inheritable || caps[1].effective || caps[1].permitted || caps[1].inheritable){return 2;}
 int root=open(argv[1],O_RDONLY|O_DIRECTORY|O_NOFOLLOW|O_CLOEXEC);
 if(root<0){return 2;}int result=boot_runtime(root);close(root);
 if(result<0){return 1;}close(result);return 0;
}
