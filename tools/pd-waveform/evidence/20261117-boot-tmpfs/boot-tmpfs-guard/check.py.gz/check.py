from pathlib import Path
import json,os,re,resource,subprocess
P=Path(__file__).resolve().parent;W=P.parents[1]/'aetherpd-source';S=W/'tools/pd-waveform/boot';B=P.parent/'first-install-desktop-monitor/project'
test=(S/'boot_runtime_test.c').read_text();current=(S/'pd_boot.c').read_text();old=subprocess.check_output(['git','show','HEAD:tools/pd-waveform/boot/pd_boot.c'],cwd=W,text=True)
variants={'baseline':old,'missing_parent':re.sub(r'    if\(fstatfs\(run,&filesystem\).*?\n    }\n','',current,count=1,flags=re.S),'missing_child':re.sub(r'    if\(fd>=0 && \(fstatfs\(fd,&filesystem\).*?\n    }\n','',current,count=1,flags=re.S)}
def no_core():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
report=[]
for name,source in variants.items():
 out=P/name;out.mkdir(exist_ok=False)
 source=source.replace('#include "../session/pd_shim_launch.c"','#include "'+str(S.parent/'session/pd_shim_launch.c')+'"')
 (out/'pd_boot.c').write_text(source);(out/'test.c').write_text(test)
 args=['cc','-std=gnu11','-O0','-g','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-I'+str(S),'-I'+str(B/'pd-boot-runtime-policy'),'-I'+str(W/'third_party/monocypher'),str(out/'test.c'),'-o',str(out/'test')]
 r=subprocess.run(args,capture_output=True,text=True);(out/'build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
 r=subprocess.run([str(out/'test')],capture_output=True,text=True,timeout=10,preexec_fn=no_core);(out/'result.log').write_text(r.stdout+r.stderr);assert r.returncode==-6,(name,r.returncode,r.stdout,r.stderr);report.append({'variant':name,'rejected':True,'exit':r.returncode})
(P/'mutations.json').write_text(json.dumps(report,indent=2)+'\n')
args=['cc','-std=gnu11','-O1','-g','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-fsanitize=address,undefined','-fno-omit-frame-pointer','-I'+str(B/'pd-boot-runtime-policy'),'-I'+str(W/'third_party/monocypher'),str(S/'boot_runtime_test.c'),'-o',str(P/'sanitized')]
r=subprocess.run(args,capture_output=True,text=True);(P/'sanitize-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
r=subprocess.run([str(P/'sanitized')],capture_output=True,text=True,timeout=10,preexec_fn=no_core,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1'));(P/'sanitize.log').write_text(r.stdout+r.stderr);assert r.returncode==0,(r.returncode,r.stdout,r.stderr)
print(json.dumps({'mutants':report,'ASan_UBSan_LSan_passed':True}))
