from pathlib import Path
import hashlib,json,os,subprocess
P=Path(__file__).resolve().parent;W=P.parents[1]/'aetherpd-source';S=W/'tools/pd-waveform/boot';B=P.parent/'first-install-desktop-monitor/project';report={}
for arch,target in [('armv7',['-target','arm-linux-musleabihf','-mcpu=cortex_a8']),('arm64',['-target','aarch64-linux-musl'])]:
 out=P/('native-check-'+arch)
 args=['zig','cc',*target,'-std=gnu11','-O2','-static','-s','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-Wl,--build-id=none','-I'+str(S),'-I'+str(B/'pd-boot-runtime-policy'),'-I'+str(W/'third_party/monocypher'),str(P/'native-check.c'),'-o',str(out)]
 r=subprocess.run(args,capture_output=True,text=True,env=dict(os.environ,ZIG_LOCAL_CACHE_DIR=str(P/'zig-cache'),ZIG_GLOBAL_CACHE_DIR=str(P/'zig-cache')));(P/('cross-'+arch+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==0,r.stderr
 report[arch]={'bytes':out.stat().st_size,'sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'file':subprocess.check_output(['file',str(out)],text=True).strip()}
(P/'cross-builds.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report))
