from pathlib import Path
import subprocess,json,resource,os
P=Path(__file__).resolve().parent;W=P.parents[1]/'aetherpd-source';S=W/'tools/pd-waveform/guardian';report=[]
def no_core():resource.setrlimit(resource.RLIMIT_CORE,(0,0))
for name,expression in [('term','sigaction(SIGTERM, &ignored, NULL)'),('int','sigaction(SIGINT, &ignored, NULL)')]:
 out=P/('mutant-C-'+name);out.mkdir(exist_ok=False)
 src=(S/'unkey_guard.c').read_text();assert expression in src;(out/'unkey_guard.c').write_text(src.replace(expression,'0',1));(out/'unkey_guard_deadline_test.c').write_bytes((S/'unkey_guard_deadline_test.c').read_bytes())
 r=subprocess.run(['cc','-std=gnu11','-O0','-g',str(out/'unkey_guard_deadline_test.c'),'-o',str(out/'test')],capture_output=True,text=True);assert r.returncode==0,r.stderr
 r=subprocess.run([str(out/'test')],capture_output=True,text=True,timeout=10,preexec_fn=no_core);(P/('mutant-C-'+name+'.log')).write_text(r.stdout+r.stderr);assert r.returncode==-6,(r.returncode,r.stdout,r.stderr)
 report.append({'missing_signal':name,'exit':r.returncode,'rejected':True})
(P/'C-mutations-result.json').write_text(json.dumps(report,indent=2)+'\n')
args=['cc','-std=gnu11','-O1','-g','-fno-omit-frame-pointer','-fsanitize=address,undefined',str(S/'unkey_guard_deadline_test.c'),'-o',str(P/'unkey-asan')]
r=subprocess.run(args,capture_output=True,text=True);(P/'C-sanitizer-build.log').write_text(r.stdout+r.stderr);assert r.returncode==0
r=subprocess.run([str(P/'unkey-asan')],capture_output=True,text=True,timeout=15,preexec_fn=no_core,env=dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1'));(P/'C-sanitizer.log').write_text(r.stdout+r.stderr);assert r.returncode==0,(r.returncode,r.stderr)
print(json.dumps({'C_mutations':report,'ASan_UBSan_LSan_passed':True}))
