"""Separate legitimate GUI clients; standalone validation, concurrent Start, Stop. No RF."""
import base64,hashlib,json,math,pathlib,re,socket,struct,subprocess,sys,threading,time
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent
sys.path.insert(0,str(BASE.parent/'aetherpd-source/tools'));from automation_probe import Bridge
UUID='C98D90C7-83A3-4DB1-9DF9-E078986504DA'
assert not (ROOT/'outcome.json').exists(),'Preserve prior attempt'
report={'passed':False,'RF_commands':[],'credential_mutations':[],'attempts':[]};events=[]
b=Bridge('/tmp/aetherpd-measurement-arm-status');api=None;started=False;pan=None;waterfall=None;slice_id=None

def event(name,**v):
 events.append({'event':name,'monotonic_ns':time.monotonic_ns(),**v});(ROOT/'events.json').write_text(json.dumps(events,indent=2)+'\n')
def bridge(q):
 r=b.request(q,7);assert r.get('ok'),r;return r

def idle():
 r=bridge({'cmd':'get','model':'radio'})['radio'];assert r['connected'] and not r['transmitting'] and not r['fullDuplex'] and r['serial']=='2125-1213-8600-8895';return r

def read(path):
 p=subprocess.run([str(BASE/'first-iq-live/vault-v3'),path],capture_output=True,text=True,timeout=22)
 assert p.stdout.strip().startswith('{'),('read_failed',p.returncode);r=json.loads(p.stdout);event('read',path=path,result=r);return r

def vault(mode,identities=None):
 p=subprocess.run([str(ROOT/'vault-owners'),mode],input=json.dumps(identities or []),capture_output=True,text=True,timeout=30)
 assert p.returncode==0,('credential_helper',p.returncode,p.stderr[-500:]);r=json.loads(p.stdout);event(mode,result=r);return r

def stop():
 global started
 r=vault('stop');assert r['requests'][0]['http_status']==202,r
 deadline=time.monotonic()+25
 while True:
  s=read('aetherpd/status')
  if s['http_status']==200 and s['body']=={'available':False,'state':'stopped'}:started=False;return s
  assert time.monotonic()<deadline,s;time.sleep(.25)

def registered(identity):
 deadline=time.monotonic()+35
 while True:
  r=read('aetherpd/status')
  if r['http_status']==200 and r['body'].get('registered'):break
  assert time.monotonic()<deadline,r;time.sleep(.25)
 s=r['body'];assert not s['keyed'] and not s['correcting'] and s['diagnostics']['version']==2
 idle();return s

def capture(identity,label):
 r=read('aetherpd/capture');assert r['http_status']==200,r;c=r['body'];binding=c['feedback_binding']
 assert binding['transport']=='local_dax_iq' and binding['valid'] and not binding['failed']
 assert binding['channel']==identity['iq_channel'] and binding['pan']==identity['feedback_pan'] and binding['gui_handle']==identity['gui_handle'],binding
 assert c['sample_rate_hz']==48000 and c['sample_count']==16384 and not c['keyed'] and not c['correcting']
 raw=bytearray()
 for chunk in range(32):
  r=read('aetherpd/capture/'+c['capture_id']+'/'+str(chunk));assert r['http_status']==200,r;part=r['body'];assert part['offset']==chunk*512
  data=base64.b64decode(part['iq_f32le'],validate=True);assert len(data)==4096;raw.extend(data)
 values=struct.unpack('<'+str(len(raw)//4)+'f',raw);assert len(raw)==131072 and all(math.isfinite(x) for x in values) and any(x!=0 for x in values)
 (ROOT/(label+'-iq.f32le')).write_bytes(raw)
 return {'metadata':c,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'finite_nonzero':True}

class API:
 def __init__(self):
  self.sock=socket.create_connection(('192.168.50.100',4992),6);self.sock.settimeout(.5);self.lines=[];self.commands=[];self.seq=0;self.done=False;self.error=None
  self.thread=threading.Thread(target=self.reader,daemon=True);self.thread.start()
 def reader(self):
  pending=b''
  try:
   while not self.done:
    try:data=self.sock.recv(65536)
    except socket.timeout:continue
    if not data:break
    pending+=data;assert len(pending)<131072
    while b'\n' in pending:
     line,pending=pending.split(b'\n',1);self.lines.append(line.decode('ascii',errors='strict').rstrip('\r'));assert len(self.lines)<20000
  except Exception as e:
   if not self.done:self.error=str(e)
 def wait(self,predicate,seconds=8):
  end=time.monotonic()+seconds
  while True:
   for line in list(self.lines):
    if predicate(line):return line
   assert not self.error,self.error;assert time.monotonic()<end,'API observation deadline';time.sleep(.03)
 def command(self,cmd):
  allowed=['sub client all','sub pan all','sub slice all','sub tx all','sub stream all','client program AetherPDQualification','client station AetherPDReceiveOnly','client gui '+UUID,'display panafall create x=100 y=100']
  assert cmd in allowed or re.fullmatch(r'display pan set 0x[0-9a-f]{8} (?:center=7\.150000 bandwidth=0\.200000 rxant=RX_A rfgain=0 daxiq_channel=3 fps=1|daxiq_channel=3)',cmd) or re.fullmatch(r'slice create pan=0x[0-9a-f]{8} freq=7\.150000 rxant=RX_A mode=USB',cmd) or re.fullmatch(r'(?:slice remove [1-9]|display pan remove 0x[0-9a-f]{8}|display panafall remove 0x[0-9a-f]{8})',cmd),cmd
  self.seq+=1;seq=self.seq;self.commands.append({'seq':seq,'command':cmd,'monotonic_ns':time.monotonic_ns()});self.sock.sendall(f'C{seq}|{cmd}\n'.encode());r=self.wait(lambda s:s.startswith(f'R{seq}|'));code=r.split('|')[1];assert int(code,16)==0,('radio_command_refused',cmd,r);return r.split('|')[2]
 def close(self):
  self.done=True;self.sock.close();self.thread.join(2);(ROOT/'temporary-GUI-API.json').write_text(json.dumps({'commands':self.commands,'received':self.lines,'reader_error':self.error},indent=2)+'\n')

def owned_pan_line(line,owner,pid):return '|display pan '+pid+' ' in line and 'client_handle='+owner in line
try:
 who=bridge({'cmd':'whoami'});assert who['pid']==2925772 and who['guiClientId']=='5D14B8D4-A745-5620-BAF8-B3614CA1C814';report['whoami']=who;report['radio_before']=idle()
 pans=bridge({'cmd':'get','model':'pans'})['pans'];assert len(pans)==1 and pans[0]['ownedByUs'] and pans[0]['rfGain']==0 and pans[0]['rxAntenna']=='RX_A' and abs(pans[0]['centerMhz']-7.15)<1e-6
 primary={'gui_client_id':who['guiClientId'],'gui_handle':int(pans[0]['clientHandle'],16),'iq_channel':4,'feedback_pan':int(pans[0]['panId'],16)}
 assert read('aetherpd/status')['body']=={'available':False,'state':'stopped'}
 api=API();h=api.wait(lambda s:s.startswith('H'));handle=int(h[1:],16);assert handle!=primary['gui_handle'];owner=f'0x{handle:08x}'
 for cmd in ['sub client all','sub pan all','sub slice all','sub tx all','sub stream all','client program AetherPDQualification','client station AetherPDReceiveOnly','client gui '+UUID]:api.command(cmd)
 report['temporary_GUI_registered']=api.wait(lambda s:'|client '+owner+' connected ' in s and 'client_id='+UUID in s)
 reply=api.command('display panafall create x=100 y=100');report['create_reply']=reply
 created=re.findall(r'0x[0-9a-fA-F]{8}',reply);assert created,reply
 pan=created[0].lower();assert int(pan,16)!=primary['feedback_pan'];api.wait(lambda s:owned_pan_line(s,owner,pan))
 api.command('display pan set '+pan+' center=7.150000 bandwidth=0.200000 rxant=RX_A rfgain=0 daxiq_channel=3 fps=1')
 line=api.wait(lambda s:'|display pan '+pan+' ' in s and 'daxiq_channel=3' in s and 'rxant=RX_A' in s);report['temporary_pan_verified']=line
 # The returned paired waterfall belongs to this GUI; its id is observed, never guessed.
 wf=api.wait(lambda s:'|display waterfall ' in s and 'panadapter='+pan in s)
 waterfall=wf.split('|display waterfall ',1)[1].split()[0]
 reply=api.command('slice create pan='+pan+' freq=7.150000 rxant=RX_A mode=USB');assert reply.isdecimal() and 1<=int(reply)<=9,reply;slice_id=int(reply)
 report['temporary_slice_verified']=api.wait(lambda s:f'|slice {slice_id} ' in s and 'client_handle='+owner in s and 'active=1' in s and 'mode=USB' in s)
 temporary={'gui_client_id':UUID,'gui_handle':handle,'iq_channel':3,'feedback_pan':int(pan,16)};report['identities']=[primary,temporary];event('both_GUIs_observed',identities=report['identities'])
 print('two_independent_GUI_receivers_observed',flush=True)
 started=True;single=vault('start',[temporary]);assert single['requests'][0]['http_status']==202,single
 standalone={'start':single,'registered':registered(temporary),'IQ':capture(temporary,'standalone-temporary')};standalone['stopped']=stop();report['standalone_temporary']=standalone;idle();print('temporary_owner_independently_started_IQ_and_stopped',flush=True)
 started=True;race=vault('race',[primary,temporary]);report['race']=race;rows=race['requests'];assert sorted(x['http_status'] for x in rows)==[202,409],race
 assert max(x['dispatched_ns'] for x in rows)<min(x['completed_ns'] for x in rows),race
 winner=next(x['identity'] for x in rows if x['http_status']==202);report['winner']=winner;report['registered']=registered(winner)
 print('race_one_accepted_one_refused',flush=True)
 (ROOT/'active-graph-job.py').write_text('IDENTITY='+repr(winner)+'\n'+(ROOT/'active-graph-template.py').read_text())
 with (ROOT/'active-graph-console.log').open('w') as log:subprocess.run([sys.executable,str(ROOT/'run-job.py'),'active-graph'],stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
 outer=json.loads((ROOT/'active-graph-result.json').read_text());active=json.loads(outer['logs']);assert outer['wait']['StatusCode']==0 and active['passed'] and outer['job_container_deleted'] and outer['temporary_host_directory_deleted'],active
 report['active_graph']=active;report['winning_IQ']=capture(winner,'race-winner');report['stopped']=stop();report['radio_after_race']=idle();report['passed']=True
except Exception as error:
 report['error']=type(error).__name__+': '+str(error)
finally:
 if started:
  try:report['fallback_stop']=stop()
  except Exception as error:report['stop_error']=str(error);report['passed']=False
 if api:
  try:
   if slice_id is not None:report['temporary_slice_remove_reply']=api.command('slice remove '+str(slice_id))
   if pan:report['temporary_pan_remove_reply']=api.command('display pan remove '+pan)
   if waterfall:report['temporary_waterfall_remove_reply']=api.command('display panafall remove '+waterfall)
  except Exception as error:report['temporary_remove_error']=str(error);report['passed']=False
  api.close()
 try:
  report['final_radio']=idle();report['final_pans']=bridge({'cmd':'get','model':'pans'})['pans'];report['final_slices']=bridge({'cmd':'get','model':'slices'})['slices']
  assert len(report['final_pans'])==1 and len(report['final_slices'])==1 and report['final_slices'][0]['sliceId']==0 and report['final_slices'][0]['mode']=='USB'
 except Exception as error:report['final_receiver_error']=str(error);report['passed']=False
 b.close();(ROOT/'outcome.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({k:report[k] for k in ['passed','error','stop_error','temporary_remove_error','final_receiver_error'] if k in report}),flush=True)
 if not report['passed']:raise SystemExit(1)
