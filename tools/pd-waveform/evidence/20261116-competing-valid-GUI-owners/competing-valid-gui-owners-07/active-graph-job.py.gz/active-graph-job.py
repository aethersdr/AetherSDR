IDENTITY={'feedback_pan': 1073741824, 'gui_client_id': '5D14B8D4-A745-5620-BAF8-B3614CA1C814', 'gui_handle': 330944360, 'iq_channel': 4}
import collections,hashlib,json,os,pathlib,subprocess
P=pathlib.Path
report={'passed':False,'RF_commands':[],'signals':[],'processes':[]}
try:
 assert P('/proc/sys/kernel/random/boot_id').read_text().strip()=='a0bc3e5f-0a2f-433b-aa25-08d5cc0d6cf4'
 assert hashlib.sha256(P('/var/lib/smartsdr/aetherpd/state/provision.json').read_bytes()).hexdigest()=='f511e5f09f41a99b0f5cd29e4e321eb6f93ec02162df41175ae6866173233cb5'
 for p in P('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   exe=os.readlink(p/'exe')
   if '/aetherpd/' not in exe:continue
   status={l.split(':',1)[0]:l.split(':',1)[1].strip() for l in (p/'status').read_text().splitlines() if ':' in l}
   report['processes'].append({'pid':int(p.name),'exe':exe,'uid':status['Uid'],'cgroup':(p/'cgroup').read_text().splitlines(),'caps':{k:status[k] for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']},'nnp':status['NoNewPrivs']})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 dsps=[row for row in report['processes'] if row['exe']=='/run/aetherpd/bin/aether-pd'];assert len(dsps)==1
 dsp=dsps[0];proc=P('/proc')/str(dsp['pid'])
 assert dsp['uid'].split()==['78666']*4 and dsp['nnp']=='1' and not any(int(v,16) for v in dsp['caps'].values())
 assert hashlib.sha256((proc/'exe').read_bytes()).hexdigest()=='b3fc2de87fb51a20721d53a3e0758c4206b29f4ccd6ad1b96e273400471cdf8d'
 env=dict(x.split(b'=',1) for x in (proc/'environ').read_bytes().split(b'\0') if b'=' in x)
 assert int(env[b'AETHER_PD_GUI_HANDLE'],16)==IDENTITY['gui_handle'] and int(env[b'AETHER_PD_DAXIQ'])==IDENTITY['iq_channel'] and int(env[b'AETHER_PD_FEEDBACK_PAN'],16)==IDENTITY['feedback_pan']
 workers={'pd-fixed-arp':2,'pd-iq-source':1,'pd-capture-bootstrap':3,'aether-pd':1,'pd-unkey-guard':1,'pd-lease-guard':1}
 counts=collections.Counter(P(row['exe']).name for row in report['processes'] if P(row['exe']).name in workers)
 assert dict(counts)==workers,dict(counts)
 assert all(row['uid'].split()==(['65534']*4 if P(row['exe']).name in ['pd-fixed-arp','pd-capture-bootstrap'] else ['78666']*4) for row in report['processes'])
 report['worker_counts']=dict(counts)
 report['ARP']=[l for l in P('/proc/net/arp').read_text().splitlines()[1:] if l.split()[0]=='172.30.2.1'];assert len(report['ARP'])==1
 report['accept_local']=P('/proc/sys/net/ipv4/conf/eth0.10/accept_local').read_text().strip();assert report['accept_local']=='0'
 report['sessions']=subprocess.run(['/usr/bin/systemctl','show','aetherpd-start@*.service','-p','Id','-p','ActiveState','-p','MainPID','-p','SendSIGKILL','-p','KillMode'],capture_output=True,text=True,timeout=8,check=True).stdout
 active=[]
 for block in report['sessions'].strip().split('\n\n'):
  if not block:continue
  row=dict(line.split('=',1) for line in block.splitlines())
  assert row['SendSIGKILL']=='no' and row['KillMode']=='control-group'
  if row['ActiveState']=='active':active.append(row)
 assert len(active)==1 and any('/'+active[0]['Id'] in line for line in dsp['cgroup']),active
 report['passed']=True
finally:
 print(json.dumps(report),flush=True)
