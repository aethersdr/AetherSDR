import json,pathlib,socket,time,re
out=pathlib.Path(__file__).resolve().parent;report={'passed':False,'RF_commands':[],'commands':['sub client all','sub pan all','sub slice all','sub tx all']};lines=[]
s=socket.create_connection(('192.168.50.100',4992),6);s.settimeout(.25)
try:
 for i,cmd in enumerate(report['commands'],1):s.sendall(f'C{i}|{cmd}\n'.encode())
 pending=b'';end=time.monotonic()+4;replies=set()
 while time.monotonic()<end:
  try:data=s.recv(65536)
  except socket.timeout:
   if len(replies)==4:break
   continue
  assert data;pending+=data;assert len(pending)<131072
  while b'\n' in pending:
   raw,pending=pending.split(b'\n',1);line=raw.decode('ascii').rstrip('\r');lines.append(line);assert len(lines)<10000
   if line.startswith('R'):
    a=line.split('|');assert int(a[1],16)==0;replies.add(int(a[0][1:]))
 assert replies=={1,2,3,4}
 clients={};pans={};slices={};interlock={}
 for line in lines:
  if '|' not in line or not line.startswith('S'):continue
  text=line.split('|',1)[1];words=text.split();fields=dict(x.split('=',1) for x in words if '=' in x)
  if text.startswith('client ') and len(words)>2:
   if words[2]=='connected':clients[words[1]]=fields
   elif words[2]=='disconnected':clients.pop(words[1],None)
  elif text.startswith('display pan ') and len(words)>3:
   if words[3]=='removed':pans.pop(words[2],None)
   else:pans.setdefault(words[2],{}).update(fields)
  elif text.startswith('slice ') and len(words)>2:
   if fields.get('in_use')=='0':slices.pop(words[1],None)
   else:slices.setdefault(words[1],{}).update(fields)
  elif text.startswith('interlock '):interlock.update(fields)
 report.update(clients=clients,pans=pans,slices=slices,interlock=interlock,received=lines)
 assert len(clients)==1 and next(iter(clients.values()))['client_id']=='5D14B8D4-A745-5620-BAF8-B3614CA1C814'
 assert set(pans)=={'0x40000000'} and pans['0x40000000']['client_handle'].lower()=='0x13b9cf68'
 assert set(slices)=={'0'} and slices['0']['client_handle'].lower()=='0x13b9cf68' and slices['0']['mode']=='USB' and abs(float(slices['0']['RF_frequency'])-7.15)<1e-6
 assert interlock['state']=='READY' and int(interlock['tx_client_handle'],16)==0
 report['passed']=True
finally:
 s.close();(out/'final-inventory.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps({'passed':report['passed'],'clients':len(report.get('clients',{})),'pans':len(report.get('pans',{})),'slices':len(report.get('slices',{}))}))
