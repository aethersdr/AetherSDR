from pathlib import Path
import hashlib,json,re,subprocess,sys,time
sys.path.insert(0,'/home/jeremy/AetherSDR/build/aetherpd-source/tools')
from automation_probe import Bridge
OUT=Path(__file__).resolve().parent;BASE=OUT.parent
reboot=json.loads((BASE/'managed-owner-pending-reboot/reboot-result.json').read_text());assert reboot['passed']
assert not (OUT/'cancel-after-reboot-intent.json').exists(), 'Inspect prior cancellation attempt'
b=Bridge('/tmp/aetherpd-managed-remote-access')
def req(q):
 r=b.request(q,8)
 if not r.get('ok'):raise RuntimeError('Bridge refused '+q['cmd'])
 return r
def walk(x):
 if isinstance(x,dict):
  yield x
  for key in ('roots','children'):
   for item in x.get(key,[]):yield from walk(item)
 elif isinstance(x,list):
  for item in x:yield from walk(item)
def root(name):return next((x for x in walk(req({'cmd':'dumpTree'})) if x.get('objectName')==name and x.get('visible')),None)
def panel(name):
 view=root(name)
 if view is None:return {}
 wanted={'pdRemoteAccess','pdState','tsStatusLine','tsRefresh','tsDisconnect','tsDone'}
 return {x['objectName']:{k:re.sub(r'https?://\S+','<URL withheld>',str(x[k])) if isinstance(x[k],str) else x[k] for k in ('value','visible','enabled') if k in x} for x in walk(view) if x.get('objectName') in wanted}
def login():
 p=subprocess.run([str(OUT/'credential-probe'),'login'],capture_output=True,text=True,timeout=35);assert p.returncode==0,'Login observation unavailable';return json.loads(p.stdout)
def public():
 p=subprocess.run([str(BASE/'first-iq-live/vault-v3'),'status'],capture_output=True,text=True,timeout=22);assert p.returncode==0,'Owner status unavailable';return json.loads(p.stdout)['body']
def radio():return req({'cmd':'get','model':'radio'})['radio']
report={'passed':False,'RF_commands':[],'account_joined':False}
try:
 old=panel('TailnetShimDialog');report['old_window_after_reboot']=old
 assert not old or (not old.get('tsRefresh',{}).get('enabled') and not old.get('tsDisconnect',{}).get('enabled')),'Old connection still offers remote-access actions'
 r=radio()
 if not r['connected']:req({'cmd':'connect','action':'local','value':'serial 2125-1213-8600-8895'})
 end=time.monotonic()+35
 while True:
  r=radio();assert not r['transmitting'] and not r['fullDuplex'],'Radio precondition changed'
  if r['connected']:
   pans=req({'cmd':'get','model':'pans'})['pans'];slices=req({'cmd':'get','model':'slices'})['slices']
   if len(pans)==1 and pans[0]['ownedByUs'] and len(slices)==1:break
  assert time.monotonic()<end,'Original receiver did not return';time.sleep(.25)
 report['radio_before']=r;report['pans_before']=pans
 if root('AetherPDDialog') is not None:
  req({'cmd':'invoke','target':'pdDone','action':'click'});time.sleep(.25)
 req({'cmd':'invoke','target':'Waveforms...','action':'trigger'});req({'cmd':'invoke','target':'openAetherPD','action':'click'})
 end=time.monotonic()+20
 while not panel('AetherPDDialog').get('pdRemoteAccess',{}).get('enabled'):
  assert time.monotonic()<end,'Owner cannot reopen Remote Access after pending reboot';time.sleep(.25)
 req({'cmd':'invoke','target':'pdRemoteAccess','action':'click'})
 end=time.monotonic()+20
 while time.monotonic()<end:
  visible=panel('TailnetShimDialog');observed=login();view=root('TailnetShimDialog')
  assert observed['state'] not in ('running','needs_approval'),'External account approval detected; leave it intact'
  match=view is not None and observed['auth_url_present'] and any(hashlib.sha256(url.encode()).hexdigest()==observed['auth_url_sha256'] for x in walk(view) for url in re.findall(r'https://[^\s<>]+',str(x.get('value',''))))
  if match and visible.get('tsDisconnect',{}).get('enabled'):break
  time.sleep(.25)
 else:raise RuntimeError('Pending sign-in did not reopen in current connection')
 assert observed['owner_verifier_fingerprint']==reboot['login_before']['owner_verifier_fingerprint'],'Owner changed'
 report['reopened_after_reboot']=visible;report['login_before_cancel']=observed
 assert visible['tsDisconnect'].get('value')=='Cancel sign-in','Wrong cancellation control'
 owner=public();assert owner['state']=='needs_login' and not owner['tailnet_ip'] and not owner['claimable']
 (OUT/'cancel-after-reboot-intent.json').write_text(json.dumps(report,indent=2)+'\n')
 req({'cmd':'invoke','target':'tsDisconnect','action':'click'})
 end=time.monotonic()+10
 while root('tsDisconnectConfirmation') is None:
  assert time.monotonic()<end,'Cancellation confirmation did not appear';time.sleep(.1)
 report['confirmation_observed']=True
 req({'cmd':'invoke','target':'tsConfirmDisconnect','action':'click'})
 end=time.monotonic()+40
 while time.monotonic()<end:
  after=public();observed=login()
  if after['state']=='local' and observed['state']=='local' and not observed['auth_url_present']:break
  time.sleep(.25)
 else:raise RuntimeError('Cancellation did not return to local control')
 assert after['installation_id']==owner['installation_id'] and after['managed_owner_version']==1 and not after['claimable'] and after['provisioned'],'Managed local ownership changed'
 assert observed['owner_verifier_fingerprint']==reboot['login_before']['owner_verifier_fingerprint'],'Cancellation changed owner credential'
 report.update(owner_after_cancel=after,login_after_cancel=observed,window_after_cancel=panel('TailnetShimDialog'))
 req({'cmd':'invoke','target':'tsDone','action':'click'})
 report['radio_after']=radio();assert report['radio_after']['connected'] and not report['radio_after']['transmitting'] and not report['radio_after']['fullDuplex']
 report['passed']=True
finally:
 (OUT/'cancel-after-reboot-result.json').write_text(json.dumps(report,indent=2)+'\n');b.close()
print(json.dumps({'passed':True,'old_window_retired':True,'pending_sign_in_reopened_after_reboot':True,'ordinary_UI_cancellation_returned_local':True,'existing_owner_preserved':True}),flush=True)
