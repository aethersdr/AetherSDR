from pathlib import Path
import json,re,subprocess
paths=['/var/lib/smartsdr/aetherpd/state/tsnet','/run/aetherpd/primary/tsnet','/var/lib/smartsdr/aetherpd/state/provision.json.tmp']
r={'absent_paths':{p:not Path(p).exists() for p in paths},'RF_commands':[]}
assert all(r['absent_paths'].values())
p=subprocess.run(['/usr/bin/journalctl','-u','aetherpd-shim.service','-n','200','--no-pager','-o','short-monotonic'],capture_output=True,text=True,timeout=8,check=True)
keep=('api: provisioning requested','api: sign-out requested','logout:','could not delete','could not save','panic:','fatal error:')
r['relevant_primary_journal']=[re.sub(r'https?://\S+','<URL withheld>',line) for line in p.stdout.splitlines() if any(x in line for x in keep)]
r['logout_warning_observed']=any('logout:' in line for line in r['relevant_primary_journal'])
r['passed']=True
print(json.dumps(r),flush=True)
