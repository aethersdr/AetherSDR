from pathlib import Path
import hashlib,json,re,subprocess,sys,time
sys.path.insert(0,'/home/jeremy/AetherSDR/build/aetherpd-source/tools')
from automation_probe import Bridge
OUT=Path(__file__).resolve().parent
assert not (OUT/'discard-reply-intent.json').exists(), 'Inspect prior one-shot discard attempt'
assert json.loads((OUT/'open-pending-result.json').read_text())['passed']
b=Bridge('/tmp/aetherpd-managed-remote-access')
def req(q):
 r=b.request(q,8)
 if not r.get('ok'):raise RuntimeError('Bridge refused '+q['cmd'])
 return r
def walk(x):
 if isinstance(x,dict):
  yield x
  for key in ('roots','children'):
   for item in x.get(key,[]):yield from walk(item)
 elif isinstance(x,list):
  for item in x:yield from walk(item)
def root(name):return next((x for x in walk(req({'cmd':'dumpTree'})) if x.get('objectName')==name and x.get('visible')),None)
def observe():
 p=subprocess.run([str(OUT/'credential-probe'),'login'],capture_output=True,text=True,timeout=35)
 if p.returncode!=0:raise RuntimeError('Login observation unavailable')
 return json.loads(p.stdout)
def unkeyed():
 r=req({'cmd':'get','model':'radio'})['radio']
 assert r['connected'] and not r['transmitting'] and not r['fullDuplex'],'Radio precondition changed'
 return r
before=observe();assert before['state']=='needs_login' and before['auth_url_present']
assert before['owner_verifier_fingerprint']==json.loads((OUT/'open-pending-result.json').read_text())['login_before']['owner_verifier_fingerprint']
report={'passed':False,'login_before':before,'RF_commands':[],'account_approval_requested':False,'provision_response_consumed':False}
(OUT/'discard-reply-intent.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 unkeyed();req({'cmd':'invoke','target':'tsDone','action':'click'})
 end=time.monotonic()+10
 while root('TailnetShimDialog') is not None:
  assert time.monotonic()<end,'Sign-in window did not close';time.sleep(.1)
 p=subprocess.run([str(OUT/'credential-probe'),'discard-provision-reply'],capture_output=True,text=True,timeout=35)
 assert p.returncode==0,'Bounded discard helper failed'
 report['discard']=json.loads(p.stdout)
 assert not report['discard']['reply_consumed'] and report['discard']['socket_closed']
 end=time.monotonic()+65
 while time.monotonic()<end:
  unkeyed();after=observe()
  assert after['owner_verifier_fingerprint']==before['owner_verifier_fingerprint'],'Owner credential changed'
  assert after['state'] not in ('running','needs_approval'),'External account approval detected; leave it intact'
  if after['state']=='needs_login' and after['auth_url_present'] and after['auth_url_sha256']!=before['auth_url_sha256']:break
  time.sleep(.25)
 else:raise RuntimeError('No replacement sign-in committed after discarded reply')
 report['login_after_discard']=after
 req({'cmd':'invoke','target':'pdRemoteAccess','action':'click'})
 end=time.monotonic()+15
 while time.monotonic()<end:
  view=root('TailnetShimDialog')
  shown=view is not None and any(hashlib.sha256(url.encode()).hexdigest()==after['auth_url_sha256'] for x in walk(view) for url in re.findall(r'https://[^\s<>]+',str(x.get('value',''))))
  if shown:break
  time.sleep(.25)
 else:raise RuntimeError('Ordinary UI did not recover discarded provision reply')
 report.update(same_existing_owner_recovered_new_sign_in_link=True,radio_after=unkeyed(),passed=True)
finally:
 (OUT/'discard-reply-result.json').write_text(json.dumps(report,indent=2)+'\n');b.close()
print(json.dumps({'passed':True,'provision_reply_consumed':False,'new_sign_in_link_recovered_in_UI':True,'existing_owner_unchanged':True,'account_joined':False}),flush=True)
