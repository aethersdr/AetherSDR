from pathlib import Path
import json,socket,subprocess,sys,time
sys.path.insert(0,'/home/jeremy/AetherSDR/build/aetherpd-source/tools')
from automation_probe import Bridge
OUT=Path(__file__).resolve().parent;BASE=OUT.parent;UI=BASE/'managed-remote-access-ui';start=time.monotonic()
assert not (OUT/'reboot-intent.json').exists(), 'One reboot only; inspect the prior attempt'
assert json.loads((UI/'discard-reply-result.json').read_text())['passed']
report={'passed':False,'reboot_commands_sent':0,'RF_commands':[],'joined_tailnet_account':False}
ssh=['ssh','-F','/dev/null','-o','BatchMode=yes','-o','ConnectTimeout=3','-o','IdentitiesOnly=yes','-i','/home/jeremy/agent-worktrees/c3957d44/flexipv6-build/keys/probe','-o','UserKnownHostsFile=/tmp/aetherpd-shim-integration-kh-probe','-o','StrictHostKeyChecking=yes','-p','22222','root@192.168.50.100','cat /proc/sys/kernel/random/boot_id']
def boot():
 p=subprocess.run(ssh,capture_output=True,text=True,timeout=5);assert p.returncode==0,'Boot ID unavailable';s=p.stdout.strip();assert len(s)==36;return s
def status(path):
 p=subprocess.run([str(BASE/'first-iq-live/vault-v3'),path],capture_output=True,text=True,timeout=22);assert p.returncode==0,'Status unavailable';return json.loads(p.stdout)['body']
def login():
 p=subprocess.run([str(UI/'credential-probe'),'login'],capture_output=True,text=True,timeout=35);assert p.returncode==0,'Owner login observation unavailable';return json.loads(p.stdout)
def listening(port):
 try:
  with socket.create_connection(('192.168.50.100',port),.4):return True
 except OSError:return False
b=Bridge('/tmp/aetherpd-managed-remote-access')
try:
 who=b.request({'cmd':'whoami'},5);assert who['pid']==3647749 and who['automationIdentity']=='aetherpd-shim-integration'
 radio=b.request({'cmd':'get','model':'radio'},5)['radio'];assert radio['connected'] and not radio['transmitting'] and not radio['fullDuplex'];report['radio_before']=radio
 report['installation_before']=status('aetherpd/installation');assert report['installation_before']['installation_committed'] and report['installation_before']['selected_release_blake2b_256']=='43d1c23b5ba4c7567d234650aa77e95dc4a096732087654de0b1228ca730d043'
 report['owner_before']=status('status');assert report['owner_before']['state']=='needs_login' and not report['owner_before']['claimable'] and report['owner_before']['sessions']==0 and not report['owner_before']['tailnet_ip'] and report['owner_before']['managed_owner_version']==1
 report['login_before']=login();assert report['login_before']['auth_url_present'] and report['login_before']['state']=='needs_login'
 report['boot_id_before']=boot()
 (OUT/'reboot-intent.json').write_text(json.dumps(report,indent=2)+'\n')
 with socket.create_connection(('192.168.50.100',4992),3) as api:
  api.settimeout(2);api.recv(16384);api.sendall(b'C1|radio reboot\n');report['reboot_commands_sent']=1
  try:api.recv(16384)
  except OSError:pass
 deadline=time.monotonic()+45
 while time.monotonic()<deadline:
  if not listening(4992) and not listening(48992):report['both_down_s']=round(time.monotonic()-start,3);print('radio_down',flush=True);break
  time.sleep(.5)
 assert 'both_down_s' in report,'Reboot shutdown not observed'
 deadline=time.monotonic()+180
 while time.monotonic()<deadline:
  if listening(48992):
   try:
    after=status('aetherpd/installation')
    if after==report['installation_before']:report['installation_after']=after;report['ready_s']=round(time.monotonic()-start,3);print('exact_release_ready',report['ready_s'],flush=True);break
   except (OSError,AssertionError,ValueError,subprocess.TimeoutExpired):pass
  time.sleep(.5)
 assert 'installation_after' in report,'Installed service did not return'
 deadline=time.monotonic()+65
 while time.monotonic()<deadline:
  try:
   after=status('status');observed=login()
   assert after['state'] not in ('running','needs_approval'),'External account approval detected; leave it intact'
   assert after['installation_id']==report['owner_before']['installation_id'] and not after['claimable'] and after['managed_owner_version']==1,'Owner boundary changed'
   assert observed['owner_verifier_fingerprint']==report['login_before']['owner_verifier_fingerprint'],'Owner credential changed'
   if observed['state']=='needs_login' and observed['auth_url_present']:report['owner_after']=after;report['login_after']=observed;break
  except (OSError,ValueError,subprocess.TimeoutExpired):pass
  time.sleep(.5)
 assert 'login_after' in report,'Pending sign-in did not resume'
 deadline=time.monotonic()+90
 while time.monotonic()<deadline:
  try:
   changed=boot()
   if changed!=report['boot_id_before']:report['boot_id_after']=changed;break
  except (OSError,AssertionError,subprocess.TimeoutExpired):pass
  time.sleep(.5)
 assert 'boot_id_after' in report,'Changed kernel boot ID not observed'
 report['passed']=True
finally:
 report['elapsed_s']=round(time.monotonic()-start,3);(OUT/'reboot-result.json').write_text(json.dumps(report,indent=2)+'\n');b.close()
print(json.dumps({k:report[k] for k in ('passed','ready_s','boot_id_before','boot_id_after')}),flush=True)
