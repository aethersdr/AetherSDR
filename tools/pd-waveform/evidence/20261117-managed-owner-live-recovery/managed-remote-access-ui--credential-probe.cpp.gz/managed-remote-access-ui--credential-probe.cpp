#include "core/TailnetShimTokenStore.h"
#include <QCoreApplication>
#include <QCryptographicHash>
#include <QEventLoop>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkProxy>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QRegularExpression>
#include <QTcpSocket>
#include <QTimer>
#include <cstdio>

using namespace AetherSDR;

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("AetherSDR"));
    if (argc != 2) { return 2; }
    const QString mode = QString::fromLocal8Bit(argv[1]);
    if (mode != QStringLiteral("login") && mode != QStringLiteral("discard-provision-reply")) { return 2; }
    QTimer::singleShot(30000, &app, [&] { app.exit(3); });
    TailnetShimTokenStore::load(QStringLiteral("2125-1213-8600-8895"), &app, [&](const QString& token) {
        if (!QRegularExpression(QStringLiteral("\\A[0-9a-f]{64}\\z")).match(token).hasMatch()) {
            std::puts("credential_unavailable"); app.exit(4); return;
        }
        const QByteArray verifier = QCryptographicHash::hash(token.toLatin1(), QCryptographicHash::Sha256).toHex();
        const QString fingerprint = QString::fromLatin1(QCryptographicHash::hash(verifier, QCryptographicHash::Sha256).toHex());
        QNetworkAccessManager network;
        network.setProxy(QNetworkProxy::NoProxy);
        QNetworkRequest request(QUrl(QStringLiteral("http://192.168.50.100:48992/v1/")
            + (mode == QStringLiteral("login") ? QStringLiteral("login") : QStringLiteral("status"))));
        request.setAttribute(QNetworkRequest::RedirectPolicyAttribute, QNetworkRequest::ManualRedirectPolicy);
        request.setRawHeader("Authorization", "Bearer " + token.toLatin1());
        request.setTransferTimeout(12000);
        QNetworkReply* reply = network.get(request);
        QEventLoop loop;
        QObject::connect(reply, &QNetworkReply::finished, &loop, &QEventLoop::quit);
        loop.exec();
        const int code = reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt();
        const QByteArray bytes = reply->read(65537);
        const QJsonDocument parsed = QJsonDocument::fromJson(bytes);
        if (code != 200 || bytes.size() > 65536 || !parsed.isObject()) {
            std::puts("observation_unavailable"); app.exit(5); return;
        }
        const QJsonObject status = parsed.object();
        QJsonObject result{{QStringLiteral("mode"), mode}, {QStringLiteral("http_status"), code},
            {QStringLiteral("owner_verifier_fingerprint"), fingerprint}};
        if (mode == QStringLiteral("login")) {
            const QString url = status.value(QStringLiteral("auth_url")).toString();
            result.insert(QStringLiteral("state"), status.value(QStringLiteral("state")));
            result.insert(QStringLiteral("auth_url_present"), !url.isEmpty());
            result.insert(QStringLiteral("auth_url_sha256"), url.isEmpty() ? QString() : QString::fromLatin1(
                QCryptographicHash::hash(url.toUtf8(), QCryptographicHash::Sha256).toHex()));
        } else {
            result.remove(QStringLiteral("http_status"));
            result.insert(QStringLiteral("precondition_http_status"), code);
            result.insert(QStringLiteral("post_reply_status_observed"), false);
            const QString expectedId = QStringLiteral("b6050e0036d2cfe91bce6f36c8c88faaea90e86722dd13c710a57015adb53654");
            const QString hostname = status.value(QStringLiteral("hostname")).toString();
            if (status.value(QStringLiteral("installation_id")).toString() != expectedId
                || status.value(QStringLiteral("managed_owner_version")).toInt() != 1
                || status.value(QStringLiteral("claimable")).toBool(true)
                || !status.value(QStringLiteral("provisioned")).toBool()
                || status.value(QStringLiteral("state")).toString() != QStringLiteral("needs_login")
                || !status.value(QStringLiteral("tailnet_ip")).toString().isEmpty()
                || !QRegularExpression(QStringLiteral("\\A[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?\\z")).match(hostname).hasMatch()) {
                std::puts("bounded_probe_precondition_failed"); app.exit(6); return;
            }
            const QJsonObject provision{{QStringLiteral("hostname"), hostname},
                {QStringLiteral("routes"), status.value(QStringLiteral("routes"))},
                {QStringLiteral("share_discovered"), status.value(QStringLiteral("share_discovered"))}};
            const QByteArray body = QJsonDocument(provision).toJson(QJsonDocument::Compact);
            const QByteArray wire = "POST /v1/provision HTTP/1.1\r\nHost: 192.168.50.100:48992\r\n"
                "Connection: close\r\nContent-Type: application/json\r\nAuthorization: Bearer "
                + token.toLatin1() + "\r\nContent-Length: " + QByteArray::number(body.size()) + "\r\n\r\n" + body;
            QTcpSocket socket;
            socket.setProxy(QNetworkProxy::NoProxy);
            socket.connectToHost(QStringLiteral("192.168.50.100"), 48992);
            if (!socket.waitForConnected(6000) || socket.write(wire) != wire.size()) {
                std::puts("request_not_written"); app.exit(7); return;
            }
            while (socket.bytesToWrite() != 0) {
                if (!socket.waitForBytesWritten(3000)) {
                    std::puts("request_write_unconfirmed"); app.exit(8); return;
                }
            }
            // Intentionally consume no provision response or returned credential.
            socket.abort();
            result.insert(QStringLiteral("request_bytes_written"), wire.size());
            result.insert(QStringLiteral("reply_consumed"), false);
            result.insert(QStringLiteral("socket_closed"), socket.state() == QAbstractSocket::UnconnectedState);
        }
        const QByteArray output = QJsonDocument(result).toJson(QJsonDocument::Compact);
        std::fwrite(output.constData(), 1, output.size(), stdout);
        std::puts("");
        app.exit(0);
    });
    return app.exec();
}
