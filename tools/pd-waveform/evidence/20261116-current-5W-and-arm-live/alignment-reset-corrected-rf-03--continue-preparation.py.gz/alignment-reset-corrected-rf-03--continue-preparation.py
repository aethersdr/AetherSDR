import json,pathlib,sys,time
sys.path.insert(0,'/home/jeremy/AetherSDR/build/aetherpd-source/tools');from automation_probe import Bridge
p=pathlib.Path(__file__).resolve().parent;b=Bridge('/tmp/aetherpd-measurement-arm-status');r={}
def req(q):
 x=b.request(q,8);assert x['ok'],x;return x
def invoke(n,a='click',v=None):
 q={'cmd':'invoke','target':n,'action':a}
 if v is not None:q['value']=v
 return req(q)
def widgets():
 out={}
 def walk(x):
  if isinstance(x,dict):
   if x.get('objectName','').startswith('pd'):out[x['objectName']]={k:v for k,v in x.items() if k!='children'}
   for v in x.values():walk(v)
  elif isinstance(x,list):
   for v in x:walk(v)
 walk(req({'cmd':'dumpTree'}));return out
def wait(f):
 end=time.monotonic()+25
 while True:
  x=f()
  if x:return x
  assert time.monotonic()<end,'Preparation timeout';time.sleep(.2)
import subprocess
r['identity']=req({'cmd':'whoami'});assert r['identity']['pid']==json.loads((p/'instance.json').read_text())['pid']
native=json.loads(subprocess.run([str(p.parent/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=10,check=True).stdout)
assert native['body']['registered'] and not native['body']['keyed'] and native['body']['correction_enabled']
r['preparation_note']='Fresh native session already has correction enabled; no redundant Enable request is needed.'
invoke('pdMeasurement');wait(lambda:widgets().get('pdMeasureRadioPower',{}).get('enabled'));invoke('pdMeasureRadioPower','setValue',5)
if req({'cmd':'get','model':'transmit'})['transmit']['rfPower']!=5:
 wait(lambda:widgets()['pdMeasureApplyPower']['enabled']);invoke('pdMeasureApplyPower');wait(lambda:req({'cmd':'get','model':'transmit'})['transmit']['rfPower']==5)
invoke('pdMeasureAverages','setValue',4);invoke('pdMeasureTimeout','setValue',10)
r['RF_commands']=[]
r['planned_native_cutoff_key_seconds']=9
r['source_noise_preamble_seconds']=4
r['LP100A_product_integration_deferred']=True
for m in ['radio','transmit','slices','pans']:r[m]=req({'cmd':'get','model':m})
assert not r['radio']['radio']['transmitting'] and not r['radio']['radio']['fullDuplex'];assert r['transmit']['transmit']['rfPower']==5 and r['transmit']['transmit']['maxPowerLevel']<=10
r['controls']=widgets();(p/'prepared.json').write_text(json.dumps(r,indent=2));print('Prepared: 5 W, timeout 10 s, local IQ channel4, FDX off; no RF yet.')
