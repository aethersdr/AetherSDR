#pragma once
#include "core/AetherPDPackage.h"
namespace AetherSDR::aetherpd::development {
inline QString version() { return QString::fromUtf8(QByteArray::fromHex("302e302e302d647370636c65616e75702e656139326562313365")); }
inline QString firmware() { return QString::fromUtf8(QByteArray::fromHex("342e332e31362e3432303334")); }
inline std::optional<AetherPDPackage> load() {
    AetherPDPackage::Trust trust;
    trust.candidateKey = QByteArray::fromHex("9a4286d5d3e006c5237a2fa3cf282ec3b9710a4e1b92b18d80f0122177e5a7ce");
    trust.previousKey = QByteArray::fromHex("9a4286d5d3e006c5237a2fa3cf282ec3b9710a4e1b92b18d80f0122177e5a7ce");
    trust.files[0] = {488768, QByteArray::fromHex("d45d88ff4587b5b5578fa8b4e2bdd9e13842a35c757cb1875e277296a989b77f")};
    trust.files[1] = {9069052, QByteArray::fromHex("1294f1d85d4637e608222858448ad66e46bdda737cbdbb40899d5c6de07a2a1b")};
    trust.files[2] = {9069023, QByteArray::fromHex("da01a56d6301aebd85b7bc1abfd85d46d28eecc7cdac6a1d6eed4ba1984b0382")};
    trust.files[3] = {29984, QByteArray::fromHex("4cda5ed6f692de5ea8950c78b418979a6d7d1f2dc5ed3da6d0147d3e8f84c31d")};
    trust.files[4] = {6291616, QByteArray::fromHex("b1c90bc317f59c49438079934dc7cfbfc607a98cb78bf458e6f608218dd1c8dc")};
    trust.files[5] = {42344, QByteArray::fromHex("c2cd5aede08badfd67dd4fa0d989f92ab9715961bd49e654a20d4806ced757df")};
    trust.files[6] = {110472, QByteArray::fromHex("7ff519413c52cd99daa17671d40a3049575c3c5607668283efbbfba9742fbb2b")};
    trust.files[7] = {215346, QByteArray::fromHex("3acd62434bb56358ffb5f34e1909bb53a0f29470523f637427ac80f23c1c2127")};
    const auto package = AetherPDPackage::load(QString::fromUtf8(QByteArray::fromHex("2f686f6d652f6a6572656d792f4165746865725344522f6275696c642f61657468657270642d7368696d2d696e746567726174696f6e2f757067726164652d70726570617265642d636c65616e75702d7265746972656d656e742f7365636f6e642d64697374696e63742d6c6f6e672d736f757263652d706174682f7061636b616765")), trust);
    if (!package || package->profile() != 1 || package->firmware() != firmware()) { return std::nullopt; }
    return package;
}
}
