from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
p=Path(__file__).resolve().parent;e=p.parent;w=e.parent/'aetherpd-source';d=w/'tools/pd-waveform/evidence/20261117-prepared-cleanup-installed';d.mkdir(exist_ok=False)
load=lambda f:json.loads(f.read_text());sha=lambda b:hashlib.sha256(b).hexdigest()
rebuild=load(e/'runtime-prepared-cleanup-retirement/report.json');distribution=load(e/'upgrade-prepared-cleanup-retirement/report.json');budget=load(e/'runtime-prepared-cleanup-retirement/budget-report.json');changes=load(e/'runtime-prepared-cleanup-retirement/payload-comparison.json')
install=load(p/'install-result.json');baseline=load(e/'prepared-dsp-stall-02/outcome.json');fixed=load(e/'prepared-dsp-stall-fixed/outcome.json');recovered=load(e/'prepared-cleanup-recovery/recovery-outcome.json');outer=load(e/'prepared-cleanup-recovery/audit-result.json');audit=json.loads(outer['logs']);reboot=load(e/'prepared-cleanup-reboot/reboot-check.json')
assert install['committed'] and baseline['passed'] and fixed['passed'] and recovered['passed'] and audit['passed']
assert outer['wait']['StatusCode']==0 and outer['job_container_deleted'] and outer['temporary_host_directory_deleted']
assert distribution['complete_eight_file_distribution_identical'] and all(a['identical_release'] and a['identical_manifest'] for a in rebuild['architectures'].values())
assert fixed['probe']['ordinary_cleanup_observation_count']>=3 and not fixed['probe']['post_timeout_root_observations']
assert recovered['capture_after_restart']['bytes']==131072 and not reboot['passed'] and reboot['reboot_commands_sent']==1
folders=[p,e/'prepared-dsp-stall-fixed',e/'prepared-dsp-stall-recovery',e/'prepared-cleanup-recovery',e/'prepared-cleanup-reboot']
files=[]
for folder in folders:
 files.extend(f for f in folder.iterdir() if f.is_file() and f.suffix in ['.py','.json','.log','.f32le'])
for folder in ['runtime-prepared-cleanup-retirement','upgrade-prepared-cleanup-retirement']:
 root=e/folder;files.extend(f for f in root.iterdir() if f.is_file() and f.suffix in ['.py','.json','.log','.c'])
 for label in ['short','second-distinct-long-source-path']:
  for tail in ['manifest.json','selection.json','upgrade-selection.h','armv7/manifest.json','arm64/manifest.json']:
   f=root/label/tail
   if f.exists():files.append(f)
files.append(e/'prepared-cleanup-artifact-archive.json')
evidence={}
for file in sorted(set(files)):
 target=d/(str(file.relative_to(e))+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(file.read_bytes(),mtime=0));evidence[str(target.relative_to(w))]=sha(target.read_bytes())
rows=[r for r in budget['measurements'] if r['arch']=='armv7'];worst=max(rows,key=lambda r:r['successor_peak_including_native_reserve_bytes'])
report={
 'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'ordinary_update_installed_DSP_timeout_privilege_retirement_and_IQ_recovery_passed_single_reboot_return_unqualified',
 'production_ready':False,'runtime_source_commit':rebuild['source_commit'],
 'candidate_release_blake2b_256':'b732344cad128503ee8f2bf67cfd912dee4cc947bf5beac212a606766f79a42c','approved_plan_blake2b_256':'e0b73370e023a026fdd3ad7f1eb7ab3785b1d5324ea3f6c809024d5124e861e0',
 'desktop':load(p/'instance.json'),'desktop_build':load(p/'desktop-provenance.json'),
 'reproducibility':{'complete_runtime_two_paths_both_architectures':True,'complete_eight_file_upgrade_distribution_identical':True,'architectures':changes,'development_signing_seed_in_files':False,'authenticated_archive':load(e/'prepared-cleanup-artifact-archive.json')},
 'upgrade_space':{'native_boundary_checks':sum(len(r['boundary_checks_passed']) for r in budget['measurements']),'worst_ARMv7_modelled_peak_bytes':worst['successor_peak_including_native_reserve_bytes'],'headroom_against_rounded_decimal41MB_bytes':worst['remaining_from_41_decimal_MB'],'actual6300_qualification':False,'scope':'Native signature/admission functions with actual signed predecessor/candidate files and synthetic filesystem capacities; modelled steady state plus explicit state/metadata allowances, not measured whole-volume6300 usage.'},
 'ordinary_update':{'committed_and_temporary_cleanup_confirmed':True,'elapsed_s':install['elapsed_s'],'states':install['states'],'broad_diagnostics_used_for_delivery':False,'owner_identity_preserved':True,'no_new_privileged_interface':True},
 'installed_startup_stall':{'baseline_workers_gone_ms':baseline['probe']['workers_gone_ms'],'baseline_post_timeout_root_observation_count':len(baseline['probe']['post_timeout_root_observations']),'fixed_workers_gone_ms':fixed['probe']['workers_gone_ms'],'fixed_post_timeout_root_observation_count':0,'fixed_ordinary_cleanup_observations':fixed['probe']['ordinary_cleanup_observation_count'],'cleanup_parent_UID':78666,'all_capability_sets_zero':True,'NoNewPrivs':1,'DSP_registered':fixed['registered_was_observed'],'independent_resume_watchdog_used':False,'original_DSP_PID_including_zombie_gone':fixed['probe']['original_DSP_PID_including_zombie_gone'],'fixed_ARP_removed':not fixed['probe']['arp_after'],'ARP_journal_bytes':fixed['probe']['journal_bytes_after'],'accept_local':fixed['probe']['accept_local']},
 'ordinary_post_fault_recovery':{'passed':True,'ready_s':recovered['restart']['ready_s'],'capture':recovered['capture_after_restart'],'final_stop':recovered['final_stop'],'privileged_repair':False,'FDX':False,'RF_commands':[]},
 'independent_pre_reboot_audit':audit,
 'reboot':{'passed':False,'commands_sent':reboot['reboot_commands_sent'],'old_boot_id':reboot['boot_id_before'],'both_ports_down_s':reboot['both_down_s'],'observation_ended_s':reboot['elapsed_s'],'error':reboot['error'],'new_boot_id':None,'exact_release_return_verified':False,'meaning':'Radio did not return within the single reboot monitor. Subsequent discovery omitted this radio, neighbor lookup failed and API/shim/diagnostic ports were unreachable; other bench radios remained discoverable. Firmware, power, network and startup causality is not established.','external_check_requested':'Operator power/status LED and Ethernet link state.','reboot_retries':0},
 'credential_mutations':[],'RF_key_actions':0,'production_defaults_changed':False,
 'limitations':['Current software-reboot persistence and post-reboot IQ are unqualified; radio is currently unreachable, so no fresh RF-idle claim is made after disconnect. Last confirmed state before reboot was idle and stopped.','One bounded prepared-DSP stall before registration. No indefinite kernel stall, keyed fault, all other partial stages or full failure matrix qualification.','Privilege reduction is demonstrated during failed-start termination; the constructor still uses setup authority before completing the required scheduling step.','Actual FLEX6300/Linux2.6/one-core qualification, full shipping catalogue/credentials/platform/disk/power-loss and independent release gates remain open.','Prior RF evidence applies to its recorded binaries/captures. This new release has not been RF-qualified, despite unchanged DSP/shim bytes.','The operator-deferred5W SWR investigation and preamble experiment remain parked; no RF or safety threshold changes.'],
 'evidence_sha256':evidence,
}
(w/'tools/pd-waveform/PREPARED-CLEANUP-INSTALLED-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
planpath=e/'production-completion-plan-20261113.json';plan=load(planpath)
plan['prepared_cleanup_retirement']={'report':'tools/pd-waveform/PREPARED-CLEANUP-INSTALLED-QUALIFICATION.json','component_report':'tools/pd-waveform/PREPARED-CLEANUP-RETIREMENT-QUALIFICATION.json','source_commit':rebuild['source_commit'],'installed_fix':True,'installed_timeout_privilege_retirement_passed':True,'full_receive_IQ_recovery_passed':True,'reboot_persistence_qualified':False,'production_ready':False}
current=plan['current_candidate'];current['source_commit']=rebuild['source_commit'];current['release_blake2b_256']=report['candidate_release_blake2b_256'];current['desktop_PID']=report['desktop']['pid'];current['desktop_bridge']=report['desktop']['socket'];current['desktop_sha256']=report['desktop']['binary_sha256'];current['desktop_source']=rebuild['source_commit'];current['unchanged_fixed_helper_pins']['pd-radio-launch']=audit['runtime_sha256']['pd-radio-launch'];current['runtime_state']='unreachable_after_single_reboot';current['RF_idle']=None;current['last_confirmed_pre_reboot_RF_idle']=True;current['current_release_post_reboot_qualified']=False;current['current_release_RF_qualified']=False;current['current_mode']=None;current['current_GUI_handle']=None;current['last_confirmed_boot_id']=reboot['boot_id_before'];current['boot_id']=None;current['qualification_report']='tools/pd-waveform/PREPARED-CLEANUP-INSTALLED-QUALIFICATION.json'
plan['last_goal_turn_classification']='progress: reproduced unnecessary root retention during prepared-DSP timeout; implemented guarded privilege retirement, CTest/sanitizer/three mutation/cross-build checks, reproduced full signed runtime and distribution in two paths, ordinarily installed and live-requalified UID/caps, recovered fullIQ; one reboot did not return and is explicitly unqualified.'
plan['next_action']='Revalidate radio discovery/API/diagnostics without another reboot; incorporate operator power/status-LED/Ethernet check, then verify exact selected release, boot ID, identity and localIQ on return. Preserve failed reboot evidence and operator-deferred5W SWR. While hardware is unavailable, continue independent packaging/portability/failure-review work without claiming final production qualification; retain full P1–P10 and actual6300 gates.'
planpath.write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'report':'PREPARED-CLEANUP-INSTALLED-QUALIFICATION.json','evidence_files':len(evidence),'installed_fix':True,'reboot_qualified':False,'production_ready':False}))
