import hashlib,json,os,pathlib,subprocess,sys,time
sys.path.insert(0,'/home/jeremy/AetherSDR/build/aetherpd-source/tools');from automation_probe import Bridge
p=pathlib.Path(__file__).resolve().parent;b=Bridge('/tmp/aetherpd-post-ptt-power')
who=b.request({'cmd':'whoami'},5);assert who['pid']==3832966 and who['automationIdentity']=='aetherpd-shim-integration'
r=b.request({'cmd':'get','model':'radio'},5)['radio'];assert r['connected'] and not r['transmitting'] and not r['fullDuplex']
x=json.loads(subprocess.run([str(p.parent/'first-iq-live/vault-v3'),'aetherpd/installation'],capture_output=True,text=True,timeout=20).stdout);assert x['http_status']==200 and x['body']['installation_committed'] and x['body']['selected_release_blake2b_256']=='43d1c23b5ba4c7567d234650aa77e95dc4a096732087654de0b1228ca730d043'
status=json.loads(subprocess.run([str(p.parent/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=20,check=True).stdout);assert status['http_status']==200 and status['body'].get('state') == 'stopped' and not status['body'].get('available',False)
assert hashlib.sha256(pathlib.Path('/proc',str(who['pid']),'exe').read_bytes()).hexdigest()=='5410069710987385818abc17783b61ed7f298ae07dd04185241172f90f3c4c6d'
binary=p.parent/'first-install-desktop-monitor/project/AetherSDR';digest=hashlib.sha256(binary.read_bytes()).hexdigest();assert digest==json.loads((p/'desktop-provenance.json').read_text())['sha256']
# Require the confirmed stopped state before replacing the desktop.
retirement_begin=time.monotonic()
assert b.request({'cmd':'invoke','target':'Quit','action':'trigger'},5)['ok'];b.close();end=time.monotonic()+15
while pathlib.Path('/proc',str(who['pid'])).exists():assert time.monotonic()<end;time.sleep(.2)
assert subprocess.run(['pgrep','-x','AetherSDR'],capture_output=True).returncode!=0
profile=p.parent/'guardian-owner-live/fresh/private-profile'
env=os.environ.copy();env.pop('AETHER_AUTOMATION_NO_TX',None);env.update(AETHER_SETTINGS_DIR=str(profile),AETHER_AUTOMATION='1',AETHER_AUTOMATION_ALLOW_TX='1',AETHER_AUTOMATION_IDENTITY='aetherpd-shim-integration',AETHER_AUTOMATION_AGENT_NAME='Codex AetherPD',AETHER_AUTOMATION_SOCKET='aetherpd-prepared-cleanup')
with (p/'desktop.log').open('ab') as log:proc=subprocess.Popen([str(binary)],env=env,stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
r={'pid':proc.pid,'socket':'/tmp/aetherpd-prepared-cleanup','binary_sha256':digest,'profile':str(profile),'runtime_source_before_update':'7080de965a595ac44982b8f8cfdbc5142ea07dee','desktop_source':json.loads((p/'desktop-provenance.json').read_text())['source_commit'],'keying_requires_explicit_bridge_action':True};(p/'instance.json').write_text(json.dumps(r,indent=2));print(json.dumps(r))

# Keep the AetherPD panel closed while the predecessor private channel's idle
# lifetime expires. Connection/receiver polling does not renew that channel.
deadline=time.monotonic()+15
while not pathlib.Path(r['socket']).exists():
 assert proc.poll() is None and time.monotonic()<deadline
 time.sleep(.1)
b=Bridge(r['socket']);deadline=time.monotonic()+35
while True:
 radio=b.request({'cmd':'get','model':'radio'},5)['radio']
 if not radio['connected']:
  b.request({'cmd':'connect','action':'local','value':'serial 2125-1213-8600-8895'},5)
 else:
  assert not radio['transmitting'] and not radio['fullDuplex']
  pans=b.request({'cmd':'get','model':'pans'},5)['pans']
  slices=b.request({'cmd':'get','model':'slices'},5)['slices']
  if pans and all(x['ownedByUs'] for x in pans) and slices and time.monotonic()-retirement_begin>=20:break
 assert proc.poll() is None and time.monotonic()<deadline
 time.sleep(.25)
r['receiver_ready']=True;r['predecessor_channel_idle_wait_s']=time.monotonic()-retirement_begin;(p/'instance.json').write_text(json.dumps(r,indent=2)+'\n');b.close()
