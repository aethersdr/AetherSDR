import ast,base64,hashlib,json,math,pathlib,struct,subprocess,sys,time
P=pathlib.Path(__file__).resolve().parent;E=P.parent
sys.path.insert(0,str(E.parent/'aetherpd-source/tools'));from automation_probe import Bridge
assert not (P/'recovery-outcome.json').exists(),'Preserve every attempt'
instance=json.loads((P/'instance.json').read_text());bridge=Bridge(instance['socket'])
report={'passed':False,'RF_commands':[],'credential_mutations':[],'Start_actions':0,'Stop_actions':0};events=[];job=None;started=False

def event(name,**values):
 events.append({'event':name,'monotonic_ns':time.monotonic_ns(),**values});(P/'recovery-events.json').write_text(json.dumps(events,indent=2)+'\n')
def req(q):
 r=bridge.request(q,8);event('bridge',request=q,response=r);assert r.get('ok'),r;return r

def read(path):
 r=subprocess.run([str(E/'first-iq-live/vault-v3'),path],capture_output=True,text=True,timeout=22)
 result=json.loads(r.stdout);event('authenticated_read',path=path,response=result);return result

def idle():
 r=req({'cmd':'get','model':'radio'})['radio'];assert r['connected'] and not r['transmitting'] and not r['fullDuplex'] and r['serial']=='2125-1213-8600-8895'
 tx=req({'cmd':'get','model':'transmit'})['transmit'];assert not tx['mox'] and not tx['tuning'] and not tx['apdEnabled']
 return r

def start():
 global started
 idle();req({'cmd':'invoke','target':'pdStart','action':'click'});started=True;report['Start_actions']+=1;begin=time.monotonic();end=begin+35
 while True:
  s=read('aetherpd/status')
  if s['http_status']==200 and s['body'].get('registered'):break
  assert time.monotonic()<end,s;time.sleep(.25)
 assert not s['body']['keyed'] and not s['body']['correcting']
 return {'ready_s':time.monotonic()-begin,'status':s}

def stop():
 global started
 req({'cmd':'invoke','target':'pdStop','action':'click'});report['Stop_actions']+=1;end=time.monotonic()+20
 while True:
  s=read('aetherpd/status')
  if s['http_status']==200 and s['body'].get('state')=='stopped':break
  assert time.monotonic()<end,s;time.sleep(.25)
 started=False;return s

def capture(label,identity):
 c=read('aetherpd/capture');assert c['http_status']==200,c
 meta=c['body'];binding=meta['feedback_binding']
 assert binding['valid'] and not binding['failed'] and binding['transport']=='local_dax_iq'
 assert binding['channel']==4 and binding['gui_handle']==identity['gui_handle'] and binding['pan']==identity['feedback_pan']
 assert meta['sample_rate_hz']==48000 and meta['sample_count']==16384 and not meta['keyed'] and not meta['correcting']
 raw=bytearray()
 for n in range(32):
  r=read('aetherpd/capture/'+meta['capture_id']+'/'+str(n));assert r['http_status']==200,r
  assert r['body']['offset']==n*512
  data=base64.b64decode(r['body']['iq_f32le'],validate=True);assert len(data)==4096;raw.extend(data)
 values=struct.unpack('<'+str(len(raw)//4)+'f',raw)
 assert len(raw)==131072 and all(math.isfinite(x) for x in values) and any(x!=0 for x in values)
 (P/(label+'.f32le')).write_bytes(raw)
 return {'metadata':meta,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()}
try:
 who=req({'cmd':'whoami'});assert who['pid']==instance['pid'] and who['automationIdentity']=='aetherpd-shim-integration'
 report['radio_before']=idle();report['status_before']=read('aetherpd/status')
 assert report['status_before']['http_status'] in [200,503] and report['status_before']['body'].get('state') in ['unavailable','cleanup_unconfirmed','stopped']
 pans=req({'cmd':'get','model':'pans'})['pans'];assert len(pans)==1 and pans[0]['ownedByUs'] and pans[0]['rxAntenna']=='RX_A' and pans[0]['rfGain']==0
 identity={'gui_handle':int(pans[0]['clientHandle'],16),'feedback_pan':int(pans[0]['panId'],16)}
 report['restart']=start();report['capture_after_restart']=capture('dsp-stall-restarted-IQ',identity)
 report['final_stop']=stop();report['radio_after']=idle()
 report['owner_after']=json.loads(subprocess.run([str(E/'managed-remote-access-ui/credential-probe'),'login'],capture_output=True,text=True,timeout=35,check=True).stdout)
 assert report['owner_after']['state']=='local' and not report['owner_after']['auth_url_present'] and report['owner_after']['owner_verifier_fingerprint']=='9d5efda3384e7d4100d905c7dcecbc5fa975f494db0ffd7f4d13d6095c5f925c'
 report['passed']=True
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
 if started:
  try:report['fallback_stop']=stop()
  except Exception as error:report['cleanup_error']=str(error);report['passed']=False
 bridge.close();(P/'recovery-outcome.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['passed','error','cleanup_error','Start_actions','Stop_actions'] if k in report}),flush=True)
 if not report['passed']:raise SystemExit(1)
