"""One two-second GUI-keyed5W carrier; fixed native backstop and independentLP. No retry."""
import base64,hashlib,importlib.util,json,math,pathlib,subprocess,sys,time,traceback
import numpy as np
from bench_audio_route_native import Route,SINK
from bench_meter_monitor import MeterMonitor
P=pathlib.Path(__file__).resolve().parent;sys.path.insert(0,str(P.parent.parent/'aetherpd-source/tools'));from automation_probe import Bridge
for name in ['meter-watch','bench-observer']:
 spec=importlib.util.spec_from_file_location(name,P/(name+'.py'));module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
 if name=='meter-watch':MW=module.MeterWatch
 else:Observer=module.Observer
assert not (P/'events.json').exists(),'Inspect named attempt; no automatic rekey'
assert json.loads((P/'preflight-result.json').read_text())['passed']
instance=json.loads((P/'instance.json').read_text());b=Bridge(instance['socket']);events=[];out={'passed':False,'positive_GUI_key_actions':0,'correction':False,'RF_mode':'softwarePTT USB, not TUNE'};route=None;lp=None;meter=None;observer=None;player=None;capture=None;guard=None;key_ns=None

def record(kind,**data):
 events.append({'event':kind,'monotonic_ns':time.monotonic_ns(),**data});(P/'events.json').write_text(json.dumps(events,indent=2)+'\n')
def bridge(q):
 d=b.request(q,3);record('bridge',request=q,response=d);assert d.get('ok'),d;return d

def api(action,identifier=None):
 run=subprocess.run([str(P/'bench-api'),action]+([identifier] if identifier else []),capture_output=True,text=True,timeout=16);d=json.loads(run.stdout);record('native_API',operation=action,response=d)
 if action=='status' and d['http_status']==503 and d['body'].get('state')=='stopped':return d['body']
 assert run.returncode==0 and d['complete'],d;return d['body']

def idle_state():
 s={m:bridge({'cmd':'get','model':m})[m] for m in ['radio','transmit','slices','pans']};r=s['radio'];t=s['transmit'];sl=s['slices'];pa=s['pans'];assert r['connected'] and not r['transmitting'] and not r['fullDuplex'] and r['serial']=='2125-1213-8600-8895'
 assert t['rfPower']==5 and t['maxPowerLevel']==10 and not t['apdEnabled'] and t['micSelection']=='PC' and not t['speechProc'] and not t['voxEnable'] and not t['dax']
 assert len(sl)==1 and sl[0]['mode']=='USB' and sl[0]['frequency']==7.15 and sl[0]['txAntenna']=='ANT1' and sl[0]['rxAntenna']=='RX_A' and sl[0]['txSlice']
 assert len(pa)==1 and pa[0]['ownedByUs'] and pa[0]['rfGain']==0 and pa[0]['centerMhz']==7.15;return s
try:
 who=bridge({'cmd':'whoami'});assert who['pid']==3744797 and who['txAllowed']
 with pathlib.Path('/proc/3744797/exe').open('rb') as f:assert hashlib.file_digest(f,'sha256').hexdigest()==instance['binary_sha256']
 before=idle_state();gui=int(before['pans'][0]['clientHandle'],16);native=api('status');assert native['registered'] and not native['keyed'] and not native['correction_enabled']
 binding=native['feedback_binding'];assert binding['valid'] and not binding['failed'] and binding['gui_handle']==gui and binding['channel']==4 and binding['transport']=='local_dax_iq'
 lp=MeterMonitor(P);assert lp.ready()['power_w']==0;meter=MW();deadline=time.monotonic()+5
 while not meter.ready():assert time.monotonic()<deadline;time.sleep(.02)
 observer=Observer();obs=observer.snapshot();assert obs['interlock']['state']=='READY' and obs['apd']['enable']=='0'
 rate=48000;n=4*rate;t=np.arange(n)/rate;pcm=.83*np.sin(2*np.pi*710*t);ramp=np.linspace(0,1,960);pcm[:960]*=ramp;pcm[-960:]*=ramp[::-1];raw=np.repeat(pcm[:,None],2,axis=1).astype('<f4').tobytes();(P/'carrier-source.f32le').write_bytes(raw);out['source']={'rate':rate,'channels':2,'duration_s':4,'tone_Hz':710,'peak_amplitude':.83,'sha256':hashlib.sha256(raw).hexdigest()}
 route=Route(P/'route-cleanup.json');out['route']=route.start();route.verify()
 guard=api('guard-begin');out['guard_begin']=guard;assert guard['state']=='observing' and guard['remaining_ms']>8000
 with (P/'player.log').open('w') as log:player=subprocess.Popen(['pacat','--playback','--device='+SINK,'--rate=48000','--channels=2','--format=float32le','--latency-msec=20','--client-name=AetherPD-Carrier-SWR',str(P/'carrier-source.f32le')],stdout=subprocess.DEVNULL,stderr=log)
 time.sleep(.1);assert player.poll() is None;route.verify();idle_state();assert lp.require()['power_w']==0
 active=api('guard-status',guard['test_id']);assert active['state']=='observing' and active['remaining_ms']>7000
 record('operator_key_intent',frequency_MHz=7.15,USB_carrier_RF_MHz=7.150710,nominal_W=5,configured_max_W=10,planned_GUI_key_s=2,finite_source_s=4,native_cleanup_initiation_ms=9000,LP_stop_W=6,LP_stop_SWR=1.5,Flex_stop_SWR=2,guard_limit_changes=False)
 key_ns=time.monotonic_ns();out['positive_GUI_key_actions']=1;bridge({'cmd':'key','action':'ptt','value':'on'});saw_key=False;capture_started=False;last_native=0
 while (time.monotonic_ns()-key_ns)/1e9<2:
  elapsed=(time.monotonic_ns()-key_ns)/1e9;obs=observer.snapshot();r=bridge({'cmd':'get','model':'radio'})['radio'];inter=obs['interlock'];saw_key|=r['transmitting'] or inter.get('state')=='TRANSMITTING';record('interlock',snapshot=obs,elapsed_s=elapsed)
  assert r['connected'] and not r['fullDuplex'];assert not saw_key or r['transmitting'],'Radio released early'
  if inter.get('state') in ['TRANSMITTING','PTT_REQUESTED']:assert int(inter['tx_client_handle'],16)==gui and inter.get('source')=='SW' and not inter.get('reason')
  power=meter.check(key_ns);external=lp.require();record('meters',Flex=power,LP=external,elapsed_s=elapsed)
  if power['watts']>.5:
   assert '10' in meter.latest and time.monotonic_ns()-meter.latest['10'][0]<=2_000_000_000,'SWR stale'
   assert 1<=power['radio_reported_swr']<=2,('Flex SWR stop',power)
  if elapsed-last_native>=.3:
   native=api('status');assert native['registered'] and not native['correction_enabled'] and not native['correcting'] and not any(native['faults'].values());last_native=elapsed
  if elapsed>.45 and not capture_started:
   with (P/'capture.json').open('w') as f:capture=subprocess.Popen([str(P/'bench-api'),'capture'],stdout=f,stderr=subprocess.DEVNULL)
   capture_started=True
  assert player.poll() is None,'Finite source ended early';time.sleep(.02)
 out['key_observed']=saw_key;assert saw_key
 out['normal_GUI_stop']=bridge({'cmd':'key','action':'ptt','value':'off'});out['GUI_stop_after_intent_s']=(time.monotonic_ns()-key_ns)/1e9
except Exception as e:out['error']=str(e);out['traceback']=traceback.format_exc();record('error',error=out['error'])
finally:
 if player and player.poll() is None:player.terminate()
 try:
  if observer and key_ns:
   inter=observer.snapshot()['interlock']
   if inter.get('source')=='SW' and int(inter.get('tx_client_handle','0'),16)==gui:bridge({'cmd':'key','action':'ptt','value':'off'})
  if guard:
   out['guard_stop']=api('guard-stop',guard['test_id']);deadline=time.monotonic()+12
   while True:
    state=api('guard-status',guard['test_id'])
    if state['state']=='ended':break
    assert time.monotonic()<deadline;time.sleep(.05)
   out['guard_ended']=state
  deadline=time.monotonic()+10
  while True:
   r=bridge({'cmd':'get','model':'radio'})['radio'];obs=observer.snapshot() if observer else {}
   if not r['transmitting'] and obs.get('interlock',{}).get('state')=='READY':break
   assert time.monotonic()<deadline,'Release not confirmed';time.sleep(.05)
  out['radio_idle_after']=True;out['radio_after']=r;out['LP_idle_after']=lp.await_zero() if lp else None
  if capture:
   capture.wait(timeout=6);result=json.loads((P/'capture.json').read_text());out['capture_complete']=capture.returncode==0 and result['complete']
   if out['capture_complete']:
    raw=base64.b64decode(result['iq_f32le'],validate=True);assert len(raw)==131072 and hashlib.sha256(raw).hexdigest()==result['iq_sha256'];out['capture_manifest']=result['body'];(P/'carrier-IQ.f32le').write_bytes(raw)
  out['passed']=bool(out.get('key_observed') and 'error' not in out)
 except Exception as e:out['cleanup_error']=str(e);out['cleanup_traceback']=traceback.format_exc();out['passed']=False
 if capture and capture.poll() is None:capture.terminate();capture.wait(timeout=3)
 if player:
  try:player.wait(timeout=3)
  except subprocess.TimeoutExpired:player.kill();player.wait(timeout=2)
 if route:
  out['audio_route_cleanup']=route.close()
  if out['audio_route_cleanup'].get('errors'):out['passed']=False
 if lp:lp.close()
 if meter:(P/'independent-meters.json').write_text(json.dumps({'port':meter.port,'rows':meter.rows,'replies':meter.replies},indent=2));meter.close()
 if observer:out['observer_rows']=observer.rows;observer.close()
 try:
  bridge({'cmd':'invoke','target':'pdStop','action':'click'});deadline=time.monotonic()+25
  while True:
   state=api('status')
   if state.get('state')=='stopped':break
   assert time.monotonic()<deadline;time.sleep(.2)
  out['service_stopped']=True
 except Exception as e:out['service_cleanup_error']=str(e);out['passed']=False
 b.close();(P/'outcome.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps({k:v for k,v in out.items() if k not in ['observer_rows','radio_after','capture_manifest','traceback','cleanup_traceback']},indent=2),flush=True)
