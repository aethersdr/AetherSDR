from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,sys

P=Path(__file__).resolve().parent;E=P.parent;W=E.parent/'aetherpd-source'
def read(path):return json.loads(path.read_text())
def sha(path):return hashlib.sha256(path.read_bytes()).hexdigest()
def write(path,value):path.write_text(json.dumps(value,indent=2)+'\n')
analysis=read(P/'analysis.json');assert analysis['positive_GUI_key_actions']==3 and not analysis['production_ready']
cases=analysis['cases'];assert sum(c['whole_harness_passed'] for c in cases.values())==2
assert all(c['radio_idle_after'] and c['session_stopped'] and c['LP_idle_after_W']==0 for c in cases.values())
assert cases['final-native-baseline-10W-02']['export_error']=='SWR above the configured limit' and not cases['final-native-baseline-10W-02']['valid_measurement']
outer=read(E/'final-runtime-RF-audit/audit-result.json');audit=json.loads(outer['logs']);assert audit['passed'] and outer['job_container_deleted'] and outer['temporary_host_directory_deleted']
safe=read(E/'final-runtime-RF-readiness/stop-unkeyed-preparation.json');assert safe['positive_key_actions_this_cleanup']==0 and safe['status']['body']['state']=='stopped'
for name in ['final-native-corrected-10W-02','final-native-baseline-10W-03','final-native-corrected-10W-03']:assert not (E/name/'events.json').exists()
command=[str(P/'plot-venv/bin/python'),'-c','import json,sys,numpy,matplotlib;print(json.dumps({"python":sys.version,"numpy":numpy.__version__,"matplotlib":matplotlib.__version__}))']
versions=json.loads(subprocess.check_output(command,text=True));versions['analysis_only_not_product_dependencies']=True;write(P/'analysis-environment.json',versions)
now=datetime.now(timezone.utc).isoformat()
report={'updated_utc':now,'status':'installed_candidate_finite10W_pair_corrects_signal_repeat_aborted_by_existing_SWR_guard_full_RF_qualification_incomplete',
 'production_ready':False,'source_parent_commit':'e581033ee8b6ced369f034ef9c51ef1fb8628259',
 'runtime_source_commit':'aa5a33fc5de78ad5a9d6e5d48ba2e9c697e03bf0','radio_release_blake2b_256':'c3d2522512f66f32025747661335e82eb8a3f572fe9888acf7af8380f9a43404',
 'native_DSP_sha256':'b3fc2de87fb51a20721d53a3e0758c4206b29f4ccd6ad1b96e273400471cdf8d',
 'desktop':read(E/'native-durability-installed/instance.json'),'firmware':'4.3.16.42034','boot_id':audit['boot_id'],
 'scope':{'positive_GUI_key_actions':3,'each_positive_key_through_existing_AetherSDR_automation_bridge':True,'AetherTX_launched':False,'nominal_and_configured_max_W':10,
 'frequency_MHz':7.15,'path':'ANT1 dummy load/sampler feedback RXA; RF gain0','FDX':False,'feedback':'local DAX IQ channel4/48000Hz',
 'source_seconds':8,'native_helper_cleanup_budget_seconds':9,'desktop_authorization_seconds':10,'source_or_guard_thresholds_changed':False,'automatic_key_retry_or_rearm':False,
 'reboot_commands':[],'radio_updates_this_turn':0,'LP_product_integration_deferred':True,'broad_root_diagnostics_used_for_RF_setup_or_keying':False,'broad_root_laboratory_post_RF_metadata_audit':True},
 'completed_pair':analysis['completed_pair'],'cases':cases,'analysis_environment':versions,
 'prepared_but_not_keyed':['final-native-corrected-10W-02','final-native-baseline-10W-03','final-native-corrected-10W-03'],
 'preserved_sequencing_mistake':{'observation':'After baseline02 failed, a shell newline allowed receive-only corrected02 preparation to proceed despite the preceding Python assertion. No corrected02 arm or key command was run. Preparation was allowed to become terminal, then the ordinary Stop was verified.',
 'stop_receipt':safe,'analysis_of_invalid_export':'Initial offline analyzers raised KeyError because the aborted export had no measurement object. The per-frame CLI now refuses invalid exports explicitly; no spectrum was computed for the failed run.',
 'derived_sign_correction':'Initial pair JSON used corrected-minus-baseline under an improvement label; it was preserved as pair-01-initial-sign-error.json, then corrected to baseline-minus-corrected. Raw data and analyzer results were unchanged.'},
 'post_RF_native_audit':audit,'post_RF_laboratory_observer_and_scratch_removed':True,
 'plots':['tools/pd-waveform/evidence/20261117-final-runtime-RF/finite-pair-spectrum.png','tools/pd-waveform/evidence/20261117-final-runtime-RF/finite-pair-spectrum.svg'],
 'limitations':['One completed finite10W-setting OFF/ON pair, four16384-sample frames per run. The following baseline repeat hit the unchanged SWR guard. Repeatability, endurance, speech and fullP7 remain unqualified.',
 'IMD3 is per mean fundamental tone; fundamental-only PEP rose0.345990dB ON. LP reports a7.49W peak-held maximum in both runs, not synchronized calibrated instantaneous forward watts. Its configured forward/net basis remains unknown.',
 'Independent NumPy FFT and interpolated products agree with the application export; this is independent computation of the same IQ, not a second RF instrument. Frames are not asserted statistically independent.',
 'No alignment reset, dispatch deadline, send error, stale IQ or TX-input limiting was observed in these bounded runs. This does not attribute the historical natural128sample slip or certify all scheduling behavior.',
 'Raw IQ scale, absolute ADC headroom, receiver linearity and sampler attenuation remain uncalibrated. The unchanged operator-confirmed bench path and its prior−31dBm-at5W estimate were retained; no physical attenuation measurement was made.',
 'SWR cause was not investigated. The earlier operator-deferred5W investigation and related preamble prototype stay deferred. A new steering question asks whether diagnosis should resume now that a10Wrepeat also stops; no answer has been received.',
 'The previous software reboot hard lock is unchanged, unresolved and failed. No reboot retry occurred; bench recovery coordination remains unanswered.',
 'Actual6300 adapter/kernel/resource/RF qualification, package catalogue/distribution, other process faults, credential/platform/transaction/power-loss and final stockAPD/independent release gates remain open.']}
destination=W/'tools/pd-waveform/evidence/20261117-final-runtime-RF';destination.mkdir(exist_ok=False);hashes={};paths=[]
directories=[P,E/'final-runtime-RF-readiness',E/'final-runtime-RF-audit']+[E/name for name in cases]+[E/name for name in report['prepared_but_not_keyed']]
for directory in directories:paths.extend(path for path in directory.iterdir() if path.is_file() and path.suffix in ['.py','.json','.jsonl','.log','.f32le'])
for path in sorted(set(paths)):
 target=destination/(str(path.relative_to(E))+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(path.read_bytes(),mtime=0));assert gzip.decompress(target.read_bytes())==path.read_bytes();hashes[str(target.relative_to(W))]=sha(target)
for name in ['finite-pair-spectrum.png','finite-pair-spectrum.svg']:
 target=destination/name;target.write_bytes((P/name).read_bytes());hashes[str(target.relative_to(W))]=sha(target)
report['evidence_sha256']=hashes
plan_path=E/'production-completion-plan-20261113.json';plan=read(plan_path);plan['updated_utc']=now
plan['current_candidate']['finite_10W_RF_pair_qualified']=True;plan['current_candidate']['RF_qualified_on_this_package']=False
plan['final_runtime_RF']={'report':'tools/pd-waveform/FINAL-RUNTIME-RF-QUALIFICATION.json','positive_GUI_key_actions':3,'completed_matched_pairs':1,'IMD3_improvement_dB':analysis['completed_pair']['IMD3_improvement_dB'],'10W_repeat_SWR_guard_stop':True,'repeatability_qualified':False,'full_P7_passed':False,'stock_APD_final_comparison_passed':False,'post_RF_metadata_audit_passed':True}
plan['operator_deferred_5W_SWR']['new_10W_repeat_stop']={'report':'tools/pd-waveform/FINAL-RUNTIME-RF-QUALIFICATION.json','direction_change_asked':True,'answer_received':False,'investigation_resumed':False}
plan['next_action']='Keep RF stopped pending operator steering on deferred SWR diagnosis after the new10Wrepeat guard stop. Do not retry software reboot until bench recovery coordination is answered. Continue implementing authenticated shipping package catalogue and first-install download/ordinary UI delivery, preserving all fullP1-P10, actual6300 adapter/hardware, natural-alignment/cold-start, process/credential/platform/power-loss and final RF/stockAPD/release gates. Preserve the finite completed20.29/19.21dB pair and aborted repeat separately.'
write(plan_path,plan);target=destination/'production-completion-plan.json.gz';target.write_bytes(gzip.compress(plan_path.read_bytes(),mtime=0));hashes[str(target.relative_to(W))]=sha(target)
write(W/'tools/pd-waveform/FINAL-RUNTIME-RF-QUALIFICATION.json',report)
print(json.dumps({'evidence_files':len(hashes),'positive_keys':3,'completed_pairs':1,'repeatability_qualified':False,'production_ready':False}))
