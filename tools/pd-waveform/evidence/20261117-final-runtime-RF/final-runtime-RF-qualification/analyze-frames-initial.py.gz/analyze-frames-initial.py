from pathlib import Path
import base64,hashlib,json,math,re,sys
import numpy as np

path=Path(sys.argv[1]);data=json.loads(path.read_text());rate=48000;n=16384
assert data['window']=='blackman-harris-7' and data['measurement']['valid']
coefficients=[.27105140069342,.43329793923448,.21812299954311,.06592544638803,.01081174209837,.00077658482522,.00001388721735]
x=np.arange(n,dtype=np.float64);window=sum((-1)**j*v*np.cos(2*np.pi*j*x/n) for j,v in enumerate(coefficients));bin_hz=rate/n
def rounded(value):return int(math.floor(value+.5) if value>=0 else math.ceil(value-.5))
def peak(power,frequency):
    centre=rounded(frequency/bin_hz)+n//2;lo=max(1,centre-7);hi=min(n-2,centre+7)
    best=lo+int(np.argmax(power[lo:hi+1]));alpha,beta,gamma=10*np.log10(np.maximum(power[best-1:best+2],1e-300));denom=alpha-2*beta+gamma;delta=0.;height=beta
    if abs(denom)>1e-12:
        delta=.5*(alpha-gamma)/denom
        if abs(delta)<=1:height=beta-.25*(alpha-gamma)*delta
        else:delta=0.
    return {'frequency_hz':(best-n//2+delta)*bin_hz,'power_db_raw_iq':float(height)}
def measure(power):
    tones=data['captures'][0]['source_tones'];lo=peak(power,tones['lower_offset_hz']);hi=peak(power,tones['upper_offset_hz']);spacing=hi['frequency_hz']-lo['frequency_hz']
    reference=10*math.log10(.5*(10**(lo['power_db_raw_iq']/10)+10**(hi['power_db_raw_iq']/10)));rows=[]
    for order in [3,5,7]:
        for upper,frequency in [(False,lo['frequency_hz']-(order-1)/2*spacing),(True,hi['frequency_hz']+(order-1)/2*spacing)]:
            p=peak(power,frequency);rows.append({'order':order,'upper':upper,'dbc_per_tone':p['power_db_raw_iq']-reference})
    return rows
rows=[];powers=[]
outcome=json.loads(path.with_name('outcome.json').read_text());alignment=outcome['native_after']['diagnostics']['alignment']['text'];key=int(re.search(r'\bkey_ns=(\d+)',alignment)[1])
for index,capture in enumerate(data['captures']):
    raw=base64.b64decode(capture['iq_f32le'],validate=True);assert hashlib.sha256(raw).hexdigest()==capture['sha256'];z=np.frombuffer(raw,dtype='<c8').astype(np.complex128);assert len(z)==n and np.isfinite(z).all()
    power=np.abs(np.fft.fftshift(np.fft.fft(z*window))/window.sum())**2;powers.append(power)
    rows.append({'index':index,'capture_id':capture['id'],'timestamp_ns':capture['timestamp_ns'],'receipt_timestamp_after_native_key_s':(int(capture['timestamp_ns'])-key)/1e9,'products':measure(power)})
mean_products=measure(np.mean(powers,axis=0));exported=data['measurement']['products'];error=max(abs(a['dbc_per_tone']-b['dbc_per_tone']) for a,b in zip(mean_products,exported));assert error<1e-4
report={'source_export_sha256':hashlib.sha256(path.read_bytes()).hexdigest(),'independent_average_product_agreement_max_dB':error,'frames':rows,'scope':'Per-frame NumPy FFT and log-parabolic peaks of retained IQ using the existing analyzer convention. Uncalibrated raw scale; radio-process receive timestamps, not FPGA timestamps or physical latency. Frames are not asserted statistically independent.'}
path.with_name('per-frame-analysis.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({'export':str(path),'average_product_error_dB':error,'per_frame_IMD3_dBc':[[p['dbc_per_tone'] for p in r['products'] if p['order']==3] for r in rows]}))
