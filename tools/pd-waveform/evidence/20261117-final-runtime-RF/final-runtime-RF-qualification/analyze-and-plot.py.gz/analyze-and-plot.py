from pathlib import Path
import base64,hashlib,json,os,subprocess,sys
import numpy as np

P=Path(__file__).resolve().parent;E=P.parent
cases=['final-native-baseline-10W-01','final-native-corrected-10W-01','final-native-baseline-10W-02']
summary={}
for name in cases:
    directory=E/name;outcome=json.loads((directory/'outcome.json').read_text());data=json.loads((directory/'measurement.json').read_text())
    lp=[json.loads(line) for line in (directory/'lp100a-readings.jsonl').read_text().splitlines()]
    native=outcome['native_samples'];diagnostics=outcome['native_after']['diagnostics']
    row={'whole_harness_passed':outcome['passed'],'positive_GUI_key_actions':outcome['positive_GUI_key_actions'],'export_error':data.get('error'),
         'original_cleanup_error_field':outcome.get('cleanup_error'),'valid_measurement':bool(data.get('measurement',{}).get('valid')),
         'radio_idle_after':not outcome['radio_after']['transmitting'],'session_stopped':outcome['session_stopped'],'LP_idle_after_W':outcome['LP_idle_after']['power_w'],
         'LP_peak_held_max_W':max(x['power_w'] for x in lp),'LP_SWR_with_RF_max':max(x['swr'] for x in lp if x['rf_present']),
         'all_observed_native_faults_zero':all(all(v==0 for v in x['faults'].values()) for x in native),'input_limited_samples_max':max(x['input_limited_samples'] for x in native),
         'alignment_count':diagnostics['alignment']['count'],'alignment_reset_count':diagnostics['alignment_reset']['count'],
         'diagnostics_after':diagnostics,'outcome_sha256':hashlib.sha256((directory/'outcome.json').read_bytes()).hexdigest()}
    if row['valid_measurement']:
        assert outcome['passed']
        for script,log in [(E/'post-PTT-RF-qualification/recheck-spectrum.py','independent-recheck.log'),(P/'analyze-frames.py','per-frame-analysis.log')]:
            result=subprocess.run([sys.executable,str(script),str(directory/'measurement.json')],capture_output=True,text=True)
            (directory/log).write_text(result.stdout+result.stderr);assert result.returncode==0,result.stderr
        row['IMD3_dBc_per_tone']=[x['dbc_per_tone'] for x in data['measurement']['products'] if x['order']==3]
        row['fundamental_pep_db_raw_iq']=data['measurement']['fundamental_pep_db_raw_iq'];row['correction_active']=data['correction_active'];row['frames']=len(data['captures'])
        row['per_frame_analysis']=json.loads((directory/'per-frame-analysis.json').read_text())
    else:
        assert not outcome['passed'] and data['error']=='SWR above the configured limit'
        result=subprocess.run([sys.executable,str(P/'analyze-frames.py'),str(directory/'measurement.json')],capture_output=True,text=True)
        (directory/'analysis-refused.log').write_text(result.stdout+result.stderr);assert result.returncode!=0 and 'No valid measurement' in result.stderr
        assert not (directory/'per-frame-analysis.json').exists()
    summary[name]=row
off=summary[cases[0]];on=summary[cases[1]]
pair={'baseline':cases[0],'corrected':cases[1],'IMD3_improvement_dB':[a-b for a,b in zip(off['IMD3_dBc_per_tone'],on['IMD3_dBc_per_tone'])],
      'fundamental_pep_change_dB':on['fundamental_pep_db_raw_iq']-off['fundamental_pep_db_raw_iq'],'definition':'Positive improvement is baseline dBc_per_tone minus corrected dBc_per_tone.',
      'repeated_pair_qualified':False,'following_repeat_stopped_by_existing_SWR_guard':True}
report={'cases':summary,'completed_pair':pair,'positive_GUI_key_actions':sum(v['positive_GUI_key_actions'] for v in summary.values()),'production_ready':False}
(P/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')

os.environ['MPLCONFIGDIR']=str(P/'mpl-cache')
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
fig,ax=plt.subplots(figsize=(11,5.8))
n=16384;rate=48000;x=np.arange(n,dtype=float)
coefficients=[.27105140069342,.43329793923448,.21812299954311,.06592544638803,.01081174209837,.00077658482522,.00001388721735]
window=sum((-1)**j*a*np.cos(2*np.pi*j*x/n) for j,a in enumerate(coefficients));frequencies=np.fft.fftshift(np.fft.fftfreq(n,1/rate))/1000
for name,label,color in [(cases[0],'AetherPD OFF','#72777d'),(cases[1],'AetherPD ON','#1665b5')]:
    data=json.loads((E/name/'measurement.json').read_text());powers=[]
    for capture in data['captures']:
        raw=base64.b64decode(capture['iq_f32le'],validate=True);z=np.frombuffer(raw,dtype='<c8').astype(np.complex128)
        powers.append(np.abs(np.fft.fftshift(np.fft.fft(z*window))/window.sum())**2)
    product=data['measurement']['products'][0];tone_reference=product['power_db_raw_iq']-product['dbc_per_tone']
    spectrum=10*np.log10(np.maximum(np.mean(powers,axis=0),1e-30))-tone_reference
    ax.plot(frequencies,spectrum,label=label,color=color,linewidth=1)
for hz in [-480,3090]:
    ax.axvline(hz/1000,color='#666666',linestyle=':',linewidth=.7)
ax.set(xlim=(-6,7),ylim=(-100,4),xlabel='Offset from 7.150 MHz (kHz)',ylabel='dBc relative to each curve’s mean per-tone power',
       title='FLEX-8600: finite matched 10 W setting pair · local DAX IQ · FDX off')
ax.grid(alpha=.2);ax.legend(loc='upper right');a,b=pair['IMD3_improvement_dB']
ax.text(.02,.06,f'IMD3 suppression gain: {a:.2f} / {b:.2f} dB\nLP-100A peak-held maximum: 7.49 W in both runs',transform=ax.transAxes,fontsize=10,bbox={'facecolor':'white','alpha':.85,'edgecolor':'none'})
fig.text(.01,.035,'4 × 16,384 samples per curve; 48 kHz; 7-term Blackman–Harris. Fundamental-only PEP changed +0.346 dB ON.',fontsize=8)
fig.text(.01,.012,'One subsequent repeat aborted at the unchanged SWR guard. Repeatability/endurance remain unqualified; ADC headroom is uncalibrated.',fontsize=8)
fig.tight_layout(rect=(0,.07,1,1));fig.savefig(P/'finite-pair-spectrum.png',dpi=170);fig.savefig(P/'finite-pair-spectrum.svg');plt.close(fig)
print(json.dumps({'keys':report['positive_GUI_key_actions'],'completed_pairs':1,'IMD3_improvement_dB':pair['IMD3_improvement_dB'],'repeatability_qualified':False,'plot':str(P/'finite-pair-spectrum.png')}))
