"""Observe pending native startup, cancel it, audit cleanup and recover via GUI."""
import json,pathlib,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent
sys.path.insert(0,str(BASE.parent/'aetherpd-source/tools'))
from automation_probe import Bridge
assert not (ROOT/'outcome.json').exists(),'Preserve every attempt'
b=Bridge('/tmp/aetherpd-empty-session-retirement')
report={'passed':False,'RF_commands':[],'credential_mutations':[],'helper_requested':False}
def bridge(q):
 r=b.request(q,8);assert r.get('ok'),r;return r
def status():
 p=subprocess.run([str(BASE/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=22)
 return json.loads(p.stdout)
def audit(case):
 with (ROOT/(case+'-console.log')).open('w') as log:
  subprocess.run([sys.executable,str(ROOT/'run-job.py'),case],stdout=log,stderr=subprocess.STDOUT,timeout=120,check=True)
 outer=json.loads((ROOT/(case+'-result.json')).read_text());inner=json.loads(outer['logs'])
 assert outer['wait']['StatusCode']==0 and inner['passed'],inner
 assert outer['job_container_deleted'] and outer['temporary_host_directory_deleted']
 return inner
try:
 who=bridge({'cmd':'whoami'});assert who['pid']==2699295 and who['automationIdentity']=='aetherpd-shim-integration'
 radio=bridge({'cmd':'get','model':'radio'})['radio'];assert radio['connected'] and not radio['transmitting'] and not radio['fullDuplex'];report['radio_before']=radio
 pans=bridge({'cmd':'get','model':'pans'})['pans'];assert len(pans)==1 and pans[0]['ownedByUs'] and pans[0]['rxAntenna']=='RX_A' and pans[0]['rfGain']==0 and abs(pans[0]['centerMhz']-7.15)<1e-6
 identity={'gui_client_id':who['guiClientId'],'gui_handle':int(pans[0]['clientHandle'],16),'feedback_pan':int(pans[0]['panId'],16),'iq_channel':4};report['identity']=identity
 before=status();assert before['http_status']==200 and before['body']=={'available':False,'state':'stopped'};report['before']=before
 report['helper_requested']=True
 result=subprocess.run([str(ROOT/'vault-cancel')],input=json.dumps(identity),capture_output=True,text=True,timeout=30)
 assert result.returncode==0,(result.returncode,result.stderr)
 outcome=json.loads(result.stdout);report['cancellation']=outcome
 (ROOT/'helper-result.json').write_text(json.dumps(outcome,indent=2)+'\n')
 assert outcome['pending_observation']['http_status']==503 and outcome['pending_observation']['body']=={'available':False,'state':'starting'},outcome
 assert outcome['start']['http_status']==503 and outcome['start']['body']['state']=='start_unavailable',outcome
 assert outcome['stop']['http_status']==202 and outcome['stop']['body']['state']=='stop_requested',outcome
 assert outcome['pending_observation']['completed_ns']<=outcome['stop_dispatched_ns']<outcome['start']['completed_ns'],outcome
 print('pending_start_observed_and_cancelled',flush=True)
 report['after_cancel']=status();assert not report['after_cancel']['body'].get('available',False) and not report['after_cancel']['body'].get('registered',False)
 report['cleanup']=audit('before-restart')
 print('cancelled_native_graph_cleanup_verified',flush=True)
 result=subprocess.run([sys.executable,str(ROOT/'receive-iq-check.py')],capture_output=True,text=True,timeout=120)
 (ROOT/'recovery-console.log').write_text(result.stdout+result.stderr)
 assert result.returncode==0,result.stdout+result.stderr
 recovery=json.loads((ROOT/'usb-receive-iq-check.json').read_text());assert recovery['passed'] and recovery['iq_bytes']==131072 and recovery['stopped']['body']['state']=='stopped'
 report['recovery_IQ']=recovery
 report['final_audit']=audit('final-audit')
 report['radio_after']=bridge({'cmd':'get','model':'radio'})['radio'];assert report['radio_after']['connected'] and not report['radio_after']['transmitting'] and not report['radio_after']['fullDuplex']
 report['passed']=True
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
 if report['helper_requested'] and not report.get('recovery_IQ',{}).get('passed'):
  try:report['fallback_Stop']=bridge({'cmd':'invoke','target':'pdStop','action':'click'})
  except Exception as error:report['fallback_Stop_error']=str(error)
 b.close();(ROOT/'outcome.json').write_text(json.dumps(report,indent=2)+'\n')
 print(json.dumps({k:report[k] for k in ['passed','error','fallback_Stop_error'] if k in report}),flush=True)
 if not report['passed']:raise SystemExit(1)
