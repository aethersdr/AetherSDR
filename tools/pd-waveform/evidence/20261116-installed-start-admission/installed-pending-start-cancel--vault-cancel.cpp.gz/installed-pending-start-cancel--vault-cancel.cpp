#include "core/TailnetShimTokenStore.h"
#include <QCoreApplication>
#include <QElapsedTimer>
#include <QEventLoop>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkProxy>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QRegularExpression>
#include <QTimer>
#include <array>
#include <cstdio>

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("AetherSDR"));
    if (argc != 1) { return 2; }
    QFile input;
    if (!input.open(stdin, QIODevice::ReadOnly)) { return 2; }
    const QByteArray bytes = input.read(513);
    const QJsonDocument document = QJsonDocument::fromJson(bytes);
    const QJsonObject identity = document.object();
    const double handle = identity.value("gui_handle").toDouble();
    if (bytes.size() > 512 || !document.isObject() || identity.size() != 4
        || identity.value("gui_client_id").toString() != "5D14B8D4-A745-5620-BAF8-B3614CA1C814"
        || handle <= 0 || handle > 4294967295.0 || handle != identity.value("gui_handle").toInteger()
        || identity.value("feedback_pan").toDouble() != 1073741824.0
        || identity.value("iq_channel").toDouble() != 4.0) { return 2; }
    const QByteArray payload = QJsonDocument(identity).toJson(QJsonDocument::Compact);
    QTimer::singleShot(25000, &app, [&app] { app.exit(3); });
    AetherSDR::TailnetShimTokenStore::load(QStringLiteral("2125-1213-8600-8895"), &app,
        [&](const QString& token) {
        if (!QRegularExpression("^(?:[0-9a-f]{64}|[A-Za-z0-9_-]{43})$").match(token).hasMatch()) {
            std::puts("credential_unavailable"); app.exit(4); return;
        }
        std::array<QNetworkAccessManager, 3> networks;
        for (QNetworkAccessManager& network : networks) { network.setProxy(QNetworkProxy::NoProxy); }
        QElapsedTimer timer;
        timer.start();
        QEventLoop loop;
        QTimer poll;
        poll.setInterval(20);
        QJsonObject startResult;
        QJsonObject stopResult;
        QJsonObject pendingObservation;
        bool startDone = false;
        bool stopDone = false;
        bool stopSent = false;
        bool polling = false;
        int pollCount = 0;
        qint64 stopDispatched = 0;
        const auto request = [&](const QString& suffix) {
            QNetworkRequest value(QUrl(QStringLiteral("http://192.168.50.100:48992") + suffix));
            value.setAttribute(QNetworkRequest::RedirectPolicyAttribute, QNetworkRequest::ManualRedirectPolicy);
            value.setRawHeader("Authorization", "Bearer " + token.toLatin1());
            value.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
            value.setTransferTimeout(22000);
            return value;
        };
        const auto response = [&](QNetworkReply* reply) {
            const QByteArray raw = reply->read(65537);
            return QJsonObject{{"http_status", reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt()},
                {"completed_ns", timer.nsecsElapsed()}, {"response_bounded", raw.size() <= 65536},
                {"body", QJsonDocument::fromJson(raw).object()}};
        };
        const auto finish = [&] { if (startDone && stopDone) { loop.quit(); } };
        const auto postStop = [&] {
            if (stopSent) { return; }
            stopSent = true;
            poll.stop();
            stopDispatched = timer.nsecsElapsed();
            QNetworkReply* reply = networks[2].post(request(QStringLiteral("/v1/aetherpd/stop")), QByteArray{});
            reply->setReadBufferSize(65537);
            QObject::connect(reply, &QNetworkReply::finished, &loop, [&, reply] {
                stopResult = response(reply);
                stopDone = true;
                finish();
            });
        };
        QObject::connect(&poll, &QTimer::timeout, &loop, [&] {
            if (polling || stopSent) { return; }
            if (++pollCount > 64) { postStop(); return; }
            polling = true;
            QNetworkReply* reply = networks[1].get(request(QStringLiteral("/v1/aetherpd/status")));
            reply->setReadBufferSize(65537);
            QObject::connect(reply, &QNetworkReply::finished, &loop, [&, reply] {
                const QJsonObject observed = response(reply);
                polling = false;
                if (observed.value("http_status").toInt() == 503
                    && observed.value("body").toObject().value("state").toString() == "starting") {
                    pendingObservation = observed;
                    postStop();
                }
                reply->deleteLater();
            });
        });
        const qint64 startDispatched = timer.nsecsElapsed();
        QNetworkReply* startReply = networks[0].post(request(QStringLiteral("/v2/aetherpd/start")), payload);
        startReply->setReadBufferSize(65537);
        QObject::connect(startReply, &QNetworkReply::finished, &loop, [&] {
            startResult = response(startReply);
            startDone = true;
            postStop();
            finish();
        });
        poll.start();
        loop.exec();
        if (!startDone || !stopDone) { app.exit(5); return; }
        const QJsonDocument output(QJsonObject{
            {"start", startResult}, {"stop", stopResult}, {"pending_observation", pendingObservation},
            {"start_dispatched_ns", startDispatched}, {"stop_dispatched_ns", stopDispatched},
            {"status_polls", pollCount}, {"separate_connection_managers", true},
            {"RF_commands", QJsonArray{}}, {"credential_mutations", QJsonArray{}}});
        const QByteArray serialized = output.toJson(QJsonDocument::Compact);
        std::fwrite(serialized.constData(), 1, serialized.size(), stdout);
        std::puts("");
        app.exit(0);
    });
    return app.exec();
}
