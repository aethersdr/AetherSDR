#include "core/TailnetShimTokenStore.h"
#include <QCoreApplication>
#include <QElapsedTimer>
#include <QEventLoop>
#include <QFile>
#include <QJsonArray>
#include <QJsonDocument>
#include <QJsonObject>
#include <QNetworkAccessManager>
#include <QNetworkProxy>
#include <QNetworkReply>
#include <QNetworkRequest>
#include <QRegularExpression>
#include <QTimer>
#include <array>
#include <cstdio>

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("AetherSDR"));
    if (argc != 1) { return 2; }
    QFile input;
    if (!input.open(stdin, QIODevice::ReadOnly)) { return 2; }
    const QByteArray bytes = input.read(513);
    const QJsonDocument document = QJsonDocument::fromJson(bytes);
    const QJsonObject identity = document.object();
    const double handle = identity.value("gui_handle").toDouble();
    if (bytes.size() > 512 || !document.isObject() || identity.size() != 4
        || identity.value("gui_client_id").toString() != "5D14B8D4-A745-5620-BAF8-B3614CA1C814"
        || handle <= 0 || handle > 4294967295.0 || handle != identity.value("gui_handle").toInteger()
        || identity.value("feedback_pan").toDouble() != 1073741824.0
        || identity.value("iq_channel").toDouble() != 4.0) { return 2; }
    const QByteArray payload = QJsonDocument(identity).toJson(QJsonDocument::Compact);
    QTimer::singleShot(25000, &app, [&app] { app.exit(3); });
    AetherSDR::TailnetShimTokenStore::load(QStringLiteral("2125-1213-8600-8895"), &app,
        [&](const QString& token) {
        if (!QRegularExpression("^(?:[0-9a-f]{64}|[A-Za-z0-9_-]{43})$").match(token).hasMatch()) {
            std::puts("credential_unavailable"); app.exit(4); return;
        }
        std::array<QNetworkAccessManager, 2> networks;
        std::array<QJsonObject, 2> results;
        QElapsedTimer timer;
        timer.start();
        QEventLoop loop;
        int completed = 0;
        for (int i = 0; i < 2; ++i) {
            networks[i].setProxy(QNetworkProxy::NoProxy);
            QNetworkRequest request(QUrl("http://192.168.50.100:48992/v2/aetherpd/start"));
            request.setAttribute(QNetworkRequest::RedirectPolicyAttribute, QNetworkRequest::ManualRedirectPolicy);
            request.setRawHeader("Authorization", "Bearer " + token.toLatin1());
            request.setHeader(QNetworkRequest::ContentTypeHeader, QStringLiteral("application/json"));
            request.setTransferTimeout(22000);
            results[i].insert("dispatched_ns", timer.nsecsElapsed());
            QNetworkReply* reply = networks[i].post(request, payload);
            reply->setReadBufferSize(65537);
            QObject::connect(reply, &QNetworkReply::finished, &loop, [&, i, reply] {
                const QByteArray raw = reply->read(65537);
                results[i].insert("completed_ns", timer.nsecsElapsed());
                results[i].insert("http_status", reply->attribute(QNetworkRequest::HttpStatusCodeAttribute).toInt());
                results[i].insert("network_error", static_cast<int>(reply->error()));
                results[i].insert("response_bounded", raw.size() <= 65536);
                results[i].insert("body", QJsonDocument::fromJson(raw).object());
                if (++completed == 2) { loop.quit(); }
            });
        }
        loop.exec();
        if (completed != 2) { app.exit(5); return; }
        const QJsonDocument output(QJsonObject{
            {"requests", QJsonArray{results[0], results[1]}},
            {"separate_connection_managers", true},
            {"RF_commands", QJsonArray{}}, {"credential_mutations", QJsonArray{}}});
        const QByteArray serialized = output.toJson(QJsonDocument::Compact);
        std::fwrite(serialized.constData(), 1, serialized.size(), stdout);
        std::puts("");
        app.exit(0);
    });
    return app.exec();
}
