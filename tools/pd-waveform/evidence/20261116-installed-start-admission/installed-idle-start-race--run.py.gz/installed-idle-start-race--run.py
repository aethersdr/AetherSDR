"""One genuine idle-start race, current native graph and full IQ; never RF."""
import base64
import hashlib
import json
import math
import pathlib
import struct
import subprocess
import sys
import time

ROOT = pathlib.Path(__file__).resolve().parent
BASE = ROOT.parent
sys.path.insert(0, str(BASE.parent / 'aetherpd-source/tools'))
from automation_probe import Bridge

assert not (ROOT / 'outcome.json').exists(), 'Preserve every attempt'
b = Bridge('/tmp/aetherpd-empty-session-retirement')
report = {'passed': False, 'RF_commands': [], 'credential_mutations': [], 'Start_requests': 0}
events = []
started = False


def event(name, **values):
    events.append({'event': name, 'monotonic_ns': time.monotonic_ns(), **values})
    (ROOT / 'events.json').write_text(json.dumps(events, indent=2) + '\n')


def bridge(request):
    result = b.request(request, 8)
    event('bridge', request=request, result=result)
    assert result.get('ok'), result
    return result


def read(path):
    result = subprocess.run([str(BASE / 'first-iq-live/vault-v3'), path],
        capture_output=True, text=True, timeout=22)
    parsed = json.loads(result.stdout)
    event('authenticated_read', path=path, result=parsed)
    return parsed


def idle():
    radio = bridge({'cmd': 'get', 'model': 'radio'})['radio']
    assert radio['connected'] and not radio['transmitting'] and not radio['fullDuplex']
    assert radio['serial'] == '2125-1213-8600-8895'
    return radio


def stop():
    global started
    bridge({'cmd': 'invoke', 'target': 'pdStop', 'action': 'click'})
    end = time.monotonic() + 20
    while True:
        result = read('aetherpd/status')
        if result['http_status'] == 200 and result['body'].get('state') == 'stopped':
            started = False
            return result
        assert time.monotonic() < end, result
        time.sleep(.25)


try:
    who = bridge({'cmd': 'whoami'})
    assert who['pid'] == 2699295 and who['automationIdentity'] == 'aetherpd-shim-integration'
    report['whoami'] = who
    report['radio_before'] = idle()
    pans = bridge({'cmd': 'get', 'model': 'pans'})['pans']
    assert len(pans) == 1 and pans[0]['ownedByUs'] and pans[0]['rxAntenna'] == 'RX_A'
    assert pans[0]['rfGain'] == 0 and abs(pans[0]['centerMhz'] - 7.15) < 1e-6
    identity = {'gui_client_id': who['guiClientId'], 'gui_handle': int(pans[0]['clientHandle'], 16),
        'iq_channel': 4, 'feedback_pan': int(pans[0]['panId'], 16)}
    report['identity'] = identity
    before = read('aetherpd/status')
    assert before['http_status'] == 200 and before['body'] == {'available': False, 'state': 'stopped'}
    report['stopped_before'] = before
    started = True
    report['Start_requests'] = 2
    result = subprocess.run([str(ROOT / 'vault-race')], input=json.dumps(identity),
        capture_output=True, text=True, timeout=30)
    assert result.returncode == 0, (result.returncode, result.stderr)
    race = json.loads(result.stdout)
    report['race'] = race
    event('idle_start_race', result=race)
    requests = race['requests']
    assert race['separate_connection_managers'] and all(x['response_bounded'] for x in requests)
    assert sorted(x['http_status'] for x in requests) == [202, 409], race
    assert max(x['dispatched_ns'] for x in requests) < min(x['completed_ns'] for x in requests), race
    report['both_dispatched_before_either_completed'] = True
    print('one_start_accepted_one_refused', flush=True)
    end = time.monotonic() + 35
    while True:
        result = read('aetherpd/status')
        if result['http_status'] == 200 and result['body'].get('registered'):
            break
        assert time.monotonic() < end, result
        time.sleep(.25)
    report['running'] = result['body']
    assert not result['body']['keyed'] and not result['body']['correcting']
    idle()
    (ROOT / 'identity.json').write_text(json.dumps(identity, indent=2) + '\n')
    template = (ROOT / 'active-graph-template.py').read_text()
    (ROOT / 'active-graph-job.py').write_text('IDENTITY=' + repr(identity) + '\n' + template)
    with (ROOT / 'active-graph-console.log').open('w') as output:
        subprocess.run([sys.executable, str(ROOT / 'run-job.py'), 'active-graph'],
            stdout=output, stderr=subprocess.STDOUT, timeout=120, check=True)
    outer = json.loads((ROOT / 'active-graph-result.json').read_text())
    active = json.loads(outer['logs'])
    assert outer['wait']['StatusCode'] == 0 and active['passed'], active
    assert outer['job_container_deleted'] and outer['temporary_host_directory_deleted']
    report['active_graph'] = active
    print('exactly_one_native_DSP_verified', flush=True)
    result = read('aetherpd/capture')
    assert result['http_status'] == 200, result
    capture = result['body']
    binding = capture['feedback_binding']
    assert binding['transport'] == 'local_dax_iq' and binding['valid'] and not binding['failed']
    assert binding['channel'] == 4 and binding['gui_handle'] == identity['gui_handle']
    assert binding['pan'] == identity['feedback_pan'] and capture['sample_rate_hz'] == 48000
    assert capture['sample_count'] == 16384 and not capture['keyed'] and not capture['correcting']
    raw = bytearray()
    for chunk in range(32):
        result = read('aetherpd/capture/' + capture['capture_id'] + '/' + str(chunk))
        assert result['http_status'] == 200, result
        part = result['body']
        assert part['offset'] == chunk * 512
        data = base64.b64decode(part['iq_f32le'], validate=True)
        assert len(data) == 4096
        raw.extend(data)
    values = struct.unpack('<' + str(len(raw) // 4) + 'f', raw)
    assert len(raw) == 131072 and all(math.isfinite(v) for v in values) and any(v != 0 for v in values)
    (ROOT / 'receive-iq.f32le').write_bytes(raw)
    report['capture'] = capture
    report['iq_bytes'] = len(raw)
    report['iq_sha256'] = hashlib.sha256(raw).hexdigest()
    report['stopped'] = stop()
    report['radio_after'] = idle()
    report['passed'] = True
except Exception as error:
    report['error'] = type(error).__name__ + ': ' + str(error)
finally:
    if started:
        try:
            report['fallback_Stop'] = stop()
        except Exception as error:
            report['Stop_error'] = str(error)
            report['passed'] = False
    b.close()
    (ROOT / 'outcome.json').write_text(json.dumps(report, indent=2) + '\n')
    print(json.dumps({k: report[k] for k in ['passed', 'error', 'Stop_error', 'iq_bytes'] if k in report}), flush=True)
    if not report['passed']:
        raise SystemExit(1)
