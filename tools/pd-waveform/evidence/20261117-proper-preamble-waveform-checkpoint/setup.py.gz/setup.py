from pathlib import Path
import shutil,hashlib,json,difflib
w=Path('/home/jeremy/AetherSDR/build/aetherpd-source');e=w.parent/'aetherpd-shim-integration';p=e/'proper-preamble-waveform';p.mkdir(exist_ok=False)
for variant in ['control','candidate']:
 root=p/variant/'source';root.mkdir(parents=True)
 for prefix in ['tools/pd-waveform','third_party/wdsp','third_party/fftw3/include']:
  for f in (w/prefix).rglob('*'):
   if not f.is_file() or any(x.startswith('evidence') for x in f.relative_to(w).parts):continue
   if f.suffix not in ['.c','.h','.py','.txt'] and not f.name.startswith('LICENSE'):continue
   dst=root/f.relative_to(w);dst.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(f,dst)
 t=(w/'tests/tests.cmake').read_text();start=t.index('    add_library(aether_pd_test_core STATIC');end=t.index('    add_executable(pd_pi_lock_policy_test',start)
 cmake='cmake_minimum_required(VERSION 3.20)\nproject(AetherPDWaveformExperiment LANGUAGES C)\nfind_package(Threads REQUIRED)\nenable_testing()\n'+t[start:end]
 cmake+='\nadd_executable(pd_waveform_probe tools/pd-waveform/pd_waveform.c)\ntarget_link_libraries(pd_waveform_probe PRIVATE aether_pd_test_core)\nadd_test(NAME pd_waveform_selftest COMMAND pd_waveform_probe selftest)\nset_tests_properties(pd_waveform_selftest PROPERTIES TIMEOUT 180)\n'
 (root/'CMakeLists.txt').write_text(cmake)
original=(p/'control/source/tools/pd-waveform/pd_waveform.c').read_text();s=original
old='    cbp_t noise_bp;               // band-limits the preamble to the correction band\n';assert s.count(old)==1;s=s.replace(old,old+'    cbp_t noise_q_bp;             // independent imaginary input for this experiment\n')
needle='cbp_init(&w->noise_bp, TEST_NOISE_LO_HZ, TEST_NOISE_HI_HZ);';assert s.count(needle)==2
lines=[]
for line in s.splitlines():
 lines.append(line)
 if needle in line:lines.append(line.replace('&w->noise_bp','&w->noise_q_bp'))
s='\n'.join(lines)+'\n'
old='''                double u = ((w->noise_seed >> 8) / 16777216.0) - 0.5;
                cbp_step(&w->noise_bp, TEST_NOISE_GAIN * w->peak * u, &i, &q);'''
new='''                double u = ((w->noise_seed >> 8) / 16777216.0) - 0.5;
                w->noise_seed = w->noise_seed * 1664525u + 1013904223u;
                double v = ((w->noise_seed >> 8) / 16777216.0) - 0.5;
                double ri, rq, ii, iq;
                const double scale = TEST_NOISE_GAIN * w->peak / sqrt(2.0);
                cbp_step(&w->noise_bp, scale * u, &ri, &rq);
                cbp_step(&w->noise_q_bp, scale * v, &ii, &iq);
                i = ri - iq;
                q = rq + ii;'''
assert s.count(old)==1;s=s.replace(old,new)
(p/'candidate/source/tools/pd-waveform/pd_waveform.c').write_text(s)
(p/'candidate.patch').write_text(''.join(difflib.unified_diff(original.splitlines(True),s.splitlines(True),fromfile='a/tools/pd-waveform/pd_waveform.c',tofile='b/tools/pd-waveform/pd_waveform.c')))
(p/'provenance.json').write_text(json.dumps({'production_source_unchanged':(w/'tools/pd-waveform/pd_waveform.c').read_text()==original,'base_source_sha256':hashlib.sha256(original.encode()).hexdigest(),'experimental_source_sha256':hashlib.sha256(s.encode()).hexdigest(),'candidate_patch_sha256':hashlib.sha256((p/'candidate.patch').read_bytes()).hexdigest(),'scope':'Separate source copies only; no package/default/privilege changes.'},indent=2)+'\n')
print('Prepared control/candidate roots and bounded source-only patch.')
