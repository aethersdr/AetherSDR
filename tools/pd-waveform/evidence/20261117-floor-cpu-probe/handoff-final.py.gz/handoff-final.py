from pathlib import Path
import hashlib,json,os,shutil,subprocess,tarfile
E=Path(__file__).resolve().parent;W=E.parent.parent/'aetherpd-source';D=E/'handoff-final';D.mkdir(exist_ok=False)
assert not os.environ.get('AETHER_PD_SOURCE_ROOT')
meta=json.loads((E/'qualified-reproduction.json').read_text());package=E/'qualified-first/AetherPDCpuProbe.ssdr_waveform'
assert hashlib.sha256(package.read_bytes()).hexdigest()==meta['sha256']
shutil.copyfile(package,D/package.name)
for name in ['cpu_probe_tool.py','cpu_probe_package.py','kernel_probe_tool.py']:shutil.copyfile(W/'tools/pd-waveform/session'/name,D/name)
source=D/'source'
for p in (W/'tools/pd-waveform').iterdir():
 if p.is_file() and p.suffix in ['.c','.h','.py']:
  q=source/p.relative_to(W);q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(p,q)
for name in ['tools/pd-waveform/vendor','third_party/wdsp','third_party/fftw3/include']:
 shutil.copytree(W/name,source/name,ignore=shutil.ignore_patterns('__pycache__','*.dll','*.lib','*.a','*.o','.git'))
for name in ['LICENSE','third_party/fftw3/COPYING','third_party/fftw3/COPYRIGHT']:
 q=source/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/name,q)
for name in ['cpu_probe.c','cpu_probe_package.py','cpu_probe_tool.py','kernel_probe_tool.py']:
 q=source/'tools/pd-waveform/session'/name;q.parent.mkdir(parents=True,exist_ok=True);shutil.copyfile(W/'tools/pd-waveform/session'/name,q)
start=f'''# AetherPD CPU diagnostic 0.1.0 — FLEX-6300 teammate handoff\n\nDevelopment diagnostic only. No FLEX-6300 qualification is claimed yet.\n\nPackage: `{package.name}` ({meta['bytes']:,} bytes)\nSHA256: `{meta['sha256']}`\n\nThis runs the five existing CPU-only DSP regressions as the ordinary waveform user.\nNo SSH, root bridge, radio API/RF commands, IQ setup, reboot or privileged helper.\nThe client uses ordinary waveform upload and removes only this diagnostic.\n\nKeep the radio unkeyed and stop AetherPD. Use a fresh extracted kit directory.\nThe manifest has empty setup/end sections. Budget roughly1MiB expanded plus the\nfirmware's upload/cache copies; verify free space with the separate kernel probe.\n\nFrom this directory on the teammate's LAN computer, substitute the radio IP:\n\n```sh\npython3 cpu_probe_tool.py --host RADIO install {package.name} --sha256 {meta['sha256']}\n# Wait for all five cases. They have45s watchdog budgets each, at most225s total.\npython3 cpu_probe_tool.py --host RADIO status > cpu-results.json\npython3 cpu_probe_tool.py --host RADIO uninstall\n```\n\nA refused status connection while tests run is not an invitation to reupload.\nOnce a report is collected, uninstall promptly and verify TCP48999 closes. The\nreport server has a five-minute window after tests and an overall ten-minute\nalarm. If a test fails, keep that report; it is not a passing runtime result.\nUninstall acknowledgement/closed listener do not prove firmware cached-file deletion.\n\nAdmission requires UID78666/GID20, zero effective/permitted/inheritable capabilities\nand SCHED_OTHER. The probe lowers itself to nice19; it requests no real-time grant.\nEach child has30/31s CPU,256MiB address-space and zero core/file-data limits.\nWatchdog/SIGKILL requests cannot guarantee deadlines under a frozen kernel.\nThe forked fixed entry points do not exec an external command or test path.\n\nReturn cpu-results.json with model, firmware and the package SHA256, plus the\nseparate kernel/filesystem report from AetherPDKernelProbe0.1.3. Preserve errors,\ntimeouts and output_truncated flags. Peak RSS is kernel-reported KiB per child,\nnot radio free memory or combined running-service RSS. CPU time includes these\nfinite simulations, not actual on-radio feedback latency or continuous throughput.\n\nSource for the diagnostic, existing regressions and WDSP dependencies is under\nsource/. With Zig0.17.1 installed, rebuild from source/ using:\n\n```sh\npython3 tools/pd-waveform/session/cpu_probe_package.py --output /absolute/new-output\n```\n\nThe package reproduced across distinct source/output/cache paths and passed\nordinary install/run/uninstall on an8600. Those results do not establish Linux2.6,\nCortex-A8, one-core scheduling, FPGA capture, RF or native6300 installation.\nThe original native6000 privilege-entry mechanism remains unresolved; the\ncurrently available transport depends on host Podman and is not a6300 adapter.\n'''
(D/'START-HERE.md').write_text(start)
manifest={str(p.relative_to(D)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(D.rglob('*')) if p.is_file()}
(D/'SHA256SUMS').write_text(''.join(h+'  '+n+'\n' for n,h in manifest.items()))
archive=E.parent/'cpu-probe-0.1.0-6300-handoff.tar.gz'
with tarfile.open(archive,'w:gz') as tar:
 for p in sorted(D.rglob('*')):
  if p.is_file():tar.add(p,arcname=str(p.relative_to(D)),recursive=False)
record={'archive':str(archive),'bytes':archive.stat().st_size,'sha256':hashlib.sha256(archive.read_bytes()).hexdigest(),'files':len(manifest)+1,'package':meta,'source_root_override_present':False}
(E/'handoff-archive.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record))
