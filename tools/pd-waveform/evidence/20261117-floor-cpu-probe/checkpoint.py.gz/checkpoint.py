from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,shutil,subprocess,tarfile
E=Path(__file__).resolve().parent.parent;W=E.parent/'aetherpd-source'
previous=Path((E/'latest-checkpoint-path.txt').read_text().strip());old=json.loads((previous/'checkpoint.json').read_text())
assert old['source_commit'].startswith('32267e3b9')
commit=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();assert not subprocess.check_output(['git','status','--porcelain'],cwd=W)
dest=previous.parent/('20261117-floor-cpu-probe-'+commit[:9]);dest.mkdir(exist_ok=False)
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(1024*1024):h.update(b)
 return h.hexdigest()
for p in previous.glob('*.tar.gz'):os.link(p,dest/p.name)
kit=E/'cpu-probe-0.1.0-6300-handoff.tar.gz';kitmeta=json.loads((E/'floor-cpu-probe/handoff-archive.json').read_text());assert sha(kit)==kitmeta['sha256'];os.link(kit,dest/kit.name)
changes=subprocess.check_output(['git','diff','--name-only','--diff-filter=ACMRT',old['source_commit'],commit],cwd=W,text=True).splitlines();assert not subprocess.check_output(['git','diff','--name-only','--diff-filter=D',old['source_commit'],commit],cwd=W)
overlay=dest/'source-floor-cpu-probe-overlay.tar.gz'
with tarfile.open(overlay,'w:gz') as t:
 for n in changes:t.add(W/n,arcname=n,recursive=False)
archives=old['source_reconstruction']+[overlay.name];expected={}
for name in archives:
 with tarfile.open(dest/name) as t:
  for m in t:
   if m.isfile():expected[m.name]=hashlib.sha256(t.extractfile(m).read()).hexdigest()
   elif m.issym():expected[m.name]=hashlib.sha256(m.linkname.encode()).hexdigest()
tracked=subprocess.check_output(['git','ls-files','-z'],cwd=W).decode().split('\0')[:-1]
for n in tracked:
 p=W/n;assert expected.get(n)==(hashlib.sha256(os.readlink(p).encode()).hexdigest() if p.is_symlink() else sha(p)),n
for p in [E/'production-completion-plan-20261113.json',W/'tools/pd-waveform/CPU-PROBE-QUALIFICATION.json',W/'tools/pd-waveform/UPGRADE-CATALOGUE-QUALIFICATION.json',W/'tools/pd-waveform/FIRST-INSTALL-CATALOGUE-QUALIFICATION.json',W/'tools/pd-waveform/FIRST-INSTALL-HTTPS-QUALIFICATION.json',W/'tools/pd-waveform/FINAL-RUNTIME-RF-QUALIFICATION.json',E/'floor-cpu-probe/qualified-live-result.json',E/'floor-cpu-probe/postflight.json',E/'floor-cpu-probe/handoff-archive.json']:
 shutil.copyfile(p,dest/p.name)
meta={'created_utc':datetime.now(timezone.utc).isoformat(),'source_commit':commit,'source_reconstruction':archives,'source_deletions':[],'overlay_in_order_in_empty_directory':True,'all_tracked_source_paths_verified':len(tracked),'latest_overlay_members':len(changes),'installed_release':old['installed_release'],'runtime_source_commit':old['runtime_source_commit'],'floor_CPU_handoff':'330383-byte diagnostic, SHA b1136f77a78e0828c6904c41a8add2258459ffe62dd5063ea544826fe6be8074. Five finite CPU cases passed through ordinary8600 install/run/uninstall; port closed, radio connected/unkeyed/FDXoff, PDstopped. Package reproduced from two source/output/cache paths and supplied source. 13Python+2CTest suites,6mutants,address/undefined/leak selected-unit checks and static/docs builds passed. Actual6300 and original native privilege entry remain unqualified.','RF':'No RF this turn; prior finite10Wpair and SWR-aborted repeat preserved separately. No repeatability qualification.','software_reboot_qualified':False,'radio_changes_this_turn':['fixed ordinary CPU diagnostic install/run/read/uninstall; no privileged setup'],'pending_operator_steering':old['pending_operator_steering'],'production_ready':False,'goal_status':'active','previous_checkpoint':str(previous),'all_exec_jobs_this_turn':'All current build/test/sanitizer/mutation/docs/UI jobs terminal; checkpoint performs no radio or build operation.'}
(dest/'checkpoint.json').write_text(json.dumps(meta,indent=2)+'\n')
hashes={p.name:sha(p) for p in dest.iterdir() if p.is_file()};(dest/'SHA256SUMS').write_text(''.join(h+'  '+n+'\n' for n,h in sorted(hashes.items())));assert all(sha(dest/n)==h for n,h in hashes.items())
(E/'latest-checkpoint-path.txt').write_text(str(dest)+'\n');print(json.dumps({'checkpoint':str(dest),'verified_files':len(hashes),'tracked_source_paths':len(tracked)}))
