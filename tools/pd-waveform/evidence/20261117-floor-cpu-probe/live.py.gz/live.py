from pathlib import Path
from datetime import datetime,timezone
import json,subprocess,socket,sys,time
W=Path('/home/jeremy/AetherSDR/build/aetherpd-source');E=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'tools/pd-waveform/session'));import cpu_probe_tool as tool
subprocess.run([sys.executable,str(E/'preflight.py')],check=True,timeout=35)
meta=json.loads((E/'reproduction.json').read_text());package=E/'final-first/AetherPDCpuProbe.ssdr_waveform'
assert len(tool.package(package,meta['sha256']))==meta['bytes']
report={'started_utc':datetime.now(timezone.utc).isoformat(),'package':meta,'RF_commands':[],'reboot_commands':[],'root_bridge_jobs':[],'mutating_API_scope':['fixed CPU diagnostic upload','fixed CPU diagnostic uninstall'],'observations':[]}
attempted=False
try:
 attempted=True
 command=[sys.executable,str(W/'tools/pd-waveform/session/cpu_probe_tool.py'),'--host','192.168.50.100','install',str(package),'--sha256',meta['sha256']]
 installed=subprocess.run(command,capture_output=True,text=True,timeout=40)
 report['install']={'exit':installed.returncode,'stdout':installed.stdout,'stderr':installed.stderr};assert installed.returncode==0,report['install']
 deadline=time.monotonic()+90
 while True:
  try:
   result=tool.status('192.168.50.100');report['CPU_results']=result;break
  except (ConnectionRefusedError,socket.timeout,TimeoutError) as error:
   report['observations'].append({'elapsed_s':round(90-(deadline-time.monotonic()),3),'status':type(error).__name__})
   if time.monotonic()>=deadline:raise
   time.sleep(.5)
 assert result['uid']==78666 and result['passed'],result
except Exception as error:
 report['failure']=type(error).__name__+': '+str(error)
finally:
 if attempted:
  stopped=subprocess.run([sys.executable,str(W/'tools/pd-waveform/session/cpu_probe_tool.py'),'--host','192.168.50.100','uninstall'],capture_output=True,text=True,timeout=25)
  report['uninstall']={'exit':stopped.returncode,'stdout':stopped.stdout,'stderr':stopped.stderr}
  deadline=time.monotonic()+20
  while True:
   try:c=socket.create_connection(('192.168.50.100',48999),.5);c.close()
   except ConnectionRefusedError:report['listener_closed_after_uninstall']=True;break
   except (socket.timeout,TimeoutError):pass
   if time.monotonic()>=deadline:report['listener_closed_after_uninstall']=False;break
   time.sleep(.2)
 report['completed_utc']=datetime.now(timezone.utc).isoformat()
 (E/'live-result.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps({k:v for k,v in report.items() if k not in ['observations','CPU_results']}))
assert 'failure' not in report and report.get('listener_closed_after_uninstall') and report['uninstall']['exit']==0
