import hashlib,json,socket,subprocess,sys
from pathlib import Path
from datetime import datetime,timezone
W=Path('/home/jeremy/AetherSDR/build/aetherpd-source');E=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'tools'));from automation_probe import Bridge
b=Bridge('/tmp/aetherpd-native-durability')
def get(q):
 r=b.request(q,8);assert r['ok'],r;return r
identity=get({'cmd':'whoami'});radio=get({'cmd':'get','model':'radio'})['radio'];tx=get({'cmd':'get','model':'transmit'})['transmit'];b.close()
assert identity['pid']==363057
image=hashlib.sha256(Path('/proc',str(identity['pid']),'exe').read_bytes()).hexdigest()
assert image=='a2e6f53b1ade27624ddf46a30a4a1c162259015727def69bea1234834a77e973'
assert radio['connected'] and radio['serial']=='2125-1213-8600-8895' and not radio['transmitting']
assert not tx['transmitting'] and not tx['mox'] and not tx['tuning']
pd=json.loads(subprocess.run([str(E.parent/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=20,check=True).stdout)
assert pd['http_status']==200 and pd['body']['state']=='stopped',pd
try:
 c=socket.create_connection(('192.168.50.100',48999),1);c.close()
except ConnectionRefusedError:pass
else:raise RuntimeError('CPU diagnostic port already occupied')
r={'observed_utc':datetime.now(timezone.utc).isoformat(),'desktop_pid':identity['pid'],'desktop_image_sha256':image,'radio':{'connected':radio['connected'],'serial':radio['serial'],'firmware':radio['version'],'transmitting':radio['transmitting'],'fullDuplex':radio['fullDuplex']},'AetherPD':pd,'CPU_probe_port_refused_before_install':True,'mutations':[]}
(E/'preflight.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
