from pathlib import Path
from datetime import datetime,timezone
import json,socket,subprocess,sys,time
W=Path('/home/jeremy/AetherSDR/build/aetherpd-source');E=Path(__file__).resolve().parent
sys.path.insert(0,str(W/'tools/pd-waveform/session'));import cpu_probe_tool as tool
(E/'qualified-preflight.py').write_text((E/'preflight.py').read_text().replace("E/'preflight.json'","E/'qualified-preflight.json'"))
subprocess.run([sys.executable,str(E/'qualified-preflight.py')],check=True,timeout=35)
meta=json.loads((E/'qualified-reproduction.json').read_text());package=E/'qualified-first/AetherPDCpuProbe.ssdr_waveform'
assert len(tool.package(package,meta['sha256']))==meta['bytes']
r={'started_utc':datetime.now(timezone.utc).isoformat(),'package':meta,'RF_commands':[],'reboot_commands':[],'root_bridge_jobs':[],'scope':'ordinary fixed CPU diagnostic upload/run/read/uninstall; no settings restoration or RF','observations':[]};attempted=False
def command(args):
 c=subprocess.run([sys.executable,str(W/'tools/pd-waveform/session/cpu_probe_tool.py'),'--host','192.168.50.100',*args],capture_output=True,text=True,timeout=40)
 return {'exit':c.returncode,'stdout':c.stdout,'stderr':c.stderr}
try:
 attempted=True;r['install']=command(['install',str(package),'--sha256',meta['sha256']]);assert r['install']['exit']==0,r['install']
 deadline=time.monotonic()+90
 while True:
  try:r['CPU_results']=tool.status('192.168.50.100');break
  except (ConnectionRefusedError,socket.timeout,TimeoutError) as error:
   r['observations'].append(type(error).__name__)
   if time.monotonic()>=deadline:raise
   time.sleep(.5)
 assert r['CPU_results']['uid']==78666 and r['CPU_results']['passed'],r['CPU_results']
except Exception as error:r['failure']=type(error).__name__+': '+str(error)
finally:
 try:
  if attempted:
   r['uninstall']=command(['uninstall']);deadline=time.monotonic()+20
   while True:
    try:c=socket.create_connection(('192.168.50.100',48999),.5);c.close()
    except ConnectionRefusedError:r['listener_closed_after_uninstall']=True;break
    except (socket.timeout,TimeoutError):pass
    if time.monotonic()>=deadline:r['listener_closed_after_uninstall']=False;break
    time.sleep(.2)
 except Exception as error:r['cleanup_failure']=type(error).__name__+': '+str(error)
 r['completed_utc']=datetime.now(timezone.utc).isoformat();(E/'qualified-live-result.json').write_text(json.dumps(r,indent=2)+'\n')
print(json.dumps({k:v for k,v in r.items() if k not in ['CPU_results','observations']}))
assert 'failure'not in r and 'cleanup_failure'not in r and r['uninstall']['exit']==0 and r.get('listener_closed_after_uninstall')
