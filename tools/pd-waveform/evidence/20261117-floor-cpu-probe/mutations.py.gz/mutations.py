from pathlib import Path
import json,os,resource,signal,subprocess
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
E=Path(__file__).resolve().parent;W=E.parent.parent/'aetherpd-source';C=W/'tools/pd-waveform/session'
mutations=[('exit-status','result.exit_code==0','1'),('deadline','now-started>=budget_ns','0'),('output-truncation','result->truncated=1','result->truncated=0'),('memory-limit','memory={256UL*1024*1024,256UL*1024*1024}','memory={512UL*1024*1024,512UL*1024*1024}'),('summary','all&=results[i].passed;','(void)i;'),('cancellation','if(index>=kCases || !budget_ns || stopping)','if(index>=kCases || !budget_ns)')]
results=[]
for name,old,new in mutations:
 p=E/('mutation-'+name);p.mkdir(exist_ok=True);source=(C/'cpu_probe.c').read_text();assert old in source
 (p/'cpu_probe.c').write_text(source.replace(old,new));(p/'cpu_probe_test.c').write_text((C/'cpu_probe_test.c').read_text())
 with (p/'build.log').open('w') as log:subprocess.run(['cc','-std=c11','-O1','-Wall','-Wextra','-Werror',str(p/'cpu_probe_test.c'),'-o',str(p/'test')],check=True,stdout=log,stderr=subprocess.STDOUT)
 with (p/'test.log').open('w') as log:
  process=subprocess.Popen([str(p/'test')],stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
  timed_out=False
  try:process.wait(timeout=2)
  except subprocess.TimeoutExpired:
   timed_out=True;os.killpg(process.pid,signal.SIGKILL);process.wait()
 row={'name':name,'exit':process.returncode,'watchdog_killed_entire_owned_test_process_group':timed_out,'detected':process.returncode!=0};results.append(row);print(json.dumps(row),flush=True);assert row['detected']
(E/'mutations.json').write_text(json.dumps(results,indent=2)+'\n')
