cmake_minimum_required(VERSION 3.20)
project(AetherPDWaveformExperiment LANGUAGES C)
find_package(Threads REQUIRED)
enable_testing()
    add_library(aether_pd_test_core STATIC
        tools/pd-waveform/pd_core.c
        tools/pd-waveform/pd_align.c
        tools/pd-waveform/pd_eq.c
        tools/pd-waveform/pd_acquire.c
        tools/pd-waveform/pd_local_iq.c
        tools/pd-waveform/pd_stream_guard.c
        tools/pd-waveform/pd_tx_guard.c
        tools/pd-waveform/pd_udp_rx.c
        tools/pd-waveform/pd_owner.c
        tools/pd-waveform/pd_status.c
        tools/pd-waveform/pd_capture.c
        tools/pd-waveform/pd_start_gate.c
        tools/pd-waveform/pd_calibration.c
        tools/pd-waveform/vendor/calcc.c
        tools/pd-waveform/vendor/iqc.c
        third_party/wdsp/upstream/delay.c
        third_party/wdsp/upstream/extrapolate.c
        third_party/wdsp/upstream/nurbs.c
        third_party/wdsp/upstream/nurbs_fit.c
        third_party/wdsp/upstream/nurbs_spline.c
        third_party/wdsp/upstream/fir.c
        third_party/wdsp/upstream/utilities.c
        third_party/wdsp/upstream/impulse_cache.c
        third_party/wdsp/port/wdsp_port.c)
    target_include_directories(aether_pd_test_core PUBLIC
        tools/pd-waveform third_party/wdsp/upstream
        third_party/wdsp/port/include third_party/wdsp/include
        third_party/fftw3/include)
    target_compile_options(aether_pd_test_core PUBLIC
        -include "${CMAKE_CURRENT_SOURCE_DIR}/third_party/wdsp/port/include/wdsp_port.h"
        -ffunction-sections -fdata-sections)
    target_compile_definitions(aether_pd_test_core PUBLIC _POSIX_C_SOURCE=200809L _DEFAULT_SOURCE)
    target_compile_definitions(aether_pd_test_core PRIVATE AETHER_PD_PI_CRITICAL_SECTIONS)
    target_link_options(aether_pd_test_core INTERFACE -Wl,--gc-sections)
    target_link_libraries(aether_pd_test_core PUBLIC Threads::Threads m)
    set_target_properties(aether_pd_test_core PROPERTIES
        AUTOMOC OFF AUTOUIC OFF AUTORCC OFF C_STANDARD 11 C_STANDARD_REQUIRED ON)

    add_executable(pd_recovery_collection_test tools/pd-waveform/recovery_collection_test.c)
    target_link_libraries(pd_recovery_collection_test PRIVATE aether_pd_test_core)
    add_test(NAME pd_recovery_collection_test COMMAND pd_recovery_collection_test)
    # Socket-free raw IQ snapshot and real waveform tap; no radio commands.
    add_executable(pd_capture_test tools/pd-waveform/capture_test.c)
    target_link_libraries(pd_capture_test PRIVATE aether_pd_test_core)
    add_test(NAME pd_capture_test COMMAND pd_capture_test)
    add_executable(pd_eq_phase_startup_test tools/pd-waveform/eq_phase_startup_test.c)
    target_link_libraries(pd_eq_phase_startup_test PRIVATE aether_pd_test_core)
    add_test(NAME pd_eq_phase_startup_test COMMAND pd_eq_phase_startup_test)
    add_executable(pd_warm_core_test tools/pd-waveform/warm_core_test.c)
    target_link_libraries(pd_warm_core_test PRIVATE aether_pd_test_core)
    add_test(NAME pd_warm_core_test COMMAND pd_warm_core_test)
    add_executable(pd_eq_worker_test tools/pd-waveform/eq_worker_test.c)
    target_link_libraries(pd_eq_worker_test PRIVATE aether_pd_test_core)
    add_test(NAME pd_eq_worker_test COMMAND pd_eq_worker_test)
    add_executable(pd_dispatch_deadline_test
        tools/pd-waveform/dispatch_deadline_test.c
        tools/pd-waveform/warm_seed_curve.c)
    target_link_libraries(pd_dispatch_deadline_test PRIVATE aether_pd_test_core)
    add_test(NAME pd_dispatch_deadline_test COMMAND pd_dispatch_deadline_test)
    add_executable(pd_calibration_dispatch_test tools/pd-waveform/calibration_dispatch_test.c)
    target_link_libraries(pd_calibration_dispatch_test PRIVATE aether_pd_test_core)
    add_test(NAME pd_calibration_dispatch_test COMMAND pd_calibration_dispatch_test)
    # Fixed source-control timing and real native admission; injected status,
    # no network sockets or radio commands.
    add_executable(pd_calibration_state_test tools/pd-waveform/calibration_test.c)
    target_link_libraries(pd_calibration_state_test PRIVATE aether_pd_test_core)
    add_test(NAME pd_calibration_state_test COMMAND pd_calibration_state_test)
    add_executable(pd_calibration_control_test tools/pd-waveform/calibration_control_test.c)
    target_link_libraries(pd_calibration_control_test PRIVATE aether_pd_test_core)
    add_test(NAME pd_calibration_control_test COMMAND pd_calibration_control_test)
    set_target_properties(pd_capture_test pd_recovery_collection_test pd_eq_phase_startup_test pd_warm_core_test pd_eq_worker_test pd_dispatch_deadline_test pd_calibration_dispatch_test pd_calibration_state_test pd_calibration_control_test
        PROPERTIES AUTOMOC OFF AUTOUIC OFF AUTORCC OFF C_STANDARD 11 C_STANDARD_REQUIRED ON)
    set_tests_properties(pd_capture_test pd_recovery_collection_test pd_eq_phase_startup_test pd_warm_core_test pd_eq_worker_test pd_dispatch_deadline_test pd_calibration_dispatch_test pd_calibration_state_test pd_calibration_control_test
        PROPERTIES TIMEOUT 70)

    # Actual port boundary with injected pthread failures; no sockets or radio.

add_executable(pd_waveform_probe tools/pd-waveform/pd_waveform.c)
target_link_libraries(pd_waveform_probe PRIVATE aether_pd_test_core)
add_test(NAME pd_waveform_selftest COMMAND pd_waveform_probe selftest)
set_tests_properties(pd_waveform_selftest PROPERTIES TIMEOUT 180)

add_executable(pd_dispatch_preamble_test tools/pd-waveform/dispatch_preamble_test.c)
target_link_libraries(pd_dispatch_preamble_test PRIVATE aether_pd_test_core)
add_test(NAME pd_dispatch_preamble_test COMMAND pd_dispatch_preamble_test)
set_tests_properties(pd_dispatch_preamble_test PROPERTIES TIMEOUT 30)

add_executable(pd_closed_loop_preamble_test tools/pd-waveform/closed_loop_preamble_test.c)
target_link_libraries(pd_closed_loop_preamble_test PRIVATE aether_pd_test_core)
add_test(NAME pd_closed_loop_preamble_test COMMAND pd_closed_loop_preamble_test)
set_tests_properties(pd_closed_loop_preamble_test PROPERTIES TIMEOUT 50)
