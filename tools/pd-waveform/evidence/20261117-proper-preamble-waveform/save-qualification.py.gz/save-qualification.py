from pathlib import Path
import datetime,gzip,hashlib,json,subprocess
p=Path(__file__).resolve().parent;e=p.parent;w=e.parent/'aetherpd-source'
d=w/'tools/pd-waveform/evidence/20261117-proper-preamble-waveform';d.mkdir(exist_ok=False)
files=[f for f in p.iterdir() if f.is_file() and f.suffix in ['.c','.py','.json','.log','.patch']]
for v in ['control','candidate']:
 files.append(p/v/'source/CMakeLists.txt')
 files.extend((p/v/'build').glob('dispatch-*.f32le'))
evidence={}
for f in sorted(files):
 target=d/(str(f.relative_to(p))+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 target.write_bytes(gzip.compress(f.read_bytes(),mtime=0));evidence[str(target.relative_to(w))]=hashlib.sha256(target.read_bytes()).hexdigest()
comparison=json.loads((p/'dispatch-sample-comparison.json').read_text())
report={
 'updated_utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),
 'status':'offline_dispatch_and_existing_regressions_passed_full_bounded_closed_loop_incomplete_experiment_parked',
 'production_ready':False,
 'source_base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=w,text=True).strip(),
 'provenance':json.loads((p/'provenance.json').read_text()),
 'passed':{'native_regressions':{'control':9,'candidate':9},'dispatch_samples':comparison,'budget_samples':192000,'noise_samples':96000,'source_commands':['A','M','Q'],'tone_transition':True,'sample_exhaustion_retirement':True,'explicit_cancel_retirement':True,'explicit_rearm_filter_reset_exact':True,'no_automatic_source_restart':True,'measurement_retirement_holds_silence':True},
 'isolated_selftest_adjustment':{'original_control_and_candidate_selftests':'Each failed only its status-buffer capacity assertion; correction/recovery loops completed. Original logs preserved.','adjustment':'In both isolated source copies only, enlarge selftest status JSON buffer from2048 to8192bytes.','adjusted_selftests':'Both passed, including four injected transport/path faults and six warm bursts.','production_source_changed':False},
 'candidate_added_filter_state_bytes':3056,
 'unqualified_closed_loop':{'initial_fixture_failure':'Checked feedback_ok before keying, although native start_feedback computes it on key. Corrected in the fixture.','second_attempt':'Both builds aligned and fitted the linear path, then the fixture paused IQ delivery while waiting synchronously for a WDSP fit. Actual TX continuity/freshness guards canceled the bounded source; complete closed-loop test did not pass.','supporting_logs':['control-closed-loop-02.log','candidate-closed-loop-02.log'],'next_fixture_action_if_resumed':'Keep source and feedback delivery paced while the asynchronous WDSP fit runs; do not suppress continuity/freshness guards.','causal_limits':'No radio failure, no candidate-specific regression and no diagnosis of the natural alignment slip are established by these host-fixture failures.'},
 'operator_deferral':'User deferred the unexplained5W SWR stop investigation. Related preamble experiment parked without deployment or RF.',
 'production_source_files_changed':False,'radio_package_or_defaults_changed':False,'RF_key_actions':0,
 'remaining_before_any_candidate_deployment':['Complete bounded actual-waveform WDSP loop qualification.','Measure target CPU/deadline/peak behavior.','Prepare authenticated reproducible candidate/rollback artifacts with unchanged privilege scope.','Any5W SWR-directed RF experiment remains deferred by operator.'],
 'evidence_sha256':evidence,
}
(w/'tools/pd-waveform/PROPER-COMPLEX-WAVEFORM-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
plan_path=e/'production-completion-plan-20261113.json';plan=json.loads(plan_path.read_text())
plan['operator_deferred_5W_SWR']={'deferred_utc':report['updated_utc'],'request':'defer the unexplained5W SWR stop investigation','complete':False,'related_preamble_experiment_parked':True,'report':'tools/pd-waveform/PROPER-COMPLEX-WAVEFORM-QUALIFICATION.json','policy':'Preserve all stops and existing guards. Do not mark deferred investigation achieved or resume it without operator direction.'}
plan['proper_complex_preamble_prototype']['full_waveform_integration_built']=True
plan['proper_complex_preamble_prototype']['integration_report']='tools/pd-waveform/PROPER-COMPLEX-WAVEFORM-QUALIFICATION.json'
plan['proper_complex_preamble_prototype']['full_closed_loop_qualified']=False
plan['next_action']='Qualify remaining installed-service failure, cleanup and restart behavior on the current authenticated8600 runtime, without RF or credential mutation. Preserve operator deferral of5W SWR investigation and related preamble experiment; retain all P1–P10 requirements and unqualified platform/release gates.'
plan['last_goal_turn_classification']='progress: both native variants passed9regressions and exact dispatched-sample/budget/retirement tests; original selftest-buffer failure retained and isolated adjustment qualified; unfinished bounded WDSP fixture preserved; operator-deferred5W investigation parked.'
plan_path.write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'evidence_files':len(evidence),'experiment_parked':True,'production_changed':False}))
