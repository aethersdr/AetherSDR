#include <sys/socket.h>
static ssize_t capture_send(int fd,const void* bytes,size_t size,int flags,const struct sockaddr* peer,socklen_t peer_size);
#define sendto capture_send
#define main pd_waveform_program_main
#include "pd_waveform.c"
#undef main
#undef sendto
#undef NDEBUG
#include <assert.h>

// Actual waveform dispatch is intercepted; no socket or radio is opened.
enum { kCaptureSamples = TEST_NOISE_SAMPLES + 128 };
static float captured[2*kCaptureSamples];
static unsigned captured_count;
static int collecting;
static double emitted_peak;
static unsigned long long emitted_samples;
static ssize_t capture_send(int fd,const void* bytes,size_t size,int flags,const struct sockaddr* peer,socklen_t peer_size)
{
    assert(fd==42); (void)flags; (void)peer; (void)peer_size;
    assert(size>=28 && (size-28)%8==0);
    const unsigned char* packet=bytes;
    for(size_t offset=28;offset+8<=size;offset+=8){
        float i=word_float(packet+offset),q=word_float(packet+offset+4);
        assert(isfinite(i) && isfinite(q));
        double peak=hypot(i,q);
        if(peak>emitted_peak){emitted_peak=peak;}
        if(collecting && captured_count<kCaptureSamples){
            captured[2*captured_count]=i;
            captured[2*captured_count+1]=q;
            ++captured_count;
        }
        ++emitted_samples;
    }
    return (ssize_t)size;
}
static void idle(wf_t* w)
{
    char line[]="S0|interlock state=READY tx_client_handle=0x00000000 source= reason= tx_allowed=1";
    api_line(w,line);
}
static void key(wf_t* w)
{
    w->local_iq.last_valid_ns=pd_iq_monotonic_ns();
    char line[]="S0|interlock state=TRANSMITTING tx_client_handle=0x00005678 source=SW reason= tx_allowed=1";
    api_line(w,line);
}
static void command(wf_t* w,unsigned char opcode,unsigned nonce)
{
    unsigned char request[11]={opcode,0,0,0,0,0,0,0,(unsigned char)nonce,3,233}; // Q spacing 1001 Hz.
    w->local_iq.last_valid_ns=pd_iq_monotonic_ns();
    struct pd_calibration_reply reply=operator_calibration_command(w,request,opcode=='Q'?11:9,pd_iq_monotonic_ns());
    assert(reply.result==PD_CAL_OK && reply.applied);
}
static void packet(wf_t* w,unsigned count)
{
    float input[256]; unsigned char bytes[28+sizeof(input)];
    for(int n=0;n<128;++n){input[2*n]=input[2*n+1]=(float)(.3*sin(2*M_PI*1000*(count*128+n)/RATE));}
    int size=vita_build(bytes,w->tx_in,CLASS_AUDIO_24K,(int)count,input,128);
    w->tx_arrival_ns=w->tx_last_send_ns=w->local_iq.last_valid_ns=pd_iq_monotonic_ns();
    w->tx_age_ns=0;
    on_packet(w,bytes,size);
}
static void check(unsigned char opcode)
{
    wf_t w; assert(wf_init(&w));
    w.api=open("/dev/null",O_WRONLY); assert(w.api>=0);
    w.api_leased=1;w.tx_in=0x81000001;w.active_slice=0;w.udp=42;
    w.tx_mhz=w.pan_mhz=7.15;w.daxiq_sid=0x20000000;w.local_iq.frames=1;
    w.calibration_gui=0x5678;w.calibration_slice_owner[0]=0x5678;w.calibration_control=1;
    idle(&w); command(&w,opcode,1); key(&w);
    assert(w.keyed && w.calibration.phase==PD_CAL_RUNNING && w.test_noise_left==TEST_NOISE_SAMPLES);
    assert(w.test_left==PD_CAL_SAMPLES && w.calibration.samples_left==PD_CAL_SAMPLES);
    captured_count=0;emitted_peak=0;emitted_samples=0;collecting=1;
    double start=mono();
    for(unsigned n=0;n<TEST_NOISE_SAMPLES/128;++n){packet(&w,n);}
    double noise_seconds=mono()-start;
    assert(captured_count==TEST_NOISE_SAMPLES && w.test_noise_left==0 && w.test_n==0);
    assert(w.generated_samples==TEST_NOISE_SAMPLES && w.test_left==PD_CAL_SAMPLES-TEST_NOISE_SAMPLES);
    assert(w.calibration.samples_left==w.test_left && w.calibration.phase==PD_CAL_RUNNING);
    packet(&w,TEST_NOISE_SAMPLES/128);
    assert(captured_count==kCaptureSamples && w.test_n==128 && w.test_left==PD_CAL_SAMPLES-kCaptureSamples);
    const double lower=opcode=='Q'?804.5:710,upper=opcode=='Q'?1805.5:1900;
    for(int n=0;n<128;++n){
        double expected_i=w.peak/2*(cos(2*M_PI*lower*n/RATE)+cos(2*M_PI*upper*n/RATE));
        double expected_q=w.peak/2*(sin(2*M_PI*lower*n/RATE)+sin(2*M_PI*upper*n/RATE));
        assert(fabs(captured[2*(TEST_NOISE_SAMPLES+n)]-expected_i)<4e-8);
        assert(fabs(captured[2*(TEST_NOISE_SAMPLES+n)+1]-expected_q)<4e-8);
    }
    char filename[64];snprintf(filename,sizeof filename,"dispatch-%c.f32le",opcode);
    FILE* file=fopen(filename,"wb");assert(file);
    assert(fwrite(captured,sizeof(float),2*kCaptureSamples,file)==2*kCaptureSamples);assert(!fclose(file));
    float first_packet[256];memcpy(first_packet,captured,sizeof first_packet);collecting=0;
    for(unsigned n=kCaptureSamples/128;n<PD_CAL_SAMPLES/128;++n){packet(&w,n);}
    assert(w.generated_samples==PD_CAL_SAMPLES && w.calibration.samples_left==0 && !w.test_left && !w.test_f1);
    assert(w.calibration.phase==PD_CAL_COMPLETED && !test_source_active(&w));
    assert(!w.limited_samples && !w.tx_deadline_faults && !w.tx_send_errors && !w.tx_rejected);
    assert(emitted_peak<=w.peak+4e-8 && emitted_samples==PD_CAL_SAMPLES);
    double complete_peak=emitted_peak;
    emitted_peak=0;
    for(unsigned n=1500;n<1516;++n){packet(&w,n);}
    if(opcode!='A'){assert(emitted_peak==0);}else{assert(emitted_peak>1e-4);}
    idle(&w);key(&w);emitted_peak=0;packet(&w,1516);
    assert(!test_source_active(&w) && !w.test_f1 && emitted_peak>1e-4);
    idle(&w);command(&w,opcode,3);key(&w);
    captured_count=0;collecting=1;packet(&w,1517);collecting=0;
    assert(captured_count==128 && !memcmp(first_packet,captured,sizeof first_packet));
    command(&w,'X',4);emitted_peak=0;
    for(unsigned n=1518;n<1534;++n){packet(&w,n);}
    assert(w.calibration.phase==PD_CAL_CANCELED && !test_source_active(&w));
    if(opcode!='A'){assert(emitted_peak==0);}else{assert(emitted_peak>1e-4);}
    printf("{\"opcode\":\"%c\",\"noise_samples\":%d,\"total_budget\":%d,\"emitted_peak\":%.12g,\"noise_host_wall_seconds\":%.9g,\"wf_bytes\":%zu,\"cbp_bytes\":%zu,\"sample_reset_exact\":true,\"retirement_checked\":true}\n",opcode,TEST_NOISE_SAMPLES,PD_CAL_SAMPLES,complete_peak,noise_seconds,sizeof(wf_t),sizeof(cbp_t));
    idle(&w);close(w.api);
    pd_acquire_destroy(w.acquire);pd_core_destroy(w.core);pd_align_destroy(w.align);
    pd_eq_destroy(w.eq);pd_eq_destroy(w.trusted_eq);
    free(w.ref.buf);free(w.fbk.buf);free(w.acq_tx);free(w.acq_rx);
}
int main(void)
{
    setenv("AETHER_PD_FEEDBACK","local",1);setenv("AETHER_PD_TX_DEADLINE_MS","25",1);
    unsetenv("AETHER_PD_TEST_TONES");unsetenv("AETHER_PD_TEST_SECONDS");
    unsetenv("AETHER_PD_PEAK");unsetenv("AETHER_PD_CORRECT");unsetenv("AETHER_PD_MIC_GAIN");
    check('A');check('M');check('Q');return 0;
}
