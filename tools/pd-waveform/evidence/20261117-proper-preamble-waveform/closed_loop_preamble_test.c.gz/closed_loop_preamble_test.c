#define main pd_waveform_program_main
#include "pd_waveform.c"
#undef main
#undef NDEBUG
#include <assert.h>

// Uses the existing in-process PA/delay model and private Unix IQ socket pair.
// No TCP peer, radio connection, public socket or RF.
static void check_loop(unsigned char opcode)
{
    wf_t w; assert(wf_init(&w));w.api=open("/dev/null",O_WRONLY);assert(w.api>=0);
    w.api_leased=1;w.seq_create=3;w.seq_daxiq=4;
    char stream[]="R3|0|tx_stream_in_id=0x84000001 rx_stream_in_id=0x84000000";
    char iq[]="R4|0|0x20000001";
    char slice[]="S1|slice 1 mode=PD RF_frequency=7.150000";
    char pan[]="S1|display pan 0x40000001 center=7.151000 daxiq_channel=1";
    api_line(&w,stream);api_line(&w,iq);api_line(&w,slice);api_line(&w,pan);
    assert(w.active_slice==1 && w.local_iq_mode);
    w.calibration_control=1;w.calibration_gui=0x5678;w.calibration_slice_owner[1]=0x5678;
    loop_t l={.w=&w,.len=LOOP_DELAY,.local_fd=-1};l.line=calloc(2*LOOP_DELAY,sizeof(double));assert(l.line);
    int endpoints[2];assert(!socketpair(AF_UNIX,SOCK_DGRAM,0,endpoints));
    l.local_fd=endpoints[0];w.local_iq.fd=endpoints[1];
    assert(pd_guard_init(&w.local_iq.guard,w.daxiq_sid,1,48000,25000000));
    w.tx_tap=loop_tap;w.tap_ctx=&l;
    for(int n=0;n<128;++n){loop_emit(&l,0,0);}
    char idle[]="S1|interlock state=READY tx_client_handle=0x00000000 source= reason= tx_allowed=1";
    char key[]="S1|interlock state=TRANSMITTING tx_client_handle=0x00005678 source=SW reason= tx_allowed=1";
    api_line(&w,idle);
    unsigned char request[11]={opcode,0,0,0,0,0,0,0,1,3,233};
    assert(operator_calibration_command(&w,request,opcode=='Q'?11:9,pd_iq_monotonic_ns()).applied);
    api_line(&w,key);
    assert(w.keyed && w.tx_on && w.feedback_ok && w.calibration.phase==PD_CAL_RUNNING && w.test_noise_left==TEST_NOISE_SAMPLES);
    float mic[256]={0};unsigned char packet[28+sizeof(mic)];
    long first_fit_sample=-1,first_correcting_sample=-1;unsigned correcting_packets=0;
    double started=mono();
    for(unsigned n=0;n<PD_CAL_SAMPLES/128;++n){
        int bytes=vita_build(packet,w.tx_in,CLASS_AUDIO_24K,(int)n,mic,128);
        w.tx_arrival_ns=w.tx_last_send_ns=pd_iq_monotonic_ns();w.tx_age_ns=0;
        on_packet(&w,packet,bytes);
        if(w.eq_pending){struct timespec pause={0,1000000};nanosleep(&pause,NULL);}
        for(int wait=0;wait<2000 && pd_core_state(w.core)==6 && !pd_core_swap_pending(w.core);++wait){
            extern void pscc(int,int,double*,double*);double none[2]={0,0};pscc(0,0,none,none);
            struct timespec pause={0,500000};nanosleep(&pause,NULL);
        }
        if(first_fit_sample<0 && pd_core_fits(w.core)>0){first_fit_sample=(long)(n+1)*128;}
        if(correction_ready(&w) && pd_core_correcting(w.core)){
            if(first_correcting_sample<0){first_correcting_sample=(long)(n+1)*128;}
            ++correcting_packets;
        }
        assert(w.calibration.phase==PD_CAL_RUNNING || n+1==PD_CAL_SAMPLES/128);
        assert(mono()-started<12);
    }
    printf("{\"opcode\":\"%c\",\"source_samples\":%llu,\"noise_samples\":%d,\"first_fit_sample\":%ld,\"first_correcting_sample\":%ld,\"correcting_packets\":%u,\"fits\":%d,\"delay_samples\":%.9g,\"alignment_correlation\":%.9g,\"coherence\":%.9g,\"alignment_events\":%u,\"alignment_resets\":%u,\"input_limited\":%llu,\"deadline_faults\":%llu,\"IQ_stale\":%llu,\"host_wall_seconds\":%.9g}\n",opcode,(unsigned long long)w.generated_samples,TEST_NOISE_SAMPLES,first_fit_sample,first_correcting_sample,correcting_packets,pd_core_fits(w.core),pd_align_delay(w.align),pd_align_estimate_corr(w.align),pd_align_coherence(w.align),w.alignment_event.count,w.alignment_reset_event.count,(unsigned long long)w.limited_samples,(unsigned long long)w.tx_deadline_faults,(unsigned long long)w.local_iq.stale,mono()-started);
    fflush(stdout);
    assert(w.generated_samples==PD_CAL_SAMPLES && w.calibration.phase==PD_CAL_COMPLETED);
    assert(w.aligned && pd_eq_ready(w.eq) && pd_core_current_solution(w.core) && pd_core_correcting(w.core));
    assert(first_fit_sample>=0 && first_correcting_sample>=0 && correcting_packets>0);
    assert(pd_align_estimate_corr(w.align)>.8 && pd_align_coherence(w.align)>.8);
    assert(fabs(pd_align_delay(w.align)-(LOOP_DELAY/2.0+(TAPS-1)/4.0))<2);
    assert(!w.limited_samples && !w.tx_deadline_faults && !w.tx_rejected && !w.local_iq.stale);
    assert(w.alignment_event.count==1 && !w.alignment_reset_event.count);
    api_line(&w,idle);close(w.api);close(l.local_fd);close(w.local_iq.fd);
    pd_acquire_destroy(w.acquire);pd_core_destroy(w.core);pd_align_destroy(w.align);
    pd_eq_destroy(w.eq);pd_eq_destroy(w.trusted_eq);
    free(w.ref.buf);free(w.fbk.buf);free(w.acq_tx);free(w.acq_rx);free(l.line);
}
int main(void)
{
    setenv("AETHER_PD_FEEDBACK","local",1);setenv("AETHER_PD_TX_DEADLINE_MS","25",1);
    unsetenv("AETHER_PD_TEST_TONES");unsetenv("AETHER_PD_TEST_SECONDS");
    unsetenv("AETHER_PD_PEAK");unsetenv("AETHER_PD_CORRECT");unsetenv("AETHER_PD_MIC_GAIN");
    check_loop('A');check_loop('M');check_loop('Q');return 0;
}
