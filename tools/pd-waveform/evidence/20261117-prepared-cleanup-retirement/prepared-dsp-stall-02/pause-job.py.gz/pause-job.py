import hashlib,json,os,select,signal,socket,time
from pathlib import Path
CONFIG={'host': '192.168.50.221', 'port': 33249, 'nonce': '4357e66be879a5b5c8a314ced06d30c925f633567f933885', 'gui_handle': '0x1a181f77', 'pan': '0x40000000'}
report={'case':'prepared-DSP-startup-stall','probe_complete':False,'signals':[],'RF_commands':[],'runtime_restart_requested':False};observer=None;handles=[];stopped=False;resumer=None;cancel_write=None;fd=None;started=time.monotonic()

def graph():
 rows=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   exe=os.readlink(p/'exe')
   if '/aetherpd/' not in exe:continue
   f={x.split(':',1)[0]:x.split(':',1)[1].strip() for x in (p/'status').read_text().splitlines() if ':' in x}
   rows.append({'pid':int(p.name),'ppid':int(f['PPid']),'exe':exe,'uid':f['Uid'],'state':f['State'],'cgroup':(p/'cgroup').read_text().splitlines(),'start_ticks':int((p/'stat').read_text().rsplit(')',1)[1].split()[19]),'caps':{k:f[k] for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']},'nnp':f['NoNewPrivs']})
  except (FileNotFoundError,ProcessLookupError,PermissionError):pass
 return rows

def alive(row):
 try:return int((Path('/proc')/str(row['pid'])/'stat').read_text().rsplit(')',1)[1].split()[19])==row['start_ticks']
 except (FileNotFoundError,ProcessLookupError):return False

def idle():
 global observer
 if observer:observer.close()
 observer=socket.create_connection(('127.0.0.1',4992),2);observer.setblocking(False);observer.sendall(b'C1|sub tx all\n');buffer=b'';end=time.monotonic()+3
 while time.monotonic()<end:
  if not select.select([observer],[],[],.1)[0]:continue
  data=observer.recv(16384);assert data;buffer+=data;assert len(buffer)<131072
  while b'\n' in buffer:
   line,buffer=buffer.split(b'\n',1);text=line.decode('ascii').strip()
   if text.startswith('S') and '|interlock ' in text and '|interlock band ' not in text:
    fields=dict(x.split('=',1) for x in text.split('|',1)[1].split()[1:] if '=' in x)
    if all(x in fields for x in ['state','source','tx_client_handle','tx_allowed','reason']):
     assert fields['state']=='READY' and fields['source']=='' and fields['tx_client_handle']=='0x00000000' and fields['tx_allowed']=='1' and fields['reason']=='',fields
     return fields
 raise RuntimeError('Fresh complete idle interlock absent; no fault injected')

try:
 assert hashlib.sha256(Path('/var/lib/smartsdr/aetherpd/state/provision.json').read_bytes()).hexdigest()=='d2e1df2b422811c47f68e2ec18440265960f6a6e2014df55033f46b14db79ed1'
 assert Path('/var/lib/smartsdr/aetherpd/upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('ca1b8f835ed90fa96e641e2e5c3a9223015e3c16f709b51f5965329e504dbc30')
 report['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert report['boot_id']=='1225abd2-52c4-4716-af98-e789ebb0bff5'
 report['before']=graph();workers={'aether-pd','pd-iq-source','pd-capture-bootstrap','pd-fixed-arp','pd-unkey-guard','pd-lease-guard'}
 assert not any(Path(r['exe']).name in workers for r in report['before']);report['idle_before']=idle();observer.close();observer=None
 assert not any(line.split()[0]=='172.30.2.1' for line in Path('/proc/net/arp').read_text().splitlines()[1:])
 with socket.create_connection((CONFIG['host'],CONFIG['port']),3) as notice:notice.sendall((json.dumps({'nonce':CONFIG['nonce'],'ready':True})+'\n').encode())
 deadline=time.monotonic()+30;target=None
 while time.monotonic()<deadline:
  rows=graph();by_pid={r['pid']:r for r in rows}
  for row in rows:
   parent=by_pid.get(row['ppid'])
   if row['exe']=='/run/aetherpd/bin/aether-pd' and row['uid'].split()==['78666']*4 and row['nnp']=='1' and not any(int(v,16) for v in row['caps'].values()) and parent and parent['exe']=='/run/aetherpd/bin/pd-radio-launch' and parent['uid'].split()==['0']*4 and '/aetherpd-start@' in str(row['cgroup']):
    target=row;break
  if target:break
  time.sleep(.001)
 assert target,'No prepared DSP appeared; no signal sent'
 p=Path('/proc')/str(target['pid']);fd=os.pidfd_open(target['pid']);handles.append(fd);assert alive(target)
 assert hashlib.sha256((p/'exe').read_bytes()).hexdigest()=='b3fc2de87fb51a20721d53a3e0758c4206b29f4ccd6ad1b96e273400471cdf8d'
 parent=Path('/proc')/str(target['ppid']);assert hashlib.sha256((parent/'exe').read_bytes()).hexdigest()=='09c9103a47581d829c61ff33fa180556ccda2e3a4071ed1951fb643e0c838877'
 env=dict(x.split(b'=',1) for x in (p/'environ').read_bytes().split(b'\0') if b'=' in x)
 assert env.get(b'AETHER_PD_GUI_HANDLE')==CONFIG['gui_handle'].encode() and env.get(b'AETHER_PD_FEEDBACK_PAN')==CONFIG['pan'].encode() and env.get(b'AETHER_PD_DAXIQ')==b'4' and env.get(b'AETHER_PD_START_FD')==b'9'
 assert os.sched_getscheduler(target['pid'])==os.SCHED_OTHER,'DSP already promoted; no signal sent'
 report['target']=target;report['at_fault']=graph();cohort=[r for r in report['at_fault'] if r['cgroup']==target['cgroup']]
 cancel_read,cancel_write=os.pipe();resumer=os.fork()
 if resumer==0:
  os.close(cancel_write)
  if not select.select([cancel_read],[],[],18)[0]:
   try:signal.pidfd_send_signal(fd,signal.SIGCONT)
   except ProcessLookupError:pass
   os._exit(11)
  os._exit(0)
 os.close(cancel_read);stamp=time.monotonic_ns();signal.pidfd_send_signal(fd,signal.SIGSTOP);stopped=True
 report['signals'].append({'pid':target['pid'],'start_ticks':target['start_ticks'],'signal':'SIGSTOP','monotonic_ns':stamp})
 end=time.monotonic()+.1
 while True:
  state=(p/'stat').read_text().rsplit(')',1)[1].split()[0]
  if state in ('T','t'):break
  assert time.monotonic()<end;time.sleep(.001)
 assert os.sched_getscheduler(target['pid'])==os.SCHED_OTHER,'DSP readiness race; startup stall not established'
 observations=[];previous=None;last_seen={r['pid']:r for r in cohort};deadline=time.monotonic()+16
 while True:
  rows=graph();cohort_now=[r for r in rows if r['cgroup']==target['cgroup']]
  for row in cohort_now:last_seen.setdefault(row['pid'],row)
  view={'elapsed_ms':(time.monotonic_ns()-stamp)/1e6,'processes':cohort_now}
  key=[(r['pid'],r['exe'],r['uid'],r['state'],r['caps']['CapEff']) for r in cohort_now]
  if key!=previous or not observations or view['elapsed_ms']-observations[-1]['elapsed_ms']>200:
   observations.append(view);previous=key
  active=[r for r in cohort_now if Path(r['exe']).name in workers]
  original=alive(target)
  if not active and not original:break
  assert time.monotonic()<deadline,('Startup workers remain',active,original)
  time.sleep(.025)
 report['workers_gone_ms']=(time.monotonic_ns()-stamp)/1e6;report['observations']=observations
 report['original_DSP_PID_including_zombie_gone']=not alive(target)
 report['post_timeout_root_observations']=[v for v in observations if v['elapsed_ms']>=10200 and any(r['uid'].split()==['0']*4 for r in v['processes'])]
 report['all_observed_original_workers_gone']=all(not alive(r) for r in last_seen.values() if Path(r['exe']).name in workers);assert report['all_observed_original_workers_gone']
 stopped=False;os.write(cancel_write,b'x');os.close(cancel_write);cancel_write=None;_,status=os.waitpid(resumer,0);resumer=None;report['resume_watchdog_exit']=os.waitstatus_to_exitcode(status);assert report['resume_watchdog_exit']==0
 report['after']=graph();assert not any(Path(r['exe']).name in workers for r in report['after'])
 report['arp_after']=[line for line in Path('/proc/net/arp').read_text().splitlines()[1:] if line.split()[0]=='172.30.2.1'];assert not report['arp_after']
 report['journal_bytes_after']=Path('/run/.aetherpd-fixed-arp.8600').stat().st_size;assert report['journal_bytes_after']==0
 report['accept_local']=Path('/proc/sys/net/ipv4/conf/eth0.10/accept_local').read_text().strip();assert report['accept_local']=='0'
 report['idle_after']=idle();report['probe_complete']=True
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
 if stopped:
  try:signal.pidfd_send_signal(fd,signal.SIGCONT)
  except ProcessLookupError:pass
 if cancel_write is not None:os.close(cancel_write)
 if resumer is not None:
  _,status=os.waitpid(resumer,0);report['fallback_watchdog_exit']=os.waitstatus_to_exitcode(status)
 for fd in handles:os.close(fd)
 if observer:observer.close()
 report['total_s']=round(time.monotonic()-started,3);print(json.dumps(report),flush=True)
