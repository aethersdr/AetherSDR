from pathlib import Path
import ctypes,hashlib,json,os,shutil,signal,subprocess,time
p=Path(__file__).resolve().parent;w=p.parent.parent/'aetherpd-source';source=w/'tools/pd-waveform/session'
assert ctypes.CDLL(None,use_errno=True).prctl(36,1,0,0,0)==0 # Subreap only this runner's deliberately aborted mutants.
import resource
resource.setrlimit(resource.RLIMIT_CORE,(0,0))
report={'installed':False,'mutations':[],'cross_builds':{}}

def run(cmd,name,environment=None):
 with (p/(name+'.log')).open('w') as output:
  child=subprocess.Popen(cmd,stdout=output,stderr=subprocess.STDOUT,env=environment,start_new_session=True)
  try:returncode=child.wait(timeout=35)
  finally:
   try:os.killpg(child.pid,signal.SIGKILL)
   except ProcessLookupError:pass
   deadline=time.monotonic()+3
   while True:
    try:pid,_=os.waitpid(-child.pid,os.WNOHANG)
    except ChildProcessError:break
    if not pid:
     assert time.monotonic()<deadline,'Own mutant descendant was not reaped';time.sleep(.01)
 return returncode

for name in ['missing-retirement','ignored-retirement-failure','retirement-after-TERM']:
 result=run([str(p/name/'test')],name+'-host-retest');log=(p/(name+'-host-retest.log')).read_text()
 assert result!=0 and 'prepared_cleanup_privileged' in log
 report['mutations'].append({'name':name,'exit':result,'assertion':log.strip()[-500:]})
result=run([str(p/'radio-test-sanitized')],'sanitizer-host-run',dict(os.environ,ASAN_OPTIONS='detect_leaks=1:abort_on_error=1'));assert result==0;report['ASan_UBSan_LSan_exit']=result
report['initial_sanitizer_environment_failure']='Sandbox run failed because LSan cannot run under ptrace; unchanged binary passed on host.'
env=dict(os.environ,ZIG_LOCAL_CACHE_DIR=str(p/'zig-cache'),ZIG_GLOBAL_CACHE_DIR=str(p/'zig-cache'))
for arch,flags in [('arm64',['-target','aarch64-linux-musl']),('armv7',['-target','arm-linux-musleabihf','-mcpu=cortex_a8'])]:
 output=p/('pd-radio-launch-'+arch)
 assert run(['zig','cc',*flags,'-O2','-static','-s','-Wall','-Wextra','-Werror','-Wl,--build-id=none','-pthread',str(source/'pd_radio_launch.c'),'-o',str(output)],'build-'+arch,env)==0
 report['cross_builds'][arch]={'sha256':hashlib.sha256(output.read_bytes()).hexdigest(),'bytes':output.stat().st_size}
(p/'verification.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report),flush=True)
