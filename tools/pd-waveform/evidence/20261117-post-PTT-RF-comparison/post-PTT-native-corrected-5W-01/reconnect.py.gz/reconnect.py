from pathlib import Path
import sys,json,subprocess,time
p=Path(__file__).resolve().parent;e=p.parent;sys.path.insert(0,str(e.parent/'aetherpd-source/tools'));from automation_probe import Bridge
assert not (p/'reconnect-result.json').exists();b=Bridge('/tmp/aetherpd-post-ptt-power');r={'RF_commands':[]};r['before']={m:b.request({'cmd':'get','model':m},5) for m in ['radio','transmit','slices','pans']};assert r['before']['radio']['radio']['connected'] and not r['before']['radio']['radio']['transmitting'] and not r['before']['transmit']['transmit']['mox']
r['native']=json.loads(subprocess.run([str(e/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=20).stdout);assert r['native']['http_status']==200 and r['native']['body']['state']=='stopped'
r['close']=b.request({'cmd':'invoke','target':'pdDone','action':'click'},5);assert r['close']['ok'];r['disconnect']=b.request({'cmd':'disconnect'},5);assert r['disconnect']['ok'];deadline=time.monotonic()+12
while b.request({'cmd':'get','model':'radio'},5)['radio']['connected']:assert time.monotonic()<deadline;time.sleep(.1)
r['connect']=b.request({'cmd':'connect','action':'local','value':'serial 2125-1213-8600-8895'},5);assert r['connect']['ok'];deadline=time.monotonic()+30
while True:
 r['after']={m:b.request({'cmd':'get','model':m},5) for m in ['radio','transmit','slices','pans']}
 if r['after']['radio']['radio']['connected'] and len(r['after']['slices']['slices'])==1 and len(r['after']['pans']['pans'])==1:break
 assert time.monotonic()<deadline;time.sleep(.2)
a=r['after'];assert not a['radio']['radio']['transmitting'] and not a['radio']['radio']['fullDuplex'];assert a['transmit']['transmit']['rfPower']==5 and a['transmit']['transmit']['maxPowerLevel']==10
s=a['slices']['slices'][0];assert s['frequency']==7.15 and s['mode']=='USB' and s['txAntenna']=='ANT1' and s['rxAntenna']=='RX_A';pan=a['pans']['pans'][0];assert pan['ownedByUs'] and pan['rfGain']==0
r['passed']=True;(p/'reconnect-result.json').write_text(json.dumps(r,indent=2)+'\n');b.close();print(json.dumps({'passed':True,'ordinary_transport_teardown_and_reconnect':True,'new_GUI_handle':pan['clientHandle'],'RF_commands':[]}))
