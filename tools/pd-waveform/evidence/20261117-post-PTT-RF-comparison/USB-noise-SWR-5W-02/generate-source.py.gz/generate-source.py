"""Finite offline LCG-noise audio. No radio, network or keying."""
from pathlib import Path
import json,hashlib
import numpy as np
p=Path(__file__).resolve().parent;rate=48000;n=5*rate;seed=12345;x=np.empty(n)
for k in range(n):
 seed=(seed*1664525+1013904223)&0xffffffff;x[k]=((seed>>8)/16777216.)-.5
spectrum=np.fft.rfft(x);freq=np.fft.rfftfreq(n,1/rate);spectrum[(freq<300)|(freq>3000)]=0;pcm=np.fft.irfft(spectrum,n);pcm*= .12/np.sqrt(np.mean(pcm**2));peak=float(abs(pcm).max());assert peak<.6
ramp=np.linspace(0,1,960);pcm[:960]*=ramp;pcm[-960:]*=ramp[::-1];raw=np.repeat(pcm[:,None],2,axis=1).astype('<f4').tobytes();(p/'noise-source.f32le').write_bytes(raw)
r={'rate':rate,'channels':2,'duration_s':5,'noise_band_Hz':[300,3000],'PRNG':'LCG seed12345','real_RMS_before_ramps':.12,'real_RMS_after_ramps':float(np.sqrt(np.mean(pcm**2))),'peak_amplitude':peak,'peak_stop_before_RF':.6,'normalization':'Fixed offline real-PCM RMS; not a claim of calibrated RF power or native-preamble equivalence.','sha256':hashlib.sha256(raw).hexdigest()};(p/'source-metadata.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r))
