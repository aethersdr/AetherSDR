"""Quality of LP vector fields; direct power/SWR stops remain separate."""
class CoherenceWindow:
 def __init__(self):
  self.bad_since=None
  self.last=None
 def reset(self):
  self.bad_since=None
 def check(self,now_ns,coherent):
  if self.last is not None and now_ns<self.last:raise RuntimeError('LP coherence clock moved backward')
  self.last=now_ns
  if coherent:
   self.reset();return
  if self.bad_since is None:self.bad_since=now_ns
  if now_ns-self.bad_since>=250_000_000:raise RuntimeError('Steady-tone LP vector fields incoherent for250ms')
