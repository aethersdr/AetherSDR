import base64,hashlib,json,pathlib,sys
import numpy as np
p=pathlib.Path(sys.argv[1]);d=json.loads(p.read_text());assert d['window']=='blackman-harris-7' and d['measurement']['valid'];n=d['measurement']['fft_size'];assert n==16384
a=[.27105140069342,.43329793923448,.21812299954311,.06592544638803,.01081174209837,.00077658482522,.00001388721735]
x=np.arange(n,dtype=np.float64);w=sum((-1)**j*v*np.cos(2*np.pi*j*x/n) for j,v in enumerate(a));powers=[];peaks=[]
for c in d['captures']:
 raw=base64.b64decode(c['iq_f32le'],validate=True);assert hashlib.sha256(raw).hexdigest()==c['sha256'];z=np.frombuffer(raw,dtype='<c8').astype(np.complex128);assert len(z)==n and np.isfinite(z).all();powers.append(np.abs(np.fft.fftshift(np.fft.fft(z*w))/w.sum())**2);peaks.append(float(np.max(np.abs(z)**2)))
mean=np.mean(powers,axis=0);db=10*np.log10(np.maximum(mean,1e-30));export=np.asarray(d['measurement']['spectrum_db_raw_iq']);error=float(np.max(np.abs(db-export)));assert error<1e-4
r={'file':p.name,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'frames':len(powers),'samples_per_frame':n,'max_spectrum_error_db':error,'raw_envelope_peak':max(peaks)**.5,'sampled_pep_db_raw_iq':10*np.log10(max(peaks)),'products':[q for q in d['measurement']['products']],'fundamental_pep_db_raw_iq':d['measurement']['fundamental_pep_db_raw_iq'],'scope':'Independent NumPy FFT of exported samples; not calibrated watts, ADC headroom or independent RF instrument.'}
p.with_name('independent-recheck.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps({k:r[k] for k in ('sha256','frames','max_spectrum_error_db','raw_envelope_peak')}))
