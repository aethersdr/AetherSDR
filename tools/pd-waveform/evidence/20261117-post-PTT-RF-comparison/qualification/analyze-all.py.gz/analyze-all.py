"""Offline-only comparison of recorded bench events and exported IQ."""
from pathlib import Path
import json,math,hashlib
import numpy as np
p=Path(__file__).resolve().parent;e=p.parent
names=['USB-two-tone-SWR-5W-01','USB-noise-SWR-5W-01','USB-noise-SWR-5W-02','post-PTT-native-corrected-5W-01','post-PTT-native-baseline-10W-01','post-PTT-native-corrected-10W-01']
span=lambda a:{'minimum':min(a),'maximum':max(a)} if a else None
reports={}
for name in names:
 d=e/name;o=json.loads((d/'outcome.json').read_text());events=json.loads((d/'events.json').read_text());key=next(x['monotonic_ns'] for x in events if x['event']=='operator_key_intent');lp=[json.loads(x) for x in (d/'lp100a-readings.jsonl').read_text().splitlines() if x.strip()];met=[x for x in events if x['event'] in ['meters','independent_meters']];direct=json.loads((d/'independent-meters.json').read_text())['rows'];fault=[]
 for row in direct:
  raw=row['raw']
  if not {'8','9','10'}<=raw.keys() or raw['10']/128<=2:continue
  f=10**((raw['8']/128-30)/10);r=10**((raw['9']/128-30)/10)
  if f<=.5:continue
  near=min(lp,key=lambda x:abs(x['host_monotonic_ns']-row['ns']));rho=math.sqrt(r/f)
  fault.append({'elapsed_from_host_key_intent_s':(row['ns']-key)/1e9,'raw':raw,'radio_SWR':raw['10']/128,'forward_W':f,'reflected_W':r,'same_packet_directional_derived_SWR':(1+rho)/(1-rho) if rho<1 else None,'nearest_LP_peak_held_W':near['power_w'],'nearest_LP_SWR':near['swr'],'LP_offset_ms':(near['host_monotonic_ns']-row['ns'])/1e6})
 native=[x['result']['body'] for x in events if x['event']=='service' and x['path']=='aetherpd/status' and x['result']['body'].get('keyed')]
 if not native:native=[x['response']['body'] for x in events if x['event']=='native_API' and x['operation']=='status' and x['response']['body'].get('keyed')]
 correcting_times=[(x['monotonic_ns']-key)/1e9 for x in events if x['event']=='service' and x['path']=='aetherpd/status' and x['result']['body'].get('keyed') and x['result']['body'].get('correcting')]
 first=min(correcting_times) if correcting_times else None
 later=[x['result']['body']['correcting'] for x in events if first is not None and x['event']=='service' and x['path']=='aetherpd/status' and x['result']['body'].get('keyed') and (x['monotonic_ns']-key)/1e9>=first]
 r={'whole_harness_passed':o['passed'],'positive_GUI_key_actions':o['positive_GUI_key_actions'],'radio_idle_after':not o.get('radio_after',{}).get('transmitting',True),'service_stopped':o.get('service_stopped',o.get('session_stopped',False)),'LP_idle_after_W':o['LP_idle_after']['power_w'],'LP_peak_held_max_W':max(x['power_w'] for x in lp),'LP_SWR_with_RF':span([x['swr'] for x in lp if x['rf_present'] and x['power_w']>=.2]),'host_meter_observations':len(met),'host_observations_not_independent_hardware_samples':True,'Flex_forward_W':span([x['Flex']['watts'] for x in met]),'Flex_raw_SWR':span([x['Flex']['radio_reported_swr'] for x in met if 'radio_reported_swr' in x['Flex']]),'host_observations_forward_above_half_W':sum(x['Flex']['watts']>.5 for x in met),'native_SWR_above2_while_forward_above_half_W':fault,'first_host_observed_correcting_s':first,'all_observed_keyed_status_after_first_correction_correcting':all(later) if later else None,'keyed_native_status_observations':len(native),'all_observed_native_faults_zero':all(not any(x['faults'].values()) for x in native) if native else None,'observed_input_limited_samples_max':max((x['input_limited_samples'] for x in native),default=None),'failure':o.get('failure',o.get('cleanup_error',o.get('error'))),'diagnostics_after':o.get('native_after',{}).get('diagnostics')}
 f=d/'measurement.json'
 if f.exists():
  m=json.loads(f.read_text());r['export_error']=m.get('error');r['export_valid']=m.get('measurement',{}).get('valid',False);r['correction_active']=m.get('correction_active');r['frame_count']=len(m.get('captures',[]));r['export_sha256']=hashlib.sha256(f.read_bytes()).hexdigest()
  if r['export_valid']:
   r['IMD3_dBc_per_tone']=[x['dbc_per_tone'] for x in m['measurement']['products'] if x['order']==3];r['fundamental_PEP_dB_raw_IQ']=m['measurement']['fundamental_pep_db_raw_iq'];r['independent_FFT']=json.loads((d/'independent-recheck.json').read_text())
 for rawname in ['two-tone-IQ.f32le','noise-IQ.f32le']:
  f=d/rawname
  if f.exists():
   raw=f.read_bytes();z=np.frombuffer(raw,dtype='<c8').astype(np.complex128);assert len(raw)==131072 and np.isfinite(z).all();power=abs(np.fft.fft(z))**2;freq=np.fft.fftfreq(len(z),1/48000)
   r['USB_IQ']={'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest(),'raw_RMS_envelope':float(np.sqrt(np.mean(abs(z)**2))),'raw_peak_envelope':float(abs(z).max()),'fraction_unwindowed_FFT_power_300_to3000_Hz':float(power[(freq>=300)&(freq<=3000)].sum()/power.sum()),'calibrated':False}
 reports[name]=r
assert sum(r['positive_GUI_key_actions'] for r in reports.values())==6
b=reports[names[4]];c=reports[names[5]];assert b['whole_harness_passed'] and c['whole_harness_passed'] and not b['correction_active'] and c['correction_active'];assert reports[names[3]]['native_SWR_above2_while_forward_above_half_W'] and not reports[names[3]]['whole_harness_passed']
comparison={'cases':reports,'native_10W_matched_comparison':{'IMD3_improvement_dB':[a-z for a,z in zip(b['IMD3_dBc_per_tone'],c['IMD3_dBc_per_tone'])],'corrected_minus_baseline_fundamental_PEP_dB_raw_IQ':c['fundamental_PEP_dB_raw_IQ']-b['fundamental_PEP_dB_raw_IQ'],'scope':'One finite pair on desktop1f1474067 and runtime43d1. Different source/operating point from the USB comparison; no endurance or5W success claim.'},'inference':'The tested positive-frequency USB noise, including a level above the0.5W telemetry condition, did not reproduce the native preamble stop. This narrows the comparison but does not prove whether PD mode, spectral width, two-sided complex-noise statistics, detector behavior or another difference causes the disputed reading.','no_guard_threshold_relaxation':True,'no_automatic_RF_retry_or_source_rearm':True}
(p/'comparison.json').write_text(json.dumps(comparison,indent=2)+'\n');print(json.dumps({'positive_keys':6,'whole_harness_passes':sum(x['whole_harness_passed'] for x in reports.values()),'preserved_5W_native_stop':True,'10W':comparison['native_10W_matched_comparison']},indent=2))
