"""Offline mathematical replay; no native code edits or radio commands."""
from pathlib import Path
import json
import numpy as np
p=Path(__file__).resolve().parent;rate=24000;n=4*rate;tap_count=127;peak=.7;gain=.57;lo=-4500;hi=7500
m=np.arange(tap_count)-(tap_count-1)/2;fc=(hi-lo)/2/rate;f0=(hi+lo)/2/rate;lp=2*fc*np.sinc(2*fc*m)*(.42-.5*np.cos(2*np.pi*np.arange(tap_count)/(tap_count-1))+.08*np.cos(4*np.pi*np.arange(tap_count)/(tap_count-1)));h=lp/lp.sum()*np.exp(2j*np.pi*f0*m)
def uniform(count):
 seed=12345;u=np.empty(count)
 for k in range(count):seed=(seed*1664525+1013904223)&0xffffffff;u[k]=((seed>>8)/16777216.)-.5
 return u
u=uniform(n);native=2*np.convolve(gain*peak*u,h)[:n];uv=uniform(2*n).reshape(-1,2);proper=2*np.convolve(gain*peak*(uv[:,0]+1j*uv[:,1])/np.sqrt(2),h)[:n]
def stats(z):
 raw_peak=float(abs(z).max());limited=int(np.count_nonzero(abs(z)>peak));z=z*np.minimum(1,peak/np.maximum(abs(z),1e-300));z=z[tap_count:];power=float(np.mean(abs(z)**2));mean_removed=z-z.mean()
 return {'RMS':float(np.sqrt(power)),'prelimit_peak':raw_peak,'limited_samples':limited,'circularity_magnitude':float(abs(np.mean(mean_removed**2))/np.mean(abs(mean_removed)**2)),'RMS_I':float(np.sqrt(np.mean(z.real**2))),'RMS_Q':float(np.sqrt(np.mean(z.imag**2))),'fraction_amplitude_below_0_02':float(np.mean(abs(z)<.02))}
r={'scope':'Algorithmic double-precision replay of the default native generator; not captured native TX IQ and not a byte-exact C execution. Prototype proper-complex variant is offline only.','native_source_reference':'tools/pd-waveform/pd_waveform.c:98,131-134,347-380,1604-1609','native_TX_rate_Hz':rate,'feedback_capture_rate_Hz':48000,'noise_samples':n,'band_Hz':[lo,hi],'peak':peak,'noise_gain':gain,'PRNG':'LCG32 seed12345;1664525*x+1013904223; upper24bits uniform−0.5','native_real_input_complex_bandpass':stats(native),'offline_proper_complex_input_same_bandpass_and_expected_variance':stats(proper),'interpretation':'The native wide band crosses zero. Its real-input complex filter preserves strong conjugate correlation where positive and negative bands overlap. Positive-frequency USB noise has different complex statistics as well as narrower spectrum, so its passed RF test cannot establish native-preamble behavior.','limits':['No assertion that circularity causes the SWR discrepancy.','No changed generator, package, scheduling, default or RF guard.','Any native source experiment still needs strict peak/RMS/spectrum/alignment tests and separately qualified on-radio RF.']}
(p/'preamble-replay.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
