"""Offline independent NumPy two-tone spectrum and meter statistics."""
from pathlib import Path
import json,hashlib
import numpy as np
p=Path(__file__).resolve().parent;events=json.loads((p/'events.json').read_text());outcome=json.loads((p/'outcome.json').read_text());raw=(p/'two-tone-IQ.f32le').read_bytes();assert len(raw)==131072
floats=np.frombuffer(raw,dtype='<f4').reshape(-1,2);assert np.isfinite(floats).all();iq=floats[:,0].astype('float64')+1j*floats[:,1].astype('float64');n=len(iq);phase=2*np.pi*np.arange(n)/(n-1);coeff=[.27105140069342,.43329793923448,.21812299954311,.06592544638803,.01081174209837,.00077658482522,.00001388721735];window=sum((-1)**k*a*np.cos(k*phase) for k,a in enumerate(coeff));freq=np.fft.fftfreq(n,1/48000);spectrum=abs(np.fft.fft(iq*window))**2
fund=[]
for offset in [710,1900]:
 mask=abs(freq-offset)<=25;bins=np.flatnonzero(mask);peak=int(bins[np.argmax(spectrum[mask])]);assert abs(freq[peak]-offset)<5
 fund.append({'offset_Hz':offset,'peak_bin_Hz':float(freq[peak]),'integrated_windowed_power':float(spectrum[mask].sum())})
products=[]
for order,offsets in [(3,[-480,3090]),(5,[-1670,4280]),(7,[-2860,5470])]:
 for side,offset in enumerate(offsets):
  power=float(spectrum[abs(freq-offset)<=25].sum());products.append({'order':order,'offset_Hz':offset,'dBc_relative_to_same_side_fundamental':float(10*np.log10(power/fund[side]['integrated_windowed_power']))})
rows=[r for r in events if r['event']=='meters' and r['Flex']['watts']>.5];assert rows
lp=[json.loads(s) for s in (p/'lp100a-readings.jsonl').read_text().splitlines() if s.strip()];lprf=[r for r in lp if r['rf_present'] and r['power_w']>=.2];assert lprf
span=lambda a:{'minimum':min(a),'maximum':max(a)}
r={'passed':outcome['passed'],'positive_GUI_key_actions':outcome['positive_GUI_key_actions'],'mode':'USB, correction bypassed','nominal_W':5,'GUI_stop_after_intent_s':outcome['GUI_stop_after_intent_s'],'capture':outcome['capture_manifest'],'IQ_sha256':hashlib.sha256(raw).hexdigest(),'host_meter_observations_above_half_W':len(rows),'observations_are_not_unique_hardware_samples':True,'Flex_forward_W':span([r['Flex']['watts'] for r in rows]),'Flex_raw_SWR':span([r['Flex']['radio_reported_swr'] for r in rows]),'Flex_same_packet_directional_derived_SWR':span([r['Flex']['directional_power_derived_swr'] for r in rows]),'LP_peak_held_max_W':max(r['power_w'] for r in lp),'LP_SWR_with_RF':span([r['swr'] for r in lprf]),'IQ_raw_envelope_peak':float(abs(iq).max()),'FFT':{'implementation':'NumPy independent FFT','window':'7-term Blackman-Harris, coefficients matching SpectrumWindow.cpp','sample_rate_Hz':48000,'length':n,'integration_half_width_Hz':25,'fundamentals':fund,'products':products},'limits':['Single finite uncorrected USB test; no corrected RF or endurance claim.','The software audio peak ceiling matches the earlier carrier source; actual PA operating points, spectrum and mean powers differ.','This tests a two-tone USB envelope, not the native noise preamble or PD mode.','LP power is peak-held with forward/net configuration unknown; directional detector simultaneity is unproven.','IQ scale is uncalibrated. Spectral ratios are integrated windowed power relative to each side\'s fundamental; do not mix them with other analyzer definitions without matching methods.']}
(p/'analysis.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
