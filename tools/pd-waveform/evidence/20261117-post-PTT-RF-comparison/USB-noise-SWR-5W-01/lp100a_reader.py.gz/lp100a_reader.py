"""Read-only LP-100A telemetry via Flex USB passthrough; no RF/control verbs."""
import argparse,base64,json,math,re,select,socket,time
FRAME=re.compile(rb';([0-9]{1,7}\.[0-9]{2}),([0-9]{1,4}\.[0-9]),([0-9]{1,3}\.[0-9]),([0-5]),([A-Z0-9 /-]{6}),([0-2]),([0-2]),(-?[0-9]{1,3}\.[0-9]),([0-9]{1,3}\.[0-9]{2})')
class Parser:
 def __init__(self):self.buffer=b'';self.rejected=0
 def feed(self,data):
  self.buffer+=data
  if len(self.buffer)>4096:self.buffer=b'';self.rejected+=1;return []
  rows=[]
  while self.buffer:
   start=self.buffer.find(b';')
   if start<0:self.buffer=b'';break
   self.buffer=self.buffer[start:];m=FRAME.match(self.buffer)
   if m:
    self.buffer=self.buffer[m.end():];v=m.groups();power,z,phase,dbm,swr=[float(v[i]) for i in [0,1,2,7,8]]
    if not(0<=power<=100000 and 0<z<=9999.9 and 0<=phase<=180 and -150<=dbm<=100 and 1<=swr<=999.99):self.rejected+=1;continue
    rows.append({'power_w':power,'impedance_magnitude_ohm':z,'phase_magnitude_deg':phase,'alarm_selection':int(v[3]),'callsign':v[4].decode().rstrip(),'range':int(v[5]),'power_detection':{0:'average',1:'peak_hold',2:'fast'}[int(v[6])],'dbm':dbm,'swr':swr,'rf_present':power>=.05,'impedance_phase_swr_valid':power>=.05,'power_basis':'meter_configured_forward_or_net_unknown','voltage_rms_v':None,'current_rms_a':None,'raw_ascii':m.group().decode()})
    continue
   next_frame=self.buffer.find(b';',1)
   if next_frame>=0:self.buffer=self.buffer[next_frame:];self.rejected+=1;continue
   if len(self.buffer)>128:self.buffer=b'';self.rejected+=1
   break
  return rows

def read_meter(seconds=5,serial='ABBDMO0I'):
 if not 0<seconds<=900:raise ValueError('duration outside bound')
 if not re.fullmatch('[A-Za-z0-9]{1,32}',serial):raise ValueError('invalid cable identity')
 p=Parser();s=socket.create_connection(('192.168.50.100',4992),3);s.setblocking(False);buf=b'';seq=1;last_poll_ns=None;count=0;started=time.monotonic();next_poll=started+.4;deadline=started+seconds;configured=False
 def send(command):
  nonlocal seq
  # Only these two commands are generated, never caller text or RF verbs.
  message=('C%d|%s\n'%(seq,command)).encode();s.sendall(message);seq+=1
 send('sub usb_cable all')
 try:
  while time.monotonic()<deadline:
   now=time.monotonic()
   if now>=next_poll:
    if not configured:raise RuntimeError('USB passthrough readback missing or mismatched')
    last_poll_ns=time.monotonic_ns();send('usb_cable write '+serial+' base64 UA==');next_poll=now+.080
   readable,_,_=select.select([s],[],[],min(.020,max(0,deadline-time.monotonic())))
   if not readable:continue
   data=s.recv(16384)
   if not data:raise RuntimeError('radio API closed')
   buf+=data
   if len(buf)>65536:raise RuntimeError('oversized API line')
   while b'\n' in buf:
    line,buf=buf.split(b'\n',1);line=line.rstrip(b'\r')
    if line.startswith(b'R'):
     fields=line.split(b'|',2)
     if len(fields)<2 or int(fields[1],16):raise RuntimeError('radio API rejected read-only subscription/poll')
    marker=('|usb_cable '+serial+' ').encode()
    if marker not in line:continue
    fields=dict(v.split(b'=',1) for v in line.split(marker,1)[1].split() if b'=' in v)
    if b'type' in fields:
     expected={b'type':b'passthrough',b'enable':b'1',b'plugged_in':b'1',b'speed':b'115200',b'data_bits':b'8',b'parity':b'none',b'stop_bits':b'1',b'flow_control':b'none'}
     configured=all(fields.get(k)==v for k,v in expected.items())
     if not configured:raise RuntimeError('USB configuration changed')
    if b'data:base64' in fields:
     raw=base64.b64decode(fields[b'data:base64'],validate=True)
     for row in p.feed(raw):
      stamp=time.monotonic_ns();z=row['impedance_magnitude_ohm'];angle=math.radians(row['phase_magnitude_deg']);resistance=z*math.cos(angle);den=z*z+100*resistance+2500;rho2=(z*z-100*resistance+2500)/den if den>0 else 1;rho=math.sqrt(max(0,rho2));implied=(1+rho)/(1-rho) if rho<1 else None;row.update({'swr_implied_by_z_phase':implied,'coherent':implied is not None and abs(implied-row['swr'])<=.25});row['impedance_phase_swr_valid']=row['rf_present'] and row['coherent'];row.update({'host_monotonic_ns':stamp,'host_utc_ns':time.time_ns(),'milliseconds_since_latest_poll':(stamp-last_poll_ns)/1e6 if last_poll_ns else None});count+=1;yield row
 finally:s.close()
 if not count:raise RuntimeError('no complete meter readings')
 if p.rejected:raise RuntimeError('malformed meter responses: %d'%p.rejected)
if __name__=='__main__':
 a=argparse.ArgumentParser();a.add_argument('--seconds',type=float,default=5);args=a.parse_args()
 for reading in read_meter(args.seconds):print(json.dumps(reading),flush=True)
