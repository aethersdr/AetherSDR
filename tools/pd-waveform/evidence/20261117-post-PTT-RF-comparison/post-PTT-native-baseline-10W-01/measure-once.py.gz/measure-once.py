"""One ordinary-GUI10W bypass baseline key; independent bench observations; no retry/rearm."""
import hashlib,importlib.util,json,math,pathlib,subprocess,sys,time
ROOT=pathlib.Path(__file__).resolve().parent;BASE=ROOT.parent;W=BASE.parent/'aetherpd-source'
sys.path.insert(0,str(W/'tools'));from automation_probe import Bridge
from bench_meter_monitor import MeterMonitor
from bench_quality import CoherenceWindow
spec=importlib.util.spec_from_file_location('meter_watch',ROOT/'meter-watch.py');mw=importlib.util.module_from_spec(spec);spec.loader.exec_module(mw)
spec=importlib.util.spec_from_file_location('observer',ROOT/'bench-observer.py');obs=importlib.util.module_from_spec(spec);spec.loader.exec_module(obs)
assert not (ROOT/'events.json').exists(),'A named RF attempt cannot be repeated'
instance=json.loads((ROOT/'instance.json').read_text());b=Bridge(instance['socket']);events=[];start=time.monotonic();meter=None;lp=None;observer=None;key_intent=None;armed=False;session_owned=False;result={'passed':False,'positive_GUI_key_actions':0,'DSP_signals':[],'desktop_signals':[]};quality=CoherenceWindow()
def record(event,**kw):
 events.append({'event':event,'elapsed_s':round(time.monotonic()-start,3),'monotonic_ns':time.monotonic_ns(),**kw});(ROOT/'events.json').write_text(json.dumps(events,indent=2)+'\n')
def req(q):
 r=b.request(q,4);record('bridge',request=q,result=r);assert r.get('ok'),r;return r
def invoke(n,a='click',v=None):
 q={'cmd':'invoke','target':n,'action':a}
 if v is not None:q['value']=v
 return req(q)
def widgets():
 tree=b.request({'cmd':'dumpTree','target':'AetherPDMeasurementDialog'},4);assert tree.get('ok'),tree;out={}
 def walk(x):
  if isinstance(x,dict):
   if str(x.get('objectName','')).startswith('pdMeasure'):out[x['objectName']]={k:x[k] for k in ['value','enabled','toolTip'] if k in x}
   for child in x.get('children',[]):walk(child)
  elif isinstance(x,list):
   for child in x:walk(child)
 for root in tree.get('roots',[]):
  if root.get('objectName')=='AetherPDMeasurementDialog' and root.get('visible'):walk(root)
 return out
def enabled(n,seconds):
 end=time.monotonic()+seconds
 while True:
  x=widgets()
  if x.get(n,{}).get('enabled'):return x
  assert time.monotonic()<end,(n,x);time.sleep(.1)
def dispatch_ready(n,seconds):
 deadline=time.monotonic()+seconds
 while True:
  enabled(n,max(.1,deadline-time.monotonic()))
  reply=b.request({'cmd':'invoke','target':n,'action':'click'},4);record('preparatory_dispatch',target=n,result=reply)
  if reply.get('ok'):return reply
  assert reply.get('disabled') is True and time.monotonic()<deadline,reply
  time.sleep(.05)
def service(path='aetherpd/status'):
 p=subprocess.run([str(BASE/'first-iq-live/vault-v3'),path],capture_output=True,text=True,timeout=4)
 r=json.loads(p.stdout);record('service',path=path,result=r);assert r['http_status'] in (200,503),r;return r['body']
def statecheck():
 radio=req({'cmd':'get','model':'radio'})['radio'];tx=req({'cmd':'get','model':'transmit'})['transmit'];slices=req({'cmd':'get','model':'slices'})['slices'];pans=req({'cmd':'get','model':'pans'})['pans']
 assert radio['connected'] and not radio['transmitting'] and not radio['fullDuplex'] and radio['serial']=='2125-1213-8600-8895'
 assert tx['rfPower']==10 and tx['maxPowerLevel']==10 and not tx['apdEnabled']
 assert len(slices)==1 and slices[0]['mode']=='PD' and slices[0]['txSlice'] and slices[0]['frequency']==7.15 and slices[0]['txAntenna']=='ANT1' and slices[0]['rxAntenna']=='RX_A'
 assert len(pans)==1 and pans[0]['ownedByUs'] and pans[0]['rfGain']==0 and pans[0]['centerMhz']==7.15
 return pans[0]
try:
 prior=json.loads((BASE/'post-PTT-native-corrected-5W-01/events.json').read_text());assert time.monotonic_ns()-prior[-1]['monotonic_ns']>=31_000_000_000,'RF cooldown'
 who=req({'cmd':'whoami'});assert who['pid']==instance['pid'] and who['txAllowed']
 assert hashlib.sha256(pathlib.Path('/proc',str(who['pid']),'exe').read_bytes()).hexdigest()==instance['binary_sha256']
 pan=statecheck();gui=int(pan['clientHandle'],16)
 installation=service('aetherpd/installation');assert installation['installation_committed'] and installation['selected_release_blake2b_256']=='43d1c23b5ba4c7567d234650aa77e95dc4a096732087654de0b1228ca730d043'
 native=service();assert native['registered'] and not native['keyed'] and not native['correction_enabled'] and native['diagnostics']['version']==2
 binding=native['feedback_binding'];assert binding['valid'] and not binding['failed'] and binding['channel']==4 and binding['gui_handle']==gui and binding['transport']=='local_dax_iq'
 assert native['diagnostics']['alignment']['count']==native['diagnostics']['alignment_reset']['count']==0,'Cold-start requires no preceding alignment'
 session_owned=True
 meter=mw.MeterWatch();deadline=time.monotonic()+5
 while not meter.ready():assert time.monotonic()<deadline;time.sleep(.02)
 lp=MeterMonitor(ROOT);assert lp.ready()['power_w']==0;observer=obs.Observer();snap=observer.snapshot();assert snap['interlock']['state']=='READY' and snap['apd']['enable']=='0'
 metadata=req({'cmd':'get','model':'meters'})['meters']['all'];pins={(x['index'],x['name'],x['unit']) for x in metadata};assert {(4,'+13.8A','Volts'),(8,'FWDPWR','dBm'),(9,'REFPWR','dBm'),(10,'SWR','SWR'),(11,'PATEMP','degC')}<=pins
 invoke('pdMeasureDummyLoad','setChecked','true');invoke('pdMeasurePowerLimit','setValue',10)
 control=widgets();record('controls',widgets=control)
 assert float(control['pdMeasureTimeout']['value'])==10 and float(control['pdMeasureAverages']['value'])==4
 deadline=time.monotonic()+6
 while True:
  enabled('pdMeasureArm',max(.1,deadline-time.monotonic()))
  reply=b.request({'cmd':'invoke','target':'pdMeasureArm','action':'click'},4);record('arm_dispatch',result=reply)
  if reply.get('ok'):break
  assert reply.get('disabled') is True and time.monotonic()<deadline,reply
  time.sleep(.05)
 armed=True;deadline=time.monotonic()+8
 while True:
  native=service()
  record('arm_readback_widgets',widgets=widgets())
  if native.get('calibration_state')=='armed' and native.get('source_purpose')=='measurement':break
  assert time.monotonic()<deadline;time.sleep(.1)
 assert not native['keyed'] and native['measurement']['source_id']!='0000000000000000'
 dispatch_ready('pdMeasurePrepare',3);record('prepared_for_one_key',widgets=enabled('pdMeasureTransmit',5));statecheck()
 assert lp.require()['power_w']==0 and meter.check(time.monotonic_ns())['watts']<=.1
 record('operator_key_intent',frequency_MHz=7.15,nominal_W=10,configured_max_W=10,source_limit_s=8,noise_preamble_s=4,native_unkey_s=9,desktop_limit_s=10,LP_power_stop_W=12,LP_SWR_stop=1.5,LP_max_age_ms=500,Flex_directional_ratio_SWR_stop=2,production_guards_changed=False,LP_direct_guards_unchanged=True,LP_vector_comparison_is_quality_annotation_only=True,one_GUI_key_only=True)
 key_intent=time.monotonic();result['positive_GUI_key_actions']=1;invoke('pdMeasureTransmit');saw_tx=False;last_native=0;native_samples=[]
 while time.monotonic()-key_intent<10.5:
  snap=observer.snapshot();record('interlock',snapshot=snap);inter=snap['interlock'];radio=req({'cmd':'get','model':'radio'})['radio']
  assert radio['connected'] and not radio['fullDuplex'];saw_tx |= radio['transmitting'] or inter.get('state')=='TRANSMITTING'
  if inter.get('state') in ['TRANSMITTING','PTT_REQUESTED']:
   assert int(inter['tx_client_handle'],16)==gui and inter.get('source')=='SW' and not inter.get('reason')
  power=meter.check(int(key_intent*1e9));external=lp.require();record('independent_meters',Flex=power,LP=external)
  if time.monotonic()-last_native>=.15:
   native=service();last_native=time.monotonic();native_samples.append(native)
   assert native.get('registered') and native['diagnostics']['version']==2
   assert all(v==0 for v in native['faults'].values()),('Native transport fault',native['faults'])
   assert native['input_limited_samples']==0,('TX input limiting',native['input_limited_samples'])
  tones=native.get('calibration_state')=='running' and native.get('measurement',{}).get('tones',False)
  if tones and power['watts']>.5:record('LP_vector_quality_annotation',coherent=external.get('coherent'),raw_fields_not_validated_as_synchronous_with_peak_held_power_and_SWR=True)
  else:quality.reset()
  if saw_tx and inter.get('state')=='READY' and not radio['transmitting']:break
  time.sleep(.02)
 assert saw_tx,'No key observed'
 result['saw_key']=True;result['native_samples']=native_samples
except Exception as exc:
 result['failure']=type(exc).__name__+': '+str(exc)
 record('test_error',error=result['failure'])
finally:
 try:
  radio=req({'cmd':'get','model':'radio'})['radio']
  if radio['transmitting']:
   invoke('pdMeasureStop');req({'cmd':'key','action':'ptt','value':'off'})
  deadline=time.monotonic()+12
  while True:
   radio=req({'cmd':'get','model':'radio'})['radio'];state=widgets()
   if not radio['transmitting'] and not state.get('pdMeasureStop',{}).get('enabled'):break
   assert time.monotonic()<deadline,'Unkey or measurement retirement not confirmed';time.sleep(.1)
  result['radio_after']=radio;result['widgets_after']=state;result['native_after']=service();record('measurement_outcome',widgets=state,native=result['native_after'])
  if result.get('saw_key') and state.get('pdMeasureExport',{}).get('enabled'):
   path=ROOT/'measurement.json';assert not path.exists();invoke('pdMeasureExport');time.sleep(.3)
   invoke('pdMeasureExportDialog/fileTypeCombo','setCurrentIndex',0);invoke('pdMeasureExportDialog/fileNameEdit','setText',str(path));invoke('pdMeasureExportDialog/&Save');deadline=time.monotonic()+5
   while not path.exists():assert time.monotonic()<deadline;time.sleep(.1)
   data=json.loads(path.read_text());assert data['source']=='local-dax-iq' and data['raw_iq_format']=='f32le-iq-v1'
   assert not data.get('error'),data.get('error');assert 'measurement' in data,'No completed spectrum in this export';result['export_valid']=data['measurement']['valid'];result['export_correction_active']=data['correction_active'];result['export_sha256']=hashlib.sha256(path.read_bytes()).hexdigest()
   assert result['export_valid'] and not result['export_correction_active'];result['passed']='failure' not in result
  else:result.setdefault('failure','No completed GUI measurement export; preserve status and application log for diagnosis.')
  if state.get('pdMeasureCancelSource',{}).get('enabled'):invoke('pdMeasureCancelSource')
 except Exception as exc:
  import traceback
  result['cleanup_error']=type(exc).__name__+': '+str(exc);result['cleanup_traceback']=traceback.format_exc();result['passed']=False
 if lp:
  try:result['LP_idle_after']=lp.await_zero()
  except Exception as exc:result['LP_cleanup_error']=str(exc);result['passed']=False
  lp.close()
 if meter:
  (ROOT/'independent-meters.json').write_text(json.dumps({'port':meter.port,'replies':meter.replies,'rows':meter.rows},indent=2)+'\n');meter.close()
 if observer:record('observer_rows',rows=observer.rows);observer.close()
 try:
  log=b.request({'cmd':'log','action':'tail','value':'2000'},4);filtered=[x for x in log.get('events',[]) if x.get('cat')=='aether.waveform.measurement'];(ROOT/'application-log.json').write_text(json.dumps(filtered,indent=2)+'\n')
  if session_owned:
   invoke('pdStop');deadline=time.monotonic()+20
   while True:
    state=service()
    if state.get('state')=='stopped':break
    assert time.monotonic()<deadline,'Session stop not confirmed';time.sleep(.2)
   result['session_stopped']=True
 except Exception as exc:
  import traceback
  result['session_cleanup_error']=type(exc).__name__+': '+str(exc);result['session_cleanup_traceback']=traceback.format_exc();result['passed']=False
 b.close();(ROOT/'outcome.json').write_text(json.dumps(result,indent=2)+'\n');print(json.dumps({k:v for k,v in result.items() if k not in ['native_samples','native_after','widgets_after','radio_after']},indent=2),flush=True)
