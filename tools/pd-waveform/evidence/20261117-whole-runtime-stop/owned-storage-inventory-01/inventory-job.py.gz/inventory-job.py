import hashlib,json,os,stat
from pathlib import Path
report={'case':'owned_storage_metadata_inventory','passed':False,'RF_commands':[],'changes':[],'file_contents_exported':False}
def tree(root):
 rows=[];stack=[(root,0)];allocated=0;logical=0
 while stack:
  directory,depth=stack.pop();assert depth<10
  with os.scandir(directory) as scan:
   for entry in scan:
    assert len(rows)<1024
    p=Path(entry.path);s=entry.stat(follow_symlinks=False);assert len(str(p.relative_to(root)))<512
    kind='directory' if stat.S_ISDIR(s.st_mode) else 'regular' if stat.S_ISREG(s.st_mode) else 'symlink' if stat.S_ISLNK(s.st_mode) else 'other'
    rows.append({'path':str(p.relative_to(root)),'kind':kind,'size':s.st_size,'allocated_bytes':s.st_blocks*512,'uid':s.st_uid,'gid':s.st_gid,'mode':oct(stat.S_IMODE(s.st_mode)),'links':s.st_nlink})
    allocated+=s.st_blocks*512
    if kind=='regular':logical+=s.st_size
    if kind=='directory':stack.append((p,depth+1))
 return {'root':str(root),'entries':sorted(rows,key=lambda x:x['path']),'allocated_bytes_excluding_root_directory':allocated,'regular_file_logical_bytes':logical}
try:
 report['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert report['boot_id']=='65be86a7-fd98-4f16-ae62-505781cadb85'
 store=Path('/var/lib/smartsdr/aetherpd');run=Path('/run/aetherpd')
 assert (store/'upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('4e003424d8ea5c2d4046019b9e756bac530622812296c07bad36f6339e2d66e5')
 report['owner_config_sha256']=hashlib.sha256((store/'state/provision.json').read_bytes()).hexdigest();assert report['owner_config_sha256']=='d2e1df2b422811c47f68e2ec18440265960f6a6e2014df55033f46b14db79ed1'
 report['persistent']=tree(store);report['RAM_runtime']=tree(run)
 report['filesystems']={}
 for p in [store,run]:
  s=os.statvfs(p);report['filesystems'][str(p)]={'free_available_bytes':s.f_bavail*s.f_frsize,'total_bytes':s.f_blocks*s.f_frsize,'block_bytes':s.f_frsize,'free_available_inodes':s.f_favail}
 report['runtime_mount']=[line for line in Path('/proc/mounts').read_text().splitlines() if line.split()[1] in ['/run','/var/lib/smartsdr']]
 report['primary_paths']=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   if os.readlink(p/'exe')!='/run/aetherpd/bin/flex-tailnet-shim':continue
   groups=(p/'cgroup').read_text()
   if not groups.rstrip().endswith('/aetherpd-shim.service'):continue
   args=(p/'cmdline').read_bytes().rstrip(b'\0').decode('utf-8').split('\0');paths={}
   for key in ['-state','-run-dir']:
    i=args.index(key);value=args[i+1];assert value.startswith('/run/aetherpd/') or value.startswith('/var/lib/smartsdr/aetherpd/');paths[key]=value
   report['primary_paths'].append({'pid':int(p.name),'paths':paths})
  except (FileNotFoundError,ProcessLookupError):pass
 assert len(report['primary_paths'])==1
 report['persistent_state_allocated_bytes']=sum(x['allocated_bytes'] for x in report['persistent']['entries'] if x['path']=='state' or x['path'].startswith('state/'))
 report['RAM_tsnet_log_entries']=[x for x in report['RAM_runtime']['entries'] if '/tsnet/' in x['path'] and 'log' in x['path']]
 report['persistent_tsnet_log_entries']=[x for x in report['persistent']['entries'] if '/tsnet/' in x['path'] and 'log' in x['path']]
 report['passed']=True
except Exception as e:report['error']=type(e).__name__+': '+str(e)
print(json.dumps(report),flush=True)
