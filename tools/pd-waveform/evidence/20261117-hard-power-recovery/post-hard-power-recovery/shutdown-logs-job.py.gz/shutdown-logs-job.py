import json,os,re,subprocess,time
from pathlib import Path
report={'RF_commands':[],'changes':[],'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'commands':[]}
old='1225abd2-52c4-4716-af98-e789ebb0bff5'
def redact(text):
 text=re.sub(r'https?://[^\s\"<>]+','[redacted-url]',text)
 text=re.sub(r'(?i)Bearer\s+[^\s\"]+','Bearer [redacted]',text)
 text=re.sub(r'(?i)((?:auth_key|authkey|access_token|bearer_token|token)\s*[=:]\s*)[^\s\",}]+',r'\1[redacted]',text)
 return text

def run(name,args):
 try:
  result=subprocess.run(args,capture_output=True,text=True,timeout=10)
  data=redact(result.stdout+'\n'+result.stderr)
  report['commands'].append({'name':name,'argv':args,'exit':result.returncode,'output':data[-36000:],'output_truncated':len(data)>36000})
 except (OSError,subprocess.TimeoutExpired) as error:report['commands'].append({'name':name,'error':type(error).__name__+': '+str(error)})
ns=['/usr/bin/nsenter','--target','1','--cgroup']
run('available-boots',ns+['/usr/bin/journalctl','--list-boots','--no-pager','-n','8'])
run('old-boot-services',ns+['/usr/bin/journalctl','--boot='+old,'--no-pager','-n','250','-o','short-monotonic','-u','aetherpd-boot.service','-u','aetherpd-shim.service','-u','aetherpd-start@*.service','-u','flex6k-firmware.service','-u','systemd-reboot.service'])
run('old-boot-kernel',ns+['/usr/bin/journalctl','--boot='+old,'--no-pager','-k','-n','100','-o','short-monotonic'])
run('old-boot-tail',ns+['/usr/bin/journalctl','--boot='+old,'--no-pager','-n','160','-o','short-monotonic'])
run('current-system-state',ns+['/usr/bin/systemctl','show','aetherpd-boot.service','aetherpd-shim.service','aetherpd-start.socket','--property=Id,ActiveState,SubState,Result,MainPID,KillMode,SendSIGKILL,TimeoutStopUSec'])
report['journal_paths']={p:Path(p).exists() for p in ['/var/log/journal','/run/log/journal']}
report['pstore']=[]
p=Path('/sys/fs/pstore')
if p.is_dir():
 for file in sorted(p.iterdir())[:8]:
  if file.is_file():
   data=file.read_bytes()[:16000].decode('utf-8',errors='replace');report['pstore'].append({'name':file.name,'output':redact(data)})
print(json.dumps(report),flush=True)
