import hashlib,json,os,re,select,socket,subprocess,time
from pathlib import Path
report={'probe_complete':False,'RF_commands':[],'commands':[],'observations':[]};observer=None
expected={'pd-boot':'db8ea6f4cacab3976d7ba74b1327a8a46767d9ed7441fdbbbade3f22ef325444','flex-tailnet-shim':'ac4406e079ba86fa281a1986fe305537cacddac5f193a0b29804fe4a5e28eb10'}
ns=['/usr/bin/nsenter','--target','1','--cgroup','/usr/bin/systemctl']
def graph():
 out=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   exe=os.readlink(p/'exe')
   if '/aetherpd/' not in exe:continue
   f=dict(x.split(':',1) for x in (p/'status').read_text().splitlines() if ':' in x)
   out.append({'pid':int(p.name),'exe':exe,'uid':f['Uid'].strip(),'nnp':f['NoNewPrivs'].strip(),'caps':{k:f[k].strip() for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']},'cgroup':(p/'cgroup').read_text().splitlines(),'start_ticks':int((p/'stat').read_text().rsplit(')',1)[1].split()[19]),'sha256':hashlib.sha256((p/'exe').read_bytes()).hexdigest()})
  except (OSError,KeyError):pass
 return out

def alive(row):
 try:return int((Path('/proc')/str(row['pid'])/'stat').read_text().rsplit(')',1)[1].split()[19])==row['start_ticks']
 except OSError:return False

def state(unit):
 args=ns+['show','--property=Id,MainPID,ActiveState,SubState,ControlGroup,SendSIGKILL,KillMode,TimeoutStopUSec,FragmentPath',unit]
 result=subprocess.run(args,capture_output=True,text=True,timeout=3);assert result.returncode==0,result.stderr
 return dict(line.split('=',1) for line in result.stdout.splitlines() if '=' in line)
try:
 assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='65be86a7-fd98-4f16-ae62-505781cadb85'
 assert Path('/var/lib/smartsdr/aetherpd/upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('e0b73370e023a026fdd3ad7f1eb7ab3785b1d5324ea3f6c809024d5124e861e0')
 report['before']=graph();assert len(report['before'])==3
 wrappers=[r for r in report['before'] if Path(r['exe']).name=='pd-boot'];assert len(wrappers)==1;wrapper=wrappers[0]
 cohort=[r for r in report['before'] if r['cgroup']==wrapper['cgroup']];assert len(cohort)==2
 for row in cohort:
  assert row['uid'].split()==['78666']*4 and row['nnp']=='1' and not any(int(v,16) for v in row['caps'].values())
  assert row['sha256']==expected[Path(row['exe']).name]
 assert not any(line.split()[0]=='172.30.2.1' for line in Path('/proc/net/arp').read_text().splitlines()[1:])
 name=wrapper['cgroup'][0].rsplit('/',1)[1];assert re.fullmatch(r'aetherpd-start@[0-9]+-[0-9]+-78666\.service',name),name
 report['unit']=name;before=state(name);report['unit_before']=before
 assert before['Id']==name and before['MainPID']==str(wrapper['pid']) and before['ActiveState']=='active' and before['SubState']=='running' and before['SendSIGKILL']=='no' and before['KillMode']=='control-group'
 observer=socket.create_connection(('127.0.0.1',4992),2);observer.setblocking(False);observer.sendall(b'C1|sub tx all\n');buffer=b'';end=time.monotonic()+3;idle=None
 while time.monotonic()<end and idle is None:
  if not select.select([observer],[],[],.1)[0]:continue
  data=observer.recv(16384);assert data;buffer+=data;assert len(buffer)<131072
  while b'\n' in buffer:
   line,buffer=buffer.split(b'\n',1);text=line.decode('ascii').strip()
   if text.startswith('S') and '|interlock ' in text and '|interlock band ' not in text:
    f=dict(x.split('=',1) for x in text.split('|',1)[1].split()[1:] if '=' in x)
    if all(k in f for k in ['state','source','tx_client_handle','tx_allowed','reason']):
     assert f['state']=='READY' and not f['source'] and f['tx_client_handle']=='0x00000000' and f['tx_allowed']=='1' and not f['reason'];idle=f;break
 assert idle is not None;report['idle_before']=idle
 stamp=time.monotonic_ns();args=ns+['--no-block','stop',name];result=subprocess.run(args,capture_output=True,text=True,timeout=3)
 report['commands'].append({'argv':args,'exit':result.returncode,'monotonic_ns':stamp});assert result.returncode==0,result.stderr
 deadline=time.monotonic()+16
 while True:
  current=state(name);survivors=[r for r in cohort if alive(r)];report['observations'].append({'elapsed_ms':(time.monotonic_ns()-stamp)/1e6,'unit':current,'original_survivor_pids':[r['pid'] for r in survivors]})
  if not survivors and current['ActiveState'] in ['inactive','failed'] and current['MainPID']=='0':break
  assert time.monotonic()<deadline,'Idle session stop remains pending; no kill escalation requested';time.sleep(.1)
 report['retired_ms']=(time.monotonic_ns()-stamp)/1e6;report['after']=graph();assert len(report['after'])==1 and Path(report['after'][0]['exe']).name=='flex-tailnet-shim'
 assert not any(line.split()[0]=='172.30.2.1' for line in Path('/proc/net/arp').read_text().splitlines()[1:]);report['probe_complete']=True
except Exception as error:report['error']=type(error).__name__+': '+str(error)
finally:
 if observer:observer.close()
 print(json.dumps(report),flush=True)
