from pathlib import Path
import json,os,shutil,subprocess
root=Path('/home/jeremy/AetherSDR/build/aetherpd-source/tools/flex-tailnet-shim');out=Path(__file__).resolve().parent
cases=[('joined-generation','login.go','markJoined','if n.joinGen != gen || !n.cfg.PendingSignIn {','if !n.cfg.PendingSignIn {','^TestCredentialJoinedSaveCannotOverwriteReplacement$','old joined callback changed replacement identity'),('signout-transaction','node.go','forgetConfig','\tn.configMu.Lock()\n\tdefer n.configMu.Unlock()\n','','^TestCredentialJoinedSaveCannotRecreateSignedOutIdentity$','old join save recreated signed-out configuration'),('sharing-transaction','node.go','changeConfig','\tn.configMu.Lock()\n\tdefer n.configMu.Unlock()\n','','^TestCredentialSharingAndJoinRetainBothChanges$','sharing or joined state lost'),('replacement-transaction','login.go','replaceNode','\tn.configMu.Lock()\n\tdefer n.configMu.Unlock()\n','','^TestCredentialJoinedSaveCannotOverwriteReplacement$','old joined callback changed replacement identity'),('login-revalidation','login.go','Login','if !authorized {','if false && !authorized {','^TestCredentialLoginReadCannotOutliveRevocation$','delayed login authorization:'),('watcher-generation','login.go','setLoginState','if n.joinGen == gen {','if true {','^TestCredentialStaleWatchJoinDoesNotChangeReplacement$','old watcher changed successor state or ownership')]
cases.append(('current-login-generation','login.go','Login','if !current {','if false && !current {','^TestCredentialFailedReplacementDoesNotRejectCurrentOwner$','current owner lost authorization or received stale sign-in'))
results=[]
for name,file,method,before,after,pattern,expected in cases:
 d=out/('mutant-'+name);d.mkdir(exist_ok=False)
 for p in root.glob('*.go'):shutil.copy2(p,d/p.name)
 for f in ['go.mod','go.sum']:shutil.copy2(root/f,d/f)
 os.symlink(root/'vendor',d/'vendor',target_is_directory=True)
 p=d/file;s=p.read_text();a=s.index('func (n *Node) '+method+'(');b=s.find('\nfunc ',a+1);b=len(s) if b<0 else b;part=s[a:b];assert part.count(before)==1,(name,part.count(before));s=s[:a]+part.replace(before,after)+s[b:];p.write_text(s)
 env=os.environ.copy();env['GOCACHE']='/home/jeremy/AetherSDR/build/aetherpd-shim-integration/go-cache'
 cmd=['go','test','-mod=vendor','-race','-timeout=15s','-run',pattern,'-count=1','.']
 with (out/(name+'-mutant.log')).open('w') as log:r=subprocess.run(cmd,cwd=d,env=env,stdout=log,stderr=subprocess.STDOUT)
 log=(out/(name+'-mutant.log')).read_text();assert r.returncode==1 and expected in log and '[build failed]' not in log,(name,log[-2500:])
 results.append({'mutation':name,'test':pattern,'exit':r.returncode,'rejected':True,'expected_failure':expected});print(name,'rejected',flush=True)
(out/'mutation-results.json').write_text(json.dumps(results,indent=2)+'\n')
