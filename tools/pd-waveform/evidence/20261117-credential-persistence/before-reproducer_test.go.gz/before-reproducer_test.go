package main

import (
	"os"
	"runtime"
	"testing"
	"time"
)

func TestCredentialJoinSnapshotResurrectionReproducer(t *testing.T) {
	n := &Node{StateDir: t.TempDir(), RunDir: t.TempDir()}
	n.cfg = provisionConfig{TokenSHA256: sha256Hex("old-owner-fixture"), Hostname: "radio", PendingSignIn: true}
	if err := n.save(n.cfg); err != nil {
		t.Fatal(err)
	}
	// Delay the old save only after it has captured and changed the live flag.
	n.nativeConfigMu.Lock()
	done := make(chan struct{})
	go func() { n.markJoined(); close(done) }()
	deadline := time.Now().Add(3 * time.Second)
	for {
		n.mu.Lock()
		captured := !n.cfg.PendingSignIn
		n.mu.Unlock()
		if captured {
			break
		}
		if time.Now().After(deadline) {
			n.nativeConfigMu.Unlock()
			t.Fatal("join snapshot was not reached")
		}
		runtime.Gosched()
	}
	if err := n.SignOut("old-owner-fixture"); err != nil {
		n.nativeConfigMu.Unlock()
		t.Fatal(err)
	}
	if _, err := os.Stat(n.cfgPath()); !os.IsNotExist(err) {
		n.nativeConfigMu.Unlock()
		t.Fatal("signout did not remove configuration")
	}
	n.nativeConfigMu.Unlock()
	select {
	case <-done:
	case <-time.After(3 * time.Second):
		t.Fatal("delayed writer did not finish")
	}
	reloaded := &Node{StateDir: n.StateDir, RunDir: n.RunDir}
	if err := reloaded.load(); err != nil {
		t.Fatal(err)
	}
	if reloaded.checkToken("old-owner-fixture") {
		t.Fatal("revoked credential reappeared after delayed sign-in save and reload")
	}
}
