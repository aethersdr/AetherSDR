# Copyright (c) 2026 J.J. Boyd / KK7GWY 2026-10-23. SPDX-License-Identifier: MIT
# Make the IPv6 shim preload survive reboots -- SAFELY.
#
# The acceptance job installs the preload as a /run drop-in (current-boot only)
# behind a dead-man rollback, so a bad shim can never persist. To survive
# reboots we must write to /etc, which loses that safety net: a future firmware
# or glibc change that breaks the shim would make smartsdr.service fail on every
# boot (Restart=always => boot loop), recoverable only out of band.
#
# So instead of a hard "Environment=LD_PRELOAD=..." we override ExecStart with a
# wrapper that preloads the shim ONLY if it actually loads against the current
# runtime (canary: the shim preloaded into /usr/bin/python3 must start). If it
# does not load, smartsdr starts stock (IPv4-only) -- degraded, never bricked.
#
# Applies on the next smartsdr (re)start/reboot; it does NOT restart the running
# service, so an active session is preserved. Requires WORKDIR + EXPECTED_SHA256
# (native executor globals); the shim is WORKDIR/libnereus_ipv6.so.
import hashlib, json, os, pathlib, subprocess

assert os.geteuid() == 0
work = pathlib.Path(WORKDIR)                      # noqa: F821 (executor global)
src = work / 'libnereus_ipv6.so'
assert src.is_file(), 'libnereus_ipv6.so not provided to the job'
data = src.read_bytes()
sha = hashlib.sha256(data).hexdigest()
expected = globals().get('EXPECTED_SHA256')
assert expected and sha == expected, 'shim sha256 mismatch: %s' % sha

libdir = pathlib.Path('/usr/local/lib/nereus-smartsdr-ipv6')
libdir.mkdir(parents=True, exist_ok=True, mode=0o755)
lib = libdir / 'libnereus_ipv6.so'
wrapper = pathlib.Path('/usr/local/bin/nereus-smartsdr-launch')
ddir = pathlib.Path('/etc/systemd/system/smartsdr.service.d')
dropin = ddir / '90-nereus-ipv6.conf'
rundrop = pathlib.Path('/run/systemd/system/smartsdr.service.d/90-nereus-ipv6.conf')

wrapper_body = (
    '#!/bin/sh\n'
    '# Preload the IPv6 shim only if it loads against the current runtime; else\n'
    '# start stock SmartSDR. Prevents a boot loop if a firmware/glibc change\n'
    '# ever breaks the shim. Installed by host-smartsdr-persist.py.\n'
    'LIB=/usr/local/lib/nereus-smartsdr-ipv6/libnereus_ipv6.so\n'
    'if [ -f "$LIB" ] && LD_PRELOAD="$LIB" /usr/bin/python3 -c "" 2>/dev/null; then\n'
    '  export LD_PRELOAD="$LIB"\n'
    '  export NEREUS_IPV6_TCP_PORT=4992\n'
    '  export NEREUS_IPV6_UDP_PORTS=4991,4993\n'
    'fi\n'
    'exec /usr/bin/smartsdr\n'
)
dropin_body = '[Service]\nExecStart=\nExecStart=/usr/local/bin/nereus-smartsdr-launch\n'


def atomic_write(path, body, mode):
    tmp = path.with_name('.' + path.name + '.new')
    with tmp.open('w') as f:
        f.write(body); f.flush(); os.fsync(f.fileno())
    os.chmod(tmp, mode)
    os.replace(tmp, path)


# lib (binary) atomically
libtmp = libdir / '.libnereus_ipv6.so.new'
with libtmp.open('wb') as f:
    f.write(data); f.flush(); os.fsync(f.fileno())
os.chmod(libtmp, 0o755)
os.replace(libtmp, lib)

atomic_write(wrapper, wrapper_body, 0o755)
ddir.mkdir(parents=True, exist_ok=True, mode=0o755)
atomic_write(dropin, dropin_body, 0o644)

removed_run = rundrop.exists()
if removed_run:
    rundrop.unlink()
os.sync()

# Canary: does the shim preload cleanly right now? rc 0 => the wrapper will
# enable it on the next boot; nonzero => it would fall back to stock.
canary = subprocess.run(['/usr/bin/python3', '-c', ''],
                        env=dict(os.environ, LD_PRELOAD=str(lib)),
                        capture_output=True, text=True)
subprocess.run(['systemctl', 'daemon-reload'], check=True, timeout=25)
show = subprocess.run(['systemctl', 'show', 'smartsdr.service', '-p', 'ExecStart'],
                      capture_output=True, text=True, timeout=20)

print(json.dumps({
    'installed_lib': str(lib),
    'sha256': sha,
    'wrapper': str(wrapper),
    'dropin': str(dropin),
    'removed_run_dropin': removed_run,
    'preload_canary_rc': canary.returncode,
    'preload_canary_stderr': canary.stderr.strip()[:200],
    'execstart_next_boot': show.stdout.strip()[:300],
    'restarted': False,
    'note': 'persistent; engages on next smartsdr (re)start/reboot; running session preserved',
}))
