/* Build-side glibc back-compat for the in-radio shim.
 *
 * Newer toolchains (e.g. ARM GNU 14.x) ship glibc headers that unconditionally
 * redirect strtol() to __isoc23_strtol@GLIBC_2.38. The radio runs an older
 * glibc (SmartSDR 4.3.16 => ~2.36), so such a shim fails to preload:
 *   libc.so.6: version `GLIBC_2.38' not found (required by libnereus_ipv6.so)
 * and SmartSDR will not start under it.
 *
 * aarch64's glibc symbol baseline is GLIBC_2.17, so forcing strtol back to that
 * version keeps the shim loadable on any supported radio glibc. Guarded to
 * aarch64 so native (x86-64) builds/fixtures, whose strtol baseline is
 * GLIBC_2.2.5, are unaffected.
 */
#if defined(__aarch64__)
__asm__(".symver __isoc23_strtol, strtol@GLIBC_2.17");
#endif
