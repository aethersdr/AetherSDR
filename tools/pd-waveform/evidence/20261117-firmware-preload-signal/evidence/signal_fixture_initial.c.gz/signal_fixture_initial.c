#define _GNU_SOURCE
#include <dlfcn.h>
#include <fcntl.h>
#include <signal.h>
#include <sys/syscall.h>
#include <unistd.h>
static int nested = -1;
static volatile sig_atomic_t returned;
static void nested_close(int sig)
{
    (void)sig;
    static const char entered[] = "handler_entered\n";
    (void)syscall(SYS_write, STDOUT_FILENO, entered, sizeof(entered)-1);
    if (close(nested) == 0) { returned = 1; }
}
static void deadline(int sig)
{
    (void)sig;
    static const char expired[] = "deadline\n";
    (void)syscall(SYS_write, STDOUT_FILENO, expired, sizeof(expired)-1);
    _exit(124);
}
int main(void)
{
    struct sigaction on_signal = {.sa_handler = nested_close};
    struct sigaction on_alarm = {.sa_handler = deadline};
    sigemptyset(&on_signal.sa_mask); sigemptyset(&on_alarm.sa_mask);
    if (sigaction(SIGUSR1, &on_signal, 0) || sigaction(SIGALRM, &on_alarm, 0)) { return 70; }
    alarm(1);
    (void)close(-1);
    void (*arm)(int) = (void (*)(int))dlsym(RTLD_DEFAULT, "signal_probe_arm");
    if (!arm) { return 71; }
    nested = open("/dev/null", O_RDONLY);
    int first = open("/dev/null", O_RDONLY);
    if (nested < 0 || first < 0 || nested == first) { return 72; }
    arm(first);
    if (close(first) || !returned) { return 73; }
    alarm(0);
    static const char complete[] = "handler_returned\n";
    (void)syscall(SYS_write, STDOUT_FILENO, complete, sizeof(complete)-1);
    return 0;
}
