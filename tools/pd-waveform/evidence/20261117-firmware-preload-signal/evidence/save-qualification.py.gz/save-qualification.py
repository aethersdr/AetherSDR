from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile
P=Path(__file__).resolve().parent;E=P.parent;W=E.parent/'aetherpd-source';S=Path('/home/jeremy/agent-worktrees/c3957d44/flexipv6-build/src')
read=lambda p:json.loads(p.read_text());sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();assert base.startswith('71cfd2115')
roots={}
for label,path in [('metadata',P/'metadata-result.json'),('history',P/'history-result.json'),('initial_fixture',P/'signal-radio-result.json'),('fixture',P/'signal-radio-02/result.json')]:
 x=read(path);assert x['job_container_deleted'] and x['temporary_host_directory_deleted'];roots[label]={'exit':x['wait']['StatusCode'],'job_removed':True,'host_scratch_removed':True,'raw_receipt_sha256':sha(path)}
meta=json.loads(read(P/'metadata-result.json')['logs']);history=json.loads(read(P/'history-result.json')['logs']);fixture=json.loads(read(P/'signal-radio-02/result.json')['logs'])
assert meta['queries_complete'] and fixture['passed'] and roots['initial_fixture']['exit']==1 and "KeyError: 'WORKDIR'" in read(P/'signal-radio-result.json')['logs']
assert roots['fixture']['exit']==0 and len(fixture['results'])==2
control,test=fixture['results'];assert control['exit']==0 and 'handler_returned\n' in control['stdout'];assert test['exit']==124 and 'handler_entered\n' in test['stdout'] and 'handler_returned' not in test['stdout'] and 'deadline\n' in test['stdout']
assert all('admitted_uid78666_gid20_NNP1_caps0\n' in r['stdout'] for r in fixture['results'])
assert fixture['original_preload_sha256']==meta['existing_preload_files']['/usr/local/lib/nereus-smartsdr-ipv6/libnereus_ipv6.so']['sha256']=='c017fe655d6449dd7b9eba3a7d07e8d2b9b94402f6aa7e62d04a8aee62902e03'
assert any('/usr/local/lib/nereus-smartsdr-ipv6/libnereus_ipv6.so' in s for s in meta['firmware_preload_maps'])
assert meta['units']['inhibit-power-pic.service']['properties']['ActiveState']=='inactive' and meta['logs']['failed']['exit']==1 and 'No such boot ID' in meta['logs']['failed']['text']
final=read(P/'final-observation.json');assert final['installed']['aetherpd/status']['body']['state']=='stopped' and not final['radio']['radio']['transmitting'] and not final['radio']['radio']['fullDuplex']
sources=[S/'operator/README.md',S/'operator/native-rootfd-prefix.py.inc',S/'native-waveform/README.md',S/'shim/ipv6_shim.c',S/'shim/glibc217-compat.h',S/'shim/LICENSE',S/'shim/README.md',S/'deployment/host-smartsdr-persist.py',S/'host-reference/README.md']
source_meta={str(p):sha(p) for p in sources}
commands={'host':read(P/'signal-host-result.json')['commands'],'target':[['zig','cc','-target','aarch64-linux-gnu.2.17','-O2','-Wall','-Wextra','-Werror','signal_fixture.c','-ldl','-o','signal-fixture-arm64'],['zig','cc','-target','aarch64-linux-gnu.2.17','-O2','-Wall','-Wextra','-Werror','-shared','-fPIC','signal_hook.c','-o','signal-hook-arm64.so']],'zig':subprocess.check_output(['zig','version'],text=True).strip(),'target_pins':read(P/'signal-native-pins.json'),'fixture_source_sha256':{p.name:sha(p) for p in [P/'signal_fixture.c',P/'signal_hook.c']}}
(P/'build-receipt.json').write_text(json.dumps(commands,indent=2)+'\n')
report={'updated_utc':datetime.now(timezone.utc).isoformat(),'source_commit':base,'production_ready':False,'original_radio_hang_cause_proven':False,'original_software_reboot_qualified':False,
 'finding':'The separate Nereus native IPv6 preload, presently mapped by SmartSDR, deadlocks a nested close() from a signal handler when interrupted while its outer close() holds the state mutex.',
 'scope':'Deterministic fixture reproduces this behavior in the exact installed ARM64 shared library, in a separate capability-free UID78666/GID20/NNP1 process at nice19. No firmware signal handler or original reboot failure was reproduced.',
 'test_design':{'trigger':'A second test-only preload raises SIGUSR1 at the underlying-close boundary, after the IPv6 wrapper has taken its mutex. The handler closes a different /dev/null descriptor. Neither descriptor is a socket or firmware resource.','control':'Test hook without the IPv6 library; same handler returns.','timeout':'In-process one-second SIGALRM exits124 using _exit; parent has a separate three-second timeout. Observed result124 includes handler_entered and deadline, not a parent timeout.','privilege_admission':'Fixture itself verifies UID/eUID78666, GID/eGID20, all five capability sets zero and NoNewPrivs1 before arming the trigger.','actual_results':fixture['results'],'signal_target':'Only the fixture sends signals to itself; SmartSDR and AetherPD receive no signal.'},
 'installed_preload':{'path':'/usr/local/lib/nereus-smartsdr-ipv6/libnereus_ipv6.so','sha256':fixture['original_preload_sha256'],'firmware_PID_observed_before_test':meta['units']['smartsdr.service']['properties']['MainPID'],'mapped_paths':meta['firmware_preload_maps'],'file_metadata':meta['existing_preload_files'],'library_file_unchanged_through_fixture':True},
 'mechanism':{'available_MIT_source_sha256':source_meta[str(S/'shim/ipv6_shim.c')],'wrapper':'close() holds state_lock across next_close(); reentrant close() attempts that same normal mutex.','primary_references':[{'url':'https://man7.org/linux/man-pages/man7/signal-safety.7.html','supports':'POSIX requires close to be async-signal-safe.'},{'url':'https://man7.org/linux/man-pages/man3/pthread_mutex_init.3.html','supports':'Mutex operations are not async-signal-safe; reentrant mutex calls can deadlock.'}],'available_source_host_fixture':read(P/'signal-host-result.json')},
 'power_controller_observation':{'unit':meta['units']['inhibit-power-pic.service']['properties'],'unit_file':meta['PIC_unit_file']['text'],'PIC_only_current_history':history['PIC_only_history'],'firmware_power_history':history['firmware_power_history'],'interpretation':'The oneshot executes smartsdr --noreboot. Inactive status does not measure the PIC hardware state or undo a prior oneshot effect. Current retained logs report Initial Watchdog State: off at boot; no inference about its later value or the failed boot.','unit_origin':'Existing installed unit; vendor origin is asserted in the older experiment documentation but not independently established by this audit.'},
 'failed_boot_evidence':{'boot_id':'1225abd2-52c4-4716-af98-e789ebb0bff5','query':meta['logs']['failed'],'retained_boot_list':meta['boot_list'],'original_operator_observation':'Green LED, unresponsive network, long power-button hold ineffective; rear DC removal required.','original_AetherPD_reboot_command':'One radio reboot command; inspected script contains no PIC guard invocation.','conclusion':'Failed reboot remains failed. Missing previous-boot journal and lack of a firmware-side stack/signal trace prevent assigning cause to the preload, PIC, firmware, AetherPD or kernel.'},
 'native6000_source_audit':{'inspected_source_sha256':source_meta,'result':'Available operator transport explicitly follows /run/podman/podman.sock. No native6000 privilege-entry mechanism was identified in these inspected sources. This bounded search does not prove none exists.','operator_statement_retained':'The method was originally developed on6000; original native code/procedure pointer is still requested.','no_fallback_substitution':'LAN-host or DAX-audio alternatives in other research documents do not satisfy this on-radio local DAX IQ goal.'},
 'initial_harness_failure':{'exit':1,'cause':'First fixture job expected WORKDIR in environment; transport injects a Python global. It failed before fixture execution. Corrected attempt retained separately.','receipt':roots['initial_fixture']},
 'temporary_jobs':roots,'build_receipt':commands,'final_observation':final,'radio_service_changes':[],'firmware_preload_changes':[],'RF_commands':[],'reboot_commands':[],
 'next_action':'Await baseline preference and existing physical-recovery coordination before any firmware restart/reboot. Retain the preload unchanged in the meantime. Future trace must pin baseline preload identity/PIC unit metadata and current AetherPD generation before attributing a shutdown failure.',
 'limits':['No proposed or deployed IPv6-preload fix. No AetherPD package/source/runtime change in this test.','The forced signal timing is a legitimate close() reentrancy pattern, but vendor use of this pattern is unobserved. The demonstration does not establish causality of the operator-reported whole-radio hang.','No actual6300 privilege path or hardware qualification, RF/correction comparison, keyed fault/reboot qualification or complete P1-P10 release claim.','Guard state, watchdog log and library mapping are separate observations. No direct PIC/register/device reads or writes were performed.']}
artifacts={'LICENSE-AetherSDR':W/'LICENSE'}
for n in ('signal-fixture-arm64','signal-hook-arm64.so','signal-fixture-host','signal-hook-host.so','ipv6-host.so'):artifacts[n]=P/n
artifacts['installed-preload-reference/libnereus_ipv6.so']=S.parent/'libnereus_ipv6.so'
for p in sources:artifacts['external-MIT-source/'+str(p.relative_to(S))]=p
for p in P.iterdir():
 if p.is_file() and p.suffix in ('.c','.py','.json','.log'):artifacts['evidence/'+p.name]=p
for p in (P/'signal-radio-02').iterdir():
 if p.is_file() and p.suffix in ('.py','.json','.log'):artifacts['evidence/signal-radio-02/'+p.name]=p
archive=E/'firmware-preload-signal-components-v2.tar.gz'
pending=archive.with_name('.'+archive.name+'.pending')
with tarfile.open(pending,'w:gz') as t:
 for n,p in sorted(artifacts.items()):t.add(p,arcname=n,recursive=False)
manifest={n:sha(p) for n,p in artifacts.items()}
with tarfile.open(pending) as t:assert {m.name:hashlib.sha256(t.extractfile(m).read()).hexdigest() for m in t if m.isfile()}==manifest
pending.replace(archive)
am={'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(artifacts),'all_members_verified':True,'scope':'diagnostic fixture and MIT prototype reference only; not an AetherPD release, installer or deployed fix'}
(P/'artifact-archive.json').write_text(json.dumps(am,indent=2)+'\n');report['artifact_archive']=am
destination=W/'tools/pd-waveform/evidence/20261117-firmware-preload-signal';destination.mkdir(exist_ok=False);evidence={}
for n,p in sorted(artifacts.items()):
 if p.suffix not in ('.c','.h','.py','.json','.md','.log') and p.name!='LICENSE':continue
 target=destination/(n+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
 with target.open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(p.read_bytes())
 assert gzip.decompress(target.read_bytes())==p.read_bytes();evidence[str(target.relative_to(W))]=sha(target)
report['evidence_sha256']=evidence
(W/'tools/pd-waveform/FIRMWARE-PRELOAD-SIGNAL-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
planpath=E/'production-completion-plan-20261113.json';plan=read(planpath);plan['updated_utc']=report['updated_utc'];plan['last_goal_turn_classification']='progress';plan['firmware_preload_signal']=report
plan['next_action']='Resolve final bench firmware baseline preference for demonstrated separate IPv6 preload signal-close deadlock, preserving the failed radio reboot and no-causality finding. Do not restart firmware or reboot until existing physical recovery coordination is answered. Keep installed0d AetherPD unchanged. Continue originalP1-P10 work: original native6000 privilege entry/teammate probes, remaining credentials/platform/recovery and final RF/stockAPD/release gates. DeferredSWR scope remains unchanged.'
planpath.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'evidence_files':len(evidence),'artifact_archive':am,'exact_installed_preload_fixture_deadlock_reproduced':True,'original_radio_hang_cause_proven':False}))
