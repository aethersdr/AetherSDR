from pathlib import Path
import hashlib,json,os,subprocess
P=Path(__file__).resolve().parent;S=Path('/home/jeremy/agent-worktrees/c3957d44/flexipv6-build/src/shim')
commands=[['cc','-O2','-Wall','-Wextra','-Werror','-DSIGNAL_PROBE_HOST',str(P/'signal_fixture.c'),'-ldl','-o',str(P/'signal-fixture-host')],['cc','-O2','-Wall','-Wextra','-Werror','-shared','-fPIC',str(P/'signal_hook.c'),'-o',str(P/'signal-hook-host.so')],['cc','-O2','-Wall','-Wextra','-Werror','-shared','-fPIC','-include',str(S/'glibc217-compat.h'),str(S/'ipv6_shim.c'),'-ldl','-pthread','-o',str(P/'ipv6-host.so')]]
for c in commands:subprocess.run(c,check=True)
results=[]
for name,preload,code in [('control',str(P/'signal-hook-host.so'),0),('available_source',str(P/'ipv6-host.so')+':'+str(P/'signal-hook-host.so'),124)]:
 env=dict(os.environ,LD_PRELOAD=preload);r=subprocess.run([str(P/'signal-fixture-host')],env=env,capture_output=True,text=True,timeout=3)
 results.append({'case':name,'exit':r.returncode,'stdout':r.stdout,'stderr':r.stderr});assert r.returncode==code and 'handler_entered\n' in r.stdout
 assert ('handler_returned\n' in r.stdout)==(code==0)
report={'commands':commands,'results':results,'source_sha256':hashlib.sha256((S/'ipv6_shim.c').read_bytes()).hexdigest(),'radio_executed':False,'scope':'deterministic signal at the next-close boundary, available unmodified source rebuilt for host; not proof of the original firmware signal handler or radio hang'}
(P/'signal-host-result.json').write_text(json.dumps(report,indent=2)+'\n');print(json.dumps(report['results']))
