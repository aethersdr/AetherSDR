#define _GNU_SOURCE
#include <dlfcn.h>
#include <fcntl.h>
#include <signal.h>
#include <string.h>
#include <sys/syscall.h>
#include <unistd.h>
static int nested = -1;
static volatile sig_atomic_t returned;
static void nested_close(int sig)
{
    (void)sig;
    static const char entered[] = "handler_entered\n";
    (void)syscall(SYS_write, STDOUT_FILENO, entered, sizeof(entered)-1);
    if (close(nested) == 0) { returned = 1; }
}
static void deadline(int sig)
{
    (void)sig;
    static const char expired[] = "deadline\n";
    (void)syscall(SYS_write, STDOUT_FILENO, expired, sizeof(expired)-1);
    _exit(124);
}
static int admission(void)
{
#ifndef SIGNAL_PROBE_HOST
    if (getuid() != 78666 || geteuid() != 78666 || getgid() != 20 || getegid() != 20) { return 0; }
    char status[8192];
    int fd = open("/proc/self/status", O_RDONLY);
    if (fd < 0) { return 0; }
    ssize_t n = read(fd, status, sizeof(status)-1);
    close(fd);
    if (n <= 0 || n == (ssize_t)sizeof(status)-1) { return 0; }
    status[n] = 0;
    const char* names[] = {"\nCapInh:", "\nCapPrm:", "\nCapEff:", "\nCapBnd:", "\nCapAmb:", "\nNoNewPrivs:"};
    for (unsigned i = 0; i < 6; ++i) {
        const char* value = strstr(status, names[i]);
        if (!value) { return 0; }
        value += strlen(names[i]);
        while (*value == ' ' || *value == '\t') { ++value; }
        if (i == 5) {
            if (value[0] != '1' || value[1] != '\n') { return 0; }
        } else {
            unsigned digits = 0;
            while (*value == '0') { ++value; ++digits; }
            if (!digits || *value != '\n') { return 0; }
        }
    }
    static const char admitted[] = "admitted_uid78666_gid20_NNP1_caps0\n";
#else
    static const char admitted[] = "admitted_host_fixture\n";
#endif
    (void)syscall(SYS_write, STDOUT_FILENO, admitted, sizeof(admitted)-1);
    return 1;
}
int main(void)
{
    struct sigaction on_signal = {.sa_handler = nested_close};
    struct sigaction on_alarm = {.sa_handler = deadline};
    sigemptyset(&on_signal.sa_mask); sigemptyset(&on_alarm.sa_mask);
    if (sigaction(SIGUSR1, &on_signal, 0) || sigaction(SIGALRM, &on_alarm, 0)) { return 70; }
    alarm(1);
    if (!admission()) { return 74; }
    (void)close(-1);
    void (*arm)(int) = (void (*)(int))dlsym(RTLD_DEFAULT, "signal_probe_arm");
    if (!arm) { return 71; }
    nested = open("/dev/null", O_RDONLY);
    int first = open("/dev/null", O_RDONLY);
    if (nested < 0 || first < 0 || nested == first) { return 72; }
    arm(first);
    if (close(first) || !returned) { return 73; }
    alarm(0);
    static const char complete[] = "handler_returned\n";
    (void)syscall(SYS_write, STDOUT_FILENO, complete, sizeof(complete)-1);
    return 0;
}
