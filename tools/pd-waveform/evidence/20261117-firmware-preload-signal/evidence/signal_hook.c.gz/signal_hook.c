#define _GNU_SOURCE
#include <signal.h>
#include <sys/syscall.h>
#include <unistd.h>
static volatile sig_atomic_t armed;
static int selected = -1;
void signal_probe_arm(int fd) { selected = fd; armed = 1; }
int close(int fd)
{
    if (armed && fd == selected) {
        armed = 0;
        raise(SIGUSR1);
    }
    return (int)syscall(SYS_close, fd);
}
