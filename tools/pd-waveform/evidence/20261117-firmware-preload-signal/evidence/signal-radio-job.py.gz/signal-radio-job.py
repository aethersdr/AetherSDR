PINS={'signal-fixture-arm64': '482a93db31e15d58016ef88faca54b233b9e1480186cf239a775e7bdb300f703', 'signal-hook-arm64.so': 'b95272f85ef111e141d12f1e757ca4ae230785c355058f61ea35222ee57eb1d6'}
import hashlib,json,os,stat,subprocess,time
from pathlib import Path
P=Path(os.environ['WORKDIR']);LIB=Path('/usr/local/lib/nereus-smartsdr-ipv6/libnereus_ipv6.so');EXPECTED='c017fe655d6449dd7b9eba3a7d07e8d2b9b94402f6aa7e62d04a8aee62902e03'
def sha(p):
 h=hashlib.sha256()
 with p.open('rb') as f:
  while b:=f.read(65536):h.update(b)
 return h.hexdigest()
r={'scope':'own ordinary-user signal fixture only; no firmware/device/service operations','RF_commands':[],'reboot_commands':[],'service_mutations':[],'passed':False,'results':[]}
try:
 r['boot_id']=Path('/proc/sys/kernel/random/boot_id').read_text().strip();assert r['boot_id']=='65be86a7-fd98-4f16-ae62-505781cadb85'
 assert os.geteuid()==0 and LIB.stat().st_size<=1024*1024 and sha(LIB)==EXPECTED
 for tool in ('/usr/bin/setpriv','/usr/bin/nice','/usr/bin/env'):assert Path(tool).is_file()
 r['original_preload_sha256']=EXPECTED
 for n,h in PINS.items():
  p=P/n;st=p.lstat();assert stat.S_ISREG(st.st_mode) and st.st_uid==0 and st.st_nlink==1 and sha(p)==h;p.chmod(0o555)
 P.chmod(0o711)
 for name,preload,expected in [('control',str(P/'signal-hook-arm64.so'),0),('installed_preload',str(LIB)+':'+str(P/'signal-hook-arm64.so'),124)]:
  cmd=['/usr/bin/setpriv','--reuid=78666','--regid=20','--clear-groups','--bounding-set=-all','--inh-caps=-all','--ambient-caps=-all','--no-new-privs','/usr/bin/nice','-n','19','/usr/bin/env','-i','LD_PRELOAD='+preload,str(P/'signal-fixture-arm64')]
  start=time.monotonic();p=subprocess.run(cmd,env={'PATH':'/usr/bin:/bin'},capture_output=True,text=True,timeout=3)
  row={'case':name,'argv':cmd,'exit':p.returncode,'elapsed_s':time.monotonic()-start,'stdout':p.stdout,'stderr':p.stderr};r['results'].append(row)
  assert p.returncode==expected and 'admitted_uid78666_gid20_NNP1_caps0\n' in p.stdout and 'handler_entered\n' in p.stdout
  assert ('handler_returned\n' in p.stdout)==(expected==0)
  assert ('deadline\n' in p.stdout)==(expected==124)
 assert sha(LIB)==EXPECTED and Path('/proc/sys/kernel/random/boot_id').read_text().strip()==r['boot_id']
 r['passed']=True
except Exception as e:r['error']=type(e).__name__+': '+str(e)
finally:print(json.dumps(r),flush=True)
