import hashlib,json,os,re,select,subprocess,time
from pathlib import Path
BASE=['/usr/bin/nsenter','--target','1','--cgroup']
def redact(s):
 s=re.sub(r'(?i)https?://[^\s"<>]+','[redacted-url]',s)
 s=re.sub(r'(?i)\bbearer[ \t]+[^\s",;}]+','Bearer [redacted]',s)
 return re.sub(r'(?i)(\b(?:[a-z0-9]+_)*(?:token|authkey|auth_key|password|secret|authorization)\b["\x27]?\s*[=:]\s*)(?:"(?:\\.|[^"\\])*"|\x27[^\x27]*\x27|[^\s,;}]+)',r'\1[redacted]',s)
def query(args,limit=65536,seconds=6):
 child=subprocess.Popen(BASE+args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 data=bytearray();deadline=time.monotonic()+seconds;bounded=True;why=None
 try:
  while True:
   if time.monotonic()>=deadline:bounded=False;why='deadline';break
   if not select.select([child.stdout],[],[],min(.1,max(.001,deadline-time.monotonic())))[0]:continue
   part=os.read(child.stdout.fileno(),min(4096,limit+1-len(data)))
   if not part:break
   data.extend(part)
   if len(data)>limit:bounded=False;why='output limit';break
 finally:
  if not bounded and child.poll() is None:child.terminate()
  try:child.wait(timeout=2)
  except subprocess.TimeoutExpired:child.kill();child.wait(timeout=2)
  child.stdout.close()
 return {'argv':args,'exit':child.returncode,'complete':bounded,'refusal':why,'text':redact(data[:limit].decode(errors='replace'))}
boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
r={'scope':'additional read-only current-boot PIC/shutdown history; no state changes','boot_id':boot,'RF_commands':[],'reboot_commands':[],'service_mutations':[]}
r['PIC_only_history']=query(['/usr/bin/journalctl','--boot='+boot.replace('-',''),'--unit=inhibit-power-pic.service','--lines=64','--no-pager','--output=json'],131072)
r['firmware_power_history']=query(['/usr/bin/journalctl','--boot='+boot.replace('-',''),'--unit=smartsdr.service','--grep=PIC|[Pp]ower|[Rr]eboot|[Ss]hutdown','--lines=64','--no-pager','--output=json'],131072)
r['firmware_start_metadata']=query(['/usr/bin/systemctl','show','--property=Id,MainPID,ExecMainStartTimestamp,ExecMainStartTimestampMonotonic,ActiveEnterTimestamp,ActiveEnterTimestampMonotonic,InvocationID','smartsdr.service'])
print(json.dumps(r),flush=True)
