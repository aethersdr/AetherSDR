import hashlib,json,os,re,select,subprocess,time
from pathlib import Path
BASE=['/usr/bin/nsenter','--target','1','--cgroup']
def redact(s):
 s=re.sub(r'(?i)https?://[^\s"<>]+','[redacted-url]',s)
 s=re.sub(r'(?i)\bbearer[ \t]+[^\s",;}]+','Bearer [redacted]',s)
 return re.sub(r'(?i)(\b(?:[a-z0-9]+_)*(?:token|authkey|auth_key|password|secret|authorization)\b["\x27]?\s*[=:]\s*)(?:"(?:\\.|[^"\\])*"|\x27[^\x27]*\x27|[^\s,;}]+)',r'\1[redacted]',s)
def query(args,limit=65536,seconds=6):
 child=subprocess.Popen(BASE+args,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 data=bytearray();deadline=time.monotonic()+seconds;bounded=True;why=None
 try:
  while True:
   if time.monotonic()>=deadline:bounded=False;why='deadline';break
   if not select.select([child.stdout],[],[],min(.1,max(.001,deadline-time.monotonic())))[0]:continue
   part=os.read(child.stdout.fileno(),min(4096,limit+1-len(data)))
   if not part:break
   data.extend(part)
   if len(data)>limit:bounded=False;why='output limit';break
 finally:
  if not bounded and child.poll() is None:child.terminate()
  try:child.wait(timeout=2)
  except subprocess.TimeoutExpired:child.kill();child.wait(timeout=2)
  child.stdout.close()
 return {'argv':args,'exit':child.returncode,'complete':bounded,'refusal':why,'text':redact(data[:limit].decode(errors='replace'))}
units=['inhibit-power-pic.service','smartsdr.service','finalize-upgrade.service','systemd-reboot.service','aetherpd-shim.service','aetherpd-boot.service','aetherpd-start.socket']
properties='Id,LoadState,ActiveState,SubState,MainPID,Result,ExecMainCode,ExecMainStatus,ActiveEnterTimestamp,InactiveEnterTimestamp,ExecStart,ExecStop,ExecStopPost,DefaultDependencies,Before,After,StopWhenUnneeded,KillMode,SendSIGKILL,TimeoutStopUSec,RemainAfterExit,FragmentPath,DropInPaths,TriggeredBy,Triggers'
r={'scope':'read-only power-controller, existing firmware preload and shutdown metadata; no device access or mutation','RF_commands':[],'reboot_commands':[],'service_mutations':[],'boot_id':Path('/proc/sys/kernel/random/boot_id').read_text().strip(),'units':{},'logs':{}}
for n in units:
 q=query(['/usr/bin/systemctl','show','--property='+properties,n]);q['properties']=dict(line.split('=',1) for line in q['text'].splitlines() if '=' in line);r['units'][n]=q
r['PIC_unit_file']=query(['/usr/bin/systemctl','cat','inhibit-power-pic.service'],16384)
r['boot_list']=query(['/usr/bin/journalctl','--list-boots','--no-pager','--output=json'],32768)
for label,boot in [('current',r['boot_id']),('failed','1225abd2-52c4-4716-af98-e789ebb0bff5')]:
 r['logs'][label]=query(['/usr/bin/journalctl','--boot='+boot.replace('-',''),'--unit=inhibit-power-pic.service','--unit=smartsdr.service','--lines=100','--no-pager','--output=json'],131072)
main=r['units']['smartsdr.service']['properties'].get('MainPID','0')
r['firmware_preload_maps']=[]
if main.isdecimal() and int(main)>1:
 with (Path('/proc')/main/'maps').open() as f:
  for line in f:
   if 'nereus' in line or 'socket_trace' in line:r['firmware_preload_maps'].append(line.strip())
paths=['/usr/local/bin/nereus-smartsdr-launch','/usr/local/lib/nereus-smartsdr-ipv6/libnereus_ipv6.so','/etc/systemd/system/smartsdr.service.d/90-nereus-ipv6.conf']
r['existing_preload_files']={}
for p in paths:
 path=Path(p)
 try:
  st=path.stat();h=hashlib.sha256()
  if st.st_size>4*1024*1024:r['existing_preload_files'][p]={'refused':'size bound','bytes':st.st_size};continue
  with path.open('rb') as f:
   while b:=f.read(65536):h.update(b)
  r['existing_preload_files'][p]={'bytes':st.st_size,'uid':st.st_uid,'gid':st.st_gid,'mode':oct(st.st_mode&0o7777),'sha256':h.hexdigest()}
 except OSError as e:r['existing_preload_files'][p]={'errno':e.errno}
r['queries_complete']=all(x['complete'] for x in [*r['units'].values(),r['PIC_unit_file'],r['boot_list'],*r['logs'].values()])
print(json.dumps(r),flush=True)
