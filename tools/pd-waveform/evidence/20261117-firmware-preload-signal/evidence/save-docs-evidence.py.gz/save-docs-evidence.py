from pathlib import Path
import gzip,hashlib,json
P=Path(__file__).resolve().parent;W=P.parents[1]/'aetherpd-source';report=W/'tools/pd-waveform/FIRMWARE-PRELOAD-SIGNAL-QUALIFICATION.json';r=json.loads(report.read_text());dest=W/'tools/pd-waveform/evidence/20261117-firmware-preload-signal'
assert '[SUCCESS] Generated static files' in (P/'docs-build.log').read_text()
for name in ('docs-install.log','docs-build.log','save-docs-evidence.py'):
 p=P/name;out=dest/('evidence/'+name+'.gz');out.parent.mkdir(exist_ok=True)
 with out.open('wb') as f:
  with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(p.read_bytes())
 r['evidence_sha256'][str(out.relative_to(W))]=hashlib.sha256(out.read_bytes()).hexdigest()
r['project_checks']={'docs_install':'npm ci, exit0','docs_build':'npm run build, exit0','shipping_code_changed':False}
report.write_text(json.dumps(r,indent=2)+'\n')
planpath=P.parent/'production-completion-plan-20261113.json';plan=json.loads(planpath.read_text());plan['firmware_preload_signal']=r;planpath.write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'evidence_files':len(r['evidence_sha256']),'radio_config_changes':0}))
