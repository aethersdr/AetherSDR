from pathlib import Path
import json,subprocess,sys
O=Path(__file__).resolve().parent;W=O.parents[1]/'aetherpd-source';S=W/'tools/pd-waveform/boot';T=W/'tools/pd-waveform/session';sys.path.insert(0,str(S));import build
real=subprocess.run;report={}
def execute(name,args,success=True):
 p=real(args,capture_output=True,text=True);(O/(name+'.log')).write_text(p.stdout+p.stderr);report[name]={'exit':p.returncode,'expected_success':success,'tail':(p.stdout+p.stderr)[-1600:]};print(name,p.returncode,flush=True);assert (p.returncode==0)==success,report[name]
source=(S/'pd_service.c').read_text()
for name,old,new,method in [
 ('missing-kernel-check','!service_processes_quiet(1,initial) || ','','test_prepare_rejects_hidden_kernel_member_before_reset'),
 ('collect-populated','state.quiet && !state.pid && !state.populated','state.quiet && !state.pid','test_prepare_preserves_populated_guardian_while_collecting_empty_record'),
 ('no-postcondition','if(!strcmp(selected.retire_names[i],fresh.retire_names[j])){return 0;}','if(0){return 0;}','test_prepare_requires_actual_reset_postcondition'),
 ('allow-global-reset','if(!selected.retire_count){return 1;}','','test_prepare_rechecks_before_reset_and_accepts_concurrent_collection')]:
 assert old in source;path=O/(name+'.c');path.write_text(source.replace(old,new))
 def wrapped(args,*a,**kw):return real([str(path) if str(x)==str(S/'pd_service.c') else x for x in args],*a,**kw)
 build.subprocess.run=wrapped
 try:exe=build.build(O/name,'host','service_check.c')
 finally:build.subprocess.run=real
 execute(name,[sys.executable,str(S/'test_service.py'),'--checker',str(exe),'ServiceTest.'+method],False)
base=['cc','-std=c11','-O2','-Wall','-Wextra','-Werror','-ffunction-sections','-fdata-sections','-Wl,--gc-sections','-I',str(T),'-I',str(S)]
execute('startup-build',base+[str(T/'start_session_test.c'),'-o',str(O/'startup-test')]);execute('startup-test',[str(O/'startup-test')])
s=(T/'pd_start_session.c').read_text();old='if(!pd_service_session_prepare()){return 6;}';assert old in s
path=O/'missing-pre-frame-prepare.c';path.write_text(s.replace(old,'if(0){return 6;}'))
f=O/'startup-mutant-test.c';f.write_text((T/'start_session_test.c').read_text().replace('#include "pd_start_session.c"','#include "'+str(path)+'"'))
execute('startup-mutant-build',base+[str(f),'-o',str(O/'startup-mutant')]);execute('startup-mutant',[str(O/'startup-mutant')],False)
(O/'mutations.json').write_text(json.dumps(report,indent=2)+'\n')
