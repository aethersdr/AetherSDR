from pathlib import Path
import concurrent.futures,json,subprocess,sys
O=Path(__file__).resolve().parent;W=O.parents[1]/'aetherpd-source';S=W/'tools/pd-waveform/boot'
sys.path.insert(0,str(S));import build
entries=['release_check.c','upgrade_check.c','generation_check.c','upgrade_transaction_check.c','service_activation_check.c']
def compile(entry):return entry,build.build(O/('regression-'+entry.removesuffix('.c')),'host',entry)
with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:programs=dict(pool.map(compile,entries))
report={}
runs=[('upgrade','test_upgrade.py',['--checker',str(programs['upgrade_check.c'])]),('generation','test_generation.py',['--checker',str(programs['generation_check.c']),'--upgrade-checker',str(programs['upgrade_check.c'])]),('upgrade-transaction','test_upgrade_transaction.py',['--checker',str(programs['upgrade_transaction_check.c'])]),('service-activation','test_service_activation.py',['--checker',str(programs['service_activation_check.c'])])]
for name,file,args in runs:
 p=subprocess.run([sys.executable,str(S/file),*args],capture_output=True,text=True)
 (O/(name+'-regression.log')).write_text(p.stdout+p.stderr)
 report[name]={'exit':p.returncode,'tail':(p.stdout+p.stderr)[-1200:]};print(name,p.returncode,flush=True)
 assert p.returncode==0,report[name]
for arch in ['arm64','armv7']:
 root=O.parent/'runtime-receive-reply-routing/short'/arch
 p=subprocess.run([str(programs['release_check.c']),str(root/'candidate.release'),str(root/'public-key'),'64' if arch=='arm64' else '7','1' if arch=='arm64' else '2','4.3.16.42034' if arch=='arm64' else '4.2.18.41174',str(root/'release-digest')],capture_output=True,text=True)
 report['signed-legacy-'+arch]={'exit':p.returncode,'tail':p.stdout+p.stderr};print('signed-legacy-'+arch,p.returncode,flush=True)
 assert p.returncode==0,report['signed-legacy-'+arch]
(O/'regressions.json').write_text(json.dumps(report,indent=2)+'\n')
