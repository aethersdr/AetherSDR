import hashlib,json,os,re,select,signal,socket,subprocess,time
from pathlib import Path
CONFIG=None
report={'case':'active_unkeyed_guardian_service_signals_then_unit_stop','probe_complete':False,'RF_commands':[],'reboot_commands':[],'commands':[],'observations':[]};observer=None
NS=['/usr/bin/nsenter','--target','1','--cgroup','/usr/bin/systemctl']
EXPECTED={'pd-boot':'db8ea6f4cacab3976d7ba74b1327a8a46767d9ed7441fdbbbade3f22ef325444','flex-tailnet-shim':'d864f65f74ad0def40126abb83ca848c469ebdfc4cb887026defde9b5e47a861','aether-pd':'b3fc2de87fb51a20721d53a3e0758c4206b29f4ccd6ad1b96e273400471cdf8d','pd-unkey-guard':'1663086c576cd08332a97c7c20771b3ee7653824c73c93e100c1583e4c88888f','pd-lease-guard':'297183f7504ffd6c9c6d9f4713976a2bcbfc1df5d9caa788c402fd8568c0954e','pd-fixed-arp':'2e6001780d2c8d42f2d422237cea7a4dcbc24d1ace9ee4aff7ee422a09072f49','pd-iq-source':'37fa974279793ccb0b4ee5891bc361a536d1cc917a12521ffe8d09781cc35ac0','pd-capture-bootstrap':'b3132499052fdb709c64fa0267171072299aae21fe0a970c0debc4648e40eccc'}
def graph():
 rows=[]
 for p in Path('/proc').iterdir():
  if not p.name.isdecimal():continue
  try:
   exe=os.readlink(p/'exe')
   if '/aetherpd/' not in exe:continue
   f=dict(line.split(':',1) for line in (p/'status').read_text().splitlines() if ':' in line)
   rows.append({'pid':int(p.name),'exe':exe,'state':f['State'].strip(),'uid':f['Uid'].split(),'nnp':f['NoNewPrivs'].strip(),'caps':{k:f[k].strip() for k in ['CapInh','CapPrm','CapEff','CapBnd','CapAmb']},'cgroup':(p/'cgroup').read_text().splitlines(),'start_ticks':int((p/'stat').read_text().rsplit(')',1)[1].split()[19]),'sha256':hashlib.sha256((p/'exe').read_bytes()).hexdigest()})
  except (OSError,KeyError):pass
 return rows

def alive(row):
 try:return int((Path('/proc')/str(row['pid'])/'stat').read_text().rsplit(')',1)[1].split()[19])==row['start_ticks']
 except OSError:return False

def state(unit):
 p=subprocess.run(NS+['show','--property=Id,MainPID,ActiveState,SubState,ControlGroup,KillMode,SendSIGKILL,TimeoutStopUSec',unit],capture_output=True,text=True,timeout=3);assert p.returncode==0
 return dict(line.split('=',1) for line in p.stdout.splitlines() if '=' in line)

def connect_idle():
 global observer
 if observer:observer.close()
 observer=socket.create_connection(('127.0.0.1',4992),2);observer.setblocking(False);observer.sendall(b'C1|sub tx all\nC2|sub slice all\n');buf=b'';end=time.monotonic()+4;idle=None;target=None
 while time.monotonic()<end:
  if not select.select([observer],[],[],.1)[0]:continue
  data=observer.recv(16384);assert data;buf+=data;assert len(buf)<262144
  while b'\n' in buf:
   line,buf=buf.split(b'\n',1);s=line.decode('ascii').strip()
   if not s.startswith('S') or '|' not in s:continue
   body=s.split('|',1)[1];f=dict(x.split('=',1) for x in body.split() if '=' in x)
   if body.startswith('interlock ') and not body.startswith('interlock band ') and all(k in f for k in ['state','source','tx_client_handle','tx_allowed','reason']):
    assert f['state']=='READY' and not f['source'] and f['tx_client_handle']=='0x00000000' and f['tx_allowed']=='1' and not f['reason'];idle=f
   if body.startswith('slice 0 ') and all(k in f for k in ['mode','client_handle','pan']):target=f
  if idle is not None and target is not None:return {'interlock':idle,'slice':target}
 raise RuntimeError('Fresh idle and slice snapshot absent')
try:
 assert Path('/proc/sys/kernel/random/boot_id').read_text().strip()=='65be86a7-fd98-4f16-ae62-505781cadb85'
 assert Path('/var/lib/smartsdr/aetherpd/upgrade-generation').read_bytes()==b'PDGEN001'+bytes.fromhex('4e003424d8ea5c2d4046019b9e756bac530622812296c07bad36f6339e2d66e5')
 report['firmware_before']=state('smartsdr.service');assert report['firmware_before']['ActiveState']=='active'
 report['before']=graph();dsps=[r for r in report['before'] if Path(r['exe']).name=='aether-pd'];assert len(dsps)==1;dsp=dsps[0]
 cohort=[r for r in report['before'] if r['cgroup']==dsp['cgroup']];assert len(cohort)==12
 primary=[r for r in report['before'] if r not in cohort];assert len(primary)==1
 for r in cohort:
  name=Path(r['exe']).name;assert r['sha256']==EXPECTED[name]
  if name in ['pd-fixed-arp','pd-capture-bootstrap']:
   assert r['uid']==['65534']*4
   assert {k:int(v,16) for k,v in r['caps'].items()}=={'CapInh':0,'CapPrm':4096 if name=='pd-fixed-arp' else 0,'CapEff':4096 if name=='pd-fixed-arp' else 0,'CapBnd':0,'CapAmb':0}
  else:assert r['uid']==['78666']*4 and r['nnp']=='1' and not any(int(v,16) for v in r['caps'].values())
 name=dsp['cgroup'][0].rsplit('/',1)[1];assert re.fullmatch(r'aetherpd-start@[0-9]+-[0-9]+-78666\.service',name);report['unit']=name;report['unit_before']=state(name)
 assert report['unit_before']['ActiveState']=='active' and report['unit_before']['SendSIGKILL']=='no' and report['unit_before']['KillMode']=='control-group'
 report['radio_before']=connect_idle();sl=report['radio_before']['slice'];assert sl['mode']=='PD' and int(sl['client_handle'],16)==CONFIG['gui_handle'] and int(sl['pan'],16)==CONFIG['feedback_pan']
 targets=[r for r in cohort if Path(r['exe']).name=='pd-unkey-guard']
 for row in cohort:
  if Path(row['exe']).name=='flex-tailnet-shim' and (Path('/proc')/str(row['pid'])/'cmdline').read_bytes().rstrip(b'\0').split(b'\0')[1:]==[b'--pd-receive-guardian']:targets.append(row)
 assert len(targets)==2
 report['guardian_signal_targets']=targets;report['guardian_signals']=[]
 for row in targets:
  fd=os.pidfd_open(row['pid'])
  try:
   assert alive(row)
   for sig in [signal.SIGTERM,signal.SIGINT]:
    signal.pidfd_send_signal(fd,sig);report['guardian_signals'].append({'pid':row['pid'],'start_ticks':row['start_ticks'],'signal':sig.name,'monotonic_ns':time.monotonic_ns()})
  finally:os.close(fd)
 time.sleep(.4)
 report['guardians_after_signals']=[row for row in graph() if any(row['pid']==target['pid'] and row['start_ticks']==target['start_ticks'] for target in targets)]
 assert len(report['guardians_after_signals'])==2 and all(row['state'].split()[0] in ['S','R'] for row in report['guardians_after_signals'])
 report['both_guardians_survived_live_owner_service_signals']=True
 stamp=time.monotonic_ns();args=NS+['--no-block','stop',name];p=subprocess.run(args,capture_output=True,text=True,timeout=3);report['commands'].append({'argv':args,'exit':p.returncode,'stamp_ns':stamp});assert p.returncode==0
 deadline=time.monotonic()+18
 while True:
  current=state(name);survivors=[r for r in cohort if alive(r)]
  report['observations'].append({'elapsed_ms':(time.monotonic_ns()-stamp)/1e6,'unit':current,'original_survivor_pids':[r['pid'] for r in survivors]})
  if not survivors and current['ActiveState'] in ['inactive','failed'] and current['MainPID']=='0':break
  assert time.monotonic()<deadline,'Stop incomplete; no kill escalation or firmware action';time.sleep(.05)
 report['retired_ms']=(time.monotonic_ns()-stamp)/1e6;report['after']=graph();assert len(report['after'])==1 and alive(primary[0])
 report['radio_after']=connect_idle();assert report['radio_after']['slice']['mode']=='USB'
 report['firmware_after']=state('smartsdr.service');assert report['firmware_after']['MainPID']==report['firmware_before']['MainPID'] and report['firmware_after']['ActiveState']=='active'
 report['ARP_after']=[l for l in Path('/proc/net/arp').read_text().splitlines()[1:] if l.split()[0]=='172.30.2.1'];assert not report['ARP_after']
 report['ARP_journal_bytes']=Path('/run/.aetherpd-fixed-arp.8600').stat().st_size;assert report['ARP_journal_bytes']==0
 report['accept_local']=Path('/proc/sys/net/ipv4/conf/eth0.10/accept_local').read_text().strip();assert report['accept_local']=='0'
 report['probe_complete']=True
except Exception as e:report['error']=type(e).__name__+': '+str(e)
finally:
 if observer:observer.close()
 print(json.dumps(report),flush=True)
