from pathlib import Path
import hashlib,json,re,subprocess,sys,time
sys.path.insert(0,'/home/jeremy/AetherSDR/build/aetherpd-source/tools')
from automation_probe import Bridge
OUT=Path(__file__).resolve().parent
assert not (OUT/'open-pending-intent.json').exists(), 'Inspect the existing one-shot attempt'
b=Bridge('/tmp/aetherpd-operation-epochs')
def req(q):
 r=b.request(q,8)
 if not r.get('ok'):raise RuntimeError('Bridge refused '+q['cmd'])
 return r
def walk(x):
 if isinstance(x,dict):
  yield x
  for key in ('roots','children'):
   for item in x.get(key,[]):yield from walk(item)
 elif isinstance(x,list):
  for item in x:yield from walk(item)
def root(name):
 return next((x for x in walk(req({'cmd':'dumpTree'})) if x.get('objectName')==name and x.get('visible')),None)
def safe_panel(name):
 r=root(name)
 if r is None:return {}
 wanted={'pdState','pdRemoteAccess','tsStatusLine','tsRefresh','tsDisconnect','tsDone'}
 return {x['objectName']:{k:re.sub(r'https?://\S+','<URL withheld>',str(x[k])) if isinstance(x[k],str) else x[k] for k in ('value','enabled','visible') if k in x} for x in walk(r) if x.get('objectName') in wanted}
def observe():
 p=subprocess.run([str(OUT.parent/'managed-remote-access-ui/credential-probe'),'login'],capture_output=True,text=True,timeout=35)
 if p.returncode!=0:raise RuntimeError('Credential observation failed')
 return json.loads(p.stdout)
def public():
 p=subprocess.run([str(OUT.parent/'first-iq-live/vault-v3'),'status'],capture_output=True,text=True,timeout=22)
 if p.returncode!=0:raise RuntimeError('Owner public status unavailable')
 return json.loads(p.stdout)['body']
def unkeyed():
 r=req({'cmd':'get','model':'radio'})['radio']
 assert r['connected'] and not r['transmitting'] and not r['fullDuplex'] and r['serial']=='2125-1213-8600-8895','Radio precondition changed'
 return r
before=observe();assert before['state']=='local' and not before['auth_url_present']
owner=public();assert owner['managed_owner_version']==1 and not owner['claimable'] and owner['state']=='local'
who=req({'cmd':'whoami'});assert who['pid']==json.loads((OUT/'instance.json').read_text())['pid']
radio=unkeyed()
req({'cmd':'invoke','target':'Waveforms...','action':'trigger'})
req({'cmd':'invoke','target':'openAetherPD','action':'click'})
end=time.monotonic()+20
while True:
 panel=safe_panel('AetherPDDialog')
 if panel.get('pdRemoteAccess',{}).get('enabled'):break
 assert time.monotonic()<end,'Remote Access entry did not enable'
 time.sleep(.25)
report={'passed':False,'radio_before':radio,'owner_before':owner,'login_before':before,'entry_before':panel,'RF_commands':[],'account_approval_requested':False}
(OUT/'open-pending-intent.json').write_text(json.dumps(report,indent=2)+'\n')
try:
 req({'cmd':'invoke','target':'pdRemoteAccess','action':'click'})
 end=time.monotonic()+50
 while time.monotonic()<end:
  unkeyed();current=public()
  assert current['installation_id']==owner['installation_id'] and not current['claimable'],'Managed owner boundary changed'
  assert current['state'] not in ('running','needs_approval') and not current['tailnet_ip'],'Account approval detected; do not cancel automatically'
  login=observe()
  if login['auth_url_present'] and login['state']=='needs_login':
   panel=safe_panel('TailnetShimDialog')
   if panel.get('tsDisconnect',{}).get('enabled'):break
  time.sleep(.25)
 else:raise RuntimeError('No pending managed sign-in observed')
 assert login['owner_verifier_fingerprint']==before['owner_verifier_fingerprint'],'Owner credential changed'
 view=root('TailnetShimDialog');shown=any(hashlib.sha256(url.encode()).hexdigest()==login['auth_url_sha256'] for x in walk(view) for url in re.findall(r'https://[^\s<>]+',str(x.get('value',''))))
 report.update(owner_pending=current,login_pending=login,pending_panel=panel,sign_in_link_matches_backend=shown)
 assert shown,'Sign-in link not observed in window'
 req({'cmd':'invoke','target':'tsDone','action':'click'})
 end=time.monotonic()+10
 while root('TailnetShimDialog') is not None:
  assert time.monotonic()<end,'Remote Access window did not close';time.sleep(.1)
 report['closed_while_sign_in_pending']=True
 req({'cmd':'invoke','target':'pdRemoteAccess','action':'click'})
 end=time.monotonic()+15
 while time.monotonic()<end:
  panel=safe_panel('TailnetShimDialog');view=root('TailnetShimDialog')
  shown=view is not None and any(hashlib.sha256(url.encode()).hexdigest()==login['auth_url_sha256'] for x in walk(view) for url in re.findall(r'https://[^\s<>]+',str(x.get('value',''))))
  if shown and panel.get('tsDisconnect',{}).get('enabled'):break
  time.sleep(.25)
 else:raise RuntimeError('Pending sign-in not resumed in reopened window')
 after=observe();assert after['auth_url_sha256']==login['auth_url_sha256'] and after['owner_verifier_fingerprint']==before['owner_verifier_fingerprint'],'Reopening replaced pending owner/sign-in'
 report.update(reopened_panel=panel,login_reopened=after,radio_after=unkeyed(),passed=True)
finally:
 (OUT/'open-pending-result.json').write_text(json.dumps(report,indent=2)+'\n');b.close()
print(json.dumps({'passed':True,'owner_preserved':True,'pending_code_resumed_without_replacement':True,'sign_in_link_matches_backend':True,'account_joined':False}),flush=True)
