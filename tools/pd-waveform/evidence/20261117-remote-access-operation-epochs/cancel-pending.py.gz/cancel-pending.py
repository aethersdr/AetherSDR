import hashlib,json,pathlib,re,subprocess,sys,time
P=pathlib.Path(__file__).resolve().parent;B=P.parent
sys.path.insert(0,str(B.parent/'aetherpd-source/tools'));from automation_probe import Bridge
assert not (P/'cancel-intent.json').exists(),'Inspect previous cancellation attempt'
prior=json.loads((P/'open-pending-result.json').read_text());assert prior['passed'];instance=json.loads((P/'instance.json').read_text());bridge=Bridge(instance['socket']);report={'passed':False,'RF_commands':[],'account_approval_requested':False}
def request(q):
 r=bridge.request(q,8);assert r.get('ok'),'Bridge request refused';return r
def walk(x):
 if isinstance(x,dict):
  yield x
  for key in ('roots','children'):
   for item in x.get(key,[]):yield from walk(item)
def view():return next((x for x in walk(request({'cmd':'dumpTree'})) if x.get('objectName')=='TailnetShimDialog' and x.get('visible')),None)
def observe(mode):
 command=[str(B/'managed-remote-access-ui/credential-probe'),'login'] if mode=='login' else [str(B/'first-iq-live/vault-v3'),'status']
 r=subprocess.run(command,capture_output=True,text=True,timeout=35);assert r.returncode==0,'Owner observation failed';d=json.loads(r.stdout);return d if mode=='login' else d['body']
def idle():
 r=request({'cmd':'get','model':'radio'})['radio'];assert r['connected'] and not r['transmitting'] and not r['fullDuplex'] and r['serial']=='2125-1213-8600-8895';return r
def control(name,action='click'):return request({'cmd':'invoke','target':name,'action':action})
try:
 assert request({'cmd':'whoami'})['pid']==instance['pid'];report['radio_before']=idle();before=observe('status');login=observe('login')
 assert before['state']=='needs_login' and not before['claimable'] and not before['tailnet_ip'] and before['installation_id']==prior['owner_before']['installation_id']
 assert login['owner_verifier_fingerprint']==prior['login_before']['owner_verifier_fingerprint'] and login['auth_url_sha256']==prior['login_pending']['auth_url_sha256']
 root=view();assert root is not None
 visible_match=any(x.get('visible') and hashlib.sha256(url.encode()).hexdigest()==login['auth_url_sha256'] for x in walk(root) for url in re.findall(r'https://[^\s<>]+',str(x.get('value',''))))
 assert visible_match,'Current sign-in link is not visibly shown'
 report['pending_link_visibly_matches_backend']=True
 report['owner_before']=before;report['login_before']=login;(P/'cancel-intent.json').write_text(json.dumps(report,indent=2))
 control('tsDisconnect');deadline=time.monotonic()+10
 while not any(x.get('objectName')=='tsDisconnectConfirmation' and x.get('visible') for x in walk(request({'cmd':'dumpTree'}))):
  assert time.monotonic()<deadline,'No cancel confirmation';time.sleep(.1)
 report['confirmation_observed']=True;control('tsConfirmDisconnect');deadline=time.monotonic()+45
 while True:
  idle();after=observe('status');login=observe('login')
  assert after['state'] not in ('running','needs_approval') and not after['tailnet_ip'],'External approval detected; do not alter it'
  if after['state']=='local' and login['state']=='local' and not login['auth_url_present']:break
  assert time.monotonic()<deadline,'Cancel did not return local';time.sleep(.25)
 assert after['installation_id']==before['installation_id'] and after['provisioned'] and not after['claimable'] and after['managed_owner_version']==1
 assert login['owner_verifier_fingerprint']==prior['login_before']['owner_verifier_fingerprint']
 # Observe several ordinary poll intervals without rejoining or revoking anything.
 snapshots=[];deadline=time.monotonic()+10
 while time.monotonic()<deadline:
  root=view();assert root is not None
  controls={x.get('objectName'):x for x in walk(root) if x.get('objectName') in ['tsStatusLine','tsRefresh','tsDisconnect']}
  assert not any(x.get('visible') and hashlib.sha256(url.encode()).hexdigest()==prior['login_pending']['auth_url_sha256'] for x in walk(root) for url in re.findall(r'https://[^\s<>]+',str(x.get('value','')))),'Canceled sign-in URL became visible again'
  snapshots.append({'monotonic_ns':time.monotonic_ns(),'controls':{n:{k:x[k] for k in ['value','enabled','visible'] if k in x} for n,x in controls.items()}})
  idle();time.sleep(.25)
 assert any('Local access ready' in x['controls'].get('tsStatusLine',{}).get('value','') for x in snapshots),'UI did not publish local owner state'
 report.update(owner_after=after,login_after=login,idle_poll_observations=snapshots,radio_after=idle(),passed=True)
 control('tsDone')
finally:
 (P/'cancel-result.json').write_text(json.dumps(report,indent=2)+'\n');bridge.close()
print(json.dumps({'passed':report['passed'],'same_owner_preserved':True,'no_stale_QR_across_ordinary_polls':True,'RF_commands':[]}))
