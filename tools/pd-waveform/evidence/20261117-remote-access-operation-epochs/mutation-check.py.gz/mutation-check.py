import hashlib,json,os,pathlib,subprocess
W=pathlib.Path('/home/jeremy/AetherSDR/build/aetherpd-source');E=W.parent/'aetherpd-shim-integration/remote-access-operation-epochs';B=E.parent/'first-install-desktop-monitor/project';core=W/'src/core/TailnetShimClient.cpp';ui=W/'src/gui/TailnetShimDialog.cpp';originals={core:core.read_text(),ui:ui.read_text()};env=dict(os.environ,CCACHE_DIR=str(E.parent/'first-install-desktop-monitor/ccache'));results=[]
def run(args,name):
 with (E/name).open('w') as f:return subprocess.run(args,cwd=W,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
mutants=[('reply-generation',core,'if (generation != m_replyGeneration)','if (false && generation != m_replyGeneration)','late mutating reply cannot publish'),('provision-generation',ui,'window && window->m_client.replyGeneration() == generation','window','late application-owned provision reply cannot undo'),('signout-response-kind',core,'if (operation == QLatin1String("signout"))','if (false && operation == QLatin1String("signout"))','confirmed sign-out has an operation-specific response')]
try:
 for name,path,needle,replacement,expected in mutants:
  for p,s in originals.items():p.write_text(s)
  assert needle in originals[path];path.write_text(originals[path].replace(needle,replacement))
  build=run(['cmake','--build',str(B),'--target','tailnet_shim_client_test','tailnet_shim_dialog_test','--parallel','4'],name+'-build.log');assert build==0,(name,'not a behavioral mutant')
  result=run(['ctest','--test-dir',str(B),'-R','^tailnet_shim_(client|dialog)_test$','--output-on-failure','--no-tests=error'],name+'-ctest.log');assert result==8 and expected in (E/(name+'-ctest.log')).read_text(),name
  results.append({'mutant':name,'build_exit':build,'ctest_exit':result,'expected_behavior_failure':expected});print(name+': expected behavioral failure',flush=True)
finally:
 for p,s in originals.items():p.write_text(s)
assert run(['cmake','--build',str(B),'--target','tailnet_shim_client_test','tailnet_shim_dialog_test','AetherSDR','--parallel','4'],'restored-build.log')==0
assert run(['ctest','--test-dir',str(B),'-R','^(tailnet_shim_(client|dialog)|aetherpd_dialog)_test$','--output-on-failure','--no-tests=error'],'restored-ctest.log')==0
(E/'mutations.json').write_text(json.dumps({'mutants':results,'restored_sha256':{str(p.relative_to(W)):hashlib.sha256(p.read_bytes()).hexdigest() for p in originals},'restored_full_app_and_three_tests_passed':True},indent=2)+'\n');print('Restored full app and3 tests passed.',flush=True)
