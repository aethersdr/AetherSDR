import hashlib,json,os,pathlib,subprocess
w=pathlib.Path('/home/jeremy/AetherSDR/build/aetherpd-source');out=w.parent/'aetherpd-shim-integration/credential-failure-correlation';b=out.parent/'first-install-desktop-monitor/project';source=w/'src/gui/TailnetShimDialog.cpp';original=source.read_text();prefix,body=original.split('void TailnetShimDialog::onRequestFailed(',1);env=dict(os.environ,CCACHE_DIR=str(out.parent/'first-install-desktop-monitor/ccache'));results=[]
def run(args,log):
 with (out/log).open('w') as f:return subprocess.run(args,cwd=w,env=env,stdout=f,stderr=subprocess.STDOUT).returncode
mutants=[('credential-context',"if (!credential.isEmpty() && credential !=", "if (false && !credential.isEmpty() && credential !=",'old authenticated failure cannot erase'),('managed-retention',"if (m_status && !m_status->installationId.isEmpty())", "if (false && m_status && !m_status->installationId.isEmpty())",'managed login401 reports rejected ownership'),('original-connection',"if (!current()) { return; }", "if (false && !current()) { return; }",'retired original connection cannot mutate')]
try:
 for name,needle,replacement,expected in mutants:
  assert needle in body;source.write_text(prefix+'void TailnetShimDialog::onRequestFailed('+body.replace(needle,replacement,1))
  build=run(['cmake','--build',str(b),'--target','tailnet_shim_dialog_test','--parallel','4'],name+'-build.log');assert build==0,(name,'compilation failed, not a valid behavioral mutant')
  status=run(['ctest','--test-dir',str(b),'-R','^tailnet_shim_dialog_test$','--output-on-failure','--no-tests=error'],name+'-ctest.log');assert status==8 and 'FAIL: '+expected in (out/(name+'-ctest.log')).read_text(),(name,'mutation did not fail the intended behavior')
  results.append({'mutant':name,'build_exit':build,'ctest_exit':status,'expected_behavior_failure':expected});print(name+': expected behavioral failure observed',flush=True)
finally:source.write_text(original)
assert hashlib.sha256(source.read_bytes()).hexdigest()==hashlib.sha256(original.encode()).hexdigest()
assert run(['cmake','--build',str(b),'--target','tailnet_shim_client_test','tailnet_shim_dialog_test','AetherSDR','--parallel','4'],'restored-build.log')==0
assert run(['ctest','--test-dir',str(b),'-R','^(tailnet_shim_(client|dialog)|aetherpd_dialog)_test$','--output-on-failure','--no-tests=error'],'restored-ctest.log')==0
(out/'mutations.json').write_text(json.dumps({'source_restored_sha256':hashlib.sha256(source.read_bytes()).hexdigest(),'mutants':results,'restored_build_and_three_tests_passed':True},indent=2)+'\n');print('Restored source, full app build and3 tests passed.',flush=True)
