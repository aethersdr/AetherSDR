from pathlib import Path
import subprocess,json,os
w=Path('/home/jeremy/AetherSDR/build/aetherpd-source');p=Path(__file__).resolve().parent;b=p.parent/'first-install-desktop-monitor/project';env=os.environ.copy();env['CCACHE_DIR']=str(p.parent/'first-install-desktop-monitor/ccache')
paths=[w/'src/models/AetherPDMeasurementModel.cpp',w/'src/models/RadioModel_TxCoordinator.cpp'];original={f:f.read_bytes() for f in paths};results=json.loads((p/'mutations.json').read_text()) if (p/'mutations.json').exists() else []
mutants=[('blanket-ownership',paths[0],'!m_radio->transmitConfigurationIdle()','m_radio->transmitOwnershipPending()'),('pending-cleanup',paths[1],'&& radioReceivingForTransmitDax() && m_pendingTxDeliveries == 0','&& radioReceivingForTransmitDax()'),('entered-writer',paths[1],'\n            && !m_txCoordinator.hasInFlightDispatches()','')]
def command(args,name):
 with (p/name).open('w') as out:return subprocess.run(args,cwd=w,env=env,stdout=out,stderr=subprocess.STDOUT).returncode
try:
 for name,f,old,new in mutants:
  if any(r['mutant']==name for r in results):continue
  s=original[f].decode();assert s.count(old)==1,(name,s.count(old));f.write_text(s.replace(old,new,1))
  try:
   build=command(['cmake','--build',str(b),'--target','tx_operation_integration_test','--parallel','4'],name+'-build.log');assert build==0,name
   test=command(['ctest','--test-dir',str(b),'-R','^tx_operation_integration_test$','--output-on-failure','--no-tests=error','--timeout','60'],name+'-ctest.log')
   failures=[x for x in (p/(name+'-ctest.log')).read_text().splitlines() if '[FAIL]' in x]
   results.append({'mutant':name,'build_exit':build,'ctest_exit':test,'behavior_failures':failures});assert test==8 and failures,name
  finally:f.write_bytes(original[f])
finally:
 for f,data in original.items():f.write_bytes(data)
 (p/'mutations.json').write_text(json.dumps(results,indent=2)+'\n')
assert len(results)==3
assert command(['cmake','--build',str(b),'--target','tx_operation_integration_test','aetherpd_dialog_test','AetherSDR','--parallel','4'],'restored-full-build.log')==0
assert command(['ctest','--test-dir',str(b),'-R','^(tx_operation_integration_test|aetherpd_dialog_test)$','--output-on-failure','--no-tests=error','--timeout','60'],'restored-ctest.log')==0
for f,data in original.items():assert f.read_bytes()==data
print(json.dumps({'mutations_observed':results,'restored_full_build_and_tests':True}),flush=True)
