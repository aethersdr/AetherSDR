"""Offline carrier statistics; no connections or radio control."""
from pathlib import Path
import json,hashlib,sys
import numpy as np
p=Path(sys.argv[1]);events=json.loads((p/'events.json').read_text());outcome=json.loads((p/'outcome.json').read_text())
observations=[x for x in events if x['event']=='meters' and x['Flex']['watts']>.5]
assert observations and len((p/'carrier-IQ.f32le').read_bytes())==131072
raw=np.fromfile(p/'carrier-IQ.f32le',dtype='<f4').reshape(-1,2);assert np.isfinite(raw).all();iq=raw[:,0].astype('float64')+1j*raw[:,1].astype('float64')
coeff=[.27105140069342,.43329793923448,.21812299954311,.06592544638803,.01081174209837,.00077658482522,.00001388721735];n=len(iq);phase=2*np.pi*np.arange(n)/(n-1);window=sum((-1)**k*a*np.cos(k*phase) for k,a in enumerate(coeff));freq=np.fft.fftfreq(n,1/48000);power=abs(np.fft.fft(iq*window))**2
peak=float(freq[power.argmax()]);assert abs(peak-710)<5
lp=[json.loads(line) for line in (p/'lp100a-readings.jsonl').read_text().splitlines() if line.strip()];rf=[r for r in lp if r['rf_present'] and r['power_w']>=.2]
def span(values):return {'minimum':min(values),'maximum':max(values)}
r={'positive_GUI_key_actions':outcome['positive_GUI_key_actions'],'original_harness_passed':outcome['passed'],'capture':outcome['capture_manifest'],'IQ_sha256':hashlib.sha256((p/'carrier-IQ.f32le').read_bytes()).hexdigest(),'host_meter_observations_above_half_W':len(observations),'observations_are_not_unique_hardware_samples':True,'Flex_forward_W':span([r['Flex']['watts'] for r in observations]),'Flex_raw_SWR':span([r['Flex']['radio_reported_swr'] for r in observations]),'Flex_same_packet_directional_derived_SWR':span([r['Flex']['directional_power_derived_swr'] for r in observations]),'LP_peak_held_max_W':max(r['power_w'] for r in lp),'LP_SWR_with_RF':span([r['swr'] for r in rf]),'IQ_raw_envelope_peak':float(abs(iq).max()),'IQ_peak_bin_Hz':peak,'limits':['LP power is peak-held, with meter forward/net configuration unknown.','Directional powers arrive in the same packet; detector measurement simultaneity is not established.','IQ amplitude is uncalibrated: no RX ADC full-scale/headroom claim.','One bypassed USB carrier does not isolate modulation from the PD-mode difference or qualify corrected RF.']}
(p/'carrier-analysis.json').write_text(json.dumps(r,indent=2)+'\n');print(json.dumps(r,indent=2))
