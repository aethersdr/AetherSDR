import sys,json,time,subprocess
from pathlib import Path
p=Path(__file__).resolve().parent;e=p.parent
sys.path.insert(0,str(e.parent/'aetherpd-source/tools'));from automation_probe import Bridge
assert not (p/'stop-predecessor-result.json').exists()
b=Bridge('/tmp/aetherpd-operation-epochs');r={'RF_commands':[]}
r['identity']=b.request({'cmd':'whoami'},5);assert r['identity']['pid']==3744797
for m in ['radio','transmit']:r[m]=b.request({'cmd':'get','model':m},5)
assert r['radio']['radio']['connected'] and not r['radio']['radio']['transmitting'] and not r['transmit']['transmit']['mox'] and not r['transmit']['transmit']['tuning']
r['native_before']=json.loads(subprocess.run([str(e/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=20).stdout)
assert not r['native_before']['body'].get('keyed') and r['native_before']['body'].get('calibration_state')=='idle'
r['close']=b.request({'cmd':'close','target':'AetherPDMeasurementDialog'},5)
r['stop']=b.request({'cmd':'invoke','target':'pdStop','action':'click'},5);assert r['stop']['ok']
end=time.monotonic()+25;observed=[]
while True:
 q=json.loads(subprocess.run([str(e/'first-iq-live/vault-v3'),'aetherpd/status'],capture_output=True,text=True,timeout=20).stdout);observed.append(q)
 if q['http_status']==200 and q['body'].get('state')=='stopped':break
 assert time.monotonic()<end,q;time.sleep(.2)
r['stop_observations']=observed;r['radio_after']=b.request({'cmd':'get','model':'radio'},5);assert not r['radio_after']['radio']['transmitting'];r['passed']=True
(p/'stop-predecessor-result.json').write_text(json.dumps(r,indent=2)+'\n');b.close();print(json.dumps({'passed':True,'service_stopped':True,'radio_idle':True,'RF_commands':[]}))
