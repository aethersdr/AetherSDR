from pathlib import Path
import datetime,gzip,hashlib,json,os,re
out=Path(__file__).resolve().parent;base=out.parent;w=Path('/home/jeremy/AetherSDR/build/aetherpd-source');now=datetime.datetime.now(datetime.timezone.utc).isoformat()
r=json.loads((out/'report.json').read_text());old=json.loads((base/'runtime-alignment-reset-retention/report.json').read_text());budget=json.loads((out/'budget-report.json').read_text());assert r['source_commit']=='7b7f6a15126f6fecbef55aeed3a746b1aa7b2ecd'
comparisons={}
for arch,item in r['architectures'].items():
 assert item['identical_release'] and item['identical_manifest'] and item['first']['native_release_verified']
 a,b=old['architectures'][arch]['first'],item['first']
 assert a['session_helpers']==b['session_helpers']
 before={x['name']:x['sha256'] for x in a['payload']['files']};after={x['name']:x['sha256'] for x in b['payload']['files']}
 changed=[name for name in after if before[name]!=after[name]];assert changed==['flex-tailnet-shim'],changed
 before_release={x['name']:x['sha256'] for x in a['release']['files']};after_release={x['name']:x['sha256'] for x in b['release']['files']};assert [name for name in after_release if before_release[name]!=after_release[name]]==['payload.bundle']
 binary=out/'short'/arch/'candidate.release';assert hashlib.sha256(binary.read_bytes()).hexdigest()==b['release']['sha256']
 assert binary.read_bytes()==(out/'second-distinct-long-source-path'/arch/'candidate.release').read_bytes()
 comparisons[arch]={'changed_payload_members':changed,'unchanged_DSP_and_all_fixed_helpers':True,'unchanged_boot_update_and_units':True,'release_bytes':b['release']['bytes'],'release_blake2b_256':b['release']['blake2b_256'],'shim_sha256':after['flex-tailnet-shim'],'expanded_bytes':b['payload']['expanded_bytes']}
(out/'comparison.json').write_text(json.dumps(comparisons,indent=2)+'\n')
rows=budget['measurements'];assert len(rows)==8 and all(len(row['boundary_checks_passed'])==4 for row in rows)
peak=max(x['successor_peak_including_native_reserve_bytes'] for x in rows if x['arch']=='armv7');assert peak==39673856
names=['run.py','report.json','source-sha256.json','comparison.json','build-budget.py','measure-budget.py','budget_probe.c','budget-command.json','budget-report.json','installed-before.json','save-evidence.py']
for label in ['short','second-distinct-long-source-path']:
 for arch in ['armv7','arm64']:names.extend([label+'-'+arch+'.log',label+'/'+arch+'/manifest.json'])
dest=w/'tools/pd-waveform/evidence/20261117-runtime-credential-persistence';dest.mkdir(exist_ok=False);hashes={}
for name in names:
 data=(out/name).read_bytes();assert not re.search(rb'(?i)(authorization\s*:\s*bearer\s+\S+|tskey-[a-z0-9-]{10,}|-----BEGIN (?:OPENSSH |RSA |EC )?PRIVATE KEY-----)',data),name
 target=dest/(name+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(data,mtime=0));hashes[str(target.relative_to(w))]=hashlib.sha256(target.read_bytes()).hexdigest()
report={'updated_utc':now,'status':'complete_development_runtime_reproduced_in_two_paths_and_actual_signed_pair_disk_admission_offline_qualified_not_installed','source_commit':r['source_commit'],'source_manifest_sha256':r['source_manifest_sha256'],'development_publisher_key':'9a4286d5d3e006c5237a2fa3cf282ec3b9710a4e1b92b18d80f0122177e5a7ce','architectures':comparisons,'toolchains':{name:r[name] for name in ['go','go_binary_sha256','zig','zig_binary_sha256','python','zlib']},'separate_source_output_and_compiler_caches':True,'same_host_and_toolchains':True,'native_signature_profile_and_digest_verifiers_passed':True,'development_signing_seed_in_files':False,'installed':False,'production_ready':False,'radio_actions':['Read-only existing desktop identity/radio state and authenticated installation/Stopped receipts'],'RF_commands':[],'radio_credential_mutations':[],'disk_admission':{'signed_previous_source':old['source_commit'],'signed_candidate_source':r['source_commit'],'measurements':rows,'boundary_checks':32,'maximum_ARMv7_peak_modelled_bytes':peak,'headroom_against_reported_41_decimal_MB':41000000-peak,'extra_full_release_upload_archive_fits_reported_41_decimal_MB':False},'limitations':budget['limitations']+['Development publisher only; no production catalogue/key distribution or independent release review is claimed.','Both complete releases were reproduced on the same workstation/toolchains. No independent builder or actual6300 execution is claimed.','The new shim incorporates native state limits and credential race fixes, but managed-owner identity/pending-response-loss/recovery policy and live credential mutation remain open.','Byte-identical DSP/fixed helpers do not qualify the new installed process graph, reboot behavior, RF repeatability, natural alignment cause, native SWR disagreement or final stock-APD comparison.','The final6300 legacy first-install adapter, actual single-SCU feedback path and Linux2.6 service integration remain unqualified.'],'evidence_sha256':hashes}
(w/'tools/pd-waveform/CREDENTIAL-PERSISTENCE-RUNTIME-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
p=base/'production-completion-plan-20261113.json';plan=json.loads(p.read_text());assert len(plan['phases'])==10
plan['updated_utc']=now;plan['runtime_credential_persistence'].update(status=report['status'],report='tools/pd-waveform/CREDENTIAL-PERSISTENCE-RUNTIME-QUALIFICATION.json',architectures=comparisons,modelled_ARMv7_peak_bytes=peak,modelled_headroom_decimal_MB_bytes=41000000-peak,complete_runtime_build_terminal_exit=0,installed=False)
plan['next_action']='Prepare the authenticated c732-to-938fc0 ARM64 upgrade through the ordinary desktop with unchanged fixed-helper privilege contract; qualify installed receive-only Start/IQ/Stop and reboot without changing radio credentials. Complete managed InstallationID/pending-sign-in ownership and lost-reply recovery before live credential mutation. Keep all P1-P10 RF/alignment/SWR/6300/release gates intact.'
plan['production_ready']=False;tmp=p.with_suffix('.tmp');tmp.write_text(json.dumps(plan,indent=2)+'\n');os.replace(tmp,p)
print(json.dumps({'evidence_files':len(hashes),'ARMv7_peak':peak,'decimal_headroom':41000000-peak,'both_architectures_reproduced':True,'installed':False}))
