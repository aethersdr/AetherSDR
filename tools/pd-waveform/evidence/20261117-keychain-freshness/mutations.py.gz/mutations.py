from pathlib import Path
import hashlib,json,os,shlex,subprocess,sys

P=Path(__file__).resolve().parent;W=P.parent.parent/'aetherpd-source';B=P/'build'
source=W/'src/core/TailnetShimTokenStore.cpp';original=source.read_bytes()
root=P/'mutants';root.mkdir(exist_ok=False)
commands=subprocess.check_output(['ninja','-t','commands','interprocess-probe'],cwd=B,text=True).splitlines()
object_name='CMakeFiles/interprocess-probe.dir/home/jeremy/AetherSDR/build/aetherpd-source/src/core/TailnetShimTokenStore.cpp.o'
compile_template=shlex.split(next(line for line in commands if ' -o '+object_name+' ' in line))
link_template=shlex.split(commands[-1]);assert link_template[:2]==[':','&&'] and link_template[-2:]==['&&',':'];link_template=link_template[2:-2]
cases=[('permanent_cache', 'if (session.isEmpty() || !sessionOverrides().value(key)) {','if (session.isEmpty()) {','after'),
    ('ignore_session_override','if (session.isEmpty() || !sessionOverrides().value(key)) {','if (true) {','after'),
    ('ignore_intervening_save','const bool savedSince = saveGenerations().value(key) != startedAt;','const bool savedSince = false;','inflight')]
results=[]
for name,needle,replacement,test in cases:
    folder=root/name;folder.mkdir();text=original.decode();assert text.count(needle)==1
    copied=folder/source.name;copied.write_text(text.replace(needle,replacement))
    compile_args=list(compile_template)
    for flag,value in [('-o',str(folder/'mutant.o')),('-MF',str(folder/'mutant.d')),('-MT',str(folder/'mutant.o')),('-c',str(copied))]:compile_args[compile_args.index(flag)+1]=value
    compile_args+=['-I',str(source.parent)]
    link_args=[a for a in link_template if not a.startswith('-Wl,--dependency-file=')];assert link_args.count(object_name)==1
    link_args[link_args.index(object_name)]=str(folder/'mutant.o');binary=folder/'interprocess-probe';link_args[link_args.index('-o')+1]=str(binary)
    with (folder/'compile.log').open('w') as log:built=subprocess.run(compile_args,cwd=B,stdout=log,stderr=subprocess.STDOUT)
    assert built.returncode==0,name+' compile'
    with (folder/'link.log').open('w') as log:linked=subprocess.run(link_args,cwd=B,stdout=log,stderr=subprocess.STDOUT)
    assert linked.returncode==0,name+' link'
    if test=='after':
        script=(P/'after.py').read_text().replace("binary=P/'build/interprocess-probe'",'binary=Path('+repr(str(binary))+')').replace("receipt=P/'after-result.json'",'receipt=Path('+repr(str(folder/'result.json'))+')')
        runner=folder/'run.py';runner.write_text(script);command=[sys.executable,str(runner)]
        # The copied runner locates its own directory; all paths to the
        # executable and receipt are absolute and no other fixture file is used.
    else:command=[sys.executable,str(P/'inflight.py'),str(binary),str(folder/'result.json')]
    with (folder/'run.log').open('w') as log:ran=subprocess.run(command,cwd=P,stdout=log,stderr=subprocess.STDOUT)
    record={'mutation':name,'compile_exit':built.returncode,'link_exit':linked.returncode,'test_exit':ran.returncode,'result':str(folder/'result.json')}
    results.append(record);(root/'results.json').write_text(json.dumps(results,indent=2)+'\n');print(json.dumps(record),flush=True)
    assert ran.returncode!=0 and (folder/'result.json').exists(),name+' survived or harness did not run'
assert source.read_bytes()==original
(root/'source-unchanged.json').write_text(json.dumps({'sha256':hashlib.sha256(original).hexdigest()},indent=2)+'\n')
