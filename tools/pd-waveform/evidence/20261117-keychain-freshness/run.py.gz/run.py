from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,selectors,subprocess,sys,uuid

P=Path(__file__).resolve().parent
binary=P/'build/interprocess-probe'
receipt=P/'result.json'
assert not receipt.exists(), 'Preserve the existing attempt; do not repeat it silently.'
result={'created_utc':datetime.now(timezone.utc).isoformat(),'source_commit':'6ea0f1aa10a50992d4f31afee946beaeddbb45f3',
    'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'cases':[],
    'fixture_policy':'Unique disposable names and fixture values only. No radio authority or real radio credentials.',
    'radio_mutations':[],'defect_reproduced':False}
def save():
    temporary=receipt.with_suffix('.tmp');temporary.write_text(json.dumps(result,indent=2)+'\n');temporary.replace(receipt)
def command(case,mode,value='',cleanup=False):
    record={'mode':mode};case['cleanup' if cleanup else 'operations'].append(record);save()
    completed=subprocess.run([str(binary),mode,case['identifier'],value],text=True,capture_output=True,timeout=18)
    record.update(exit=completed.returncode,output=completed.stdout.strip(),error=completed.stderr.strip());save()
    assert completed.returncode==0,record
def line(process):
    with selectors.DefaultSelector() as selector:
        selector.register(process.stdout,selectors.EVENT_READ)
        assert selector.select(timeout=10), 'actor did not answer'
    value=process.stdout.readline().strip()
    assert value,'actor closed stdout'
    return value
save()
for changed in [True,False]:
    case={'replacement':'different-token' if changed else 'identical-token',
        'identifier':'aetherpd-interprocess-probe-'+str(uuid.uuid4()),'operations':[],'cleanup':[]}
    result['cases'].append(case);save();actor=None
    try:
        command(case,'absent-direct')
        command(case,'write','fixture-v1')
        actor=subprocess.Popen([str(binary),'actor',case['identifier'],'fixture-v1'],text=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
        case['actor_pid']=actor.pid;save()
        case['actor_initial']=line(actor);save();assert case['actor_initial']=='actor_loaded_original'
        replacement='fixture-v2' if changed else 'fixture-v1'
        command(case,'write',replacement)
        command(case,'read',replacement)
        actor.stdin.write('reload\n');actor.stdin.flush()
        case['actor_reload']=line(actor);save();assert case['actor_reload']=='actor_reload_returned_original'
        actor.stdin.write('retire\n');actor.stdin.flush()
        stdout,stderr=actor.communicate(timeout=8)
        case.update(actor_exit=actor.returncode,actor_output=stdout.strip(),actor_error=stderr.strip());save()
        assert actor.returncode==0 and 'retirement_admitted' in stdout and 'backend_entry_deleted' in stdout
        command(case,'absent-direct')
        case['newer_persisted_save_deleted_by_stale_actor']=True
    except Exception as error:
        case['failure']=repr(error)
    finally:
        if actor is not None and actor.poll() is None:
            actor.kill();actor.communicate(timeout=5);case['actor_killed_for_cleanup']=True
        for mode in ['cleanup','cleanup','absent-direct']:
            try:command(case,mode,cleanup=True)
            except Exception as error:case.setdefault('cleanup_errors',[]).append(repr(error))
        save()
result['defect_reproduced']=all(c.get('newer_persisted_save_deleted_by_stale_actor') and not c.get('cleanup_errors') for c in result['cases'])
result['production_qualified']=False
save()
print(json.dumps({'defect_reproduced':result['defect_reproduced'],'cases':len(result['cases']),'all_fixture_cleanup_confirmed':all(not c.get('cleanup_errors') for c in result['cases'])}))
sys.exit(0 if result['defect_reproduced'] else 1)
