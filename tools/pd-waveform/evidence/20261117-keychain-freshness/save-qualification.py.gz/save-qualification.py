from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json,subprocess,tarfile

P=Path(__file__).resolve().parent;E=P.parent;W=E.parent/'aetherpd-source';B=E/'first-install-desktop-monitor/project'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip();assert base=='6ea0f1aa10a50992d4f31afee946beaeddbb45f3'
def sha(path):
    h=hashlib.sha256()
    with path.open('rb') as stream:
        while chunk:=stream.read(1048576):h.update(chunk)
    return h.hexdigest()
before=json.loads((P/'result.json').read_text());after=json.loads((P/'after-result.json').read_text());san=json.loads((P/'sanitized-after-result.json').read_text())
assert before['defect_reproduced'] and after['read_fix_qualified'] and san['read_fix_qualified']
assert after['atomic_retirement_still_failed'] and san['atomic_retirement_still_failed']
mutants=json.loads((P/'mutants/results.json').read_text());assert len(mutants)==3 and all(m['compile_exit']==0 and m['link_exit']==0 and m['test_exit']!=0 for m in mutants)
assert json.loads((P/'slot-lifecycle/result.json').read_text())['success'] and json.loads((P/'slot-backend-absence.json').read_text())['success']
assert json.loads((P/'inflight-result.json').read_text())['success'] and json.loads((P/'inflight-sanitized-result.json').read_text())['success']
assert '100% tests passed out of 2' in (P/'focused-test.log').read_text()
assert '[SUCCESS] Generated static files' in (P/'docs-build.log').read_text()
source_files=['src/core/TailnetShimTokenStore.cpp','src/core/TailnetShimTokenStore.h','docs/user/docs/tailscale-remote-access.md']
pins={name:sha(W/name) for name in source_files};(P/'qualified-source.diff').write_bytes(subprocess.check_output(['git','diff','--binary','--',*source_files],cwd=W))
receipts={'Linux_AetherSDR_build':'exec59841 exit0; not launched','focused_CTest':'exec59841 exit0, two tests passed',
    'session_only_ASAN_UBSAN_LSAN':'exit0; session-sanitized-test.log empty',
    'real_keychain_ASAN_UBSAN_LSAN':'All five fixture cases and separate in-flight read/save case observed expected outcomes; deliberate identical-token retirement defect remains. Only fixture/store/probe instrumented, not QtKeychain/OS libraries.',
    'docs':'npm ci and npm run build exit0, exec44645',
    'static':'git diff --check, generated references and 767 log-rule checks passed; 12 pre-existing unrelated cited-line offsets remain',
    'exact_source_sha256':pins,'binary_sha256':{'AetherSDR':sha(B/'AetherSDR'),'probe':sha(P/'build/interprocess-probe'),'sanitized_probe':sha(P/'sanitized/interprocess-probe')}}
(P/'build-receipts.json').write_text(json.dumps(receipts,indent=2)+'\n')
selected=[]
for path in P.rglob('*'):
    if not path.is_file() or 'build' in path.relative_to(P).parts or path.relative_to(P).parts[0]=='sanitized':continue
    if path.suffix in ['.py','.cpp','.h','.json','.log','.diff'] or path.name=='CMakeLists.txt':selected.append(path)
evidence=W/'tools/pd-waveform/evidence/20261117-keychain-freshness';evidence.mkdir(exist_ok=False);hashes={}
for path in sorted(selected):
    target=evidence/(str(path.relative_to(P))+'.gz');target.parent.mkdir(parents=True,exist_ok=True);target.write_bytes(gzip.compress(path.read_bytes(),mtime=0));hashes[str(target.relative_to(W))]=sha(target)
archive=E/'keychain-freshness-components.tar.gz';assert not archive.exists();entries={}
deps=subprocess.check_output(['ninja','-t','deps'],cwd=P/'build',text=True)
sources={Path(line.strip()) for line in deps.splitlines() if line.strip().startswith(str(W)+'/')};sources.update(W/name for name in [*source_files,'LICENSE'])
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(selected):
        name='qualification/'+str(path.relative_to(P));tar.add(path,arcname=name,recursive=False);entries[name]=path
    for path in sorted(sources):
        name='source/'+str(path.relative_to(W));tar.add(path,arcname=name,recursive=False);entries[name]=path
    for name,path in [('probe',P/'build/interprocess-probe'),('sanitized-probe',P/'sanitized/interprocess-probe'),('five-case-probe',P/'five-case-history/interprocess-probe'),('five-case-sanitized-probe',P/'five-case-history/interprocess-probe-sanitized'),('slot-probe',P/'slot-lifecycle/build/keychain-lifecycle')]:
        entry='binaries/'+name;tar.add(path,arcname=entry,recursive=False);entries[entry]=path
with tarfile.open(archive) as tar:
    assert len(tar.getmembers())==len(entries)
    for member in tar:assert member.isfile() and hashlib.sha256(tar.extractfile(member).read()).hexdigest()==sha(entries[member.name]),member.name
report={'updated_utc':datetime.now(timezone.utc).isoformat(),'base_commit':base,'exact_source_sha256':pins,
    'qualified_source_overlay_sha256':sha(P/'qualified-source.diff'),'production_ready':False,'read_component_qualified':True,'atomic_retirement_qualified':False,'running_desktop_contains_fix':False,
    'original_defect':'A clean persisted session cache permanently suppressed backend reads. Another process could replace/delete its entry while loads returned the old token. Process-local retirement also deleted another process newer saved value, including identical token bytes.',
    'before':before,
    'fix':'Only pending/failed local writes override the backend. Otherwise each load reads the keychain. Observed backend replacement/deletion advances a separate credential revision; save generations fence in-flight reads independently. An uncertain read returns no token and invalidates the adopted revision without making an older read erase a newer local save.',
    'after':after,'sanitized_after':san,'inflight_read_save':{'normal_passed':True,'sanitized_passed':True},
    'slot_lifecycle':{'operations':47,'direct_EntryNotFound_reads':5,'all_passed':True,'scope':'New disposable entries against changed store, including context destruction and acknowledged-writer SIGKILL.'},
    'mutations':mutants,'verification':receipts,
    'known_remaining_failure':'Even after a fresh read, identical-token external saves are indistinguishable from an unchanged entry. The stale process still admits retirement and deletes that fixture entry. Both normal and sanitized receipts retain this failure. There is also no atomic read/compare/delete interval protecting a new write after a read.',
    'required_next_work':{'implemented':False,'contract':['Serialize cooperating processes mutations for each credential with a user-scoped authority independent of settings profile/TMP overrides. Bound lock admission without blocking the GUI.',
        'Associate each adoption with an across-process version, including identical-value writes; compare it while holding authority through backend completion.',
        'Preserve authority across closed windows and late backend completions; never treat timeout/cancellation as proof a write cannot still commit.',
        'Exercise writer crash, pending/failed writes, metadata/backend disagreement, stale/foreign lock ownership, read/delete races and caller deletion. Keep secrets only in the OS keychain.',
        'Qualify the actual OS backends on Windows/macOS/Linux, including crash/late-completion behavior. Do not promote component tests to a whole-store atomicity claim.']},
    'platform_observation':{'earlier_build_source':'239931ebfc212396cb7a28460274dd320b93ec43','macOS_run':44192984291,'Intel_job':134426966144,'Intel_state':'verified live in Build step','ARM64_job':134426966670,'ARM64_state':'failed before compile at ONNX HTTP404','new_dispatch_or_retry':False,'current_fix_compiled_on_other_platforms':False},
    'radio_mutations':[],'RF_commands':[],'reboot_commands':[],'real_radio_credential_mutations':[],
    'limits':['This is a read-freshness fix, not complete inter-process credential coordination. Production and full P4 remain unqualified.',
        'Failed-write fallback uses a nonexistent D-Bus address in one child only. No real keyring lock/outage or backend-error recovery of a previously cached persisted entry was injected.',
        'No timing/power-loss durability or same-machine multi-user isolation claim. Only unique fixture entries were modified and all were cleaned up.',
        'Initial baseline ELF hash is recorded, but that exact binary was not separately retained; its source is reconstructed from the clean6ea base and the unchanged initial actor path. Final/five-case binaries and corresponding source are archived.',
        'The usual running desktop and radio package were not updated. Original whole-radio hang, actual6300 native privilege/hardware, natural alignment/cold bypass, final RF/stockAPD and independent release gates remain open.'],
    'artifact_archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(entries),'all_members_verified':True,'scope':'Diagnostic source/probes/licenses/receipts only; not a signed radio package or byte-reproducibility claim.'},'evidence_sha256':hashes}
(W/'tools/pd-waveform/KEYCHAIN-FRESHNESS-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
plan_path=E/'production-completion-plan-20261113.json';plan=json.loads(plan_path.read_text());plan['updated_utc']=report['updated_utc'];plan['last_goal_turn_classification']='progress: reproduced cross-process stale reads/deletion, fixed persisted-load freshness and qualified pending/failed-write fallback and read/save fencing; same-token atomic retirement remains positively failed.'
plan['keychain_freshness']={'report':'tools/pd-waveform/KEYCHAIN-FRESHNESS-QUALIFICATION.json','read_component_qualified':True,'atomic_retirement_qualified':False,'same_token_external_retirement_failed':True,'running_desktop_contains_fix':False,'production_ready':False}
plan['next_action']='Implement across-process credential mutation authority and version-bound retirement using the preserved identical-token failure and read/delete-race requirements; do not treat the read fix as closure. Poll existing Intel macOS job134426966144/run44192984291 without duplicate dispatch. Keep radio/RF/reboot unchanged while physical recovery/baseline steering remains pending. Preserve all P1-P10 gates and actual6300 dependencies.'
plan_path.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'report':'KEYCHAIN-FRESHNESS-QUALIFICATION.json','evidence_files':len(hashes),'artifact':report['artifact_archive']}))
