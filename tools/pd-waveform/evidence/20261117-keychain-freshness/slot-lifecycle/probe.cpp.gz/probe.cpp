#include "core/TailnetShimTokenStore.h"
#include <qt6keychain/keychain.h>
#include <QCoreApplication>
#include <QCryptographicHash>
#include <QPointer>
#include <QTimer>
#include <cstdio>

using AetherSDR::TailnetShimTokenStore;
using Entry = TailnetShimTokenStore::Entry;

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("AetherSDR"));
    if (argc != 6) { return 2; }
    const QString mode = QString::fromLocal8Bit(argv[1]);
    const QString id = QString::fromLocal8Bit(argv[2]);
    const QString slot = QString::fromLocal8Bit(argv[3]);
    const QString expected = QString::fromLocal8Bit(argv[4]);
    const QString value = QString::fromLocal8Bit(argv[5]);
    if (!id.startsWith(QStringLiteral("aetherpd-keychain-lifecycle-"))) { return 2; }
    if (slot != u"active" && slot != u"wspr" && slot != u"first") { return 2; }
    const Entry entry = slot == u"active" ? Entry::TailnetShim : slot == u"wspr" ? Entry::Wspr : Entry::AetherPDFirst;
    QTimer::singleShot(10000, &app, [&app] { std::puts("operation_timeout"); app.exit(3); });
    const auto finish = [&app](bool ok) { std::puts(ok ? "pass" : "fail"); app.exit(ok ? 0 : 1); };
    bool callbackAfterContextDestruction = false;
    if (mode == u"write-hold") {
        TailnetShimTokenStore::save(id, value, &app,
            [finish](bool persisted, const QString&) {
                if (!persisted) { finish(false); return; }
                std::puts("persistence_acknowledged");
                std::fflush(stdout);
            }, entry);
    } else if (mode == u"write" || mode == u"delete") {
        TailnetShimTokenStore::save(id, mode == u"delete" ? QString{} : value, &app,
            [finish](bool persisted, const QString&) { finish(persisted); }, entry);
    } else if (mode == u"read") {
        TailnetShimTokenStore::load(id, &app, [expected, finish](const QString& token) { finish(token == expected); }, entry);
    } else if (mode == u"write-close" || mode == u"absent-direct") {
        // Only a disposable entry is touched. This read bypasses the process
        // cache so a successful in-memory save cannot satisfy persistence.
        QObject context;
        if (mode == u"write-close") {
            TailnetShimTokenStore::save(id, value, &context,
                [&callbackAfterContextDestruction](bool, const QString&) { callbackAfterContextDestruction = true; }, entry);
        }
        QPointer<QObject> guard(&context);
        auto* read = new QKeychain::ReadPasswordJob(QStringLiteral("AetherSDR"), &app);
        const QString key = entry == Entry::AetherPDFirst
            ? QStringLiteral("aetherpd/first/") + QString::fromLatin1(QCryptographicHash::hash(id.toUtf8(), QCryptographicHash::Sha256).toHex()) + QStringLiteral("/admin_token")
            : (entry == Entry::Wspr ? QStringLiteral("AetherWSPR/AdminToken/") : QStringLiteral("TailnetShim/AdminToken/")) + id;
        read->setKey(key);
        read->setAutoDelete(true);
        QObject::connect(read, &QKeychain::Job::finished, &app,
            [read, value, mode, guard, &callbackAfterContextDestruction, finish](QKeychain::Job*) {
                if (mode == u"absent-direct") {
                    finish(read->error() == QKeychain::EntryNotFound);
                    return;
                }
                finish(!guard && !callbackAfterContextDestruction && read->error() == QKeychain::NoError && read->textData() == value);
            });
        QTimer::singleShot(0, read, [read] { read->start(); });
        // context is destroyed on leaving this branch, before the event loop.
    } else { return 2; }
    return app.exec();
}
