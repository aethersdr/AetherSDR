#include "core/TailnetShimTokenStore.h"
#include <qt6keychain/keychain.h>
#include <QCoreApplication>
#include <QSocketNotifier>
#include <QTimer>
#include <cstdio>
#include <iostream>
#include <string>

using AetherSDR::TailnetShimTokenStore;

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("AetherSDR"));
    if (argc != 4) { return 2; }
    const QString mode = QString::fromLocal8Bit(argv[1]);
    const QString id = QString::fromLocal8Bit(argv[2]);
    const QString value = QString::fromLocal8Bit(argv[3]);
    if (!id.startsWith(QStringLiteral("aetherpd-interprocess-probe-"))) { return 2; }
    const auto print = [](const char* message) { std::puts(message); std::fflush(stdout); };
    const auto finish = [&app, print](bool ok) { print(ok ? "pass" : "fail"); app.exit(ok ? 0 : 1); };
    QTimer::singleShot(15000, &app, [&app, print] { print("deadline"); app.exit(3); });
    if (mode == u"write" || mode == u"cleanup") {
        TailnetShimTokenStore::save(id, mode == u"cleanup" ? QString{} : value, &app,
            [finish](bool persisted, const QString&) { finish(persisted); });
    } else if (mode == u"failed-write-session") {
        TailnetShimTokenStore::save(id, value, &app, [&, value, finish](bool persisted, const QString&) {
            if (persisted) { finish(false); return; }
            TailnetShimTokenStore::load(id, &app, [value, finish](const QString& token) { finish(token == value); });
        });
    } else if (mode == u"pending-write-session") {
        bool acknowledged = false;
        bool loaded = false;
        bool valid = false;
        const auto complete = [&] { if (acknowledged && loaded) { finish(valid); } };
        TailnetShimTokenStore::save(id, value, &app, [&, complete, finish](bool persisted, const QString&) {
            if (!persisted) { finish(false); return; }
            acknowledged = true;
            complete();
        });
        if (acknowledged) { return 5; }
        TailnetShimTokenStore::load(id, &app, [&, value, complete](const QString& token) {
            loaded = true;
            valid = token == value;
            complete();
        });
        return app.exec();
    } else if (mode == u"inflight-read-then-save") {
        bool acknowledged = false;
        bool loaded = false;
        bool valid = false;
        const auto complete = [&] { if (acknowledged && loaded) { finish(valid); } };
        TailnetShimTokenStore::load(id, &app, [&, value, complete](const QString& token) {
            loaded = true;
            valid = token == value;
            complete();
        });
        TailnetShimTokenStore::save(id, value, &app, [&, complete, finish](bool persisted, const QString&) {
            if (!persisted) { finish(false); return; }
            acknowledged = true;
            complete();
        });
        return app.exec();
    } else if (mode == u"read") {
        TailnetShimTokenStore::load(id, &app, [finish, value](const QString& token) { finish(token == value); });
    } else if (mode == u"absent-direct") {
        auto* read = new QKeychain::ReadPasswordJob(QStringLiteral("AetherSDR"), &app);
        read->setKey(QStringLiteral("TailnetShim/AdminToken/") + id);
        read->setAutoDelete(true);
        QObject::connect(read, &QKeychain::Job::finished, &app, [read, finish](QKeychain::Job*) { finish(read->error() == QKeychain::EntryNotFound); });
        read->start();
    } else if (mode == u"actor") {
        auto* input = new QSocketNotifier(fileno(stdin), QSocketNotifier::Read, &app);
        input->setEnabled(false);
        quint64 revision = 0;
        TailnetShimTokenStore::load(id, &app, [&, input, value, print, finish](const QString& token) {
            if (token != value) { finish(false); return; }
            revision = TailnetShimTokenStore::revision(id);
            input->setEnabled(true);
            print("actor_loaded_original");
        });
        QObject::connect(input, &QSocketNotifier::activated, &app, [&, input, value, print, finish] {
            input->setEnabled(false);
            std::string command;
            if (!std::getline(std::cin, command)) { finish(false); return; }
            if (command == "reload") {
                TailnetShimTokenStore::load(id, &app, [input, value, print](const QString& token) {
                    print(token == value ? "actor_reload_returned_original" : "actor_reload_changed");
                    input->setEnabled(true);
                });
            } else if (command == "retire") {
                if (!TailnetShimTokenStore::clearIfCurrent(id, value, revision)) { print("retirement_refused"); app.exit(4); return; }
                print("retirement_admitted");
                auto* read = new QKeychain::ReadPasswordJob(QStringLiteral("AetherSDR"), &app);
                read->setKey(QStringLiteral("TailnetShim/AdminToken/") + id);
                read->setAutoDelete(true);
                QObject::connect(read, &QKeychain::Job::finished, &app, [&, read, print](QKeychain::Job*) {
                    const bool missing = read->error() == QKeychain::EntryNotFound;
                    print(missing ? "backend_entry_deleted" : "backend_entry_not_deleted");
                    app.exit(missing ? 0 : 1);
                });
                QTimer::singleShot(0, read, [read] { read->start(); });
            } else { finish(false); }
        });
        return app.exec();
    } else { return 2; }
    return app.exec();
}
