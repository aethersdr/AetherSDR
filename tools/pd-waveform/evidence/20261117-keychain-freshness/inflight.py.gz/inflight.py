from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,subprocess,sys,uuid

P=Path(__file__).resolve().parent
binary=Path(sys.argv[1]) if len(sys.argv)>1 else P/'build/interprocess-probe'
receipt=Path(sys.argv[2]) if len(sys.argv)>2 else P/'inflight-result.json'
assert not receipt.exists()
identifier='aetherpd-interprocess-probe-'+str(uuid.uuid4())
result={'created_utc':datetime.now(timezone.utc).isoformat(),'identifier':identifier,
    'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'operations':[],'cleanup':[],'success':False,'radio_mutations':[]}
def save():receipt.write_text(json.dumps(result,indent=2)+'\n')
def command(mode,value='',cleanup=False):
    record={'mode':mode};result['cleanup' if cleanup else 'operations'].append(record);save()
    child=subprocess.run([str(binary),mode,identifier,value],text=True,capture_output=True,timeout=18)
    record.update(exit=child.returncode,output=child.stdout.strip(),error=child.stderr.strip());save();assert child.returncode==0,record
save()
try:
    command('absent-direct');command('write','fixture-v1')
    command('inflight-read-then-save','fixture-v2');command('read','fixture-v2')
    result['checks_passed']=True
except Exception as error:result['failure']=repr(error)
finally:
    for mode in ['cleanup','cleanup','absent-direct']:
        try:command(mode,cleanup=True)
        except Exception as error:result.setdefault('cleanup_errors',[]).append(repr(error))
    result['success']=result.get('checks_passed',False) and not result.get('cleanup_errors');save()
print(json.dumps({'success':result['success'],'operations':len(result['operations']),'cleanup':len(result['cleanup'])}))
sys.exit(0 if result['success'] else 1)
