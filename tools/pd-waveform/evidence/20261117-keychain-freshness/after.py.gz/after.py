from pathlib import Path
from datetime import datetime,timezone
import hashlib,json,os,selectors,subprocess,sys,uuid

P=Path(__file__).resolve().parent;binary=P/'build/interprocess-probe';receipt=P/'after-result.json'
assert not receipt.exists()
result={'created_utc':datetime.now(timezone.utc).isoformat(),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
    'cases':[],'radio_mutations':[],'production_qualified':False,'read_fix_qualified':False}
def save():
    temporary=receipt.with_suffix('.tmp');temporary.write_text(json.dumps(result,indent=2)+'\n');temporary.replace(receipt)
def command(case,mode,value='',cleanup=False,environment=None):
    record={'mode':mode,'isolated_invalid_session_bus':environment is not None}
    case['cleanup' if cleanup else 'operations'].append(record);save()
    child=subprocess.run([str(binary),mode,case['identifier'],value],env=environment,text=True,capture_output=True,timeout=18)
    record.update(exit=child.returncode,output=child.stdout.strip(),error=child.stderr.strip());save();assert child.returncode==0,record
def line(process):
    with selectors.DefaultSelector() as selector:
        selector.register(process.stdout,selectors.EVENT_READ);assert selector.select(timeout=10),'actor timeout'
    value=process.stdout.readline().strip();assert value,'actor closed stdout';return value
for kind in ['changed-token','identical-token','external-delete','pending-write','failed-write']:
    case={'kind':kind,'identifier':'aetherpd-interprocess-probe-'+str(uuid.uuid4()),'operations':[],'cleanup':[]}
    result['cases'].append(case);save();actor=None
    try:
        command(case,'absent-direct')
        if kind=='pending-write':
            command(case,'pending-write-session','fixture-v1');command(case,'read','fixture-v1')
        elif kind=='failed-write':
            bad=dict(os.environ,DBUS_SESSION_BUS_ADDRESS='unix:path=/tmp/aetherpd-no-such-keyring-'+str(uuid.uuid4()))
            command(case,'failed-write-session','fixture-v1',environment=bad);command(case,'absent-direct')
        else:
            command(case,'write','fixture-v1')
            actor=subprocess.Popen([str(binary),'actor',case['identifier'],'fixture-v1'],text=True,stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE)
            case['actor_pid']=actor.pid;save();assert line(actor)=='actor_loaded_original'
            if kind=='external-delete':command(case,'cleanup')
            else:command(case,'write','fixture-v2' if kind=='changed-token' else 'fixture-v1')
            if kind=='changed-token':command(case,'read','fixture-v2')
            actor.stdin.write('reload\n');actor.stdin.flush();case['reload']=line(actor);save()
            expected='actor_reload_returned_original' if kind=='identical-token' else 'actor_reload_changed'
            assert case['reload']==expected
            actor.stdin.write('retire\n');actor.stdin.flush();stdout,stderr=actor.communicate(timeout=8)
            case.update(actor_exit=actor.returncode,actor_output=stdout.strip(),actor_error=stderr.strip());save()
            if kind=='identical-token':
                assert actor.returncode==0 and 'backend_entry_deleted' in stdout
                case['remaining_defect_reproduced']=True;command(case,'absent-direct')
            else:
                assert actor.returncode==4 and 'retirement_refused' in stdout
                command(case,'read','fixture-v2') if kind=='changed-token' else command(case,'absent-direct')
        case['expected_outcome_observed']=True
    except Exception as error:case['failure']=repr(error)
    finally:
        if actor is not None and actor.poll() is None:actor.kill();actor.communicate(timeout=5)
        for mode in ['cleanup','cleanup','absent-direct']:
            try:command(case,mode,cleanup=True)
            except Exception as error:case.setdefault('cleanup_errors',[]).append(repr(error))
        save()
result['read_fix_qualified']=all(c.get('expected_outcome_observed') and not c.get('cleanup_errors') for c in result['cases'])
result['atomic_retirement_still_failed']=any(c.get('remaining_defect_reproduced') for c in result['cases'])
save();print(json.dumps({k:result[k] for k in ['read_fix_qualified','atomic_retirement_still_failed','production_qualified']}))
sys.exit(0 if result['read_fix_qualified'] and result['atomic_retirement_still_failed'] else 1)
