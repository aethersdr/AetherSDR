from pathlib import Path
from datetime import datetime,timezone
import gzip,hashlib,json
P=Path(__file__).resolve().parent;E=P.parent;W=E.parent/'aetherpd-source';R=E/'runtime-native-identity-startup';U=E/'upgrade-native-identity-startup'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
i=read(P/'install-result.json');live=read(P/'api-outcome.json');final=read(P/'final-observation.json');runtime=read(R/'report.json');up=read(U/'report.json');budget=read(R/'budget-report.json');comparison=read(R/'payload-comparison.json');archive=read(E/'native-identity-startup-artifact-archive.json')
assert i['committed'] and 'Temporary installer cleanup confirmed.' in i['latest']['pdInstallState']['value'] and live['passed']
assert live['Start_actions']==1 and live['Stop_actions']==1 and live['capture_before']['bytes']==131072 and live['final_stop']['body']['state']=='stopped'
assert not live['radio_after']['transmitting'] and not live['radio_after']['fullDuplex']
assert all(x['identical_release'] and x['identical_manifest'] for x in runtime['architectures'].values()) and up['complete_eight_file_distribution_identical']
assert i['candidate_source']==runtime['source_commit']=='92488a6a1f55723f44c7be0efa720b651282131a'
assert all(x['changed_payload_members']==['flex-tailnet-shim'] for x in comparison.values())
assert final['owner_identity']['installation_id']=='b6050e0036d2cfe91bce6f36c8c88faaea90e86722dd13c710a57015adb53654'
assert sha(Path(archive['path']))==archive['sha256']
rows=[x for x in budget['measurements'] if x['arch']=='armv7'];peak=max(x['successor_peak_including_native_reserve_bytes'] for x in rows)
now=datetime.now(timezone.utc).isoformat();report={'updated_utc':now,'production_ready':False,'runtime_source_commit':runtime['source_commit'],'component_report':'tools/pd-waveform/NATIVE-IDENTITY-STARTUP-QUALIFICATION.json',
 'runtime_build':runtime,'upgrade_distribution':up,'authenticated_artifact_archive':archive,'payload_comparison':comparison,
 'disk_budget':{'report':budget,'ARMv7_max_modeled_peak_bytes':peak,'headroom_from_41_decimal_MB':41000000-peak,'capacity_measured_on_6300':False},
 'desktop':read(P/'desktop-provenance.json'),'ordinary_installed_update':{'committed':True,'elapsed_s':i['elapsed_s'],'temporary_cleanup_confirmation':i['latest']['pdInstallState']['value'],'predecessor_release':'c3d2522512f66f32025747661335e82eb8a3f572fe9888acf7af8380f9a43404','selected_release':'0d88765b3eaad89fde171f98955ac8dcef959543a93db9967b25d920912c43e7','diagnostics_used_for_delivery':False,'predecessor_credential_used_for_delivery':True,'broad_laboratory_root_jobs':0,'candidate_source':i['candidate_source']},
 'receive_only':{'FDX':False,'ordinary_Start_actions':live['Start_actions'],'ordinary_Stop_actions':live['Stop_actions'],'ready_s':live['first_start']['ready_s'],'capture':live['capture_before'],'registered_status':live['first_start']['status'],'owner_verifier_fingerprint':live['owner_after']['owner_verifier_fingerprint'],'installation_record_before':live['installation_before'],'installation_record_after':live['installation_after'],'final_status':live['final_stop']},
 'final_observation':final,'RF_commands':[],'reboot_commands':[],'credential_mutations':[],'actual_6300_qualified':False,'software_reboot_qualified':False,
 'limits':['New source is installed and receive-only qualified on this FLEX8600; malformed-state and process-death tests were local/offline, not injected into the live identity.',
 'Committed installation inventory is a root-owned record served by the authenticated primary, not an independent live /proc/executable/privilege audit. No new laboratory root audit was run.',
 'Only shim bytes changed within the runtime payload. This does not promote previous keyed/RF/failure/stockAPD results into final-candidate qualification.',
 'Complete builds use the retained development publisher and local development selection. Shipping catalogue, publisher-key deployment and independent release/platform gates remain.',
 'Synthetic native upgrade byte/inode boundaries and modeled /user budgets do not establish actual6300 transient uploads/cache/full-volume use, first-install adapter overhead or physical power-loss durability.',
 'No joined tailnet, key rotation/owner loss, new credential provisioning, whole-radio restart or actual6300 hardware proof in this run.',
 'Prior green-LED software-reboot hang remains failed and unexplained. Pending recovery coordination and operator-deferred SWR/preamble scope remain unchanged. Full P1–P10 remains active.']}
dest=W/'tools/pd-waveform/evidence/20261117-native-identity-startup-installed';dest.mkdir(exist_ok=False);evidence={}
for directory in (P,R,U):
 for p in sorted(directory.iterdir()):
  if not p.is_file() or p.suffix not in ('.py','.json','.log','.f32le','.c') or p.name=='desktop.log':continue
  rel=str(p.relative_to(E));target=dest/(rel+'.gz');target.parent.mkdir(parents=True,exist_ok=True)
  with target.open('wb') as f:
   with gzip.GzipFile(filename='',mode='wb',fileobj=f,mtime=0) as z:z.write(p.read_bytes())
  assert gzip.decompress(target.read_bytes())==p.read_bytes();evidence[str(target.relative_to(W))]=sha(target)
report['evidence_sha256']=evidence
(W/'tools/pd-waveform/NATIVE-IDENTITY-STARTUP-INSTALLED-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
planpath=E/'production-completion-plan-20261113.json';plan=read(planpath);plan['updated_utc']=now;plan['native_identity_startup']['installed_successor_report']='tools/pd-waveform/NATIVE-IDENTITY-STARTUP-INSTALLED-QUALIFICATION.json';plan['native_identity_startup']['installed_successor_release']=report['ordinary_installed_update']['selected_release'];plan['native_identity_startup']['complete_runtime_installed']=True
plan['current_candidate'].update(source_commit=runtime['source_commit'],selected_release_blake2b_256=report['ordinary_installed_update']['selected_release'],installed_receive_only_IQ_qualified=True,installed_receive_only_whole_graph_and_fresh_IQ_qualified=False,ordinary_native_identity_directory_write_qualified=False,RF_qualified_on_this_package=False,finite_10W_RF_pair_qualified=False,installed_receive_only_guardian_signals_and_PD_stop_qualified=False,software_reboot_qualified=False,production_ready=False)
plan['current_candidate']['last_observed_boot_id']=plan['current_candidate'].get('boot_id');plan['current_candidate']['boot_id']=None
plan['current_candidate']['inherited_component_evidence']='Other payload member bytes match priorc3 release, but live final-graph/failure/keyed/identity-write gates have not been rerun on this package.'
plan['native_identity_startup']['desktop']=read(P/'instance.json');plan['next_action']='Continue full P1–P10 from installed0d88765/92488a6. Verify remaining final-process-graph/owner-loss and interrupted lifecycle cases receive-only, preserve original natural128/cold-start and RF/SWR deferred scopes. Obtain original native6000 privilege-entry mechanism and teammate kernel/CPU reports; do not copy Podman assumptions. Coordinated reboot trace and final keyed/RF/stockAPD tests remain pending operator steering. No production-ready claim.'
planpath.write_text(json.dumps(plan,indent=2)+'\n');print(json.dumps({'evidence_files':len(evidence),'installed_source':runtime['source_commit'],'ready_s':live['first_start']['ready_s'],'IQ_bytes':live['capture_before']['bytes'],'ARMv7_modeled_peak':peak,'production_ready':False}))
