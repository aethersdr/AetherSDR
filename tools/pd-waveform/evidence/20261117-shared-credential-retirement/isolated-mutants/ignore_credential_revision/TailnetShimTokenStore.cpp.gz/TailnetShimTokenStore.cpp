#include "TailnetShimTokenStore.h"
#include "SettingsCredentialPolicy.h"

#include <QCoreApplication>
#include <QCryptographicHash>
#include <QDebug>
#include <QHash>
#include <QObject>
#include <QPointer>
#include <QTimer>

#ifdef HAVE_KEYCHAIN
#include <qt6keychain/keychain.h>
#endif

#include <utility>

namespace AetherSDR {

namespace {

QString keyFor(const QString& radioSerial, TailnetShimTokenStore::Entry entry)
{
    if (entry == TailnetShimTokenStore::Entry::AetherPDFirst) {
        return SettingsCredentialPolicy::scopedCredentialKey(SettingsCredentialPolicy::kAetherPDFirstCredential,
            QString::fromLatin1(QCryptographicHash::hash(radioSerial.toUtf8(), QCryptographicHash::Sha256).toHex()));
    }
    return (entry == TailnetShimTokenStore::Entry::Wspr ? QStringLiteral("AetherWSPR/AdminToken/")
                                                        : QStringLiteral("TailnetShim/AdminToken/"))
        + radioSerial;
}

// Session copy: always written, so a save followed at once by a load never
// races the keyring, and keychain-less builds still work until restart.
QHash<QString, QString>& sessionTokens()
{
    static QHash<QString, QString> tokens;
    return tokens;
}

// Bumped by every save, per entry: a keychain read that started before a
// save finishes after it, and must not put the older token back.
QHash<QString, quint64>& saveGenerations()
{
    static QHash<QString, quint64> generations;
    return generations;
}

#ifdef HAVE_KEYCHAIN
constexpr const char* kKeychainService = "AetherSDR";
#endif

}  // namespace

bool TailnetShimTokenStore::persistentStoreAvailable()
{
#ifdef HAVE_KEYCHAIN
    return true;
#else
    return false;
#endif
}

void TailnetShimTokenStore::save(const QString& radioSerial, const QString& token,
                                 QObject* context,
                                 std::function<void(bool persisted, const QString& error)> done,
                                 Entry entry)
{
    // Without a serial every radio would share one entry, and one radio's
    // token would be offered to another. Refuse, and say why.
    if (radioSerial.trimmed().isEmpty()) {
        if (done) {
            QTimer::singleShot(0, context ? context : QCoreApplication::instance(),
                               [done = std::move(done)] {
                done(false, QStringLiteral("the radio's serial number isn't known yet"));
            });
        }
        return;
    }
    const QString key = keyFor(radioSerial, entry);
    ++saveGenerations()[key];
    if (token.isEmpty()) {
        sessionTokens().remove(key);
    } else {
        sessionTokens().insert(key, token);
    }
#ifdef HAVE_KEYCHAIN
    QKeychain::Job* job = nullptr;
    if (token.isEmpty()) {
        job = new QKeychain::DeletePasswordJob(QString::fromLatin1(kKeychainService));
    } else {
        auto* write = new QKeychain::WritePasswordJob(QString::fromLatin1(kKeychainService));
        write->setTextData(token);
        job = write;
    }
    job->setKey(key);
    job->setAutoDelete(true);
    QPointer<QObject> guard(context);
    QObject::connect(job, &QKeychain::Job::finished, job,
                     [guard, deleting = token.isEmpty(), hasContext = context != nullptr, done = std::move(done)](QKeychain::Job* finished) {
        const bool ok = finished->error() == QKeychain::NoError
            || (deleting && finished->error() == QKeychain::EntryNotFound);
        if (!ok) {
            qWarning() << "TailnetShimTokenStore: keychain write failed:" << finished->errorString();
        }
        if (done && (!hasContext || guard)) {
            done(ok, ok ? QString() : finished->errorString());
        }
    });
    job->start();
#else
    if (done) {
        QTimer::singleShot(0, context ? context : QCoreApplication::instance(), [done = std::move(done)] {
            done(false, QStringLiteral("this build has no system keychain support"));
        });
    }
#endif
}

quint64 TailnetShimTokenStore::revision(const QString& radioSerial, Entry entry)
{
    return saveGenerations().value(keyFor(radioSerial, entry));
}

bool TailnetShimTokenStore::clearIfCurrent(const QString& radioSerial, const QString& expectedToken,
                                          quint64 expectedRevision, Entry entry)
{
    if (radioSerial.trimmed().isEmpty() || expectedToken.isEmpty()
        || sessionTokens().value(keyFor(radioSerial, entry)) != expectedToken) {
        return false;
    }
    save(radioSerial, QString(), nullptr, {}, entry);
    return true;
}

void TailnetShimTokenStore::load(const QString& radioSerial, QObject* context,
                                 std::function<void(const QString&)> callback, Entry entry)
{
    // As save() does: with no context the callback still runs, on the app.
    if (!context) {
        context = QCoreApplication::instance();
    }
    if (radioSerial.trimmed().isEmpty()) {
        // No serial, no entry to read: never another radio's token.
        QTimer::singleShot(0, context, [callback = std::move(callback)] { callback(QString()); });
        return;
    }
    const QString key = keyFor(radioSerial, entry);
    const QString session = sessionTokens().value(key);
#ifdef HAVE_KEYCHAIN
    if (session.isEmpty()) {
        const quint64 startedAt = saveGenerations().value(key);
        auto* job = new QKeychain::ReadPasswordJob(QString::fromLatin1(kKeychainService));
        job->setKey(key);
        job->setAutoDelete(true);
        QPointer<QObject> guard(context);
        QObject::connect(job, &QKeychain::Job::finished, context,
                         [guard, key, startedAt, callback = std::move(callback)](QKeychain::Job* finished) {
            QString read;
            if (finished->error() == QKeychain::NoError) {
                read = static_cast<QKeychain::ReadPasswordJob*>(finished)->textData();
            }
            const bool savedSince = saveGenerations().value(key) != startedAt;
            const QString token = pickLoadedToken(savedSince, read, sessionTokens().value(key));
            if (!savedSince && !token.isEmpty()) {
                sessionTokens().insert(key, token);
            }
            if (guard) {
                callback(token);
            }
        });
        job->start();
        return;
    }
#endif
    // Read when it runs, not now: a save in between is the newer token.
    QTimer::singleShot(0, context, [key, callback = std::move(callback)] {
        callback(sessionTokens().value(key));
    });
}

QString TailnetShimTokenStore::pickLoadedToken(bool savedSinceReadStarted, const QString& read,
                                               const QString& sessionNow)
{
    return savedSinceReadStarted ? sessionNow : read;
}

}  // namespace AetherSDR
