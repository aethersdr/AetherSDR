from pathlib import Path
from datetime import datetime, timezone
import hashlib
import json
import subprocess
import sys
import uuid

P=Path(__file__).resolve().parent
binary=P/'checks/retirement-probe'
receipt=P/'real-keychain-revision-result.json'
assert not receipt.exists()
identifier='aetherpd-shared-retirement-'+str(uuid.uuid4())
result={'created_utc':datetime.now(timezone.utc).isoformat(),'identifier':identifier,
    'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),
    'fixture_values':'fixture-v1 and fixture-v2; no radio authority',
    'operations':[],'cleanup':[],'radio_mutations':[],'success':False}
def save():
    temporary=receipt.with_suffix('.tmp')
    temporary.write_text(json.dumps(result,indent=2)+'\n')
    temporary.replace(receipt)
def operation(mode,expected='',replacement='',cleanup=False):
    record={'mode':mode,'started_utc':datetime.now(timezone.utc).isoformat()}
    result['cleanup' if cleanup else 'operations'].append(record)
    save()
    child=subprocess.run([str(binary),mode,identifier,expected,replacement],text=True,capture_output=True,timeout=15)
    record.update(exit=child.returncode,output=child.stdout.strip(),error=child.stderr.strip())
    save()
    assert child.returncode==0,record
save()
try:
    operation('absent-direct')
    operation('write',replacement='fixture-v1')
    operation('refuse-stale',expected='fixture-v1',replacement='fixture-v2')
    operation('read',expected='fixture-v2')
    operation('refuse-stale',expected='fixture-v2',replacement='fixture-v2')
    operation('read',expected='fixture-v2')
    operation('retire-current',expected='fixture-v2')
    operation('absent-direct')
    result['checks_passed']=True
except Exception as error:
    result['failure']=repr(error)
finally:
    for mode in ['cleanup','cleanup','absent-direct']:
        try: operation(mode,cleanup=True)
        except Exception as error: result.setdefault('cleanup_errors',[]).append(repr(error))
    result['success']=result.get('checks_passed',False) and not result.get('cleanup_errors')
    save()
print(json.dumps({'success':result['success'],'operations':len(result['operations']),
    'cleanup':len(result['cleanup']),'failure':result.get('failure'),'cleanup_errors':result.get('cleanup_errors',[])}))
sys.exit(0 if result['success'] else 1)
