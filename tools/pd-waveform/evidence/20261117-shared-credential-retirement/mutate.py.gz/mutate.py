from pathlib import Path
import hashlib
import json
import os
import subprocess

P=Path(__file__).resolve().parent
W=P.parent.parent/'aetherpd-source'
B=P.parent/'first-install-desktop-monitor/project'
store=W/'src/core/TailnetShimTokenStore.cpp'
dialog=W/'src/gui/TailnetShimDialog.cpp'
original={path:path.read_bytes() for path in [store,dialog]}
env=dict(os.environ, CCACHE_DIR=str(P.parent/'first-install-desktop-monitor/ccache'), QT_QPA_PLATFORM='offscreen')
receipt=P/'mutations.json'
assert not receipt.exists()
cases=[('skip_current_token_comparison',store,
    ' || expectedToken.isEmpty()\n        || sessionTokens().value(keyFor(radioSerial, entry)) != expectedToken',
    ' || expectedToken.isEmpty()',0),
    ('unconditional_legacy_signout_delete',dialog,
     'TailnetShimTokenStore::clearIfCurrent(m_radioSerial, m_adminToken);',
     'TailnetShimTokenStore::save(m_radioSerial, QString());',1),
    ('unconditional_legacy_login401_delete',dialog,
     'TailnetShimTokenStore::clearIfCurrent(m_radioSerial, m_adminToken);',
     'TailnetShimTokenStore::save(m_radioSerial, QString());',2)]
results=[]
try:
    for name,path,needle,replacement,occurrence in cases:
        for file,data in original.items(): file.write_bytes(data)
        text=path.read_text()
        if occurrence:
            assert text.count(needle)==2
            index=text.index(needle) if occurrence==1 else text.rindex(needle)
            text=text[:index]+replacement+text[index+len(needle):]
        else:
            assert text.count(needle)==1
            text=text.replace(needle,replacement)
        path.write_text(text)
        with (P/(name+'-build.log')).open('w') as log:
            build=subprocess.run(['cmake','--build',str(B),'--target','tailnet_shim_dialog_test','--parallel','2'],env=env,stdout=log,stderr=subprocess.STDOUT)
        assert build.returncode==0, 'Mutation compile failed: '+name
        with (P/(name+'-test.log')).open('w') as log:
            test=subprocess.run([str(B/'tailnet_shim_dialog_test')],env=env,stdout=log,stderr=subprocess.STDOUT)
        failures=[line for line in (P/(name+'-test.log')).read_text().splitlines() if line.startswith('FAIL:')]
        result={'mutation':name,'build_exit':build.returncode,'test_exit':test.returncode,'failures':failures}
        results.append(result)
        receipt.write_text(json.dumps(results,indent=2)+'\n')
        print(json.dumps(result),flush=True)
        assert test.returncode!=0 and failures, 'Mutation was not rejected: '+name
finally:
    for path,data in original.items(): path.write_bytes(data)
    (P/'restored-source-sha256.json').write_text(json.dumps({str(path.relative_to(W)):hashlib.sha256(path.read_bytes()).hexdigest() for path in original},indent=2)+'\n')
