from pathlib import Path
from datetime import datetime, timezone
import gzip
import hashlib
import json
import subprocess
import tarfile

P=Path(__file__).resolve().parent
E=P.parent
W=E.parent/'aetherpd-source'
B=E/'first-install-desktop-monitor/project'
base=subprocess.check_output(['git','rev-parse','HEAD'],cwd=W,text=True).strip()
assert base=='41e5b0000a4049137809ea21c3c5fa3dfeba7796'
def sha(path):
    digest=hashlib.sha256()
    with path.open('rb') as stream:
        while chunk:=stream.read(1048576):digest.update(chunk)
    return digest.hexdigest()
assert '100% tests passed out of 2' in (P/'final-dialog-test.log').read_text()
assert '[SUCCESS] Generated static files' in (P/'revision-docs-build.log').read_text()
assert (P/'revision-sanitized-test.log').stat().st_size==0
mutants=json.loads((P/'isolated-mutants/results.json').read_text())
assert len(mutants)==4 and all(m['compile_exit']==0 and m['link_exit']==0 and m['test_exit']!=0 and m['failures'] for m in mutants)
keychain=json.loads((P/'real-keychain-revision-result.json').read_text())
assert keychain['success'] and len(keychain['operations'])==8 and len(keychain['cleanup'])==3
source_files=['src/core/TailnetShimTokenStore.cpp','src/core/TailnetShimTokenStore.h',
    'src/gui/TailnetShimDialog.cpp','src/gui/TailnetShimDialog.h',
    'tests/tailnet_shim_client_test.cpp','tests/tailnet_shim_dialog_test.cpp',
    'docs/user/docs/tailscale-remote-access.md']
pins={name:sha(W/name) for name in source_files}
overlay=P/'qualified-source.diff'
overlay.write_bytes(subprocess.check_output(['git','diff','--binary','--',*source_files],cwd=W))
build_receipts={
    'full_AetherSDR_build':'exit0 (exec75897), with final revision-aware production sources; no app launch',
    'focused_CTest':'exit0 (exec51536), two tests passed',
    'sanitized_client':'exit0, ASAN_OPTIONS=detect_leaks=1:abort_on_error=1 and UBSAN_OPTIONS=halt_on_error=1; no diagnostic output',
    'docs_install':'npm ci exit0 (exec71061)',
    'docs_build':'npm run build exit0 (exec35169), after final documentation edit',
    'registration_gate_generated_reference_log_rules':'all exit0; 12 pre-existing unrelated cited-line offsets reported by log-rule checker',
    'executables_sha256':{'AetherSDR':sha(B/'AetherSDR'),
        'tailnet_shim_dialog_test':sha(B/'tailnet_shim_dialog_test'),
        'tailnet_shim_client_test':sha(B/'tailnet_shim_client_test'),
        'retirement-client-sanitized':sha(P/'checks/retirement-client-sanitized'),
        'retirement-probe':sha(P/'checks/retirement-probe')},
    'exact_source_sha256':pins
}
(P/'build-receipts.json').write_text(json.dumps(build_receipts,indent=2)+'\n')
evidence=W/'tools/pd-waveform/evidence/20261117-shared-credential-retirement'
evidence.mkdir(exist_ok=False)
selected=[]
for path in P.rglob('*'):
    if not path.is_file() or path.relative_to(P).parts[0]=='checks':continue
    if path.suffix in ['.py','.cpp','.json','.log','.diff'] or path.name=='CMakeLists.txt':selected.append(path)
hashes={}
for path in sorted(selected):
    relative=path.relative_to(P)
    target=evidence/(str(relative)+'.gz')
    target.parent.mkdir(parents=True,exist_ok=True)
    target.write_bytes(gzip.compress(path.read_bytes(),mtime=0))
    hashes[str(target.relative_to(W))]=sha(target)
archive=E/'shared-credential-retirement-components.tar.gz'
assert not archive.exists()
dependencies=subprocess.check_output(['ninja','-t','deps'],cwd=P/'checks',text=True)
corresponding={Path(line.strip()) for line in dependencies.splitlines() if line.strip().startswith(str(W)+'/')}
corresponding.update(W/name for name in source_files)
corresponding.update(W/name for name in ['LICENSE','src/core/TailnetShimTokenStore.cpp','src/core/TailnetShimClient.cpp',
    'src/core/TailnetShimDownloader.cpp','src/core/TailnetLinkTelemetry.cpp'])
entries={}
with tarfile.open(archive,'w:gz') as tar:
    for path in sorted(selected):
        name='qualification/'+str(path.relative_to(P));tar.add(path,arcname=name,recursive=False);entries[name]=path
    for path in sorted(corresponding):
        name='source/'+str(path.relative_to(W));tar.add(path,arcname=name,recursive=False);entries[name]=path
    for name in ['retirement-probe','retirement-client-sanitized']:
        path=P/'checks'/name;entry='qualification/checks/'+name;tar.add(path,arcname=entry,recursive=False);entries[entry]=path
with tarfile.open(archive) as tar:
    assert len(tar.getmembers())==len(entries)
    for member in tar:
        assert member.isfile() and hashlib.sha256(tar.extractfile(member).read()).hexdigest()==sha(entries[member.name]),member.name
jobs=json.loads((P/'macos-jobs-2315.json').read_text())
report={
    'updated_utc':datetime.now(timezone.utc).isoformat(), 'base_commit':base,
    'qualified_source_overlay_sha256':sha(overlay),'exact_source_sha256':pins,
    'production_ready':False,'component_qualified':True,'running_desktop_contains_fix':False,
    'problem':'An old legacy Remote Access window deleted the shared current owner credential on delayed login401 or successful sign-out, even after another window saved a replacement. The original guard compared only the old window own token.',
    'initial_reproduction':'Two socket-free production-window regressions fail before the fix. A value-only fix passes different-token cases but fails when the newer managed-owner save uses identical token bytes; both red receipts retained.',
    'fix':'Credential adoption retains the store revision. Legacy retirement requires nonempty known identity, matching token and matching process-local save revision. Every save advances that revision, including identical bytes. A failed comparison does not request a keychain delete. Managed-owner401 behavior remains credential-preserving.',
    'focused_regressions':['legacy login401 after another window saves a different managed-owner token',
        'legacy sign-out after another window saves a different managed-owner token',
        'both cases with identical saved token bytes','matching-current legacy retirement still works',
        'empty/missing/stale tokens, wrong entries and unknown serials reject retirement',
        'first-install attempt retirement preserves the active credential'],
    'verification':build_receipts,'mutations':mutants,
    'real_keychain':{'result':keychain,'processes':11,'current_retirement_backend_absence_verified':True,
        'different_and_identical_replacement_preserved_in_fresh_process':True,'fixture_cleanup_confirmed':True,
        'scope':'Linux GNOME Keyring/QtKeychain fixture only; no real radio credential or identity changed.'},
    'platform_observation':{'earlier_build_source':'239931ebfc212396cb7a28460274dd320b93ec43','run_id':44192984291,
        'Intel_job':134426966144,'Intel_status':'in_progress, Build step',
        'ARM64_job':134426966670,'ARM64_status':'failure before compile: pinned ONNX download HTTP404',
        'fix_compiled_on_Windows_or_macOS':False,'new_dispatch_or_retry':False},
    'harness_history':['Initial ordinary build failed on read-only default ccache; selected writable task cache and reproduced both original regressions.',
        'The original in-worktree mutation process was interrupted during its second case by a tool-session reset. Missing handle and no live host process were confirmed; the intermediate source was preserved and the final guard restored. Remaining cases were run explicitly.',
        'Final four mutations use isolated source/object/executable copies. The worktree source hashes were unchanged through those checks.',
        'Initial standalone sanitizer CMake harness omitted AUTOMOC and failed to link Qt metaobjects; corrected local harness, then both build and sanitized run passed.'],
    'radio_mutations':[],'RF_commands':[],'reboot_commands':[],'real_radio_credential_mutations':[],
    'limits':['Process-local revisions do not coordinate separate AetherSDR processes or repair cross-process stale caches; server/legacy reply ordering across instances remains unqualified.',
        'Current fix is built locally but not deployed to the usual running desktop; no live radio/bridge workflow or radio package update occurred.',
        'The sanitizer instruments the focused client/store sources, not the entire GUI/engine or its OS libraries. GUI ordering uses injected socket-free production-window tests.',
        'Linux keychain receipt does not qualify Windows/macOS keychains, keyring outages, power-loss durability or lost-owner recovery.',
        'Original radio software-reboot hang, actual6300 native privilege/hardware qualification, natural alignment/cold bypass, final packaged RF/stockAPD and independent release gates remain open.'],
    'artifact_archive':{'path':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive),'members':len(entries),'all_members_verified':True,
        'scope':'Diagnostic fixtures, source, compiler dependencies, licenses and receipts; not a signed radio package or byte-reproducibility claim.'},
    'evidence_sha256':hashes
}
(W/'tools/pd-waveform/SHARED-CREDENTIAL-RETIREMENT-QUALIFICATION.json').write_text(json.dumps(report,indent=2)+'\n')
plan_path=E/'production-completion-plan-20261113.json';plan=json.loads(plan_path.read_text())
plan['updated_utc']=report['updated_utc'];plan['last_goal_turn_classification']='progress: reproduced and fixed shared-window credential deletion, including same-token saves; final focused/full Linux build, four isolated mutations, sanitizer, real keychain and docs passed.'
plan['shared_credential_retirement']={'report':'tools/pd-waveform/SHARED-CREDENTIAL-RETIREMENT-QUALIFICATION.json','component_qualified':True,'same_token_revision_fence':True,'running_desktop_contains_fix':False,'interprocess_qualified':False,'production_ready':False}
plan['platform_builds']['macos']['state']='ARM64 failed before compile at ONNX HTTP404; Intel job134426966144 verified live in Build step at head239931ebf'
plan['next_action']='Preserve the new desktop shared-window retirement fix and its red/green receipts; complete separate-process credential coordination and platform qualification. Poll existing Intel macOS job134426966144/run44192984291; Windows and ARM macOS dependency download failures are not app-compile failures and must not be silently retried or replaced. No radio/RF/reboot changes while recovery/baseline steering is unanswered. Retain all P1-P10, actual6300 and deferred-SWR requirements.'
plan_path.write_text(json.dumps(plan,indent=2)+'\n')
print(json.dumps({'report':'SHARED-CREDENTIAL-RETIREMENT-QUALIFICATION.json','evidence_files':len(hashes),'artifact':report['artifact_archive']}))
