from pathlib import Path
import hashlib
import json
import os
import shlex
import subprocess

P=Path(__file__).resolve().parent
W=P.parent.parent/'aetherpd-source'
B=P.parent/'first-install-desktop-monitor/project'
destination=P/'isolated-mutants'
destination.mkdir(exist_ok=False)
environment=dict(os.environ,QT_QPA_PLATFORM='offscreen')
store=W/'src/core/TailnetShimTokenStore.cpp'
dialog=W/'src/gui/TailnetShimDialog.cpp'
source_hashes={str(file.relative_to(W)):hashlib.sha256(file.read_bytes()).hexdigest() for file in [store,dialog]}
targets=['tailnet_shim_dialog_test','tailnet_shim_client_test']
commands={target:subprocess.check_output(['ninja','-t','commands',target],cwd=B,text=True).splitlines() for target in targets}
store_object='CMakeFiles/tailnet_shim_test_credentials.dir/src/core/TailnetShimTokenStore.cpp.o'
dialog_object='CMakeFiles/tailnet_shim_dialog_test.dir/src/gui/TailnetShimDialog.cpp.o'
client_store_object='CMakeFiles/tailnet_shim_client_test.dir/src/core/TailnetShimTokenStore.cpp.o'
retire='TailnetShimTokenStore::clearIfCurrent(m_radioSerial, m_adminToken, m_credentialRevision);'
cases=[('ignore_token_value',store,'\n        || sessionTokens().value(keyFor(radioSerial, entry)) != expectedToken','',0,'tailnet_shim_client_test'),
       ('ignore_credential_revision',store,'\n        || revision(radioSerial, entry) != expectedRevision','',0,'tailnet_shim_dialog_test'),
       ('unconditional_signout_deletion',dialog,retire,'TailnetShimTokenStore::save(m_radioSerial, QString());',1,'tailnet_shim_dialog_test'),
       ('unconditional_login401_deletion',dialog,retire,'TailnetShimTokenStore::save(m_radioSerial, QString());',2,'tailnet_shim_dialog_test')]
results=[]
for name,source,needle,replacement,occurrence,target in cases:
    folder=destination/name
    folder.mkdir()
    text=source.read_text()
    if occurrence:
        assert text.count(needle)==2
        index=text.index(needle) if occurrence==1 else text.rindex(needle)
        text=text[:index]+replacement+text[index+len(needle):]
    else:
        assert text.count(needle)==1
        text=text.replace(needle,replacement)
    mutant_source=folder/source.name
    mutant_source.write_text(text)
    original_object=store_object if source==store else dialog_object
    command=next(line for line in commands['tailnet_shim_dialog_test'] if ' -o '+original_object+' ' in line)
    compile_args=shlex.split(command)
    if compile_args[0]=='ccache': compile_args=compile_args[1:]
    for flag,value in [('-o',str(folder/'mutant.o')),('-MF',str(folder/'mutant.d')),('-MT',str(folder/'mutant.o')),('-c',str(mutant_source))]:
        compile_args[compile_args.index(flag)+1]=value
    compile_args+=['-I',str(source.parent)]
    link_args=shlex.split(commands[target][-1])
    assert link_args[:2]==[':','&&'] and link_args[-2:]==['&&',':']
    link_args=link_args[2:-2]
    link_args=[arg for arg in link_args if not arg.startswith('-Wl,--dependency-file=')]
    replace_object=client_store_object if source==store and target=='tailnet_shim_client_test' else original_object
    assert link_args.count(replace_object)==1
    link_args[link_args.index(replace_object)]=str(folder/'mutant.o')
    binary=folder/'mutant-test'
    link_args[link_args.index('-o')+1]=str(binary)
    (folder/'commands.json').write_text(json.dumps({'compile':compile_args,'link':link_args},indent=2)+'\n')
    with (folder/'compile.log').open('w') as log:
        built=subprocess.run(compile_args,cwd=B,env=environment,stdout=log,stderr=subprocess.STDOUT)
    assert built.returncode==0, name+' compile'
    with (folder/'link.log').open('w') as log:
        linked=subprocess.run(link_args,cwd=B,env=environment,stdout=log,stderr=subprocess.STDOUT)
    assert linked.returncode==0, name+' link'
    with (folder/'test.log').open('w') as log:
        run=subprocess.run([str(binary)],cwd=B,env=environment,stdout=log,stderr=subprocess.STDOUT)
    failures=[line for line in (folder/'test.log').read_text().splitlines() if line.startswith('FAIL:')]
    result={'mutation':name,'target':target,'compile_exit':built.returncode,'link_exit':linked.returncode,'test_exit':run.returncode,'failures':failures}
    results.append(result)
    (destination/'results.json').write_text(json.dumps(results,indent=2)+'\n')
    print(json.dumps(result),flush=True)
    assert run.returncode!=0 and failures, name+' survived'
for name,expected in source_hashes.items(): assert hashlib.sha256((W/name).read_bytes()).hexdigest()==expected,name
(destination/'source-unchanged.json').write_text(json.dumps(source_hashes,indent=2)+'\n')
