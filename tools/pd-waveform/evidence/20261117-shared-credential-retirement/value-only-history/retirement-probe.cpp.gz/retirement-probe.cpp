#include "core/TailnetShimTokenStore.h"
#include <qt6keychain/keychain.h>
#include <QCoreApplication>
#include <QTimer>
#include <cstdio>

using AetherSDR::TailnetShimTokenStore;

int main(int argc, char** argv)
{
    QCoreApplication app(argc, argv);
    app.setApplicationName(QStringLiteral("AetherSDR"));
    if (argc != 5) { return 2; }
    const QString mode = QString::fromLocal8Bit(argv[1]);
    const QString id = QString::fromLocal8Bit(argv[2]);
    const QString expected = QString::fromLocal8Bit(argv[3]);
    const QString replacement = QString::fromLocal8Bit(argv[4]);
    if (!id.startsWith(QStringLiteral("aetherpd-shared-retirement-"))) { return 2; }
    const auto finish = [&app](bool ok) { std::puts(ok ? "pass" : "fail"); app.exit(ok ? 0 : 1); };
    QTimer::singleShot(10000, &app, [&app] { std::puts("operation_timeout"); app.exit(3); });
    if (mode == u"write" || mode == u"cleanup") {
        TailnetShimTokenStore::save(id, mode == u"cleanup" ? QString{} : replacement, &app,
            [finish](bool persisted, const QString&) { finish(persisted); });
    } else if (mode == u"read") {
        TailnetShimTokenStore::load(id, &app, [expected, finish](const QString& token) { finish(token == expected); });
    } else if (mode == u"refuse-stale") {
        TailnetShimTokenStore::load(id, &app, [&, expected, replacement, finish](const QString& held) {
            if (held != expected) { finish(false); return; }
            TailnetShimTokenStore::save(id, replacement, &app,
                [id, expected, finish](bool persisted, const QString&) {
                    finish(persisted && !TailnetShimTokenStore::clearIfCurrent(id, expected));
                });
        });
    } else if (mode == u"retire-current") {
        TailnetShimTokenStore::load(id, &app, [&, id, expected, finish](const QString& held) {
            if (held != expected || !TailnetShimTokenStore::clearIfCurrent(id, expected)) { finish(false); return; }
            auto* read = new QKeychain::ReadPasswordJob(QStringLiteral("AetherSDR"), &app);
            read->setKey(QStringLiteral("TailnetShim/AdminToken/") + id);
            read->setAutoDelete(true);
            QObject::connect(read, &QKeychain::Job::finished, &app, [read, finish](QKeychain::Job*) {
                finish(read->error() == QKeychain::EntryNotFound);
            });
            QTimer::singleShot(0, read, [read] { read->start(); });
        });
    } else if (mode == u"absent-direct") {
        auto* read = new QKeychain::ReadPasswordJob(QStringLiteral("AetherSDR"), &app);
        read->setKey(QStringLiteral("TailnetShim/AdminToken/") + id);
        read->setAutoDelete(true);
        QObject::connect(read, &QKeychain::Job::finished, &app, [read, finish](QKeychain::Job*) {
            finish(read->error() == QKeychain::EntryNotFound);
        });
        read->start();
    } else { return 2; }
    return app.exec();
}
